# PAE Bird engine — Linux CLI

This package contains the PAE Bird polynomial/calculus engine (plain Chez
Scheme — the same `.scm` sources the macOS app, the Windows app, and the
hosted PAE-API all run) with no GUI. There is no Linux desktop app yet;
this is CLI-only.

## 1. Get a `petite` + `petite.boot` pair

There's no prebuilt Linux Chez Scheme binary upstream, and `apt-get
install chezscheme` does not work on current Debian/Ubuntu (`chezscheme`
is a virtual package with no installation candidate). Build it from
source:

```sh
curl -LO https://github.com/cisco/ChezScheme/releases/download/v10.4.1/csv10.4.1.tar.gz
tar xzf csv10.4.1.tar.gz
cd csv10.4.1
./configure
make
```

This produces `petite` and `petite.boot` (threaded x86_64 Linux, `ta6le`,
by default) somewhere under the build tree — `find . -name petite -o -name
petite.boot` if the path isn't obvious. Copy both into this package's
`scm/` directory, or pass full paths on the command line below.

## 2. Run the engine

```sh
petite -q -b petite.boot --script scm/dispatcher.scm compute <command> <arg> <line>
```

Examples:

```sh
petite -q -b petite.boot --script scm/dispatcher.scm compute expand "" "(x+1)^2"
petite -q -b petite.boot --script scm/dispatcher.scm compute differentiate x "x^3+2x"
petite -q -b petite.boot --script scm/dispatcher.scm compute integrate x "3x^2"
```

`dispatcher.scm` also supports a batch `process <inputFile> <outputFile>`
mode and `worksheet`/`jsonworksheet` modes used by the GUI apps — see the
top-of-file comment in `scm/dispatcher.scm` for the full protocol, and
<https://paebird.com/commands.html> for the full `@:`-command reference.

## Status

CLI/engine only — no packaged binary, no Linux GUI app yet. See the
`math-edu-scheme` repo's `LINUX-RELEASE-PLAN.md` for the full Linux port
plan (desktop UI + packaging), and its `chez/LINUX.md` for the engine-only
doc this file mirrors.
