; RiemannSum.scm -- left/right/midpoint Riemann sums, calculus2.md's
; Phase 1 numerical-integration groundwork (the file itself flags
; numerical integration as a near-mandatory dependency for arc length/
; surface area/volume later in that same phase), plus the Midpoint Rule
; (Stewart Calculus 8th ed., p.312 -- theoremLibrary.scm's
; 'midpoint-rule citation). Trapezoidal rule and Simpson's rule are
; deliberately NOT here -- they aren't true Riemann sums (no single
; per-subinterval sample point), and are a separate file if wanted
; later.
;
; ---- Built entirely on sumExpr.scm's sum(...), not a new loop ----
; A left/right/midpoint Riemann sum for f(x) over [a,b] with n
; subintervals IS, structurally, exactly a finite sum: Δx=(b-a)/n,
; sample point at subinterval i is a+i*Δx for left (i=0..n-1) and right
; (i=1..n) -- the SAME formula both share, just a different index
; range -- or a+(i-1/2)*Δx for midpoint (i=1..n, same range as right,
; but the CENTER of each subinterval rather than an endpoint), term is
; f(sample)*Δx. This file's whole job is building that as a real
; <expr-sum> node (exprAst.scm) -- f(x) symbolically substituted to
; f(sample), NOT numerically evaluated yet, since i isn't a number
; until sumExpr.scm's evalSumNode sums over it -- and then handing it
; straight to evalSumNode, exactly the entry point sumcalc itself uses.
; No independent evaluation loop exists here at all.
;
; Depends on: exprAst.scm, diffExpr.scm (exprFreeVariables, and
; exprSubstitute -- added alongside this file specifically because
; nothing needed symbolic subtree substitution before this: evalExprAt
; only ever substitutes a concrete NUMBER, never another expression),
; sumExpr.scm (evalSumNode), limitExpr.scm (limitResultToString/
; numericResult, for riemannSumToString's formatting). Load after all
; four.

(define riemannSumSides '(left right midpoint))

; Picks an index-variable symbol that appears nowhere in f (neither as
; one of its free variables nor as the variable being integrated over
; itself, in case f happens to be a var-free constant) -- exprSubstitute
; is only hygienic for THIS caller because the index variable it
; introduces is provably fresh; see that function's own header note.
(define riemannIndexVarCandidates '(i k m p q))

(define (freshIndexVar f var)
    (let ((avoid (cons var (exprFreeVariables f))))
        (let try ((candidates riemannIndexVarCandidates))
            (cond
                ((null? candidates)
                    (error #f "riemannSum: couldn't find an index variable name f doesn't already use (tried i,k,m,p,q)" (exprToString f)))
                ((memv (car candidates) avoid) (try (cdr candidates)))
                ('t (car candidates))))))

; Builds the <expr-sum> node itself, unevaluated -- exprToString can
; render it as an ordinary sum(...) expression, or it can be handed to
; sumExpr.scm's evalSumNode directly (riemannSum below does exactly
; that). f is an ordinary exprAst tree in `var` (single-variable, same
; convention dcalc/icalc/eval already use); a/b are plain Scheme
; numbers (exact or inexact, same laxness intExpr.scm's own
; definiteIntegral already has -- not this file's job to be stricter);
; n is the subinterval count; side is 'left, 'right, or 'midpoint.
(define (riemannSumExpr f var a b n side)
    (cond
        ((not (memv side riemannSumSides))
            (error #f "riemannSumExpr: side must be 'left, 'right, or 'midpoint" side))
        ((not (and (integer? n) (exact? n) (> n 0)))
            (error #f "riemannSumExpr: n must be a positive exact integer (number of subintervals)" n))
        ((not (for-all (lambda (v) (eqv? v var)) (exprFreeVariables f)))
            (error #f "riemannSumExpr: f must depend only on the given variable" (exprToString f)))
        ('t
            (let* ((indexVar (freshIndexVar f var))
                   (deltaX (/ (- b a) n))
                   ; a+i*Δx for left/right; the Midpoint Rule
                   ; (theoremLibrary.scm's 'midpoint-rule) instead
                   ; samples the CENTER of each subinterval,
                   ; a+(i-1/2)*Δx, over the same i=1..n range right uses.
                   (sampleExpr (if (eqv? side 'midpoint)
                                   (makeExprAdd (makeExprNum a) (makeExprMul (makeExprNum deltaX) (makeExprSub (makeExprEvar indexVar) (makeExprNum 1/2))))
                                   (makeExprAdd (makeExprNum a) (makeExprMul (makeExprNum deltaX) (makeExprEvar indexVar)))))
                   (term (makeExprMul (exprSubstitute f var sampleExpr) (makeExprNum deltaX)))
                   (lowerIdx (if (eqv? side 'left) 0 1))
                   (upperIdx (if (eqv? side 'left) (- n 1) n)))
                (makeExprSum term indexVar (makeExprNum lowerIdx) (makeExprNum upperIdx))))))

(define (leftRiemannSumExpr f var a b n) (riemannSumExpr f var a b n 'left))
(define (rightRiemannSumExpr f var a b n) (riemannSumExpr f var a b n 'right))
(define (midpointRiemannSumExpr f var a b n) (riemannSumExpr f var a b n 'midpoint))

; ---- Evaluated entry points -- the ONLY place actual summation
;      happens, and it happens via sumExpr.scm's evalSumNode, not a
;      loop written in this file. ----
(define (riemannSum f var a b n side) (evalSumNode (riemannSumExpr f var a b n side)))
(define (leftRiemannSum f var a b n) (riemannSum f var a b n 'left))
(define (rightRiemannSum f var a b n) (riemannSum f var a b n 'right))
(define (midpointRiemannSum f var a b n) (riemannSum f var a b n 'midpoint))

; Formats the same way sumcalc/eval/etc. already do (limitExpr.scm's
; own exact-rational-vs-6-sig-fig-decimal convention).
(define (riemannSumToString f var a b n side) (limitResultToString (numericResult (riemannSum f var a b n side))))

; Picks f's own single variable rather than requiring the caller to
; name it, via diffExpr.scm's own exprInferredVariable (dedupes first --
; a bare exprFreeVariables list has a duplicate entry per occurrence,
; e.g. '(x x) for "x^3-6x", not one entry per distinct variable).
; riemannSumExpr already rejects f depending on more than one free
; variable, so the only new case here is turning exprInferredVariable's
; #f (2+ distinct variables) into a clear error instead of a silent
; #f passed on as if it were a variable name.
(define (riemannAutoVar f)
    (or (exprInferredVariable f)
        (error #f "riemann: f must depend on only one variable" (exprToString f))))
