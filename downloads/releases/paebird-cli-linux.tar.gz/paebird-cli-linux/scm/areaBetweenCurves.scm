; areaBetweenCurves.scm -- calculus2.md's Phase 0 backfill: area between
; two curves. Depends on: exprAst.scm, diffExpr.scm (exprIsPurePoly?),
; intExpr.scm (definiteIntegral), solvePoly.scm (solve), curveSketch.scm
; (parseAndSortSolutions, reused directly rather than re-derived -- same
; "parse solve()'s raw 'v = ...' strings into sorted, deduplicated real
; numbers" job this file also needs for finding where the two curves
; cross). Load this file after curveSketch.scm/intExpr.scm.
;
; ---- Why intersections matter, not just "integrate f-g" ----
; The area between two curves is NOT simply |definiteIntegral(f-g, a,
; b)| in general -- that would let a positive and a negative region
; cancel each other out before the absolute value is ever applied,
; silently undercounting whenever which curve is "on top" flips inside
; [a, b]. The correct approach: find every point in (a, b) where f and g
; actually cross (f-g=0), split [a, b] into subintervals at those
; points (f-g provably keeps one constant sign within each subinterval,
; by construction), and sum the ABSOLUTE VALUE of the definite integral
; over each subinterval separately.
;
; PURE-POLYNOMIAL f-g only, same restriction (and same reason -- solve()
; has no concept of a transcendental function) as curveSketch.scm's own
; differentiateAndSolve/this project's other intersection-finding code.

; Sums |definiteIntegral(diff, var, ., .)| over each consecutive pair in
; a sorted boundary list -- the shared core both arities of
; areaBetweenCurves below reduce to once they've each built their own
; boundary list.
(define (sumAbsAreaOverBoundaries diff var boundaries)
    (let loop ((bs boundaries) (total 0))
        (if (null? (cdr bs))
            total
            (loop (cdr bs) (+ total (abs (definiteIntegral diff var (car bs) (cadr bs))))))))

; Errors clearly if diff (f-g) isn't pure-polynomial; returns diff
; otherwise. Shared guard for both arities below.
(define (requirePurePolyDiff diff)
    (if (not (exprIsPurePoly? diff))
        (error #f "areaBetweenCurves: f-g involves a transcendental function -- intersection-finding only supports pure-polynomial functions, since solve() itself has no concept of those" diff)
        diff))

; Every point where f and g cross, as a sorted list of plain numbers
; (curveSketch.scm's own parseAndSortSolutions already discards complex/
; degree-0-special-case results -- see that file's own header for why).
(define (findIntersections diff var)
    (map car (parseAndSortSolutions (solve (string->list (string-append (exprToString diff) "=0"))))))

; Two arities:
;   (areaBetweenCurves f g var a b)  -- bounds given explicitly. Finds
;     any crossings STRICTLY INSIDE (a, b) and splits there, so a
;     mid-interval sign flip is still handled correctly rather than
;     silently cancelling out -- a caller who already knows the two
;     curves don't cross inside [a, b] pays nothing extra for this (zero
;     crossings found means zero extra splits, one definite integral).
;   (areaBetweenCurves f g var)      -- no bounds given: the region is
;     everything between two CONSECUTIVE crossings. Needs at least two
;     crossings to bound any region at all; reports a clear error
;     otherwise (zero or one crossing means the curves don't enclose a
;     finite region between them).
(define areaBetweenCurves
    (case-lambda
        ((f g var)
            (let* ((diff (requirePurePolyDiff (makeExprSub f g)))
                   (intersections (findIntersections diff var)))
                (if (< (length intersections) 2)
                    (error #f "areaBetweenCurves: fewer than two intersection points -- these curves don't enclose a bounded region" (list f g))
                    (sumAbsAreaOverBoundaries diff var intersections))))
        ((f g var a b)
            (let* ((diff (requirePurePolyDiff (makeExprSub f g)))
                   (crossings (filter (lambda (v) (and (> v a) (< v b))) (findIntersections diff var)))
                   (boundaries (append (list a) crossings (list b))))
                (sumAbsAreaOverBoundaries diff var boundaries)))))
