; Basic fraction arithmetic operations.
;
; Ported from ../basicmath.scm (MIT Scheme) to Chez Scheme.
; Changes from the original: reducefrac's #!optional f arg rewritten as
; case-lambda.

; Adds two fractions n1/d1 and n2/d2; returns result as (numerator denominator).
(define (addfrac n1 d1 n2 d2)
    (cond
        ((= d1 d2) (list (+ n1 n2) d2))
        ('t
            (set! n1 (* n1 d2))
            (set! n2 (* n2 d1))
            (set! d1 (* d1 d2))
            (set! n1 (+ n1 n2))
            (list n1 d1))))

; Reduces fraction n/d by trial division starting at f; returns (numerator denominator).
; Repeats the same divisor f until it no longer divides both, so repeated
; prime factors (e.g. 4/8 -> 2/4 -> 1/2) are fully squeezed out before f advances.
; Normalizes a negative d by flipping both signs first -- every existing
; caller already keeps d positive (Scheme's numerator/denominator on an
; exact rational always canonicalize that way), so this is a no-op for
; all of them; it only matters for expandParse.scm's division support,
; where a negative constant denominator (e.g. "x/(-2)") is possible.
; Without this, (>= f d) with a negative d returns immediately with the
; sign never normalized, e.g. reducefrac(6,-2) => (6 -2) instead of (-3 1).
;
; 2026-09-18: rewritten from trial division (f counting up from 2 until
; f>d, so O(value of d)) to a single gcd. Trial division made
; ms-from-str/exprSimplify take time proportional to a literal's
; DENOMINATOR VALUE -- 1/2^25 = 348ms, 1/2^29 = 5.6s, 1/2^31 = 22s -- which
; hung @:icalc's final simplify on any answer with a large power-of-2
; denominator (e.g. cos(x)^30). gcd gives the identical result (lowest
; terms, d>0) for every exact-integer input in O(log d). The 3-argument
; arity (formerly "start trial division at f") is kept only so existing
; call shapes still work; every real caller uses the 2-argument form, and
; f no longer matters. d=0 is returned unchanged, as before.
(define reducefrac
    (case-lambda
        ((n d) (reducefrac n d 2))
        ((n d f)
            (if (< d 0) (begin (set! n (- n)) (set! d (- d))))
            (if (= d 0)
                (list n d)
                (let ((g (gcd n d))) (list (/ n g) (/ d g)))))))

; Returns #t if two fraction values are numerically equal.
(define (eqfrac? f1 f2)
    (= f1 f2))

; Subtracts fraction n2/d2 from n1/d1; returns result as (numerator
; denominator). Reuses addfrac against the negated second numerator
; rather than duplicating its cross-multiplication logic.
(define (subfrac n1 d1 n2 d2)
    (addfrac n1 d1 (- n2) d2))

; Multiplies two fractions n1/d1 and n2/d2; returns result as
; (numerator denominator).
(define (mulfrac n1 d1 n2 d2)
    (list (* n1 n2) (* d1 d2)))

; Divides fraction n1/d1 by n2/d2 (multiplies by the reciprocal);
; returns result as (numerator denominator). Caller is responsible for
; ensuring n2 is nonzero.
(define (divfrac n1 d1 n2 d2)
    (list (* n1 d2) (* d1 n2)))
