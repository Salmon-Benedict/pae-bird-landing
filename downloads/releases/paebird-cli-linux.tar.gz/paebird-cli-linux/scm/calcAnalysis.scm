; calcAnalysis.scm -- calculus2.md's Phase 0: small Calc I backfill items
; that compose existing exprAst/diffExpr/limitExpr/solvePoly machinery
; rather than needing new architecture. Depends on: exprAst.scm,
; diffExpr.scm, limitExpr.scm (evalExprAt/limitExpr/limitResultToString/
; numericResult), solvePoly.scm (solve, ratToString), curveSketch.scm
; (differentiateAndSolve's own pattern is followed, not called directly).
; Load this file after limitExpr.scm/curveSketch.scm.

; ---- Continuity / discontinuity classification at a point ----
;
; Classifies f's behavior at x=a: continuous, or one of the three
; standard discontinuity types (removable/jump/infinite). Composes
; limitExpr's existing two-sided/one-sided resolution and evalExprAt --
; no new limit-resolution logic at all.
;
; The "jump discontinuity" branch is logically complete but currently
; UNVERIFIED against a real example: constructing one needs a function
; with two different finite one-sided limits, which in ordinary Calc I
; textbooks means a piecewise definition or an absolute value -- neither
; exists in this engine's grammar at all, and the two indirect
; constructions tried while building this (sqrt(x^2)/x and
; 1/(1+exp(1/x)), both genuine jumps mathematically) came back
; 'undefined on BOTH sides -- limitExpr's own resolution strategies
; (factor-and-cancel/rationalization/named-trig/L'Hopital) don't cover
; either shape. Falls through to the honest "discontinuous... limit
; does not exist" case for both today, which is not wrong, just less
; precise than "jump" would be. Revisit once limitExpr grows either
; absolute-value support or a resolution strategy that covers one of
; these shapes.
;
; "Removable" vs "continuous" are distinguished by comparing f(a)
; against the two-sided limit -- reuses limitExpr.scm's OWN numericResult/
; limitResultToString round-trip (rather than a hand-rolled float
; comparison) so an inexact/decimal value compares the same rounded way
; a limit result already does elsewhere in this engine (6 significant
; figures, matching evaluateTrig's own established convention) instead
; of risking a false mismatch from raw floating-point noise.
(define (classifyContinuity f var a)
    (let* ((fAtA (evalExprAt f var a))
           (twoSided (limitExpr f var a 'two-sided)))
        (cond
            ((memv (car twoSided) '(exact decimal))
                (if (and (not (eqv? fAtA 'undefined))
                         (string=? (limitResultToString (numericResult fAtA)) (limitResultToString twoSided)))
                    (string-append "continuous at " (symbol->string var) " = " (ratOrDecimalToString a))
                    (string-append "removable discontinuity at " (symbol->string var) " = " (ratOrDecimalToString a)
                        " (the limit is " (limitResultToString twoSided) ", but "
                        (if (eqv? fAtA 'undefined)
                            (string-append (symbol->string var) "=" (ratOrDecimalToString a) " is not in the domain")
                            (string-append "f(" (ratOrDecimalToString a) ") = " (limitResultToString (numericResult fAtA)))) ")")))
            ((eqv? (car twoSided) 'infinity)
                (string-append "infinite discontinuity at " (symbol->string var) " = " (ratOrDecimalToString a) " (vertical asymptote)"))
            ('t
                (let ((leftLim (limitExpr f var a 'left)) (rightLim (limitExpr f var a 'right)))
                    (cond
                        ((or (eqv? (car leftLim) 'infinity) (eqv? (car rightLim) 'infinity))
                            (string-append "infinite discontinuity at " (symbol->string var) " = " (ratOrDecimalToString a) " (vertical asymptote)"))
                        ((and (memv (car leftLim) '(exact decimal)) (memv (car rightLim) '(exact decimal)))
                            (string-append "jump discontinuity at " (symbol->string var) " = " (ratOrDecimalToString a)
                                " (left limit " (limitResultToString leftLim) ", right limit " (limitResultToString rightLim) ")"))
                        ('t (string-append "discontinuous at " (symbol->string var) " = " (ratOrDecimalToString a) " (limit does not exist)"))))))))

; Renders a's own value the same way solvePoly.scm's ratToString does
; for an exact rational (e.g. "3", "1/2"), falling back to a plain
; number->string for the (rare, since limit points are almost always
; entered as exact rationals) inexact case -- a itself is a caller-
; supplied point, not a computed result, so it doesn't need
; numericResult's 6-sig-fig rounding treatment.
(define (ratOrDecimalToString a) (if (exact? a) (ratToString a) (number->string a)))

; ---- Linear approximation (tangent-line approximation) ----
;
; Estimates f(x0) via the tangent line to f at x=a: L(x) = f(a) +
; f'(a)*(x-a), evaluated at x=x0. Reuses diffExpr (for f') and
; evalExprAt (for f(a), f'(a)) directly -- no new evaluation logic;
; Scheme's own numeric-tower contagion (exact+inexact -> inexact)
; handles the case where f(a) or f'(a) comes back an inexact decimal
; (e.g. f involves sin/cos/exp/ln at a non-special-angle point) the
; same way every other arithmetic composition in this engine already
; does, with no special-casing needed here.
(define (linearApprox f var a x0)
    (let* ((fPrime (diffExpr f var))
           (fAtA (evalExprAt f var a))
           (fPrimeAtA (evalExprAt fPrime var a)))
        (if (or (eqv? fAtA 'undefined) (eqv? fPrimeAtA 'undefined))
            'undefined
            (+ fAtA (* fPrimeAtA (- x0 a))))))

; String-rendered entry point, same "exact if exact, else a rounded
; 6-sig-fig decimal, else the literal string 'undefined'" convention
; evalExprAtToString itself already establishes for the analogous
; single-point-evaluation case.
(define (linearApproxToString f var a x0)
    (let ((v (linearApprox f var a x0)))
        (if (eqv? v 'undefined) "undefined" (limitResultToString (numericResult v)))))

; ---- Mean Value Theorem / Rolle's Theorem ----
;
; Finds every c in the open interval (a, b) with f'(c) = (f(b)-f(a))/(b-a)
; -- there can be more than one, e.g. a cubic satisfies MVT at two
; distinct points over a suitable interval. Rolle's Theorem is not a
; separate algorithm here: it's exactly the slope=0 case, which falls
; out naturally whenever f(a)=f(b) (the formula above already computes
; slope=0 in that case) -- the wording just names it "Rolle's Theorem"
; instead of "the Mean Value Theorem" when that happens, matching how a
; textbook itself treats Rolle's as MVT's special case, not a distinct
; fact to re-derive.
;
; PURE-POLYNOMIAL f' only, same restriction (and same reason --
; solve() has no concept of a transcendental function) as
; curveSketch.scm's own differentiateAndSolve, whose exact pattern
; (differentiate, build an equation string, hand it to solve()) this
; follows directly rather than reusing that function itself (the target
; here is a caller-supplied slope, not always literally "=0", and the
; result needs interval-membership filtering critical-point analysis
; doesn't need at all).
(define (meanValueTheorem f var a b)
    (let ((fA (evalExprAt f var a)) (fB (evalExprAt f var b)))
        (if (or (eqv? fA 'undefined) (eqv? fB 'undefined))
            (error #f "meanValueTheorem: f is undefined at one of the given endpoints" (list a b))
            (let* ((slope (/ (- fB fA) (- b a)))
                   (fPrime (diffExpr f var)))
                (if (not (exprIsPurePoly? fPrime))
                    (error #f "meanValueTheorem: the derivative involves a transcendental function (sin/cos/exp/ln/sqrt) -- only supports pure-polynomial functions, since solve() itself has no concept of those" f)
                    (let* ((eqStr (string-append (exprToString fPrime) "=" (ratToString slope)))
                           (rawSolutions (solve (string->list eqStr)))
                           (candidates (parseAndSortSolutions rawSolutions))
                           (inInterval (filter (lambda (p) (and (> (car p) a) (< (car p) b))) candidates))
                           (theoremName (if (= slope 0) "Rolle's Theorem" "the Mean Value Theorem")))
                        (if (null? inInterval)
                            (list (string-append "no c in (" (ratOrDecimalToString a) ", " (ratOrDecimalToString b)
                                ") satisfies " theoremName " for this f (f'(" (symbol->string var) ")="
                                (ratOrDecimalToString slope) " has no root strictly inside the interval)"))
                            (map (lambda (p) (string-append (symbol->string var) " = " (cdr p)
                                     " (" theoremName ")"))
                                inInterval))))))))
