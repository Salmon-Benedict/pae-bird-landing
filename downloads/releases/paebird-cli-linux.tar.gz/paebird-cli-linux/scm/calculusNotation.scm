; calculusNotation.scm -- differentiation/integration without a command
; (CALCULUS-AUTODETECT-PLAN.md). Recognizes three notations directly in
; the raw input line, in ANY active @: mode, the same "detect a
; glyph/pattern in the raw string and rewrite/dispatch before
; tokenization ever runs" architecture already proven five times over in
; this codebase (factorial.scm's substituteFactorials, matrix.scm's
; substituteMatrixExpressions/isMatrixResultLine?, expandParse.scm's
; rewriteSqrtCalls, superscriptFormat.scm/subscriptFormat.scm's
; fromSuperscriptNotation/fromSubscriptNotation, setOperations.scm's
; Unicode operator glyphs):
;
;   - Leibniz differentiation: "d/dx(expr)" -- variable always explicit.
;   - Prime differentiation: "(expr)'" -- variable inferred
;     (exprInferredVariable, diffExpr.scm); chained/repeated primes
;     ("(x^3)''") fall out for free via recursion.
;   - Integration: "∫expr dx" (indefinite, matches icalc's own
;     output convention exactly -- no "+C", same as icalc today) or
;     "∫(0,2)expr dx" / "∫₀²expr dx" (definite, matches defint's
;     own output convention exactly) -- the trailing "d<var>" always
;     supplies the variable, so (unlike the differentiation cases)
;     integration never needs inference at all.
;
; Depends on: exprAst.scm (exprToString), exprParse.scm (exprParse),
; diffExpr.scm (diffExpr, exprInferredVariable, exprFreeVariables,
; dedupVariables), intExpr.scm (intExpr, definiteIntegral),
; mathHelp.scm (var?), equationVariants.scm (findStringCharPos). Load
; this file after all of those (i.e. after intExpr.scm).
;
; Every function here operates on the WHOLE line (not embedded within a
; larger expression the way matrix literals can be) -- a match must
; consume the entire string, nothing before or after. A malformed but
; clearly-intended-as-this-notation input (e.g. unbalanced parens) falls
; through to ordinary command dispatch, which will almost always then
; fail its own parse too, surfacing a generic (if less specific) error --
; the same non-guarantee isMatrixResultLine? already accepts for its own
; edge cases.

; ---- Shared string-scanning helpers (this codebase's own established
;      per-file convention: a small paren-matching scanner duplicated
;      locally rather than shared -- see radicalRationalSolve.scm's
;      findMatchingParen/superscriptFormat.scm's
;      findMatchingParenForSuperscript, both the same shape) ----

(define (findMatchingParenIndex s idx)
    (let loop ((i (+ idx 1)) (depth 1))
        (cond
            ((>= i (string-length s)) #f)
            ((eqv? (string-ref s i) #\() (loop (+ i 1) (+ depth 1)))
            ((eqv? (string-ref s i) #\))
                (if (= depth 1) i (loop (+ i 1) (- depth 1))))
            ('t (loop (+ i 1) depth)))))

; Index just past the run of digit/"-"/"/" characters starting at idx
; (a plain integer or exact-rational numeral, e.g. "2", "-3", "2/3") --
; used for both halves of a "_<num>^<num>" definite-integral bound.
(define (scanNumeralRun s idx)
    (let loop ((i idx))
        (if (and (< i (string-length s))
                 (let ((c (string-ref s i))) (or (char-numeric? c) (eqv? c #\-) (eqv? c #\/))))
            (loop (+ i 1))
            i)))

; ---- Definite-integral bounds, right after the leading ∫ ----
; Two accepted shapes (see this file's own header): "(<num>,<num>)", or
; "_<num>^<num>" -- the ASCII text "₀²" becomes once
; fromSubscriptNotation/fromSuperscriptNotation (already run earlier in
; applyCommand's own chain, dispatcher.scm) convert it, so by the time
; this ever runs, both a freshly-typed "(0,2)" and a pasted-back "₀²"
; look the same: plain ASCII. Returns (list lowerNum upperNum
; nextIndex), or #f if neither shape is present at startIdx (an
; indefinite integral).
(define (parseIntegralBounds s startIdx)
    (cond
        ((and (< startIdx (string-length s)) (eqv? (string-ref s startIdx) #\())
            (let ((closeIdx (findMatchingParenIndex s startIdx)))
                (and closeIdx
                     (let* ((inner (substring s (+ startIdx 1) closeIdx))
                            (commaIdx (findStringCharPos #\, inner 0)))
                         (and commaIdx
                              (let ((lower (string->number (substring inner 0 commaIdx)))
                                    (upper (string->number (substring inner (+ commaIdx 1) (string-length inner)))))
                                  (and lower upper (list lower upper (+ closeIdx 1)))))))))
        ((and (< startIdx (string-length s)) (eqv? (string-ref s startIdx) #\_))
            (let* ((afterUnderscore (+ startIdx 1))
                   (caretIdx (scanNumeralRun s afterUnderscore)))
                (and (> caretIdx afterUnderscore)
                     (< caretIdx (string-length s)) (eqv? (string-ref s caretIdx) #\^)
                     (let* ((lowerStr (substring s afterUnderscore caretIdx))
                            (afterCaret (+ caretIdx 1))
                            (upperEnd (scanNumeralRun s afterCaret)))
                         (and (> upperEnd afterCaret)
                              (let ((lower (string->number lowerStr))
                                    (upper (string->number (substring s afterCaret upperEnd))))
                                  (and lower upper (list lower upper upperEnd))))))))
        ('t #f)))

; "∫expr dx" (indefinite) or "∫(0,2)expr dx"/"∫₀²expr dx" (definite).
; #f if the line doesn't start with ∫ or doesn't end in a bare "d<var>"
; suffix; otherwise the computed answer string.
(define (evalIntegralNotation line)
    (and (> (string-length line) 0)
         (eqv? (string-ref line 0) #\∫)
         (let* ((afterSign 1)
                (bounds (parseIntegralBounds line afterSign))
                (exprStart (if bounds (caddr bounds) afterSign))
                (len (string-length line)))
             (and (> len (+ exprStart 2))
                  (eqv? (string-ref line (- len 2)) #\d)
                  (var? (string->symbol (substring line (- len 1) len)))
                  (let* ((var (string->symbol (substring line (- len 1) len)))
                         (exprStr (substring line exprStart (- len 2)))
                         (parsed (exprParse (string->list exprStr))))
                      (if bounds
                          (number->string (definiteIntegral parsed var (car bounds) (cadr bounds)))
                          (exprToString (intExpr parsed var))))))))

; "d/dx(expr)" -- variable always explicit, no inference needed. #f
; unless the WHOLE line is exactly this shape (the trailing ")" must be
; the line's last character).
(define (evalLeibnizNotation line)
    (and (> (string-length line) 5)
         (string=? (substring line 0 3) "d/d")
         (var? (string->symbol (substring line 3 4)))
         (eqv? (string-ref line 4) #\()
         (let ((closeIdx (findMatchingParenIndex line 4)))
             (and closeIdx
                  (= closeIdx (- (string-length line) 1))
                  (let* ((var (string->symbol (substring line 3 4)))
                         (inner (substring line 5 closeIdx)))
                      (exprToString (diffExpr (exprParse (string->list inner)) var)))))))

; Parses str into an exprAst node, differentiating once (with the
; variable inferred via exprInferredVariable) for every trailing "'"
; str itself ends in -- this recursion is what makes chained primes
; ("(x^3)''", "((x^3)')'") work for free: each trailing "'" just means
; "diffExpr once more, on top of whatever the rest means." Errors
; clearly (does not guess) if a given level's expression has more than
; one free variable -- same "ask, don't guess" convention @:physics's
; ambiguity handling already established this session.
(define (parsePrimeOperand str)
    (if (and (> (string-length str) 0) (eqv? (string-ref str (- (string-length str) 1)) #\'))
        (let* ((inner (substring str 0 (- (string-length str) 1)))
               (innerParsed (parsePrimeOperand inner))
               (v (exprInferredVariable innerParsed)))
            (if (not v)
                (error #f "differentiate: expression has more than one variable -- use d/d<var>(...) to say which one"
                    (dedupVariables (exprFreeVariables innerParsed)))
                (diffExpr innerParsed v)))
        (exprParse (string->list str))))

; "(expr)'" (or a bare "x'", or chained "(x^3)''") -- #f unless the
; line ends in "'" at all.
(define (evalPrimeNotation line)
    (and (> (string-length line) 0)
         (eqv? (string-ref line (- (string-length line) 1)) #\')
         (exprToString (parsePrimeOperand line))))

; Top-level entry point (dispatcher.scm's applyCommand): #f if line
; matches none of the three notations (ordinary command dispatch should
; continue as today), otherwise the computed answer string. Checked
; regardless of which @: mode is active, the same way matrix/factorial
; notation already is -- see this file's own header.
(define (tryCalculusNotation line)
    (or (evalIntegralNotation line)
        (evalLeibnizNotation line)
        (evalPrimeNotation line)))
