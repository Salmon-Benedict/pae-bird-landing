; chooser3.scm -- when a product being Integrated By Parts has THREE OR
; MORE factors (after flattening any nesting of mul nodes), decide which
; grouping of factors to treat as u vs dv, trying more than the single
; literal two-way split the AST's own left-associative parsing happens
; to produce.
;
; Motivating case: x^2*sin(x)*cos(x) parses as (x^2*sin(x))*cos(x) --
; integrationByParts.scm's own ordinary 2-factor LIATE (pickUDv) only
; ever sees the literal two factors the AST handed it (x^2*sin(x) and
; cos(x)) and never gets the chance to notice that grouping
; sin(x)*cos(x) TOGETHER as dv (leaving x^2 alone as u) is the split
; that actually converges -- confirmed live: without this, that case
; sent IBP into an ever-growing, non-terminating remainder instead.
;
; chooser3Candidates returns an ORDERED LIST of (u . dv) pairs to try,
; best guess first. integrationByParts.scm's own ibpFirstStep tries them
; in order (via ibpStep) until one doesn't make the problem BIGGER than
; it started (exprSize, below) -- falling back to the first candidate's
; result if every candidate grows the problem, since handing SOMETHING
; back is better than giving up here; intExpr.scm's own iteration loop
; (intExprIBPRound) gets the final say regardless, the same as any other
; IBP round -- it may simplify or otherwise resolve what chooser3 handed
; back even if that particular round's remainder wasn't the smallest
; possible choice.
;
; Depends on (forward references, resolved at call time -- same
; reasoning as every other cross-file dependency in this session's own
; work): trigPowerIntegrals.scm (trigPowerInfo), limitExpr.scm
; (exprEqual?), exprAst.scm's smart constructors and accessors.
; integrationByParts.scm calls INTO this file (chooser3Candidates) --
; another genuine two-way-shaped dependency, same pattern as its other
; three (intExpr.scm, trigPowerIntegrals.scm for liateCategory).

; Plain node count, opaque to the numeric-coefficient folding
; numericCoeffAndSize (below) does -- used for a subtree neither that
; function nor exprSize itself tries to look inside any further (an
; apply/pow/add/sub/... node, or numericCoeffAndSize's own div-by-zero
; safety fallback).
(define (rawExprSize e)
    (case (exprKind e)
        ((num evar) 1)
        ((neg) (+ 1 (rawExprSize (exprNegOperand e))))
        ((add) (+ 1 (rawExprSize (exprAddLeft e)) (rawExprSize (exprAddRight e))))
        ((sub) (+ 1 (rawExprSize (exprSubLeft e)) (rawExprSize (exprSubRight e))))
        ((mul) (+ 1 (rawExprSize (exprMulLeft e)) (rawExprSize (exprMulRight e))))
        ((div) (+ 1 (rawExprSize (exprDivNumer e)) (rawExprSize (exprDivDenom e))))
        ((pow) (+ 1 (rawExprSize (exprPowBase e)) (rawExprSize (exprPowExponent e))))
        ((apply) (+ 1 (rawExprSize (exprApplyArg e))))
        ((sum) (+ 1 (rawExprSize (exprSumTerm e)) (rawExprSize (exprSumLower e)) (rawExprSize (exprSumUpper e))))
        ((factorial) (+ 1 (rawExprSize (exprFactorialOperand e))))))

; (cons combinedNumericCoeff residualSize) -- walks e through mul/div/
; neg (transparent to a numeric coefficient, combining any numeric
; LITERAL factors found along the way arithmetically); everything else
; (apply, pow, add, sub, evar, sum, factorial) is opaque, counted via
; its own rawExprSize. Exists because exprSimplify's own recursion only
; combines constants within a maximal PURE-POLYNOMIAL subtree (no apply
; node anywhere) -- it does NOT reach across an apply-containing
; boundary. Confirmed live as a real bug: ibpStep's own
; "-cos(x)^2/2*2*x" (v=-cos(x)^2/2 times du=2x) sizes at 11 raw nodes
; even AFTER exprSimplify, because the "1/2" and "2" sit on opposite
; sides of cos(x)^2 and never get combined -- even though the true
; combined form (-cos(x)^2*x, "1/2*2" cancelling to 1) is only 7. That
; inflated size was making ibpTryChooser3Candidates's own check reject
; a genuinely smaller, correct candidate (x^2*sin(x)*cos(x)'s cluster
; grouping) and fall through toward far worse ones instead.
(define (numericCoeffAndSize e)
    (case (exprKind e)
        ((num) (cons (exprNumValue e) 0))
        ((neg) (let ((inner (numericCoeffAndSize (exprNegOperand e)))) (cons (- (car inner)) (cdr inner))))
        ((mul)
            (let ((l (numericCoeffAndSize (exprMulLeft e))) (r (numericCoeffAndSize (exprMulRight e))))
                (cons (* (car l) (car r)) (+ (cdr l) (cdr r) 1))))
        ((div)
            (let ((n (numericCoeffAndSize (exprDivNumer e))) (d (numericCoeffAndSize (exprDivDenom e))))
                (if (= (car d) 0)
                    (cons 1 (rawExprSize e))
                    (cons (/ (car n) (car d)) (+ (cdr n) (cdr d) 1)))))
        ; NOTE: must be `else`, not `('t ...)` -- unlike cond, case
        ; treats a quoted symbol as a DATUM to match against, not a
        ; catch-all test (this codebase's own established gotcha,
        ; swept and fixed everywhere else it appeared this session and
        ; prior ones -- see e.g. diffExpr.scm's diffExprApply). A `'t`
        ; clause here would silently return an unspecified value for
        ; every unmatched exprKind (add, sub, apply, pow, evar, ...)
        ; instead of falling through to this opaque-subtree case.
        (else (cons 1 (rawExprSize e)))))

; The size measure ibpTryChooser3Candidates actually compares: residual
; (opaque-subtree) size, plus 1 for the combined numeric coefficient
; itself, but only when that coefficient isn't exactly 1 -- matching
; how a literal 1 factor would normally just vanish via makeExprMul's
; own smart constructor, so a "1/2*2" pair that cancels to 1 correctly
; costs nothing here, the way it would if exprSimplify had combined it.
(define (exprSize e)
    (let ((cs (numericCoeffAndSize e)))
        (+ (cdr cs) (if (= (car cs) 1) 0 1))))

; Flattens a chain of mul nodes (any nesting, e.g. left-associative
; (a*b)*c or right-associative a*(b*c)) into a flat list of factors, in
; left-to-right order.
(define (flattenMulFactors e)
    (if (eqv? (exprKind e) 'mul)
        (append (flattenMulFactors (exprMulLeft e)) (flattenMulFactors (exprMulRight e)))
        (list e)))

; (cons coeff coreOrFalse) for a SINGLE factor (never itself a mul node
; -- flattenMulFactors already broke those apart): pulls a numeric
; coefficient out of a bare literal, a negation, or a division by a
; purely-numeric denominator, leaving coreOrFalse as whatever's left
; (or #f if the factor WAS purely numeric, nothing left over). Anything
; else (apply, pow, add, sub, evar, sum, factorial, or a division whose
; denominator isn't purely numeric) is left untouched: (cons 1 e).
;
; Exists because ibpStep's own output can leave a trig-power factor
; wrapped in a division like this (v="-cos(x)^2/2"), and
; partitionTrigFactors's trigPowerInfo call only recognizes a BARE
; func(arg)^k shape, not one wrapped in "/2" -- confirmed live as a
; real gap: x^2*sin(x)*cos(x)'s round-2 remainder flattens to
; [cos(x)^2/2, 2, x], and without this, cos(x)^2/2 never gets
; recognized as a trig factor at all, so trigClusterCandidate always
; comes back empty and chooser3 falls through to per-factor candidates
; that don't converge.
(define (stripNumericCoeff e)
    (case (exprKind e)
        ((num) (cons (exprNumValue e) #f))
        ((neg) (let ((inner (stripNumericCoeff (exprNegOperand e)))) (cons (- (car inner)) (cdr inner))))
        ((div)
            (let ((n (stripNumericCoeff (exprDivNumer e))) (d (stripNumericCoeff (exprDivDenom e))))
                (if (or (cdr d) (= (car d) 0))
                    (cons 1 e)
                    (cons (/ (car n) (car d)) (cdr n)))))
        (else (cons 1 e))))

; Strips a numeric coefficient out of EACH factor (stripNumericCoeff),
; combines them all into one, and returns (cons combinedCoeff
; coreFactors) -- coreFactors being each factor's coefficient-free
; residual, in original order, dropping any factor that was purely
; numeric (its whole contribution folded into combinedCoeff instead).
(define (normalizeFactors factors)
    (let loop ((remaining factors) (coeff 1) (core '()))
        (if (null? remaining)
            (cons coeff (reverse core))
            (let ((stripped (stripNumericCoeff (car remaining))))
                (loop (cdr remaining) (* coeff (car stripped))
                    (if (cdr stripped) (cons (cdr stripped) core) core))))))

; flattenMulFactors, then normalizeFactors, then reintroduces the
; combined coefficient (if not exactly 1) as its own leading factor --
; a clean factor list with numeric coefficients collected out of any
; individual factor's division/negation, so partitionTrigFactors can
; recognize a trig-power shape even when ibpStep's own construction
; left one wrapped in a numeric division or negation.
(define (normalizedFlattenMulFactors e)
    (let* ((normalized (normalizeFactors (flattenMulFactors e)))
           (coeff (car normalized)) (core (cdr normalized)))
        (if (= coeff 1) core (cons (makeExprNum coeff) core))))

; Multiplies a nonempty list of factors back into a single expr (right
; fold via makeExprMul -- order doesn't matter for the math, multiplication
; is commutative, and this file never relies on a specific resulting shape).
(define (multiplyFactors factors)
    (if (null? (cdr factors))
        (car factors)
        (makeExprMul (car factors) (multiplyFactors (cdr factors)))))

; Splits factors into (trigFactors . otherFactors) by whether
; trigPowerInfo (trigPowerIntegrals.scm) recognizes each one.
(define (partitionTrigFactors factors)
    (let loop ((remaining factors) (trig '()) (other '()))
        (if (null? remaining)
            (cons (reverse trig) (reverse other))
            (if (trigPowerInfo (car remaining))
                (loop (cdr remaining) (cons (car remaining) trig) other)
                (loop (cdr remaining) trig (cons (car remaining) other))))))

; Whether every trigPowerInfo result in the (nonempty) list shares the
; same family (sin/cos, tan/sec, or cot/csc) and the same argument --
; i.e. their product is itself directly integrable via
; trigPowerIntegrals.scm's own product hook, one recognizable cluster,
; not a mix of unrelated trig functions.
(define (trigCluster? infos)
    (and (pair? infos) (car infos)
         (or
             ; Exactly two first-power sin/cos factors, ARGUMENTS MAY DIFFER
             ; (sin(2x)*cos(3x)*x): trigPowerIntegrals.scm's product-to-sum
             ; hook integrates that pair directly, so it's a cluster too.
             ; Non-linear arguments are rejected there, downstream, exactly
             ; like any other candidate that fails to resolve.
             (and (= (length infos) 2) (cadr infos)
                  (= (cadr (car infos)) 1) (= (cadr (cadr infos)) 1)
                  (memv (car (car infos)) '(sin cos)) (memv (car (cadr infos)) '(sin cos)))
         (let* ((first (car infos))
                (fam (cond ((memv (car first) '(sin cos)) '(sin cos))
                           ((memv (car first) '(tan sec)) '(tan sec))
                           ('t '(cot csc))))
                (arg (caddr first)))
             (let loop ((rest (cdr infos)))
                 (cond
                     ((null? rest) 't)
                     ((not (car rest)) #f)
                     ((not (memv (car (car rest)) fam)) #f)
                     ((not (exprEqual? (caddr (car rest)) arg)) #f)
                     ('t (loop (cdr rest)))))))))

; factors with the one at index i removed.
(define (listExcludingIndex factors i)
    (let loop ((rest factors) (idx 0) (acc '()))
        (cond
            ((null? rest) (reverse acc))
            ((= idx i) (loop (cdr rest) (+ idx 1) acc))
            ('t (loop (cdr rest) (+ idx 1) (cons (car rest) acc))))))

; General fallback candidates: for EACH factor, one candidate with that
; single factor as dv and the product of everything else as u. Used
; when the factors don't split cleanly into "one same-family trig
; cluster, plus everything else" (the common textbook case
; trigClusterCandidate below targets) -- e.g. a genuinely mixed
; sin(x)*tan(x)*x case, out of scope for a clean cluster grouping but
; still worth trying SOMETHING factor-by-factor rather than giving up.
(define (perFactorDvCandidates factors)
    (map (lambda (i) (cons (multiplyFactors (listExcludingIndex factors i)) (list-ref factors i)))
         (range (length factors))))

; The one candidate this file exists for: if every trig-recognizable
; factor among the list forms a single same-family, same-argument
; cluster, AND there's at least one non-trig factor too, group all the
; trig factors together as dv and everything else as u. Returns a
; 1-element list, or '() if that shape doesn't apply here.
(define (trigClusterCandidate factors)
    (let* ((parts (partitionTrigFactors factors))
           (trigFactors (car parts)) (otherFactors (cdr parts)))
        (if (and (pair? trigFactors) (pair? otherFactors) (trigCluster? (map trigPowerInfo trigFactors)))
            (list (cons (multiplyFactors otherFactors) (multiplyFactors trigFactors)))
            '())))

; The first n elements of lst (or all of it, if shorter).
(define (takeAtMost lst n)
    (cond
        ((= n 0) '())
        ((null? lst) '())
        ('t (cons (car lst) (takeAtMost (cdr lst) (- n 1))))))

; Ordered list of (u . dv) candidates for a flattened factor list
; (length>=3), best guess first: the trig-cluster grouping (if it
; applies), then the general per-factor fallbacks -- capped at 4 total.
; The cap matters: for a genuinely unsolvable mixed case (e.g.
; sin(x)*cos(x)*tan(x) -- no clean cluster, since tan isn't in sin/cos's
; family), EVERY candidate here ends up rejected by
; integrationByParts.scm's own size check, and the resulting fallback
; remainder can itself flatten into a 3+-factor product needing ANOTHER
; chooser3 call next round -- confirmed live as a real performance
; regression: with an uncapped candidate list, this compounded across
; maxIByPRounds's up to 8 rounds into over a minute of work before
; finally (correctly) giving up. Capping bounds the per-round cost
; without changing the OUTCOME for any case that actually resolves --
; the cluster candidate (when one exists) is always first and always
; kept.
(define (chooser3Candidates factors)
    (takeAtMost (append (trigClusterCandidate factors) (perFactorDvCandidates factors)) 4))
