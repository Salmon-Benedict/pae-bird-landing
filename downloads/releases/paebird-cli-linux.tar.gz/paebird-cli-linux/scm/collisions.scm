; collisions.scm -- physics module Phase 4: Linear Momentum, Collisions
; (project_physics_module.md's Mechanics curriculum order, item 4).
; Five independent, single-equation commands, each a thin wrapper over
; physicsSolve.scm's solvePhysicsCommand -- deliberately NOT bundled
; into one multi-equation system the way power (Phase 3) was.
;
; Why not bundled: momentum/impulse/the impulse-momentum theorem share
; variables and COULD be combined into one system the way power's
; p=w/t + p=f*v was, but power's own 2-equation, 5-variable system
; already turned out to have 2 of 10 "give 3, solve 2" combinations be
; genuinely underdetermined (found by hand-tracing, not by accident --
; see physicsSolve.scm/workEnergy.scm's own comments). A combined
; momentum/impulse system would be 3 equations over 7 variables --
; C(7,4)=35 combinations to hand-verify, a meaningfully larger and more
; error-prone version of the same risk, for relations that (unlike
; power's two equations, routinely used together) are normally asked as
; independent problem types in intro courses anyway. Every command below
; is its own single equation instead -- give N-1 knowns, solve the last
; one, always solvable, nothing to hand-verify, matching the already-
; proven zero-branching-risk shape of newton/gravpe/work.
;
; Depends on: physicsUnits.scm (dimMomentum and the shared role table),
; physicsSolve.scm (solvePhysicsCommand). Load this file after
; physicsSolve.scm.
;
; Variable letters (all single lowercase, per mathHelp.scm's var?
; constraint): q=momentum, j=impulse, n=second object's mass, x/y=second
; object's initial/final velocity. m/u/v are already established
; (Newton's law, SUVAT) and mean the same thing here -- mass, and one
; object's initial/final velocity.

; ---- Momentum: q = m*v ----
(define momentumVars '(q m v))
(define momentumEquations (list "q=m*v"))

; ---- Impulse: j = f*t ----
(define impulseVars '(j f t))
(define impulseEquations (list "j=f*t"))

; ---- Impulse-momentum theorem: j = m*v - m*u ----
; Reuses SUVAT's own u/v (initial/final velocity) convention directly.
; Linear in every variable -- never branches.
(define impulsemomentumVars '(j m u v))
(define impulsemomentumEquations (list "j=m*v-m*u"))

; ---- General 1D two-body collision: m*u+n*x = m*v+n*y ----
; Momentum conservation (object 1: mass m, initial u, final v; object 2:
; mass n, initial x, final y). Every term is a product of exactly two
; variables, so solving for any one given the other five is always
; linear -- never branches, no combination to verify. Deliberately
; covers momentum conservation alone, not the elastic-collision-specific
; closed form (solving momentum + kinetic-energy conservation
; simultaneously for both final velocities) -- that 2-equation
; derivation is out of scope here, same kind of boundary as work's own
; angled-force case or circular motion's banking angles.
(define collisionVars '(m n u v x y))
(define collisionEquations (list "m*u+n*x=m*v+n*y"))

; ---- Perfectly inelastic collision: m*u+n*x = (m+n)*v ----
; Objects stick together into one shared final velocity -- reuses v for
; it (fine: each command has its own semantic context, and
; physicsRoleTable only constrains dimension, not exact meaning, same as
; a/f/m already meaning slightly different specific quantities across
; suvat/newton/circular). Linear -- never branches.
(define inelasticVars '(m n u v x))
(define inelasticEquations (list "m*u+n*x=(m+n)*v"))
