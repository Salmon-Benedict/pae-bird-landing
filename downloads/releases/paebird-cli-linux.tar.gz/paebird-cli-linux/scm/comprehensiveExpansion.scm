; comprehensiveExpansion.scm -- logarithm expansion rules (product/
; quotient/power rules for a bare log(...)/ln(...)/log_N(...) call).
; Requires helperS.scm, mathHelp.scm, basicmath.scm, chemistry.scm
; (findSubstring), PolyStoSymbol.scm, simplify.scm, expandParse.scm
; (expand), equationVariants.scm (stripSpaces, findStringCharPos,
; matchingParen) to be loaded first.
;
; Ported from ../comprehensiveExpansion.scm (MIT Scheme) to Chez Scheme.
; No MIT-isms found in this file (no #!optional, no error calls, no
; record types, no sort/every/any) -- a direct, unchanged port.
;
; ---- Why this is new math, not a port ----
; This corresponds to the C++ engine's expandComprehensive and its
; helpers (expandLogarithmic, expandExponential, expandTrigonometric,
; simplifyRadicals, finalAlgebraicSimplification). Reading all of them
; directly in vendor/cpp/MathSymbol.cpp found that four of the five are
; complete no-ops -- each is literally `string result = expr; return
; result;` with a comment describing rules it never applies (e.g.
; expandLogarithmic's comment says "log(ab) = log(a) + log(b)..." but
; the function body never does this). The only real step in
; expandComprehensive was calling the existing polynomial-expansion
; pipeline when the input contains parentheses -- already exactly what
; this engine's own expand() does. So there was no existing behavior to
; port or fix here; this file is genuine new simplification logic, not
; verified against a C++ oracle the way every other file in this
; project's gap-closing work has been.
;
; ---- Scope ----
; Logarithm expansion (product/quotient/power rules) is implemented in
; full: it's a standard, well-defined textbook topic with an
; unambiguous correct answer, so it's worth doing properly. Trigonometric
; identity expansion (sum/difference formulas, double angle, Pythagorean
; identity, etc.) is deliberately NOT attempted: unlike log rules,
; there's no single canonical "the" expansion for a general trig
; expression, and getting subtle sign/identity errors wrong with no
; reference implementation to catch them is a real risk -- left as an
; open gap rather than guessed at.
;
; expandLogarithmic only handles a BARE log(...)/ln(...)/log_N(...)
; call as the entire input expression, not one embedded inside a larger
; sum -- matching the scope of a standalone "expand this logarithmic
; expression" exercise, not general mixed-expression simplification.
;
; ---- History: the exponential-expansion and top-level-dispatcher
;      pieces that used to live in this file ----
; This file originally also had an expandExponential (the power-of-a-
; product/quotient rule, (ab)^n = a^n*b^n) and an expandComprehensive
; top-level dispatcher combining it with expandLogarithmic and a
; fallback to plain expand(), reachable via a dedicated "@:expandc"
; command. Both were removed: expandExponential had gone stale relative
; to the engine's own expand(), which by this point already handles
; "(2*x)^3" -- style input directly and produces a MORE fully-
; simplified result ("8x^3") than expandExponential's own hand-rolled
; distribution ever did ("2^3*x^3", the leading power left unevaluated)
; -- so there was nothing left worth salvaging there once plain
; expand() had caught up. expandComprehensive's fallback branch (for
; input that was neither a bare log call nor a bare power-of-a-product)
; called plain expand() directly, which doesn't understand function-
; call syntax at all -- confirmed live to silently GARBLE non-
; polynomial input rather than erroring, e.g. "sin(x)+cos(x)" came back
; as "insx+cosx". That same garbling turned out to be reachable through
; plain @:expand too (not just @:expandc) for any log/ln input, e.g.
; "log(x*y)" -> "gloxy" -- so folding log detection directly into
; dispatcher.scm's "expand" case (routing to expandLogarithmic instead
; of plain expand() whenever a log call is present anywhere in the
; line) fixed a real, pre-existing bug in @:expand itself, not just
; replaced @:expandc's own scope. See dispatcher.scm's applyCommand.

; ---- Shared: top-level (paren-respecting) product/quotient splitting ----

; Splits a product/quotient chain like "x^2*y/z" into
; ((#\* . "x^2") (#\* . "y") (#\/ . "z")) -- the operator paired with
; each chunk is the one that INTRODUCED it (the first chunk is always
; paired with #\*, matching "implicitly multiplied into the product").
(define (splitTopLevelFactors s)
    (let loop ((i 0) (start 0) (depth 0) (pendingOp #\*) (acc '()))
        (cond
            ((>= i (string-length s)) (reverse (cons (cons pendingOp (substring s start (string-length s))) acc)))
            ((eqv? (string-ref s i) #\() (loop (+ i 1) start (+ depth 1) pendingOp acc))
            ((eqv? (string-ref s i) #\)) (loop (+ i 1) start (- depth 1) pendingOp acc))
            ((and (= depth 0) (memv (string-ref s i) (list #\* #\/)))
                (loop (+ i 1) (+ i 1) depth (string-ref s i) (cons (cons pendingOp (substring s start i)) acc)))
            ('t (loop (+ i 1) start depth pendingOp acc)))))

; (cons base exponent) for a top-level '^' in s (respecting parens), or
; #f if there isn't one.
(define (splitTopLevelPower s)
    (let loop ((i 0) (depth 0))
        (cond
            ((>= i (string-length s)) #f)
            ((eqv? (string-ref s i) #\() (loop (+ i 1) (+ depth 1)))
            ((eqv? (string-ref s i) #\)) (loop (+ i 1) (- depth 1)))
            ((and (= depth 0) (eqv? (string-ref s i) #\^))
                (cons (substring s 0 i) (substring s (+ i 1) (string-length s))))
            ('t (loop (+ i 1) depth)))))

(define (stripOuterParens s)
    (if (and (> (string-length s) 1)
             (eqv? (string-ref s 0) #\()
             (eqv? (string-ref s (- (string-length s) 1)) #\))
             (= (matchingParen s 0) (- (string-length s) 1)))
        (substring s 1 (- (string-length s) 1))
        s))

; ---- Logarithm expansion ----

; Locates a bare "ln(", "log_N(", or "log(" call at the start of s,
; returning (list prefixString argStartIdx), or #f if none is found.
(define (findLogCall s)
    (let ((lnIdx (findSubstring s "ln(" 0)))
        (if lnIdx
            (list (substring s lnIdx (+ lnIdx 2)) (+ lnIdx 3))
            (let ((underscoreIdx (findSubstring s "log_" 0)))
                (if underscoreIdx
                    (let ((openIdx (findStringCharPos #\( s underscoreIdx)))
                        (list (substring s underscoreIdx openIdx) (+ openIdx 1)))
                    (let ((logIdx (findSubstring s "log(" 0)))
                        (if logIdx
                            (list (substring s logIdx (+ logIdx 3)) (+ logIdx 4))
                            #f)))))))

; Expands a single factor into "logPrefix(factor)", or "exp*logPrefix
; (base)" if the factor itself is a power (the power rule).
(define (expandLogFactor factor logPrefix)
    (let* ((clean (stripOuterParens factor)) (pw (splitTopLevelPower clean)))
        (if pw
            (string-append (cdr pw) "*" logPrefix "(" (car pw) ")")
            (string-append logPrefix "(" clean ")"))))

; Expands the argument of a single log/ln call using the product rule
; (log(ab)=log(a)+log(b)), quotient rule (log(a/b)=log(a)-log(b)), and
; power rule (log(a^n)=n*log(a)) -- applied per top-level factor, so a
; combination like "x^2*y" expands fully to "2*log(x) + log(y)" in one
; pass (each factor's own power rule fires independently).
(define (expandLogArgument argString logPrefix)
    (let ((factors (splitTopLevelFactors (stripOuterParens argString))))
        (if (= (length factors) 1)
            (expandLogFactor (cdar factors) logPrefix)
            (apply string-append
                (let loop ((fs factors) (first #t) (acc '()))
                    (if (null? fs)
                        (reverse acc)
                        (let* ((op (caar fs)) (term (expandLogFactor (cdar fs) logPrefix))
                               (piece (cond (first term) ((eqv? op #\/) (string-append " - " term)) ('t (string-append " + " term)))))
                            (loop (cdr fs) #f (cons piece acc)))))))))

; Expands a bare logarithmic expression, e.g.
; (expandLogarithmic (string->list "log(x*y)")) -> "log(x) + log(y)"
; (expandLogarithmic (string->list "ln(x^3/y)")) -> "3*ln(x) - ln(y)"
; Returns expr unchanged if it isn't a single bare log/ln/log_N call
; spanning the whole input (see file header for scope) -- dispatcher.scm
; relies on this "unchanged, not garbled" fallback directly: it routes
; here whenever findLogCall finds a match ANYWHERE in the line, even an
; embedded one this function's own narrower scope doesn't expand, since
; that's still strictly better than handing log/ln syntax to plain
; expand() (which doesn't understand it at all).
(define (expandLogarithmic exprChars)
    (let* ((expr (stripSpaces (list->string exprChars)))
           (call (findLogCall expr)))
        (if (not call)
            expr
            (let* ((prefix (car call)) (argStart (cadr call))
                   (openIdx (- argStart 1))
                   (closeIdx (matchingParen expr openIdx))
                   (argument (substring expr argStart closeIdx))
                   (prefixStart (- argStart (string-length prefix) 1))
                   (before (substring expr 0 prefixStart))
                   (after (substring expr (+ closeIdx 1) (string-length expr))))
                (if (or (> (string-length before) 0) (> (string-length after) 0))
                    expr
                    (expandLogArgument argument prefix))))))
