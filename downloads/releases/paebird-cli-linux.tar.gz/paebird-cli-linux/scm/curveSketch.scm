; curveSketch.scm -- calculus.md's Phase 3: critical points, concavity/
; inflection points, and increasing/decreasing intervals. "A natural,
; mostly-mechanical extension once Phase 1 exists" per the plan -- reuses
; diffExpr for f'/f'' and the EXISTING solve() (solvePoly.scm) for
; finding their roots, rather than building a new equation-solving engine.
;
; Depends on: diffExpr.scm (diffExpr, exprIsPurePoly?), limitExpr.scm
; (evalExprAt, for sign-testing between boundary points), solvePoly.scm
; (solve), equationVariants.scm/chemistry.scm (findStringCharPos,
; findSubstring -- for parsing solve()'s own output strings back into
; numbers).
;
; ---- Scope ----
; PURE-POLYNOMIAL f only. solve() (solvePoly.scm) has no concept of a
; transcendental function at all -- it operates on <poly> term lists via
; the rational-root theorem/quadratic formula, nothing more general.
; diffExpr(f) or diffExpr(diffExpr(f)) landing on anything containing
; sin/cos/exp/ln/sqrt is a clear, explicit error here, not a silent wrong
; answer -- critical-point analysis for e.g. f(x)=x+sin(x) is out of
; scope, the same restriction the rest of this Phase 3 slice inherits
; from solve() itself, not something this file works around.
;
; ---- solve()'s own output grammar, parsed back into numbers ----
; Every solve() result is "v = <value>", where <value> is one of (see
; solvePoly.scm's solveLinear/solveQuadraticRational/
; solveQuadraticIrrational/solveQuadraticComplex/formatSignedTerm):
;   - a plain rational: "2", "-3/4"
;   - a symbolic irrational: "[realPart +/- ][coeff]√radicand" (realPart
;     omitted when 0; coeff's magnitude omitted from the string when 1,
;     with spaces around the +/- separator exactly when realPart isn't
;     omitted)
;   - a complex value ("...i") -- not a usable real critical/inflection
;     point, filtered out rather than erroring: a function having some
;     complex-only stationary points is completely ordinary (e.g.
;     f(x)=x^3+x has only x=0 as a REAL critical point).
;   - "No solution" / "All real numbers are solutions" (solveDegree0,
;     when f' or f'' is itself a nonzero or zero constant) -- also
;     filtered out (no isolated critical/inflection points either way).

; Parses one "v = ..." string into a real number (possibly inexact, for
; an irrational root -- see parseRadicalValue), or #f if it's complex or
; one of the degree-0 special-case strings (no "=" at all).
(define (parseSolutionValue solutionStr)
    (let ((eqIdx (findStringCharPos #\= solutionStr 0)))
        (if (not eqIdx)
            #f
            (let ((valueStr (substring solutionStr (+ eqIdx 2) (string-length solutionStr))))
                (cond
                    ((findSubstring valueStr "i" 0) #f)
                    ((findSubstring valueStr "√" 0) (parseRadicalValue valueStr))
                    ('t (string->number valueStr)))))))

; valueStr matches formatSignedTerm's own grammar (solvePoly.scm):
; [realPart" + "|" - "][coeff]√radicand, coeff's magnitude prefix absent
; when it's 1. sqrt(radicand) is genuinely irrational here (extractSquareFactor
; already pulled out any perfect-square factor before solvePoly.scm ever
; built this string), so the result is unavoidably inexact.
(define (parseRadicalValue valueStr)
    (let* ((radicalIdx (findSubstring valueStr "√" 0))
           (radicand (string->number (substring valueStr (+ radicalIdx 1) (string-length valueStr))))
           (beforeRadical (substring valueStr 0 radicalIdx)))
        (call-with-values
            (lambda () (splitRealPartAndCoeff beforeRadical))
            (lambda (realPart coeff)
                (+ realPart (* coeff (sqrt (exact->inexact radicand))))))))

; beforeRadical is everything before the "√" -- "", "-", a bare magnitude
; ("2", "-2"), or a realPart followed by " + "/" - " and then a bare
; magnitude. Returns (values realPart signedCoeff).
(define (splitRealPartAndCoeff beforeRadical)
    (let ((plusIdx (findSubstring beforeRadical " + " 0))
          (minusIdx (findSubstring beforeRadical " - " 0)))
        (cond
            (plusIdx
                (values (string->number (substring beforeRadical 0 plusIdx))
                        (parseSignedCoeffPrefix (substring beforeRadical (+ plusIdx 3) (string-length beforeRadical)))))
            (minusIdx
                (values (string->number (substring beforeRadical 0 minusIdx))
                        (- (parseSignedCoeffPrefix (substring beforeRadical (+ minusIdx 3) (string-length beforeRadical))))))
            ('t (values 0 (parseSignedCoeffPrefix beforeRadical))))))

(define (parseSignedCoeffPrefix prefix)
    (cond
        ((string=? prefix "") 1)
        ((string=? prefix "-") -1)
        ('t (string->number prefix))))

(define (solutionDisplayValue s) (substring s (+ (findStringCharPos #\= s 0) 2) (string-length s)))

; ---- Derivative + solve pipeline ----

; Differentiates f w.r.t. var, verifies the result is pure-polynomial
; (errors clearly otherwise -- see this file's own scope note), and
; solves THAT =0 via the existing solve().
(define (differentiateAndSolve f var)
    (let ((fPrime (diffExpr f var)))
        (if (not (exprIsPurePoly? fPrime))
            (error #f "curveSketch: the derivative involves a transcendental function (sin/cos/exp/ln/sqrt) -- critical/inflection point solving only supports pure-polynomial functions, since solve() itself has no concept of those" f)
            (values fPrime (solve (string->list (string-append (exprToString fPrime) "=0")))))))

; Parses and filters solve()'s raw output into a sorted, deduplicated
; list of (numericValue . displayString) pairs -- displayString keeps
; solve()'s own exact rendering ("√2" etc.) for output; numericValue
; (possibly inexact) is only used internally for ordering/sign-testing.
(define solutionEpsilon 1/1000000)

(define (insertUniqueByValue pair acc)
    (if (exists (lambda (p) (< (abs (- (car p) (car pair))) solutionEpsilon)) acc)
        acc
        (cons pair acc)))

; A raw solve() line that isn't "x = value" and isn't the identically-
; zero-derivative sentinel (checked separately, upstream, by
; identicallyZeroDerivative? -- see that function's own comment) means
; solve() gave up on some root entirely, e.g. "(no further rational
; roots found for: ...)" for a cubic-or-higher factor with no rational
; root. Silently dropping that line used to make @:critpoints/
; @:inflection/@:mvt return an EMPTY result for such a function instead
; of the correct (partial-or-total) answer -- confirmed live: a degree-4
; polynomial whose derivative is an unsolvable cubic gave back nothing
; at all, no error either. Erroring here instead turns that into a
; clear, honest "can't find every root" rather than a silently wrong
; (empty) one.
(define (parseAndSortSolutions rawSolutions)
    (let loop ((rest rawSolutions) (acc '()))
        (cond
            ((null? rest) (sort (lambda (a b) (< (car a) (car b))) acc))
            ('t
                (let ((v (parseSolutionValue (car rest))))
                    (cond
                        (v (loop (cdr rest) (insertUniqueByValue (cons v (solutionDisplayValue (car rest))) acc)))
                        ; "No solution" is a definitive result (verified no
                        ; real roots exist -- e.g. a derivative like x^2+1),
                        ; not a give-up -- an empty critical-point list is
                        ; the CORRECT answer here, same as "All real numbers
                        ; are solutions" above.
                        ((member (car rest) '("All real numbers are solutions" "No solution")) (loop (cdr rest) acc))
                        ('t (error #f "curveSketch: solve() couldn't find every root of the derivative -- refusing to report a partial/empty result" (car rest)))))))))

; ---- Sign-testing between boundary points ----
;
; Same exact-rational-epsilon nudge limitExpr.scm's tryOneSidedAsymptote
; already uses for one-sided limits, not a float.
(define intervalTestOffset 1/10)

; boundaryValues is a sorted, deduplicated list of numbers. Returns
; (length boundaryValues)+1 test points: before the first, between each
; consecutive pair (the midpoint if the gap is too small for the fixed
; offset to stay strictly inside it), and after the last.
(define (intervalTestPoints boundaryValues)
    (if (null? boundaryValues)
        (list 0)
        (cons (- (car boundaryValues) intervalTestOffset)
              (let loop ((vals boundaryValues))
                  (if (null? (cdr vals))
                      (list (+ (car vals) intervalTestOffset))
                      (let* ((a (car vals)) (b (cadr vals)) (gap (- b a))
                             (mid (if (< gap (* 2 intervalTestOffset)) (/ (+ a b) 2) (+ a intervalTestOffset))))
                          (cons mid (loop (cdr vals)))))))))

; A NON-identically-zero polynomial only has finitely many roots, so
; SOME candidate here must read nonzero -- used only when boundaryPairs is
; empty (a single interval spanning the whole real line, so there's no
; neighboring interval a wider search could wrongly cross into). Needed
; because f2 can have a real root that ISN'T in boundaryPairs at all:
; analyzeConcavity's genuine-inflection filter deliberately excludes a
; non-sign-changing root of f'' (e.g. f''(x)=12x^2 for f(x)=x^4 has a root
; at 0 that never changes sign), but the naive single fixed probe point 0
; used to land exactly on that excluded root and read a false zero sign --
; concavity(x^4) came back "concave down on (-infinity, infinity)", the
; OPPOSITE of correct. (The genuinely-identically-zero case, f2=0 for
; every x, is ruled out by the caller before describeIntervals is ever
; invoked -- see analyzeMonotonicity/analyzeConcavity's identicallyZero?
; check below.)
(define (findNonzeroSignOnRealLine f2 var)
    (let try ((candidates '(0 1 -1 2 -2 3 -3 1/2 -1/2)))
        (if (null? candidates)
            (error #f "describeIntervals: every sampled point reads exactly 0 for a polynomial that isn't identically zero -- shouldn't happen" f2)
            (let ((s (evalExprAt f2 var (car candidates))))
                (if (= s 0) (try (cdr candidates)) s)))))

; f2 is the exprAst to sign-test (f' for increasing/decreasing, f'' for
; concavity); boundaryPairs is a sorted, deduped (value . display) list.
(define (describeIntervals f2 var boundaryPairs posLabel negLabel)
    (if (null? boundaryPairs)
        (list (string-append (if (> (findNonzeroSignOnRealLine f2 var) 0) posLabel negLabel) " on (-infinity, infinity)"))
        (let* ((testPoints (intervalTestPoints (map car boundaryPairs)))
               (boundaryDisplays (map cdr boundaryPairs))
               (lowerLabels (cons "-infinity" boundaryDisplays))
               (upperLabels (append boundaryDisplays (list "infinity"))))
            (map (lambda (testPoint lowerLabel upperLabel)
                     (let ((sign (evalExprAt f2 var testPoint)))
                         (string-append (if (> sign 0) posLabel negLabel) " on (" lowerLabel ", " upperLabel ")")))
                 testPoints lowerLabels upperLabels))))

; ---- Classification ----

; Second-derivative test, falling back to the first-derivative test when
; f''(c)=0 (inconclusive).
(define (classifyByFirstDerivativeTest fPrime var c)
    (let ((before (evalExprAt fPrime var (- c intervalTestOffset)))
          (after (evalExprAt fPrime var (+ c intervalTestOffset))))
        (cond
            ((and (> before 0) (< after 0)) "local maximum")
            ((and (< before 0) (> after 0)) "local minimum")
            ('t "neither (first-derivative test inconclusive)"))))

(define (classifyCriticalPoints fPrime fDoublePrime var criticalPairs)
    (map (lambda (pair)
             (let* ((c (car pair)) (disp (cdr pair)) (secondDerivAtC (evalExprAt fDoublePrime var c)))
                 (string-append "x = " disp ": "
                     (cond
                         ((> secondDerivAtC 0) "local minimum")
                         ((< secondDerivAtC 0) "local maximum")
                         ('t (classifyByFirstDerivativeTest fPrime var c))))))
         criticalPairs))

; A root of f'' is only a genuine inflection point if concavity actually
; CHANGES sign across it (e.g. f''(x)=x^4 has a root at 0 but stays
; non-negative throughout -- no sign change, no inflection).
(define (filterGenuineInflectionPoints fDoublePrime var candidatePairs)
    (filter (lambda (pair)
                (let ((before (evalExprAt fDoublePrime var (- (car pair) intervalTestOffset)))
                      (after (evalExprAt fDoublePrime var (+ (car pair) intervalTestOffset))))
                    (or (and (> before 0) (< after 0)) (and (< before 0) (> after 0)))))
            candidatePairs))

; ---- Public entry points ----

; solveDegree0 (solvePoly.scm) emits exactly this string when f'/f'' is a
; ZERO constant -- i.e. identically zero for every x, not just zero at
; isolated points. Checked against the RAW (pre-parseAndSortSolutions)
; solve() output, since parseAndSortSolutions already discards it (it has
; no "=" to parse a numeric value from) -- describeIntervals's own
; empty-boundary-list case can't otherwise tell "f2 is 0 everywhere" apart
; from "f2 happens to have no genuine boundary but isn't 0 everywhere"
; (e.g. concavity(x^4) below) purely from an empty list.
(define (identicallyZeroDerivative? rawSolutions)
    (and (member "All real numbers are solutions" rawSolutions) 't))

; Critical points, each classified as a local maximum/minimum (or
; "neither" if even the first-derivative test can't tell -- e.g. a
; saddle-shaped stationary point like x^3 at x=0).
(define (analyzeCriticalPoints f var)
    (call-with-values
        (lambda () (differentiateAndSolve f var))
        (lambda (fPrime rawSolutions)
            (let ((fDoublePrime (diffExpr fPrime var)))
                (classifyCriticalPoints fPrime fDoublePrime var (parseAndSortSolutions rawSolutions))))))

; Increasing/decreasing intervals (sign of f'). A constant function (f'
; identically 0, e.g. f(x)=5) is neither increasing nor decreasing --
; describeIntervals's sign test (> sign 0) has no zero case and would
; otherwise mislabel it "decreasing" for every constant function.
(define (analyzeMonotonicity f var)
    (call-with-values
        (lambda () (differentiateAndSolve f var))
        (lambda (fPrime rawSolutions)
            (if (identicallyZeroDerivative? rawSolutions)
                (list "constant on (-infinity, infinity)")
                (describeIntervals fPrime var (parseAndSortSolutions rawSolutions) "increasing" "decreasing")))))

; Genuine (sign-changing) inflection points.
(define (analyzeInflectionPoints f var)
    (let ((fPrime (diffExpr f var)))
        (call-with-values
            (lambda () (differentiateAndSolve fPrime var))
            (lambda (fDoublePrime rawSolutions)
                (map (lambda (pair) (string-append "x = " (cdr pair) ": inflection point"))
                     (filterGenuineInflectionPoints fDoublePrime var (parseAndSortSolutions rawSolutions)))))))

; Concave-up/concave-down intervals (sign of f'', between genuine
; inflection points only -- a non-sign-changing root of f'' doesn't
; split an interval). f'' identically 0 (e.g. f(x)=5, or any linear
; function) has no concavity at all, same reasoning as analyzeMonotonicity
; above -- checked first so it's never confused with the DIFFERENT empty-
; boundary case where f'' isn't identically zero but simply has no
; sign-changing root (e.g. f(x)=x^4: f''=12x^2 touches zero at x=0 without
; changing sign, which is a real, isolated root that findNonzeroSignOnRealLine
; must route around, not "f'' is 0 everywhere").
(define (analyzeConcavity f var)
    (let ((fPrime (diffExpr f var)))
        (call-with-values
            (lambda () (differentiateAndSolve fPrime var))
            (lambda (fDoublePrime rawSolutions)
                (if (identicallyZeroDerivative? rawSolutions)
                    (list "no concavity (f'' = 0 everywhere) on (-infinity, infinity)")
                    (let ((genuine (filterGenuineInflectionPoints fDoublePrime var (parseAndSortSolutions rawSolutions))))
                        (describeIntervals fDoublePrime var genuine "concave up" "concave down")))))))

; Full summary, in calculus.md's own Phase 3 ordering: critical points,
; monotonicity, inflection points, concavity.
(define (sketchCurve f var)
    (append (analyzeCriticalPoints f var)
            (analyzeMonotonicity f var)
            (analyzeInflectionPoints f var)
            (analyzeConcavity f var)))
