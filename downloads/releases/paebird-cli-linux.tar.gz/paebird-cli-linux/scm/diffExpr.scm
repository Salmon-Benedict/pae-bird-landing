; diffExpr.scm -- symbolic differentiation over exprAst.scm's AST. This is
; calculus.md's Phase 1.
;
; Depends on: exprAst.scm, exprParse.scm, exprSimplify.scm (exprSimplify,
; used by this file's own public diffExpr entry point below -- moved to
; its own file 2026-08-15 so it's a nameable step other control flow,
; e.g. intExpr.scm's IBP loop, can call out to explicitly).
;
; ---- diffExprRaw: rule application only ----
; Structural recursion per calculus.md's Phase 1 rule table, using
; exprAst.scm's smart constructors throughout -- so ×0/×1/+0 identities,
; double negation, and literal constant-folding are already eliminated as
; the derivative tree is built, not left for a later pass to clean up
; (see exprAst.scm's own header for why that matters: L'Hopital's rule and
; second derivatives both feed a diffExpr output back in as a new diffExpr
; input, and structural pattern-matching there needs a canonical enough
; shape to actually recognize e.g. "this is a literal constant").
;
; Rule table (u, v are subexpressions; u', v' their derivatives):
;   add/sub  -> sum rule, term-by-term
;   neg      -> negate the derivative
;   mul      -> product rule: u'v + uv'
;   div      -> quotient rule: (u'v - uv') / v^2
;   pow      -> constant exponent (exprNum? exponent): generalized power
;               rule with chain rule, n * u^(n-1) * u'. No restriction to
;               integer n here (unlike SICP's Exercise 2.56) -- the power
;               rule holds for any real/rational n, and exprNum already
;               holds general exact rationals, so x^(1/2) differentiates
;               correctly via this same branch without needing the
;               separate sqrt case at all.
;            -> constant base (exprNum? base), variable exponent (a^u):
;               a^u * ln(a) * u'
;            -> variable base AND variable exponent (u^v, e.g. x^x): out
;               of scope per calculus.md (needs logarithmic
;               differentiation) -- raises a clear error rather than
;               silently returning a wrong answer.
;   apply    -> table-driven chain rule, f(u) -> f'(u) * u' (or f'(u)/...
;               -- see each case below, matching calculus.md's own table
;               exactly so the derivativeGoldenTable.scm entries this was
;               checked against stay traceable back to that source)

(define (diffExprRaw e var)
    (case (exprKind e)
        ((num) (makeExprNum 0))
        ((evar) (if (eqv? (exprEvarName e) var) (makeExprNum 1) (makeExprNum 0)))
        ((add) (makeExprAdd (diffExprRaw (exprAddLeft e) var) (diffExprRaw (exprAddRight e) var)))
        ((sub) (makeExprSub (diffExprRaw (exprSubLeft e) var) (diffExprRaw (exprSubRight e) var)))
        ((neg) (makeExprNeg (diffExprRaw (exprNegOperand e) var)))
        ((mul) (diffExprMul e var))
        ((div) (diffExprDiv e var))
        ((pow) (diffExprPow e var))
        ((apply) (diffExprApply e var))
        ; sum(...) (exprAst.scm/sumExpr.scm) -- differentiating a
        ; summation (Leibniz's rule for differentiating under the sum
        ; sign) is out of scope here, same posture as diffExprPow's
        ; u^v case above: a clear error, not a silently wrong answer.
        ((sum) (error #f "diffExprRaw: differentiating a summation expression isn't supported" e))
        ; operand! -- discrete factorial has no elementary derivative
        ; (needs the Gamma function -- out of scope, same posture as
        ; the sum(...) case just above).
        ((factorial) (error #f "diffExprRaw: differentiating a factorial expression isn't supported" e))))

; Product rule: u'v + uv'.
(define (diffExprMul e var)
    (let ((u (exprMulLeft e)) (v (exprMulRight e)))
        (makeExprAdd
            (makeExprMul (diffExprRaw u var) v)
            (makeExprMul u (diffExprRaw v var)))))

; Quotient rule: (u'v - uv') / v^2.
(define (diffExprDiv e var)
    (let ((u (exprDivNumer e)) (v (exprDivDenom e)))
        (makeExprDiv
            (makeExprSub (makeExprMul (diffExprRaw u var) v) (makeExprMul u (diffExprRaw v var)))
            (makeExprPow v (makeExprNum 2)))))

(define (diffExprPow e var)
    (let ((base (exprPowBase e)) (exponent (exprPowExponent e)))
        (cond
            ; n * u^(n-1) * u'
            ((exprNum? exponent)
                (makeExprMul
                    (makeExprMul exponent (makeExprPow base (makeExprSub exponent (makeExprNum 1))))
                    (diffExprRaw base var)))
            ; a^u * ln(a) * u'
            ((exprNum? base)
                (makeExprMul
                    (makeExprMul (makeExprPow base exponent) (makeExprApplyChecked 'ln base))
                    (diffExprRaw exponent var)))
            ; General u^v (Stewart 3.6, logarithmic differentiation): with
            ; y = u^v, ln y = v*ln(u), so y'/y = v'*ln(u) + v*u'/u, i.e.
            ;   d/dx[u^v] = u^v * (v'*ln(u) + v*u'/u).
            ; Reached whenever NEITHER the exponent nor the base is a plain
            ; number: x^x, x^sin(x), (x^2+1)^x, sin(x)^cos(x), and also a
            ; symbolic constant exponent/base. Valid where u > 0 (ln u is
            ; defined), same domain caveat the textbook states.
            ('t (makeExprMul e
                    (makeExprAdd
                        (makeExprMul (diffExprRaw exponent var) (makeExprApplyChecked 'ln base))
                        (makeExprDiv (makeExprMul exponent (diffExprRaw base var)) base)))))))

; Table-driven chain rule: f(u) -> [rule below] where u' = diffExprRaw of
; the argument. Each entry matches calculus.md's own table exactly.
(define (diffExprApply e var)
    (let* ((func (exprApplyFunc e)) (u (exprApplyArg e)) (uPrime (diffExprRaw u var)))
        (case func
            ((sin)  (makeExprMul (makeExprApplyChecked 'cos u) uPrime))
            ((cos)  (makeExprNeg (makeExprMul (makeExprApplyChecked 'sin u) uPrime)))
            ((tan)  (makeExprDiv uPrime (makeExprPow (makeExprApplyChecked 'cos u) (makeExprNum 2))))
            ; sec/csc/cot -- calculus.md's standard reciprocal-trig table:
            ; d/dx[sec(u)]=sec(u)tan(u)u', d/dx[csc(u)]=-csc(u)cot(u)u',
            ; d/dx[cot(u)]=-csc(u)^2 u' (the -(1+cot^2(u)) form is
            ; equivalent but -csc^2 is the more standard textbook spelling).
            ((sec)  (makeExprMul (makeExprMul (makeExprApplyChecked 'sec u) (makeExprApplyChecked 'tan u)) uPrime))
            ((csc)  (makeExprNeg (makeExprMul (makeExprMul (makeExprApplyChecked 'csc u) (makeExprApplyChecked 'cot u)) uPrime)))
            ((cot)  (makeExprNeg (makeExprMul (makeExprPow (makeExprApplyChecked 'csc u) (makeExprNum 2)) uPrime)))
            ((exp)  (makeExprMul (makeExprApplyChecked 'exp u) uPrime))
            ((ln)   (makeExprDiv uPrime u))
            ((log)  (makeExprDiv uPrime (makeExprMul u (makeExprApplyChecked 'ln (makeExprNum 10)))))
            ((sqrt) (makeExprDiv uPrime (makeExprMul (makeExprNum 2) (makeExprApplyChecked 'sqrt u))))
            ; arcsin/arccos/arctan -- exist mainly so intExpr.scm's
            ; arctan(x)-shaped integration results (see its own header)
            ; are genuinely differentiable, for round-trip verification;
            ; also generally useful on their own.
            ((arcsin) (makeExprDiv uPrime (makeExprApplyChecked 'sqrt (makeExprSub (makeExprNum 1) (makeExprPow u (makeExprNum 2))))))
            ((arccos) (makeExprNeg (makeExprDiv uPrime (makeExprApplyChecked 'sqrt (makeExprSub (makeExprNum 1) (makeExprPow u (makeExprNum 2)))))))
            ((arctan) (makeExprDiv uPrime (makeExprAdd (makeExprNum 1) (makeExprPow u (makeExprNum 2)))))
            ; d/dx[abs(u)] = sign(u)*u', expressed as (u/abs(u))*u' since
            ; there's no separate sign() node -- u/abs(u) equals +1 when
            ; u>0, -1 when u<0, matching sign(u) exactly in both cases.
            ; Undefined at u=0 (abs itself has a corner there, not
            ; differentiable) -- same as every other domain edge case in
            ; this table (e.g. tan at cos(u)=0), not specially guarded
            ; against here, consistent with the rest of this file.
            ; Added specifically to close a self-verification gap:
            ; intExpr.scm's ln(abs(...)) antiderivatives (tan, 1/x,
            ; 1/(linear)) couldn't be differentiated back to confirm
            ; correctness without this rule existing.
            ((abs)  (makeExprMul (makeExprDiv u (makeExprApplyChecked 'abs u)) uPrime))
            ; NOTE: must be `else`, not `('t ...)` -- unlike cond, case
            ; treats a quoted symbol as a DATUM to match against (here,
            ; matching the literal symbols quote/t), not a catch-all test.
            ; Confirmed live: ('t ...) here silently returned an
            ; unspecified value for any unmatched func (e.g. 'abs) instead
            ; of erroring, surfacing later as a confusing "not an expr
            ; node" crash somewhere downstream instead of this file's own
            ; clear message. Swept and fixed everywhere else this pattern
            ; appeared in a `case` (not `cond`, where 't IS a valid
            ; always-true test) across exprAst/exprParse/diffExpr/
            ; limitExpr/curveSketch/implicitDiff/intExpr.
            (else (error #f "diffExprApply: unsupported function" func)))))

; ---- Public entry point ----
; exprSimplify -- bridging pure-polynomial results out to the existing
; engine's own expand()/classifyFrac normalization -- now lives in its
; own file, exprSimplify.scm (moved 2026-08-15; see that file's own header).
(define (diffExpr e var) (exprSimplify (diffExprRaw e var)))

; ---- diffExprWithSteps: STEPS-FEATURE-PLAN.md's step-logging sibling ----
;
; Mirrors diffExprRaw's structural recursion EXACTLY (same smart-
; constructor calls in the same order on the same sub-results), just
; threaded through an accumulator of <step> records (steps.scm) on the
; side, so the mandatory invariant holds: the last step's expr is
; byte-identical to (exprToString (diffExpr e var)) for any input,
; since the raw derivative tree built here is structurally identical to
; diffExprRaw's own output and both then go through the same
; exprSimplify.
;
; Not every rule application gets its own step -- sum/difference/
; negation are structural (linearity), not a "rule" a textbook would
; narrate, and a mul/div node where one side doesn't depend on `var`
; (e.g. "3*x", "x/2") is a constant multiple/divisor, not a genuine
; product/quotient rule, so those also log nothing beyond recursing
; into the side that does depend on var. Only product rule (both sides
; depend on var), quotient rule (denominator depends on var), the power
; rule (pow, constant exponent), the exponential rule (pow, constant
; base), and the chain rule/table lookup (apply) are narrated.

; #t if var appears anywhere in e's subtree.
(define (exprContainsVar? e var)
    (case (exprKind e)
        ((num) #f)
        ((evar) (eqv? (exprEvarName e) var))
        ((neg) (exprContainsVar? (exprNegOperand e) var))
        ((add) (or (exprContainsVar? (exprAddLeft e) var) (exprContainsVar? (exprAddRight e) var)))
        ((sub) (or (exprContainsVar? (exprSubLeft e) var) (exprContainsVar? (exprSubRight e) var)))
        ((mul) (or (exprContainsVar? (exprMulLeft e) var) (exprContainsVar? (exprMulRight e) var)))
        ((div) (or (exprContainsVar? (exprDivNumer e) var) (exprContainsVar? (exprDivDenom e) var)))
        ((pow) (or (exprContainsVar? (exprPowBase e) var) (exprContainsVar? (exprPowExponent e) var)))
        ((apply) (exprContainsVar? (exprApplyArg e) var))
        ; sum(...) -- term's indexVar is a binder (exprAst.scm's own
        ; header note): an occurrence of `var` inside term only counts
        ; as a real reference if var is NOT the index variable itself
        ; (capture-avoiding, same convention any binder needs -- e.g.
        ; "does sum(n,n,1,5) contain n" is asking about the OUTER n,
        ; which this node doesn't reference at all, regardless of the
        ; bound occurrences inside its own term).
        ((sum) (or (and (not (eqv? var (exprSumIndexVar e))) (exprContainsVar? (exprSumTerm e) var))
                   (exprContainsVar? (exprSumLower e) var)
                   (exprContainsVar? (exprSumUpper e) var)))
        ((factorial) (exprContainsVar? (exprFactorialOperand e) var))))

; Every distinct variable name appearing anywhere in e's subtree, in no
; particular order, no duplicates -- CALCULUS-AUTODETECT-PLAN.md's
; prime-notation differentiation ((expr)') needs this to infer which
; variable a bare expression should be differentiated with respect to
; (exprContainsVar? above only ever answers "does it contain THIS ONE
; variable", not "which variables does it contain at all" -- neither
; this nor that function replaces the other). polyVariable
; (factorPoly.scm) is the existing analog for the polynomial-only
; <poly> representation; this is that same idea generalized to a full
; exprAst tree, since polyVariable can't see into a `sin(t)`/`exp(y)`/
; etc. subtree at all.
(define (exprFreeVariables e)
    (case (exprKind e)
        ((num) '())
        ((evar) (list (exprEvarName e)))
        ((neg) (exprFreeVariables (exprNegOperand e)))
        ((add) (append (exprFreeVariables (exprAddLeft e)) (exprFreeVariables (exprAddRight e))))
        ((sub) (append (exprFreeVariables (exprSubLeft e)) (exprFreeVariables (exprSubRight e))))
        ((mul) (append (exprFreeVariables (exprMulLeft e)) (exprFreeVariables (exprMulRight e))))
        ((div) (append (exprFreeVariables (exprDivNumer e)) (exprFreeVariables (exprDivDenom e))))
        ((pow) (append (exprFreeVariables (exprPowBase e)) (exprFreeVariables (exprPowExponent e))))
        ((apply) (exprFreeVariables (exprApplyArg e)))
        ; sum(...) -- same capture-avoiding reasoning as exprContainsVar?
        ; above: indexVar is bound by this node, so it's filtered out of
        ; term's own free variables before appending lower/upper's.
        ((sum) (append (filter (lambda (v) (not (eqv? v (exprSumIndexVar e)))) (exprFreeVariables (exprSumTerm e)))
                   (exprFreeVariables (exprSumLower e))
                   (exprFreeVariables (exprSumUpper e))))
        ((factorial) (exprFreeVariables (exprFactorialOperand e)))))

; ---- exprSubstitute: replace every free occurrence of var with a full
;      subtree ----
;
; Nothing existing needed this until RiemannSum.scm (calculus2.md's
; Phase 1 numerical-integration groundwork): building a left/right
; Riemann sum means turning f(x) into f(a+i*Δx) SYMBOLICALLY (i is the
; sum's own fresh index variable, not yet a number) before ever handing
; the result to sumExpr.scm's evalSumNode -- evalExprAt can't do this,
; it only ever substitutes a concrete Scheme NUMBER, never another
; subtree. Built through the smart constructors throughout (same as
; diffExprRaw/intExpr) so the result comes out already locally
; simplified, not a literal structural copy with `replacement` spliced
; in unreduced.
;
; Capture-avoiding for var itself, same convention as exprContainsVar?/
; exprFreeVariables above: substituting into a sum(...) node's term
; only happens when var isn't that node's own bound indexVar. NOT
; hygienic the other direction, though -- if `replacement` itself
; contains a free occurrence of some OTHER binder's index variable (a
; sum node substitution recurses into), that occurrence WOULD get
; captured. No caller anywhere in this codebase can trigger that today
; (the only caller, RiemannSum.scm, always substitutes in a
; provably-fresh index variable name -- see its own freshIndexVar), so
; this is a documented, currently-unreachable limitation rather than a
; fixed one; a real general-purpose caller would need to rename bound
; variables apart first (alpha-conversion) before substituting.
(define (exprSubstitute e var replacement)
    (case (exprKind e)
        ((num) e)
        ((evar) (if (eqv? (exprEvarName e) var) replacement e))
        ((neg) (makeExprNeg (exprSubstitute (exprNegOperand e) var replacement)))
        ((add) (makeExprAdd (exprSubstitute (exprAddLeft e) var replacement) (exprSubstitute (exprAddRight e) var replacement)))
        ((sub) (makeExprSub (exprSubstitute (exprSubLeft e) var replacement) (exprSubstitute (exprSubRight e) var replacement)))
        ((mul) (makeExprMul (exprSubstitute (exprMulLeft e) var replacement) (exprSubstitute (exprMulRight e) var replacement)))
        ((div) (makeExprDiv (exprSubstitute (exprDivNumer e) var replacement) (exprSubstitute (exprDivDenom e) var replacement)))
        ((pow) (makeExprPow (exprSubstitute (exprPowBase e) var replacement) (exprSubstitute (exprPowExponent e) var replacement)))
        ((apply) (makeExprApplyChecked (exprApplyFunc e) (exprSubstitute (exprApplyArg e) var replacement)))
        ((sum) (makeExprSum
                   (if (eqv? var (exprSumIndexVar e)) (exprSumTerm e) (exprSubstitute (exprSumTerm e) var replacement))
                   (exprSumIndexVar e)
                   (exprSubstitute (exprSumLower e) var replacement)
                   (exprSubstitute (exprSumUpper e) var replacement)))
        ((factorial) (makeExprFactorial (exprSubstitute (exprFactorialOperand e) var replacement)))))

; Same dedup-preserving-first-occurrence-order shape as solvePoly.scm's
; own dedupSolutions, applied to a list of variable symbols instead of
; solution strings.
(define (dedupVariables varList)
    (let loop ((remaining varList) (seen '()) (acc '()))
        (cond
            ((null? remaining) (reverse acc))
            ((memq (car remaining) seen) (loop (cdr remaining) seen acc))
            ('t (loop (cdr remaining) (cons (car remaining) seen) (cons (car remaining) acc))))))

; Returns two values (uniqueVars . fallbackChoice): the distinct free
; variables (dedupVariables + exprFreeVariables), and a single "best
; guess" variable to actually use -- 'x when there are none at all (a
; bare constant expression, matching polyVariable's own "fall back to
; x" convention elsewhere), the one free variable when there's exactly
; one, or #f when there are two or more (genuinely ambiguous -- the
; caller must ask for explicit notation instead of guessing, same
; "ask, don't guess" philosophy as @:physics's ambiguity handling).
(define (exprInferredVariable e)
    (let ((vars (dedupVariables (exprFreeVariables e))))
        (cond
            ((null? vars) 'x)
            ((null? (cdr vars)) (car vars))
            ('t #f))))

; Returns (cons derivedRawNode stepList), stepList in recursion order
; (children's steps before this node's own, matching diffExprRaw's own
; recursion -- see this section's header comment above).
(define (diffExprRawSteps e var)
    (case (exprKind e)
        ((num) (cons (makeExprNum 0) '()))
        ((evar) (cons (if (eqv? (exprEvarName e) var) (makeExprNum 1) (makeExprNum 0)) '()))
        ((add)
            (let* ((L (diffExprRawSteps (exprAddLeft e) var)) (R (diffExprRawSteps (exprAddRight e) var)))
                (cons (makeExprAdd (car L) (car R)) (append (cdr L) (cdr R)))))
        ((sub)
            (let* ((L (diffExprRawSteps (exprSubLeft e) var)) (R (diffExprRawSteps (exprSubRight e) var)))
                (cons (makeExprSub (car L) (car R)) (append (cdr L) (cdr R)))))
        ((neg)
            (let ((O (diffExprRawSteps (exprNegOperand e) var)))
                (cons (makeExprNeg (car O)) (cdr O))))
        ((mul) (diffExprMulSteps e var))
        ((div) (diffExprDivSteps e var))
        ((pow) (diffExprPowSteps e var))
        ((apply) (diffExprApplySteps e var))
        ((sum) (error #f "diffExprRawSteps: differentiating a summation expression isn't supported" e))
        ((factorial) (error #f "diffExprRawSteps: differentiating a factorial expression isn't supported" e))))

(define (diffExprMulSteps e var)
    (let* ((u (exprMulLeft e)) (v (exprMulRight e))
           (uSteps (diffExprRawSteps u var)) (vSteps (diffExprRawSteps v var))
           (derived (makeExprAdd (makeExprMul (car uSteps) v) (makeExprMul u (car vSteps))))
           (childSteps (append (cdr uSteps) (cdr vSteps))))
        (if (and (exprContainsVar? u var) (exprContainsVar? v var))
            (cons derived
                (append childSteps
                    (list (makeStep 'product-rule
                        (string-append "Differentiate " (exprToString e)
                            " using the product rule: (fg)' = f'g+fg', with f = " (exprToString u)
                            " and g = " (exprToString v))
                        (exprToString derived)))))
            (cons derived childSteps))))

(define (diffExprDivSteps e var)
    (let* ((u (exprDivNumer e)) (v (exprDivDenom e))
           (uSteps (diffExprRawSteps u var)) (vSteps (diffExprRawSteps v var))
           (derived (makeExprDiv
                        (makeExprSub (makeExprMul (car uSteps) v) (makeExprMul u (car vSteps)))
                        (makeExprPow v (makeExprNum 2))))
           (childSteps (append (cdr uSteps) (cdr vSteps))))
        (if (exprContainsVar? v var)
            (cons derived
                (append childSteps
                    (list (makeStep 'quotient-rule
                        (string-append "Differentiate " (exprToString e)
                            " using the quotient rule: (f/g)' = (f'g-fg')/g^2, with f = " (exprToString u)
                            " and g = " (exprToString v))
                        (exprToString derived)))))
            (cons derived childSteps))))

(define (diffExprPowSteps e var)
    (let ((base (exprPowBase e)) (exponent (exprPowExponent e)))
        (cond
            ((exprNum? exponent)
                (let* ((baseSteps (diffExprRawSteps base var))
                       (derived (makeExprMul
                                    (makeExprMul exponent (makeExprPow base (makeExprSub exponent (makeExprNum 1))))
                                    (car baseSteps))))
                    (cons derived
                        (append (cdr baseSteps)
                            (list (makeStep 'power-rule
                                (string-append "Differentiate " (exprToString e)
                                    " using the power rule: d/dx[u^n] = n*u^(n-1)*u', with n = " (exprToString exponent))
                                (exprToString derived)))))))
            ((exprNum? base)
                (let* ((expSteps (diffExprRawSteps exponent var))
                       (derived (makeExprMul
                                    (makeExprMul (makeExprPow base exponent) (makeExprApplyChecked 'ln base))
                                    (car expSteps))))
                    (cons derived
                        (append (cdr expSteps)
                            (list (makeStep 'exponential-rule
                                (string-append "Differentiate " (exprToString e)
                                    " using the exponential rule: d/dx[a^u] = a^u*ln(a)*u', with a = " (exprToString base))
                                (exprToString derived)))))))
            ; General u^v -- logarithmic differentiation (see diffExprPow).
            ('t (let* ((baseSteps (diffExprRawSteps base var))
                       (expSteps (diffExprRawSteps exponent var))
                       (derived (makeExprMul e
                                    (makeExprAdd
                                        (makeExprMul (car expSteps) (makeExprApplyChecked 'ln base))
                                        (makeExprDiv (makeExprMul exponent (car baseSteps)) base)))))
                    (cons derived
                        (append (cdr baseSteps) (cdr expSteps)
                            (list (makeStep 'logarithmic-differentiation
                                (string-append "Differentiate " (exprToString e)
                                    " using logarithmic differentiation: d/dx[u^v] = u^v*(v'*ln(u) + v*u'/u), with u = "
                                    (exprToString base) " and v = " (exprToString exponent))
                                (exprToString derived))))))))))

(define (diffExprApplySteps e var)
    (let* ((func (exprApplyFunc e)) (u (exprApplyArg e))
           (uSteps (diffExprRawSteps u var))
           (uPrime (car uSteps))
           (derived
               (case func
                   ((sin)  (makeExprMul (makeExprApplyChecked 'cos u) uPrime))
                   ((cos)  (makeExprNeg (makeExprMul (makeExprApplyChecked 'sin u) uPrime)))
                   ((tan)  (makeExprDiv uPrime (makeExprPow (makeExprApplyChecked 'cos u) (makeExprNum 2))))
                   ((sec)  (makeExprMul (makeExprMul (makeExprApplyChecked 'sec u) (makeExprApplyChecked 'tan u)) uPrime))
                   ((csc)  (makeExprNeg (makeExprMul (makeExprMul (makeExprApplyChecked 'csc u) (makeExprApplyChecked 'cot u)) uPrime)))
                   ((cot)  (makeExprNeg (makeExprMul (makeExprPow (makeExprApplyChecked 'csc u) (makeExprNum 2)) uPrime)))
                   ((exp)  (makeExprMul (makeExprApplyChecked 'exp u) uPrime))
                   ((ln)   (makeExprDiv uPrime u))
                   ((log)  (makeExprDiv uPrime (makeExprMul u (makeExprApplyChecked 'ln (makeExprNum 10)))))
                   ((sqrt) (makeExprDiv uPrime (makeExprMul (makeExprNum 2) (makeExprApplyChecked 'sqrt u))))
                   ((arcsin) (makeExprDiv uPrime (makeExprApplyChecked 'sqrt (makeExprSub (makeExprNum 1) (makeExprPow u (makeExprNum 2))))))
                   ((arccos) (makeExprNeg (makeExprDiv uPrime (makeExprApplyChecked 'sqrt (makeExprSub (makeExprNum 1) (makeExprPow u (makeExprNum 2)))))))
                   ((arctan) (makeExprDiv uPrime (makeExprAdd (makeExprNum 1) (makeExprPow u (makeExprNum 2)))))
                   ((abs)  (makeExprMul (makeExprDiv u (makeExprApplyChecked 'abs u)) uPrime))
                   (else (error #f "diffExprApplySteps: unsupported function" func)))))
        (cons derived
            (append (cdr uSteps)
                (list (makeStep 'chain-rule
                    (string-append "Differentiate " (exprToString e) " using the derivative of " (symbol->string func)
                        (if (exprEvar? u) "" (string-append " and the chain rule (u = " (exprToString u) ")")))
                    (exprToString derived)))))))

; Public entry point. Always returns a nonempty list of <step>; the
; last step's expr always equals (exprToString (diffExpr e var)) --
; either because it's literally the last logged rule step, a trailing
; "Simplify" step is appended when exprSimplify actually changed
; something, or (for an input where no rule above ever fires, e.g. a
; bare variable/constant or a sum of only constant multiples) a single
; fallback step covers the whole thing.
(define (diffExprWithSteps e var)
    (let* ((rawAndSteps (diffExprRawSteps e var))
           (rawDerived (car rawAndSteps))
           (steps (cdr rawAndSteps))
           (simplifiedStr (exprToString (exprSimplify rawDerived))))
        (cond
            ((null? steps)
                (list (makeStep 'power-rule
                    (string-append "Differentiate " (exprToString e) " with respect to " (symbol->string var))
                    simplifiedStr)))
            ((string=? (stepExpr (last steps)) simplifiedStr) steps)
            ('t (append steps (list (makeStep 'simplify "Simplify the result" simplifiedStr)))))))
