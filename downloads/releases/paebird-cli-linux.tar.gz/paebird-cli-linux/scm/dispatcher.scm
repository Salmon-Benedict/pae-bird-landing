; dispatcher.scm -- CLI entry point for the PAE Bird native bridge
; (see /Users/rat/Documents/CS/C++/Poly/PolySwift/PAEBird-Chez/
; CHEZ-ENGINE-SWAP-PLAN.md for full context). Loads the engine (this
; directory's load-engine.scm file list minus cppBridge.scm -- see
; note below) and implements the small subset of the old C++ engine's
; batch protocol that the Swift app actually uses, confirmed
; empirically by reading AppState.swift/WorksheetView.swift directly:
; a batch of lines, optionally headed by one "@:<command>[ <arg>]"
; line setting the command for every subsequent line (default command
; is expand), one output line per input line, joined with newlines.
;
; Usage:
;   petite -q -b petite.boot --script dispatcher.scm process <inputFile> <outputFile>
;   petite -q -b petite.boot --script dispatcher.scm worksheet <type> <difficulty> <count> <baseFilename>
;
; NOTE: cppBridge.scm is deliberately NOT loaded (and not bundled into
; the app) -- its only job was shelling out to the OLD C++ engine this
; whole file exists to replace; nothing in the app's command
; vocabulary needs it once the engine is Chez-native.

; Loads each engine file by base name (no extension), preferring a
; precompiled foo.so over foo.scm when one is present -- this is what lets
; the shipped app bundle ship opaque compiled code instead of readable
; source (see PolySwift/Poly's SOURCE-PROTECTION-PLAN.md) with ZERO
; changes needed anywhere else: local development (this directory, the
; Docker chez-test container, the Poly/ChezEngine/scm synced copies) never
; has .so files sitting next to the .scm source, so this always falls
; through to the plain .scm path there, exactly like before this existed.
; Only a build step that actually produces foo.so files (and, for a
; genuine source-hiding win, removes the corresponding foo.scm from what
; it ships) changes which branch actually runs.
; A per-machine-type foo.<machine>.so (e.g. foo.tarm64osx.so, foo.ta6osx.so)
; wins over a plain foo.so, since a universal app bundle must ship one
; compiled copy per CPU architecture -- Chez fasl output is machine-specific.
(define (load-engine-file name)
    (let ((arch-compiled (string-append name "." (symbol->string (machine-type)) ".so"))
          (compiled (string-append name ".so")))
        (load (cond ((file-exists? arch-compiled) arch-compiled)
                    ((file-exists? compiled) compiled)
                    (else (string-append name ".scm"))))))

(for-each load-engine-file
    '("helperS" "steps" "mathHelp" "recordPoly2" "basicmath"
      "chemistry" "PolyStoSymbol" "simplify" "expandParse"
      "factorPoly" "solvePoly" "calcPoly" "equationVariants"
      "comprehensiveExpansion" "linearSystems" "functionAnalysis"
      "conicSections" "worksheetMath" "worksheetGenerator" "radicalRationalSolve"
      "mathSymbolClass" "polyBridge" "trigonometry" "factorial"
      "matrix" "nextLineTrigger" "superscriptFormat" "subscriptFormat"
      "variableSubstitution"
      ; calculus.md's Foundation + Phase 1/2/3 layer -- loaded last since
      ; limitExpr.scm needs ms-from-str/ms-poly-str (polyBridge.scm,
      ; already loaded above) and curveSketch.scm/implicitDiff.scm/
      ; intExpr.scm need diffExpr.scm/limitExpr.scm/solvePoly.scm.
      ; Reachable only via the new "dcalc"/"limit"/"critpoints"/
      ; "monotonic"/"inflection"/"concavity"/"sketch"/"implicit"/"icalc"/
      ; "defint" compute commands below -- the existing differentiate/
      ; integrate commands are untouched.
      ; exprSimplify (not "simplify" -- that name is already taken above,
      ; an unrelated <poly>-record simplification file) needs to load
      ; after exprParse, before diffExpr/intExpr, which both call it.
      "exprAst" "exprParse" "exprSimplify" "diffExpr" "limitExpr" "curveSketch" "implicitDiff" "intExpr" "integrationByParts" "trigPowerIntegrals" "trigRationalIntegrals" "chooser3" "calculusNotation" "calcAnalysis" "areaBetweenCurves" "identityLibrary" "theoremLibrary" "sumExpr" "RiemannSum" "riemannLimitIntegral"
      ; setOperations.scm -- finite sets (union/intersection/difference/
      ; subset/membership). Reachable only via the "set" compute command
      ; below. Depends on chemistry/expandParse, both already loaded above.
      "setOperations"
      ; Physics module -- project_physics_module.md. Reachable only via
      ; the "velocity"/"acceleration"/"suvat"/"newton"/"circular" compute
      ; commands below; the core algebra engine above is untouched by
      ; any of these files' existence. physicsDispatch loaded last since
      ; it references kinematics.scm, dynamics.scm, workEnergy.scm, and
      ; collisions.scm.
      "physicsUnits" "physicsSolve" "kinematics" "dynamics" "workEnergy" "collisions" "rotation" "oscillations" "gravitation" "physicsRegistry" "physicsDispatch"))

; Unlike MIT Scheme, Chez's `random` does NOT auto-seed from OS
; entropy -- every fresh process (this dispatcher runs as one per
; Swift-app request; see header comment above) starts the exact same
; pseudo-random sequence, so worksheet generation silently produced
; the identical worksheet on every "generate" call. Seed once here,
; before any command runs, from process id + wall-clock time
; (nanosecond-resolution) so back-to-back requests land on different
; sequences even if launched within the same clock second.
; random-seed requires an integer in [1, 4294967295].
(random-seed
    (+ 1 (modulo (+ (* 65599 (get-process-id))
                     (time-second (current-time))
                     (time-nanosecond (current-time)))
                  4294967295)))

; ---- string utilities (copied from chain.scm, not loaded wholesale --
; chain.scm implements a different, richer protocol Swift never sends;
; only these small MIT-compat/string-splitting helpers are needed here.
; See chain.scm's own header for why string-trim/string-search-forward
; need shims at all in Chez.) ----

(define (ws-char? c) (or (char=? c #\space) (char=? c #\tab) (char=? c #\newline) (char=? c #\return)))

(define (string-trim-left s)
    (let ((len (string-length s)))
        (let loop ((i 0))
            (if (and (< i len) (ws-char? (string-ref s i)))
                (loop (+ i 1))
                (substring s i len)))))

(define (string-trim-right s)
    (let ((len (string-length s)))
        (let loop ((i len))
            (if (and (> i 0) (ws-char? (string-ref s (- i 1))))
                (loop (- i 1))
                (substring s 0 i)))))

(define (trim s) (string-trim-left (string-trim-right s)))

(define (starts-with? s prefix)
    (and (>= (string-length s) (string-length prefix))
         (string=? (substring s 0 (string-length prefix)) prefix)))

(define (string-search-forward pattern str start)
    (let ((plen (string-length pattern)) (slen (string-length str)))
        (let loop ((i start))
            (cond
                ((> (+ i plen) slen) #f)
                ((string=? (substring str i (+ i plen)) pattern) i)
                ('t (loop (+ i 1)))))))

; Splits s on its first space; returns (before . after-trimmed).
; If no space, returns (s . "").
(define (split-first-space s)
    (let ((i (string-search-forward " " s 0)))
        (if i
            (cons (substring s 0 i)
                  (trim (substring s (+ i 1) (string-length s))))
            (cons s ""))))

(define (join-strings strs sep)
    (cond
        ((null? strs) "")
        ((null? (cdr strs)) (car strs))
        ('t (string-append (car strs) sep (join-strings (cdr strs) sep)))))

; ---- ";:command" answer-chaining suffix ----
; A suffix that feeds "the previous solution" (a running Ans register --
; see applyCommandChain below) into a new command, chainable by suffixing
; another ";:command": "expr;:factor;:expand" runs expr under the ambient
; command, factors that, then re-expands the factored result. Reuses
; string-search-forward (above) to find each 2-character ";:" marker.

; Splits line into the flat list of pieces between successive ";:"
; markers (a line with no ";:" at all -> a one-element list).
(define (splitOnChainMarker line)
    (let ((markerPos (string-search-forward ";:" line 0)))
        (if (not markerPos)
            (list line)
            (cons (substring line 0 markerPos)
                  (splitOnChainMarker (substring line (+ markerPos 2) (string-length line)))))))

; (cons leadingExpr segmentList): leadingExpr is the trimmed text before
; the first ";:" (possibly ""), segmentList is the list of trimmed
; command names after it ('() if line has no ";:" at all -- an ordinary
; line is a strict no-op through this split).
(define (splitChainSegments line)
    (let ((parts (map trim (splitOnChainMarker line))))
        (cons (car parts) (cdr parts))))

; The exact set of applyCommand cmd strings that return a joined
; multi-value result (join-strings ... ", ") rather than one plain
; string -- see applyCommand's own cond table below.
(define (isListValuedCommand? cmd)
    (or (string=? cmd "solve") (string=? cmd "solveexp") (string=? cmd "solvelog")
        (string=? cmd "radical") (string=? cmd "rational")
        (string=? cmd "trig") (string=? cmd "trigonometric")
        (string=? cmd "conic") (string=? cmd "conics")
        (string=? cmd "domain") (string=? cmd "range")
        (string=? cmd "compose") (string=? cmd "inverse") (string=? cmd "system")
        (string=? cmd "critpoints") (string=? cmd "monotonic")
        (string=? cmd "inflection") (string=? cmd "concavity") (string=? cmd "sketch")
        ; mvt -- calculus2.md's Phase 0: the Mean Value Theorem can have
        ; more than one valid c in (a,b), same unchainable-result
        ; reasoning as critpoints/etc. above.
        (string=? cmd "mvt")
        ; physics -- @:physics's own answer can be multi-branch (e.g. two
        ; paired SUVAT-style roots) or multi-candidate (an ambiguous match,
        ; several relations labeled and joined with " | "), same
        ; unchainable-result reasoning as solve/suvat/etc. above.
        (string=? cmd "physics")))

; The commands whose only argument is a single variable name (dcalc,
; curveSketch.scm's five analysis commands, intExpr.scm's icalc, and
; kinematics.scm's velocity/acceleration) -- all share the same
; persisted calcVar register (applyCommandChain/runProcess below) for a
; bare ";:<cmd>" chain segment or an "@:<cmd> <var>" batch directive.
(define (singleVarCalcCommand? cmd)
    (or (string=? cmd "dcalc") (string=? cmd "critpoints") (string=? cmd "monotonic")
        (string=? cmd "inflection") (string=? cmd "concavity") (string=? cmd "sketch")
        (string=? cmd "icalc") (string=? cmd "velocity") (string=? cmd "acceleration")))

; Short command aliases, directly requested by the user: shortest-
; unique-prefix (1st letter, then 1st+2nd, then 1st+2nd+3rd if still
; colliding), capped at 3 -- a command that still collides with another
; at 3 letters, or whose full name is itself a strict prefix of another
; command's (riemann/riemannlimit, no prefix <=7 chars distinguishes
; them), simply gets no short form; typing the full name always still
; works for every command, abbreviated or not. Computed once externally
; against dispatcher.scm's own command vocabulary (every applyCommand
; cmd string, plus the directiveName-only "clearval"/"showwork", which
; never become an applyCommand cmd) -- not hand-picked, so re-deriving
; it after a future command is added/renamed means re-running that
; computation, not guessing a new entry in isolation.
(define commandAbbreviations
    (list
        (cons "ac" "acceleration") (cons "ar" "areabetween") (cons "ba" "balance")
        (cons "br" "bracket2csv") (cons "ca" "canon") (cons "cl" "clearval")
        (cons "com" "compose") (cons "cr" "critpoints") (cons "cs" "csv2bracket")
        (cons "dc" "dcalc") (cons "def" "defint") (cons "deg" "degtorad")
        (cons "di" "differentiate") (cons "do" "domain") (cons "ev" "eval")
        (cons "fa" "factor") (cons "fl" "flip") (cons "ic" "icalc")
        (cons "im" "implicit") (cons "inf" "inflection") (cons "int" "integrate")
        (cons "inv" "inverse") (cons "lim" "limit") (cons "lin" "linapprox")
        (cons "lo" "logtoexp") (cons "mo" "monotonic") (cons "mv" "mvt")
        (cons "o" "oxstate") (cons "p" "physics") (cons "ran" "range")
        (cons "rat" "rational") (cons "ro" "rotate") (cons "sh" "showwork")
        (cons "sk" "sketch") (cons "sq" "sqrt") (cons "su" "sumcalc")
        (cons "sy" "system") (cons "t" "trigonometric") (cons "v" "velocity")))

; Expands a short alias to its canonical command name; returns name
; unchanged if it isn't a recognized abbreviation (already-canonical
; names, and pre-existing full-word aliases like "trig"/"conics" that
; applyCommand's own cond already understands directly, both just pass
; through here untouched). Applied at every point a command name string
; first arrives from user input -- runProcess's "@:"/"@@:" directiveName
; parsing, and applyCommandChain's ";:" chain segments below -- so every
; comparison downstream of those three places (isListValuedCommand?,
; singleVarCalcCommand?, applyCommand's own cond, etc.) only ever sees
; canonical names and needed no changes of its own.
(define (resolveCommand name)
    (let ((hit (assoc name commandAbbreviations)))
        (if hit (cdr hit) name)))

; #t for either of applyCommand/safeApplyCommand's two failure-string
; shapes ("Error: ..." from a caught exception, "[unknown command: ...]"
; from an unrecognized cmd) -- both mean this segment didn't produce a
; usable value to chain further.
(define (isErrorResult? s)
    (or (starts-with? s "Error: ") (starts-with? s "[unknown command: ")))

; @:showwork's own "detect what kind of problem it solves" logic --
; the ONLY entry point into diffExprWithSteps/solveWithSteps/
; expandStepsFromExpression's JSON output; there is deliberately no
; separate "differentiatesteps"/"solvesteps"/"expandsteps" command
; (an earlier pass of this feature had those as their own applyCommand
; cases, removed as redundant once @:showwork's own detection made
; them unnecessary -- one toggle, not four things to remember).
; ambientCmd is ALREADY whatever mode the user last switched to (via
; the ordinary "@:<mode>" mechanism, e.g. "@:solve" or "@:dcalc x") --
; that's the detection, no separate guessing from the expression text
; itself is needed or even well-defined (a bare "x^2+3x" alone can't
; say whether it's meant to be differentiated, solved, or expanded).
; This just routes the CURRENT mode to its *WithSteps sibling when one
; exists:
;   - "differentiate" (polynomial-only, variable optional -- infers via
;     polyVariable, same fallback differentiateExpr itself uses) and
;     "dcalc" (the AST engine, variable required) both go through
;     diffExprWithSteps.
;   - "solve" goes through solveWithSteps.
;   - "expand" goes through expandStepsFromExpression.
;   - every other mode (factor, physics/chemistry commands, the other
;     solve variants like solveexp/solvelog/radical/rational/trig,
;     etc.) has no steps support built -- returns #f immediately, no
;     attempt made.
; Returns the steps JSON string, or #f -- for "no steps support" OR for
; any error the steps computation itself raises (a malformed
; expression, dcalc's own "variable required" case, an
; expandStepsFromExpression input outside its scoped shapes like a
; bare "3x^2+5x+7"). #f always means "fall back to the plain result",
; by design (applyCommandChain's
; own (or (tryShowWorkJSON ...) (safeApplyCommand ...)) call site) --
; @:showwork is a pure enhancement, never a way to make an otherwise-
; working line suddenly error.
(define (tryShowWorkJSON cmd arg line)
    (guard (c (#t #f))
        (cond
            ((or (string=? cmd "differentiate") (string=? cmd "dcalc"))
                (let* ((charL (string->list line))
                       (v (if (not (string=? arg ""))
                              (string->symbol arg)
                              (or (polyVariable (expandSum (parseExpansion charL))) 'x)))
                       (steps (diffExprWithSteps (exprParse charL) v)))
                    (resultStepsToJSON (stepExpr (last steps)) steps)))
            ((string=? cmd "solve")
                (let ((steps (solveWithSteps (string->list line))))
                    (resultStepsToJSON (stepExpr (last steps)) steps)))
            ((string=? cmd "expand")
                (let ((steps (expandStepsFromExpression (string->list line))))
                    (resultStepsToJSON (stepExpr (last steps)) steps)))
            ('t #f))))

; Runs one line/call's worth of ";:"-chained commands, seeded either by
; ambientCmd's own evaluation of leadingExpr (the normal case) or, for a
; BARE chain (leadingExpr is empty -- nothing before the first ";:"), by
; lastSolution itself -- defaulting to "0" is the caller's job (runProcess
; and the compute CLI branch both start lastSolution at "0"), not this
; function's.
;
; Returns two values (resultString . newLastSolution): lastSolution is
; only ever updated on success, so one bad line/call can't clobber the
; Ans register -- a later bare ";:..." chain still resumes from the last
; GOOD result, not an error string. A mid-chain (not the final) step
; whose command is list-valued (isListValuedCommand?) is a hard error --
; there's no single value to feed into the next step -- but the FINAL
; step (or a plain expression with no ";:" at all) is free to be
; list-valued, rendering the normal joined result exactly like today.
; This guard applies to the ambientCmd seed step too, not just later
; ";:" segments -- "solve" as the ambient command followed by ";:expand"
; is exactly as unchainable as ";:solve;:expand" is (confirmed live: it
; used to fall through to a confusing generic parseTerm error instead of
; this function's own clear one). It does NOT extend across separate
; calls -- a list-valued result with no further ";:" on its own line
; still becomes lastSolution as usual (a later line might reasonably
; want it), so a bare ";:..." on a LATER line chaining off a multi-value
; lastSolution still hits that generic downstream error rather than this
; one, a known, narrower gap than the single-call case this guards.
;
; scmProgram: every OTHER bare ";:" segment intentionally gets arg=""
; below (a chain segment has no syntax slot of its own for an argument),
; but scmS/scmL need "the user's Scheme program" from somewhere -- runProcess
; threads scmProgram through here (set by the most recent "@:scmS <code>"/
; "@:scmL <code>" directive, exactly like varValues persists across lines)
; specifically so a bare ";:scmS"/";:scmL" segment can still reach it,
; without changing arg-passing for any other command's chain segments.
;
; dcalc/limit/curveSketch.scm's five commands/icalc have the exact same
; problem: a bare ";:dcalc" (or ";:critpoints"/";:monotonic"/
; ";:inflection"/";:concavity"/";:sketch"/";:icalc") has nowhere to put
; its variable, ";:limit"/";:defint"/";:eval" have nowhere to put their
; fields, and ";:implicit" has nowhere to put its two (x/y variable
; names), so calcVar/limitParams/implicitVars/defintParams/evalParams
; thread through here the same way -- calcVar shared by all seven
; single-variable-argument commands (see singleVarCalcCommand? below),
; each set by the most recent "@:<cmd> <var>" directive; limitParams set
; by "@:limit <var> <point> <direction>"; implicitVars set by
; "@:implicit <xVar> <yVar>"; defintParams set by "@:defint <var> <lower>
; <upper>"; evalParams set by "@:eval <var> <value>".
; showWork? (default #f -- only runProcess's "@:showwork on" ever sets
; it true): when true AND this line has no ";:" chain segments of its
; own, the seed step tries tryShowWorkJSON first, falling back to the
; normal safeApplyCommand result whenever that returns #f (ambientCmd
; has no steps support, or the steps computation itself errored for
; this particular input). Deliberately NOT extended to a ";:"-chained
; line -- a chain segment re-parses the previous step's result as a
; plain expression to feed the next command, which a JSON string isn't,
; so showwork is simply inert on a chained line rather than producing
; something a later segment can't consume.
(define applyCommandChain
    (case-lambda
        ((ambientCmd ambientArg line lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams)
            (applyCommandChain ambientCmd ambientArg line lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams #f))
        ((ambientCmd ambientArg line lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork?)
            (let* ((split (splitChainSegments line))
                   (leadingExpr (car split))
                   (segments (map resolveCommand (cdr split))))
                (if (and (not (string=? leadingExpr "")) (not (null? segments)) (isListValuedCommand? ambientCmd))
                    (values "Error: cannot chain from a multi-value result" lastSolution)
                    (let ((seed (cond
                                    ((string=? leadingExpr "") lastSolution)
                                    ((and showWork? (null? segments))
                                        (or (tryShowWorkJSON ambientCmd ambientArg leadingExpr)
                                            (safeApplyCommand ambientCmd ambientArg leadingExpr)))
                                    ('t (safeApplyCommand ambientCmd ambientArg leadingExpr)))))
                        (if (isErrorResult? seed)
                            (values seed lastSolution)
                            (let loop ((segs segments) (running seed))
                                (cond
                                    ((null? segs) (values running running))
                                    ((and (not (null? (cdr segs))) (isListValuedCommand? (car segs)))
                                        (values "Error: cannot chain from a multi-value result" lastSolution))
                                    ('t
                                        (let* ((segArg (cond
                                                           ((or (string=? (car segs) "scmS") (string=? (car segs) "scmL")) scmProgram)
                                                           ((singleVarCalcCommand? (car segs)) calcVar)
                                                           ((string=? (car segs) "limit") limitParams)
                                                           ((string=? (car segs) "implicit") implicitVars)
                                                           ((string=? (car segs) "defint") defintParams)
                                                           ((string=? (car segs) "eval") evalParams)
                                                           ('t "")))
                                               (next (safeApplyCommand (car segs) segArg running)))
                                            (if (isErrorResult? next)
                                                (values next lastSolution)
                                                (loop (cdr segs) next)))))))))))))

; Splits a newline-separated string into a list of line strings
; (unlike split-lines elsewhere in this codebase, this keeps blank
; lines as empty strings rather than dropping them, since the
; protocol's own invariant -- one output line per input line -- means
; the dispatcher can't silently drop or merge lines).
(define (splitOnNewline s)
    (let loop ((chars (string->list s)) (cur '()) (result '()))
        (cond
            ((null? chars) (reverse (cons (list->string (reverse cur)) result)))
            ((char=? (car chars) #\newline)
                (loop (cdr chars) '() (cons (list->string (reverse cur)) result)))
            ('t (loop (cdr chars) (cons (car chars) cur) result)))))

; ---- command dispatch ----

; #t if s (already space-stripped, optional leading "-") is nothing
; but digits and at most one ".". toScientificNotation (equationVariants.scm)
; assumes exactly this shape and does NOT validate it -- fed anything
; else (e.g. "6/2") it doesn't error, it silently produces garbage
; (confirmed empirically: toScientificNotation("6/2") -> "6./2 × 10^2",
; no exception at all), so a guard/try-catch fallback can't detect the
; bad case. This explicit check is what sciCommand uses instead.
(define (bareNumeralString? s)
    (let* ((body (if (and (> (string-length s) 0) (eqv? (string-ref s 0) #\-))
                      (substring s 1 (string-length s))
                      s))
           (len (string-length body)))
        (and (> len 0)
             (let loop ((i 0) (seenDot #f))
                 (cond
                     ((>= i len) #t)
                     ((char-numeric? (string-ref body i)) (loop (+ i 1) seenDot))
                     ((and (eqv? (string-ref body i) #\.) (not seenDot)) (loop (+ i 1) #t))
                     ('t #f))))))

; Converts line to scientific notation. A bare decimal/integer numeral
; (the common case, and the only shape toScientificNotation itself is
; actually built to parse -- see its own golden tests: "12345",
; "123456789", "0.001", "-45.6", "0") is converted directly. Anything
; else is expand()ed first (covers integer-arithmetic expressions like
; "6/2" -> "3"), which only works because THIS engine's expand() itself
; has no decimal-literal support at all (a separate, pre-existing
; scope limit of parseTerm/expandParse.scm, not something introduced
; here) -- so a decimal combined with another operator (e.g. "6.5/2")
; remains genuinely unsupported and reports an error via
; safeApplyCommand's guard, rather than silently mishandling it.
(define (sciCommand line)
    (let ((stripped (stripSpaces line)))
        (if (bareNumeralString? stripped)
            (toScientificNotation (string->list stripped))
            (toScientificNotation (string->list (expand (string->list line)))))))

; runProcess's own persistent "@:sci ... @:scioff" toggle (directly
; requested by the user): unlike the ordinary "@:sci" MODE above (which
; only converts a line that IS a bare numeral, and only while "sci" is
; itself the active cmd), this reformats any OTHER command's plain-
; numeral RESULT into scientific notation too, and keeps doing so
; across a later "@:"/"@@:"/";:" mode switch until "@:scioff" turns it
; off -- runProcess threads a sciMode? flag through its loop for
; exactly this, set by "@:sci" and cleared by "@:scioff" (see
; runProcess's own comments), and applies this to every result string
; right before it's pushed to the output accumulator. Deliberately
; NEVER applied to newLastSolution (the persisted ";:" chain register)
; -- that has to stay the true unformatted value, or chaining a further
; ";:<mode>" onto a scientific-notation STRING like "2.99792458 × 10^8"
; would feed that display text in as if it were a new expression.
;
; toScientificNotation's own "^N" exponent still needs the same
; toSubscriptNotation-then-toSuperscriptNotation pass safeApplyCommand's
; own choke point already runs on every OTHER command's result (see
; that function's own comment on why subscript has to run first) --
; this runs strictly AFTER safeApplyCommand/applyCommandChain have
; already returned, so without redoing that pass here explicitly the
; "^1" in "1 × 10^1" would reach the user as a literal caret instead of
; "1 × 10¹" the way @:sci's own direct mode already renders it
; (confirmed empirically: this exact mismatch, caught live).
(define (applySciFormatting result sciMode?)
    (if (and sciMode? (bareNumeralString? result))
        (toSuperscriptNotation (toSubscriptNotation (toScientificNotation (string->list result))))
        result))

; Applies command `cmd` (with optional trailing argument `arg`, e.g.
; differentiate's optional variable name) to one input line, returning
; a single output string. List-valued engine results (solve and
; friends) are joined with ", " -- matches chain.scm's own established
; convention for the identical situation (its "solve" case).
; "!" and "[...]" are both resolved BEFORE dispatching to any specific
; command (rather than being commands themselves) so they work
; transparently everywhere -- "3!+2" under @:expand becomes "6+2"
; before expand() ever sees it, "3!=x" under @:solve becomes "6=x"
; before solve() ever sees it, etc. Matrix expressions (matrix.scm's
; substituteMatrixExpressions) work the same way: "[[1,2],[3,4]]+
; [[5,6],[7,8]]" reduces to "[[6,8],[10,12]]" regardless of the active
; command -- and since no command besides a matrix one understands
; bracket notation, isMatrixResultLine? short-circuits straight to that
; result rather than handing it to whatever @: mode happens to be set,
; the one place this doesn't mirror factorial exactly (see matrix.scm's
; own header comment on why a matrix-shaped or "Error: ..." result
; can't keep composing the way a plain number always can).
;
; csv2bracket/bracket2csv are exempted from that implicit recognition
; entirely (checked first, before substituteMatrixExpressions ever
; runs): bracket2csv's own input IS a bare bracket-matrix, which is
; exactly the shape isMatrixResultLine? treats as "already a final
; result" -- without this exemption, that check would swallow
; bracket2csv's input and return the reformatted matrix directly,
; never reaching bracket2csv at all.
; Normalizes Unicode dash/minus lookalikes -- em dash "—", en dash "–",
; the math minus sign "−", and the Unicode hyphen "‐" -- to the plain
; ASCII hyphen-minus this engine's tokenizer treats as '-'. Same
; "normalize before anything else looks at it" precedent as
; fromSuperscriptNotation/fromSubscriptNotation just below: a text
; editor's/OS's smart-punctuation autocorrect routinely turns a typed
; "--" (or even a single "-") into "—" while a worksheet CSV is being
; edited, which otherwise reaches parseTerm as a raw, unparseable
; character (confirmed live: "parseTerm: expected a term" on
; "(1/2 + 1/3)+—(1/4 + 1/5)", an autocorrected "+-"). ASCII hyphen-minus
; itself is deliberately NOT in this list -- it's already what every
; parser expects, nothing to normalize.
(define dashLookalikes (list #\— #\– #\− #\‐))
(define (normalizeDashes s)
    (list->string (map (lambda (c) (if (memv c dashLookalikes) #\- c)) (string->list s))))

; rawLine is first normalized back from any Unicode superscript/subscript
; characters (superscriptFormat.scm/subscriptFormat.scm's own reverse
; maps) to plain "^"/"_" ASCII notation, before anything else -- including
; substituteFactorials -- ever looks at it. Results now DISPLAY with real
; superscript/subscript characters (safeApplyCommand's own final pass),
; so without this, copying a previous answer like "x²+1" back in as new
; input would reach parseTerm as a raw, unparseable Unicode character
; (confirmed: "parseTerm: expected a term" on literal "2x²+2x+2" input).
(define (applyCommand cmd arg rawLine)
    (let* ((rawLine (normalizeDashes rawLine))
           ; balance/oxstate -- reverse their own subscripted output (chemistry.scm's
           ; subscriptDigitsToAscii, "H₂O" -> "H2O", no underscore involved) BEFORE the
           ; generic fromSubscriptNotation pass below ever sees it -- that pass
           ; reconstructs the UNRELATED indexed-variable convention ("x_1" <-> "x₁",
           ; always WITH an underscore), which parseFormula has no grammar rule for at
           ; all, so pasting a @:balance/@:oxstate result back in as new input would
           ; otherwise turn "H₂O" into "H_2O" and error on the "_" -- see
           ; subscriptDigitsToAscii's own comment. A no-op for every other command.
           (rawLine (if (or (string=? cmd "balance") (string=? cmd "oxstate"))
                        (subscriptDigitsToAscii rawLine)
                        rawLine))
           (afterFactorial (substituteFactorials (fromSuperscriptNotation (fromSubscriptNotation rawLine)))))
        (cond
            ((string=? cmd "csv2bracket") (csvFieldToMatrix afterFactorial))
            ((string=? cmd "bracket2csv") (matrixToCSVField afterFactorial))
            ; scmS/scmL -- runs a user's own Chez Scheme program (arg) against
            ; this line's data. arg is either the ambient "@:scmS/scmL <code>"
            ; directive's stored code, or -- for a bare ";:scmS"/";:scmL"
            ; chain segment -- runProcess's own scmProgram register, threaded
            ; in by applyCommandChain (see its own comment for why chain
            ; segments need this special-cased rather than the normal ambient
            ; arg, which chain segments otherwise always discard). Handled
            ; here, before matrix-expression substitution, since the data
            ; line is meant as a generic symbol-list source, not necessarily
            ; a matrix expression. See runScmCommand's own header comment.
            ((string=? cmd "scmS") (runScmCommand arg afterFactorial 'symbolic))
            ((string=? cmd "scmL") (runScmCommand arg afterFactorial 'list))
            ('t
                (let ((line (substituteMatrixExpressions afterFactorial)))
                    (if (isMatrixResultLine? line)
                        line
                        ; calculusNotation.scm's "(expr)'"/"d/dx(expr)"/
                        ; "∫expr dx" -- recognized regardless of which @:
                        ; mode is active, same "no mode switch needed"
                        ; precedent as matrix/factorial above
                        ; (CALCULUS-AUTODETECT-PLAN.md).
                        (let ((calcResult (tryCalculusNotation line)))
                            (if calcResult
                                calcResult
                        (let ((charL (string->list line)))
                            (cond
                                ; expand -- a bare log(...)/ln(...)/log_N(...) call anywhere in
                                ; the line routes to comprehensiveExpansion.scm's own
                                ; expandLogarithmic instead of plain expand(), which doesn't
                                ; understand function-call syntax at all and silently GARBLES it
                                ; otherwise (confirmed live: "log(x*y)" -> "gloxy" under plain
                                ; expand()). expandLogarithmic's own scope is narrower than "any
                                ; line containing a log call" -- only a BARE log/ln/log_N call
                                ; spanning the ENTIRE line actually expands; anything else (a log
                                ; call embedded in a larger sum, etc.) is returned unchanged by
                                ; expandLogarithmic itself, which is still strictly better than
                                ; the garbling plain expand() would otherwise produce. The
                                ; standalone "expandc"/"@:expandc" command this used to require is
                                ; removed as redundant now that this is folded directly into
                                ; @:expand -- see comprehensiveExpansion.scm's own header for why
                                ; its other half (power-of-a-product expansion) was dropped rather
                                ; than also folded in (plain expand() already does that better).
                                ((string=? cmd "expand")
                                    (if (findLogCall (stripSpaces line))
                                        (expandLogarithmic charL)
                                        (expand charL)))
                                ((string=? cmd "factor") (factor charL))
                                ; solve -- a comparison operator (<, >, <=, >=) anywhere in
                                ; the line is recognized directly, the same "no separate mode
                                ; needed" precedent as matrix brackets/"!" factorial/calculus
                                ; notation above, routing straight to equationVariants.scm's
                                ; existing (linear-only) solveInequality rather than erroring
                                ; on parseEquationToZero's own "expected an equation containing
                                ; '='". The standalone "inequality" command this used to require
                                ; (CHEZ-ENGINE-SWAP-PLAN.md's original ~27-command list) is
                                ; removed below as redundant -- solveInequality itself is
                                ; unchanged and still reachable, just no longer under its own
                                ; command name; nothing in the Swift app's UI ever exposed
                                ; "@:inequality" as a selectable mode (grepped AppState.swift and
                                ; every other .swift file -- no match), so this has no live
                                ; caller to preserve compatibility for. Otherwise, an
                                ; empty arg is the existing single-variable behavior (unchanged);
                                ; a non-empty arg (e.g. "@:solve x") additionally supports a
                                ; genuinely multivariable equation, linear in that variable --
                                ; see solvePoly.scm's solve/solveLinearMultivar. Two more shapes
                                ; are recognized the same "no separate mode needed" way, checked
                                ; in this order (inequality first, since a comparison operator is
                                ; the cheapest and most unambiguous signal): a "log_BASE(ARG)=Y"
                                ; equation routes to solveLogarithm (equationVariants.scm's own
                                ; looksLikeLogEquation?), and a numeric-base exponential like
                                ; "2^x=16" routes to solveExponential (looksLikeExponentialEquation?)
                                ; -- both leaving an ordinary polynomial power like "x^2=16"
                                ; correctly alone (variable base, not numeric, so it falls through
                                ; to the plain solve() call below instead). @:solveexp/@:solvelog
                                ; (below) still work too, unaffected, for a caller that already
                                ; sends them explicitly.
                                ((string=? cmd "solve")
                                    (cond
                                        ((or (findStringCharPos #\< line 0) (findStringCharPos #\> line 0))
                                            (solveInequality charL))
                                        ((looksLikeLogEquation? charL)
                                            (join-strings (solveLogarithm charL) ", "))
                                        ((looksLikeExponentialEquation? charL)
                                            (join-strings (solveExponential charL) ", "))
                                        ('t (join-strings (if (string=? arg "") (solve charL) (solve charL (string->symbol arg))) ", "))))
                                ((string=? cmd "solveexp") (join-strings (solveExponential charL) ", "))
                                ((string=? cmd "solvelog") (join-strings (solveLogarithm charL) ", "))
                                ((string=? cmd "radical") (join-strings (solveRadical charL) ", "))
                                ((string=? cmd "rational") (join-strings (solveRational charL) ", "))
                                ((or (string=? cmd "trig") (string=? cmd "trigonometric")) (join-strings (solveTrigEquation charL) ", "))
                                ((or (string=? cmd "conic") (string=? cmd "conics")) (join-strings (analyzeConic charL) ", "))
                                ((string=? cmd "domain") (join-strings (analyzeDomain charL) ", "))
                                ((string=? cmd "range") (join-strings (analyzeRange charL) ", "))
                                ((string=? cmd "compose") (join-strings (composeFunction charL) ", "))
                                ((string=? cmd "inverse") (join-strings (inverseFunction charL) ", "))
                                ((string=? cmd "system") (join-strings (solveSystem charL) ", "))
                                ((string=? cmd "logtoexp") (logToExp charL))
                                ((string=? cmd "exptolog") (expToLog charL))
                                ((string=? cmd "rotate") (rotateEq charL))
                                ((string=? cmd "flip") (flipEq charL))
                                ((string=? cmd "degtorad") (degToRad charL))
                                ((string=? cmd "radtodeg") (radToDeg charL))
                                ((string=? cmd "sqrt") (simplifySquareRootCmd charL))
                                ; sci -- see sciCommand below for why this isn't a direct
                                ; one-line call to toScientificNotation.
                                ((string=? cmd "sci") (sciCommand line))
                                ; balance/oxstate take a plain string, not a char list --
                                ; the only two commands in this table that do (confirmed
                                ; from chemistry.scm's own function signatures).
                                ((string=? cmd "balance") (balanceEquation line))
                                ((string=? cmd "oxstate") (oxidationStates line))
                                ; setval as a one-shot command (as opposed to the
                                ; persistent "@:setval"/"@:clearval" batch directives
                                ; runProcess itself handles): arg is a var=val string
                                ; (variableSubstitution.scm's parseSetvalArg), applied
                                ; to this one line only -- no persistence needed since
                                ; the substitution is fully specified per-call. This is
                                ; what makes "compute setval <vars> <expr>" work.
                                ((string=? cmd "setval") (substituteKnownValues line (parseSetvalArg arg)))
                                ((string=? cmd "differentiate")
                                    (if (string=? arg "") (differentiateExpr charL) (differentiateExpr charL (string->symbol arg))))
                                ((string=? cmd "integrate")
                                    (if (string=? arg "") (integrateExpr charL) (integrateExpr charL (string->symbol arg))))
                                ; dcalc/limit -- calculus.md's new AST-based engine
                                ; (exprAst/exprParse/diffExpr/limitExpr), entirely
                                ; separate from differentiate/integrate above (those
                                ; stay on the original polynomial-only <poly> path,
                                ; untouched). dcalc's arg is just the variable, same
                                ; convention as differentiate/integrate except a
                                ; variable is required here (no polyVariable-style
                                ; inference exists for this newer AST). limit's arg
                                ; packs three space-separated fields -- "<var> <point>
                                ; <direction>", matching setval's own space-separated-
                                ; fields convention above -- since compute's calling
                                ; convention only has one arg slot beyond the
                                ; expression itself. point is a plain rational
                                ; ("2", "-1", "1/2") or the literal "+infinity"/
                                ; "-infinity"; direction is "two-sided", "left", or
                                ; "right".
                                ((string=? cmd "dcalc")
                                    (if (string=? arg "")
                                        (error #f "dcalc: a variable is required, e.g. \"compute dcalc x <expr>\"")
                                        (exprToString (diffExpr (exprParse charL) (string->symbol arg)))))
                                ((string=? cmd "limit")
                                    (let* ((parts (splitOnSpaces arg))
                                           (var (string->symbol (car parts)))
                                           (pointStr (cadr parts))
                                           (point (cond
                                                      ((string=? pointStr "+infinity") '+infinity)
                                                      ((string=? pointStr "-infinity") '-infinity)
                                                      ('t (string->number pointStr))))
                                           (direction (string->symbol (caddr parts))))
                                        (limitResultToString (limitExpr (exprParse charL) var point direction))))
                                ; curveSketch.scm's five commands -- calculus.md's Phase
                                ; 3, "critical points, concavity/inflection points, and
                                ; increasing/decreasing intervals". Same single-variable
                                ; arg convention as dcalc (required, no inference).
                                ; PURE-POLYNOMIAL scope only -- see curveSketch.scm's own
                                ; header for why (it reuses solve(), which has no concept
                                ; of a transcendental function).
                                ((string=? cmd "critpoints")
                                    (if (string=? arg "")
                                        (error #f "critpoints: a variable is required, e.g. \"compute critpoints x <expr>\"")
                                        (join-strings (analyzeCriticalPoints (exprParse charL) (string->symbol arg)) ", ")))
                                ((string=? cmd "monotonic")
                                    (if (string=? arg "")
                                        (error #f "monotonic: a variable is required, e.g. \"compute monotonic x <expr>\"")
                                        (join-strings (analyzeMonotonicity (exprParse charL) (string->symbol arg)) ", ")))
                                ((string=? cmd "inflection")
                                    (if (string=? arg "")
                                        (error #f "inflection: a variable is required, e.g. \"compute inflection x <expr>\"")
                                        (join-strings (analyzeInflectionPoints (exprParse charL) (string->symbol arg)) ", ")))
                                ((string=? cmd "concavity")
                                    (if (string=? arg "")
                                        (error #f "concavity: a variable is required, e.g. \"compute concavity x <expr>\"")
                                        (join-strings (analyzeConcavity (exprParse charL) (string->symbol arg)) ", ")))
                                ((string=? cmd "sketch")
                                    (if (string=? arg "")
                                        (error #f "sketch: a variable is required, e.g. \"compute sketch x <expr>\"")
                                        (join-strings (sketchCurve (exprParse charL) (string->symbol arg)) ", ")))
                                ; implicit -- calculus.md's Phase 3 implicit differentiation
                                ; (implicitDiff.scm). arg packs two space-separated fields,
                                ; "<xVar> <yVar>", same convention as limit's arg above.
                                ; Takes the raw equation charL directly (NOT exprParse'd
                                ; first) -- implicitDiff.scm does its own "=" splitting and
                                ; parses each side itself, the same way solve()'s own
                                ; parseEquationToZero works on a raw equation string, not a
                                ; pre-parsed single expression.
                                ((string=? cmd "implicit")
                                    (let* ((parts (splitOnSpaces arg))
                                           (xVar (string->symbol (car parts)))
                                           (yVar (string->symbol (cadr parts))))
                                        (exprToString (implicitDiff charL xVar yVar))))
                                ; icalc/defint -- calculus.md's Phase 3 integration
                                ; extensions (intExpr.scm). intExpr.scm's own intExprMul
                                ; now owns the decision to fall back to
                                ; integrationByParts.scm's IBP for an unresolved product,
                                ; at every product node in the tree (not just when the
                                ; whole integrand's own top-level node happens to be one,
                                ; which is what this file used to gate on) -- this case
                                ; just calls intExpr once and lets whatever it returns, or
                                ; whatever error it raises, propagate as-is. icalc's arg is
                                ; just the variable, same convention as dcalc. defint's
                                ; arg packs three space-separated fields, "<var> <lower>
                                ; <upper>", same convention as limit's arg.
                                ((string=? cmd "icalc")
                                    (if (string=? arg "")
                                        (error #f "icalc: a variable is required, e.g. \"compute icalc x <expr>\"")
                                        ; exprSimplify is a final, unconditional pass over whatever
                                        ; intExpr produced -- most paths through intExpr.scm (the
                                        ; basic antiderivative table, division, powers) never call
                                        ; exprSimplify themselves; only the IBP path (intExprMul)
                                        ; does, on its own final combined result. This guarantees
                                        ; every @:icalc answer gets at least one simplify pass
                                        ; regardless of which path produced it, not just IBP's --
                                        ; a no-op on an already-IBP-simplified result (exprSimplify
                                        ; is idempotent). simplifyAcrossApplyBoundaries (intExpr.scm)
                                        ; is the DEEPER pass on top of that: exprSimplify's own gate
                                        ; refuses to distribute/combine across a transcendental
                                        ; function boundary (exp(x), sin(x), ...) at all -- e.g.
                                        ; "x^2*exp(x)-(2*x*exp(x)-exp(x)*2)" used to stay exactly
                                        ; that undistributed/inconsistently-ordered shape even after
                                        ; exprSimplify ran -- so this closes that gap by swapping
                                        ; each transcendental subtree for a placeholder variable,
                                        ; running the real polynomial normalizer, and swapping back.
                                        ; See intExpr.scm's own header on that function for why the
                                        ; swap is required (not optional) and exactly what it does
                                        ; and doesn't fix.
                                        (let* ((e (exprParse charL)) (var (string->symbol arg)))
                                            (exprToString (simplifyAcrossApplyBoundaries (exprSimplify (intExpr e var)))))))
                                ((string=? cmd "defint")
                                    (let* ((parts (splitOnSpaces arg))
                                           (var (string->symbol (car parts)))
                                           (lower (string->number (cadr parts)))
                                           (upper (string->number (caddr parts))))
                                        (number->string (definiteIntegral (exprParse charL) var lower upper))))
                                ; eval -- direct point evaluation (limitExpr.scm's
                                ; evalExprAtToString), for the exprAst engine's own
                                ; transcendental expressions -- @:setval
                                ; (variableSubstitution.scm) is polynomial-only and can't
                                ; touch a dcalc/icalc result like "cos(2t)*2". arg packs
                                ; two space-separated fields, "<var> <value>", same
                                ; convention as dcalc/icalc's single-variable arg plus one
                                ; more field. Deliberately distinct from "limit" -- see
                                ; evalExprAtToString's own comment for why a value-at-a-
                                ; point and a limit are different questions.
                                ((string=? cmd "eval")
                                    (let* ((parts (splitOnSpaces arg))
                                           (var (string->symbol (car parts)))
                                           (point (string->number (cadr parts))))
                                        (evalExprAtToString (exprParse charL) var point)))
                                ; sumcalc -- calculus2.md's Phase 4 Foundation gap, finite-
                                ; sum slice (sumExpr.scm). Takes no variable arg (unlike
                                ; dcalc/icalc/eval) -- a sumcalc line is expected to already
                                ; be a closed, fully numeric expression once every embedded
                                ; sum(term,indexVar,lower,upper) is evaluated, the same
                                ; "no ambient variable" posture as "expand"'s own default
                                ; command. See sumExpr.scm's own header for the full scope
                                ; (finite ranges with literal-integer bounds only).
                                ((string=? cmd "sumcalc") (evalConstExprToString (exprParse charL)))
                                ; riemann -- calculus2.md's Phase 1 numerical-integration
                                ; groundwork (RiemannSum.scm), built entirely on top of
                                ; sumcalc's own sum(...) machinery. Unlike every other
                                ; command here, this one is deliberately self-contained on
                                ; a single line -- "<f(x)> <a> <b> <n> <side>", <side> being
                                ; the literal word "left", "right", or "midpoint" (p.312's
                                ; Midpoint Rule, theoremLibrary.scm's 'midpoint-rule) --
                                ; rather than an
                                ; ambient "@:riemann <params>" header plus a separate data
                                ; line, since a Riemann-sum problem is one-off, not a batch
                                ; of functions sharing the same bounds. runProcess's own
                                ; "@:riemann"/"@@:riemann" handling both route the WHOLE
                                ; rest of the line here as `line`/charL, with no ambient
                                ; state persisted (see runProcess's own comment). f's single
                                ; variable is auto-detected (riemannAutoVar below) rather
                                ; than given explicitly -- riemannSumExpr already rejects
                                ; more than one free variable, so there was never a second
                                ; variable name to parse out here. The last 4
                                ; space-separated tokens are always <a> <b> <n> <side>;
                                ; everything before them (rejoined with single spaces) is
                                ; f -- works whether or not f itself contains spaces
                                ; ("x^3 - 6x") or is wrapped in parens ("(x^3-6x)"), since
                                ; exprParse accepts a fully-parenthesized top-level
                                ; expression either way.
                                ((string=? cmd "riemann")
                                    (let ((tokens (splitOnSpaces line)))
                                        (if (< (length tokens) 5)
                                            (error #f "riemann: expected \"<f(x)> <a> <b> <n> <side>\"" line)
                                            (let* ((splitPoint (- (length tokens) 4))
                                                   (fTokens (list-head tokens splitPoint))
                                                   (paramTokens (list-tail tokens splitPoint))
                                                   (f (exprParse (string->list (join-strings fTokens " "))))
                                                   (var (riemannAutoVar f))
                                                   (a (string->number (car paramTokens)))
                                                   (b (string->number (cadr paramTokens)))
                                                   (n (string->number (caddr paramTokens)))
                                                   (side (string->symbol (cadddr paramTokens))))
                                                (riemannSumToString f var a b n side)))))
                                ; riemannlimit -- the EXACT counterpart to riemann above:
                                ; "<f(x)> <a> <b>" (no n, no side -- Theorem 4 takes
                                ; n->infinity and always uses right endpoints), evaluating
                                ; the definite integral via riemannLimitIntegral.scm's
                                ; definiteIntegralByRiemannLimit (Theorem 4 + Equations
                                ; 5-11, theoremLibrary.scm), same self-contained-one-line/
                                ; auto-detected-variable posture as riemann. Restricted to
                                ; degree <=3 polynomials -- see that file's own header for
                                ; why. Same trailing-tokens split as riemann, just 3 fields
                                ; instead of 5.
                                ((string=? cmd "riemannlimit")
                                    (let ((tokens (splitOnSpaces line)))
                                        (if (< (length tokens) 3)
                                            (error #f "riemannlimit: expected \"<f(x)> <a> <b>\"" line)
                                            (let* ((splitPoint (- (length tokens) 2))
                                                   (fTokens (list-head tokens splitPoint))
                                                   (paramTokens (list-tail tokens splitPoint))
                                                   (f (exprParse (string->list (join-strings fTokens " "))))
                                                   (var (riemannAutoVar f))
                                                   (a (string->number (car paramTokens)))
                                                   (b (string->number (cadr paramTokens))))
                                                (number->string (definiteIntegralByRiemannLimit f var a b))))))
                                ; continuity -- calculus2.md's Phase 0 (calcAnalysis.scm).
                                ; Same "<var> <point>" arg convention as eval, no persisted
                                ; chain register (unlike dcalc/limit/implicit/defint/eval) --
                                ; the ordinary ambient "@:continuity <var> <point>" directive
                                ; line already works for every realistic use the same way
                                ; "@:differentiate"/"@:solve" do without one; only a bare
                                ; mid-chain ";:continuity" suffix would need it, deliberately
                                ; not built out for this smaller Phase 0 feature.
                                ((string=? cmd "continuity")
                                    (let* ((parts (splitOnSpaces arg))
                                           (var (string->symbol (car parts)))
                                           (point (string->number (cadr parts))))
                                        (classifyContinuity (exprParse charL) var point)))
                                ; linapprox -- calculus2.md's Phase 0 (calcAnalysis.scm):
                                ; tangent-line approximation. arg packs three fields,
                                ; "<var> <center> <target>", same convention as defint's own
                                ; "<var> <lower> <upper>" -- <center> is where the tangent
                                ; line touches f (a in textbook notation), <target> is the
                                ; point being estimated (x0). No persisted chain register,
                                ; same reasoning as continuity above.
                                ((string=? cmd "linapprox")
                                    (let* ((parts (splitOnSpaces arg))
                                           (var (string->symbol (car parts)))
                                           (center (string->number (cadr parts)))
                                           (target (string->number (caddr parts))))
                                        (linearApproxToString (exprParse charL) var center target)))
                                ; mvt -- calculus2.md's Phase 0 (calcAnalysis.scm): Mean Value
                                ; Theorem / Rolle's Theorem (Rolle's is the slope=0 special
                                ; case, not a separate command -- see meanValueTheorem's own
                                ; comment). arg packs three fields, "<var> <a> <b>", same
                                ; convention as defint/linapprox. List-valued (there can be
                                ; more than one c) -- see isListValuedCommand? below.
                                ((string=? cmd "mvt")
                                    (let* ((parts (splitOnSpaces arg))
                                           (var (string->symbol (car parts)))
                                           (a (string->number (cadr parts)))
                                           (b (string->number (caddr parts))))
                                        (join-strings (meanValueTheorem (exprParse charL) var a b) ", ")))
                                ; areabetween -- calculus2.md's Phase 0 (areaBetweenCurves.scm).
                                ; Needs TWO expressions on one line, unlike every other calculus
                                ; command here -- "f;g", same ";"-separated convention
                                ; solveSystem (linearSystems.scm) already uses for multiple
                                ; equations on one line. arg is "<var>" (bounds inferred from
                                ; where the two curves cross) or "<var> <a> <b>" (explicit
                                ; bounds, still sign-aware around any crossing strictly inside
                                ; them -- see areaBetweenCurves's own header for why that
                                ; matters).
                                ((string=? cmd "areabetween")
                                    (let* ((exprStrings (splitOnChar line #\;))
                                           (f (exprParse (string->list (car exprStrings))))
                                           (g (exprParse (string->list (cadr exprStrings))))
                                           (argParts (splitOnSpaces arg))
                                           (var (string->symbol (car argParts))))
                                        (number->string
                                            (if (>= (length argParts) 3)
                                                (areaBetweenCurves f g var (string->number (cadr argParts)) (string->number (caddr argParts)))
                                                (areaBetweenCurves f g var)))))
                                ((string=? cmd "canon") (canonicalize charL))
                                ; set -- setOperations.scm: union/intersection/difference/
                                ; subset/membership over finite sets. Unlike dcalc/limit/
                                ; etc., the WHOLE expression (both operands and the
                                ; operator) is packed into charL as one self-contained
                                ; string, e.g. "{1,2,3}∪{2,3,4}" -- arg is unused, same
                                ; convention as expand/factor/solve (no separate variable
                                ; or parameters needed).
                                ((string=? cmd "set") (evalSetExpr charL))
                                ; velocity/acceleration -- physics module Phase 1
                                ; (Kinematics), kinematics.scm. One clause here delegates
                                ; to that file's own applyPhysicsCommand rather than
                                ; adding more cases directly to this cond table --
                                ; project_physics_module.md's own locked-in decision:
                                ; "New physics commands get their own namespace/prefix in
                                ; the dispatcher rather than growing the general
                                ; applyCommand cond table."
                                ((physicsCommand? cmd) (applyPhysicsCommand cmd arg charL))
                                ; physics -- @:physics, PHYSICS-EXPERT-SYSTEM-PLAN.md.
                                ; ONE mode replacing the old 26 separate physics command
                                ; names (suvat/newton/circular/.../universalgravpe):
                                ; auto-detects which relation applies from the variables
                                ; given (physicsRegistry.scm's physicsMatchAndSolve),
                                ; instead of the caller already knowing and typing the
                                ; exact command name for it. arg is unused, same
                                ; convention as expand/factor/solve -- everything needed
                                ; is already in the data line itself (optionally marking
                                ; one or more roles "?" to name the desired target, e.g.
                                ; "k=? m=2kg v=3m/s", disambiguating relations that would
                                ; otherwise tie on the same given variables).
                                ((string=? cmd "physics") (physicsMatchAndSolve line))
                                ('t (string-append "[unknown command: " cmd "]"))))))))))))

; Runs applyCommand, catching any engine exception and turning it into
; an "Error: ..." string instead -- see runProcess's own comment for
; why this per-line isolation matters (one malformed line must not
; abort the whole batch). Mirrors framework.scm's `safely` pattern
; (guard IS Chez/R7RS's direct equivalent of MIT's ignore-errors, no
; separate condition-catching step needed), not loaded here since
; framework.scm is test-only infrastructure, not part of the app's
; bundled engine.
;
; Also handles the "next line/cell" trigger (nextLineTrigger.scm): a
; leading or trailing ç on `cmd` -- not the expression/line -- is
; stripped BEFORE applyCommand ever sees it, and if present, the same ç
; is re-prepended to the final result string. Putting the marker on the
; command name rather than embedded in the math expression decouples
; trigger detection entirely from expression parsing: no matrix-bracket
; detection, factorial substitution, or any other line-parsing logic
; downstream ever needs to tolerate a stray ç character. In batch mode
; this also means a single "@:expandç" directive line (runProcess's own
; directive parsing needs no changes at all -- the ç just rides along
; inside the directive name it already threads through as `cmd`) applies
; triggering to every subsequent line under that command, instead of
; needing each line individually marked. This is the one wire signal
; every downstream client (Mac App, Excel/Sheets via PAE-API,
; LibreOffice) checks for on the RESULT to decide whether to render/
; place the answer on the next line/cell instead of in place --
; deliberately not a separate structured field, so it works identically
; for both `process` (batch) and `compute` (single-shot) modes without
; needing two different response formats, and without any risk to
; runProcess's one-line-per-input-line invariant (the marker is a single
; leading character, never an embedded newline).
;
; The result also goes through toSubscriptNotation (subscriptFormat.scm)
; and THEN toSuperscriptNotation (superscriptFormat.scm) before
; returning -- this is the one choke point every command's result
; passes through (both `process` and `compute` modes), so it's where
; "_subscript" and "^exponent" notation become real Unicode subscript/
; superscript characters for display, without any internal engine
; function needing to change its own "_"/"^"-based working
; representation. Order matters: subscript MUST run first -- Chez's
; char-numeric? is true for Unicode superscript digits too (e.g. "²"),
; so running superscript first and subscript second lets an already-
; converted "x_1^2" -> "x_1²" get its trailing "²" swallowed into the
; subscript scanner's digit-run, which then fails to map as a whole and
; leaves "_1²" unconverted (confirmed empirically).
(define (safeApplyCommand cmd arg line)
    (call-with-values
        (lambda () (stripNextLineTrigger cmd))
        (lambda (strippedCmd triggered?)
            (let ((result (toSuperscriptNotation (toSubscriptNotation
                              (guard (c (#t (string-append "Error: " (with-output-to-string (lambda () (display-condition c))))))
                                  (applyCommand strippedCmd arg line))))))
                (if triggered?
                    (string-append (string next-line-trigger-char) result)
                    result)))))

; Evaluates a user-provided Chez Scheme program (`code`, one or more forms)
; against `dataLine` converted to a symbol list via PolyStoSymbol (the same
; conversion PolyStoSymbol.scm already does for a polynomial), in an
; isolated environment that has ordinary Scheme (car, map, define, +, etc.)
; but NONE of this engine's own top-level bindings -- expand/differentiate/
; solve/etc. are simply unbound there. Verified directly:
; (environment '(chezscheme)) only carries forward library-exported
; bindings, not this script's own interaction-environment defines, even
; though both live in the same running process.
;
; (environment ...) is READ-ONLY, though -- eval can evaluate expressions
; against it but can't (define ...) into it directly (confirmed live:
; "invalid definition in immutable environment"). So `data` is bound via a
; `let` instead: every form in `code` is read, and all of them are
; evaluated together as the body of one `(let ((data 'dataList)) form1
; form2 ... formN)`, in a single eval call -- letting a user `define` a
; helper as an internal definition (before any other expression in the
; body, same as any Scheme `let` body) and use it in a later form, while
; the LAST form's value becomes the let's own value, with no separate
; "keep the last result" bookkeeping needed.
;
; outputMode 'list prints the raw result via write. outputMode 'symbolic
; stringifies the result back into polynomial-source text and re-runs it
; through expand()'s own parse step, so it renders exactly like a normal
; answer -- a result that isn't valid polynomial syntax throws during that
; re-parse, letting safeApplyCommand's existing guard turn it into a clean
; "Error: ..." rather than garbage output.
;
; No error-catching here: a bad user program's exception (or a bad re-parse
; in 'symbolic mode) is left to propagate to safeApplyCommand's own guard,
; the SAME one every other command's errors already go through -- this is
; also what makes the factor(0) fix load-bearing, since a bare ";:factor"
; chained off an unparseable scm result resumes from the Ans register's
; "0" default.
;
; One naming gotcha, confirmed live, not a security gap: this engine's own
; polynomial `expand` is unreachable in the sandbox (verified: "factor" and
; "differentiateExpr" both cleanly error as unbound), but calling `expand`
; specifically resolves to Chez's OWN unrelated builtin macro-expansion
; utility instead of erroring -- the exact same name collision
; PolyStoSymbol.scm's own header comment already documents ("expand's OWN
; name collides with a pre-existing Chez built-in"). The real polynomial
; logic is still genuinely not reachable; it's just a confusing result
; instead of a clean error for that one specific name.
(define (runScmCommand code dataLine outputMode)
    (let* ((dataList (PolyStoSymbol (string->list dataLine)))
           (sandboxEnv (environment '(chezscheme)))
           (port (open-input-string code))
           (forms (let loop ((acc '()))
                      (let ((form (read port)))
                          (if (eof-object? form) (reverse acc) (loop (cons form acc))))))
           (wrapped (append (list 'let (list (list 'data (list 'quote dataList)))) forms))
           (result (eval wrapped sandboxEnv)))
        (if (eqv? outputMode 'list)
            (with-output-to-string (lambda () (write result)))
            (expand (string->list (schemeValueToPolyString result))))))

; PolyStoSymbol actually appends a trailing bare '+' SENTINEL to
; whatever it produces (confirmed live: PolyStoSymbol("x+1") ->
; (x + 1 +), PolyStoSymbol("3") -> (3 +) -- always at the very end,
; regardless of input), not the leading-sign form schemeValueToPolyString's
; own comment below describes. Left as-is, that trailing '+' concatenates
; straight into the output text ("x+1" -> "x+1+"), which expand()'s
; parser then chokes on trying to read the (nonexistent) next term --
; confirmed live: even the simplest possible @:scmS program, the
; identity "data" with no transformation at all, crashed with a raw
; "car: () is not a pair" instead of round-tripping back to "x+1".
; Dropped here, once, before concatenating.
(define (dropTrailingPlusSentinel lst)
    (cond
        ((null? lst) lst)
        ((and (null? (cdr lst)) (eqv? (car lst) '+)) '())
        ('t (cons (car lst) (dropTrailingPlusSentinel (cdr lst))))))

; Flattens a Scheme value (typically the result of a user's scmS/scmL
; program) into plain polynomial-source text -- numbers/symbols print as
; themselves, a list concatenates its elements' own text with no separator
; (the inverse of PolyStoSymbol's own forward conversion, e.g. (+ x 1) ->
; "+x1", which re-parses via expand() the same way any other leading-"+"
; -signed expression already does). Anything else (a string, boolean,
; improper list, etc.) falls back to raw `write` text, which will then
; simply fail expand()'s own parse -- an expected, cleanly-caught outcome
; for a non-polynomial-shaped result, not something this function needs to
; guard against itself.
(define (schemeValueToPolyString v)
    (cond
        ((number? v) (number->string v))
        ((symbol? v) (symbol->string v))
        ((list? v) (apply string-append (map schemeValueToPolyString (dropTrailingPlusSentinel v))))
        ('t (with-output-to-string (lambda () (write v))))))

; Reads the whole content of a file as one string.
(define (readWholeFile path)
    (call-with-input-file path
        (lambda (port)
            (let loop ((acc '()))
                (let ((c (read-char port)))
                    (if (eof-object? c)
                        (list->string (reverse acc))
                        (loop (cons c acc))))))))

(define (writeWholeFile path content)
    (call-with-output-file path
        (lambda (port) (display content port))
        'replace))

; Reads inputPath and processes it as a stream of directive-or-data
; lines, threading (cmd, arg, varValues) state forward across the whole
; file -- not just a single header on line 1. Also recognizes "@@:" as a
; ONE-LINE override sharing the same directive vocabulary ("@@:factor
; x^2+5x+6" applies just to that line, cmd/arg/varValues unchanged for
; every line after; "@@:setval x=3 x^2+1" substitutes for just that
; line, no persistence) -- see its own cond clause below for why
; "setval" needs different parsing there than the persistent form does.
; Checked first since "@@:" and "@:" are disjoint prefixes (a line
; starting "@@:" never also starts with the two-character prefix "@:"
; starting at index 0, so order between the two clauses doesn't
; actually matter, but reads more naturally this way).
;
; Recognizes THREE kinds of "@:" directive, anywhere in the batch:
;   "@:setval <vars>"  -- merges parseSetvalArg's (var=val ...) pairs
;                          into the current varValues (new keys added,
;                          existing keys overwritten -- matches the old
;                          C++ engine's incremental map[key]=value
;                          semantics), leaving cmd/arg unchanged.
;   "@:clearval"        -- resets varValues to empty, leaving cmd/arg
;                          unchanged.
;   "@:<anything else>" -- today's existing mode switch (updates
;                          cmd/arg, e.g. "@:factor" or "@:differentiate
;                          x"), leaving varValues unchanged -- so a
;                          value set via setval survives a later mode
;                          switch, exactly like README_COMMANDS.html
;                          documents ("Will set variable values (all
;                          following lines)").
; Every directive line is dropped from the output entirely -- this
; extends rather than changes the existing precedent (a single header
; on line 1 already produced zero output lines here before this
; feature existed), so real callers (Swift, PAE-API), which only ever
; send at most one header today, see no behavior change at all.
;
; Blank/whitespace-only lines (including the trailing empty "line" a
; final newline always produces) get an empty-string result rather
; than being run through the engine, which would crash on empty input
; for most commands -- matches the old C++ engine's own handling of
; blank rows (skip processing, but still emit one output line).
;
; Every data line first goes through substituteKnownValues
; (variableSubstitution.scm -- a no-op when varValues is empty), then
; safeApplyCommand, which catches any engine exception (e.g. a
; malformed/out-of-grammar input for the selected command) and turns
; it into an "Error: ..." string for THAT line only -- without this,
; one bad line in an otherwise-valid batch would abort the whole
; process call via an uncaught exception, losing every other line's
; result and leaving outputPath never written at all. Matches the old
; C++ engine's own per-problem try/catch (main.cpp) rather than a
; per-batch all-or-nothing failure.
; lastSolution (init "0") is the ";:command" chain's Ans register (see
; its own header comment above) -- threaded alongside cmd/arg/varValues,
; but only ever touched by the plain-data-line branch at the bottom via
; applyCommandChain. Blank lines and @:/@@: directive lines leave it
; unchanged (deliberately out of scope -- directives keep calling
; safeApplyCommand directly, easy to extend later if wanted).
; scmProgram: the most recently set "@:scmS <code>"/"@:scmL <code>"
; directive's code, threaded alongside cmd/arg/varValues/lastSolution the
; same way -- persists across lines like varValues does, and exists
; specifically so a bare ";:scmS"/";:scmL" chain segment (applyCommandChain,
; whose chain segments otherwise always get arg="") still has a way to
; reach "the user's program". Untouched by "@@:" (deliberately -- that
; form is already documented as a one-line-only override, same as every
; other directive under it).
; showWork?: persistent boolean toggled by "@:showwork on"/"@:showwork
; off" (STEPS-FEATURE-PLAN.md's follow-up -- see tryShowWorkJSON's own
; comment for the detection logic), threaded through exactly like
; varValues/scmProgram/etc. -- set here, left unchanged by every other
; directive, and read only by the final plain-data-line branch below
; (via applyCommandChain), same as every other persistent register.
(define (runProcess inputPath outputPath)
    (let ((rawLines (splitOnNewline (readWholeFile inputPath))))
        (let loop ((lines rawLines) (cmd "expand") (arg "") (varValues '()) (lastSolution "0") (scmProgram "") (calcVar "") (limitParams "") (implicitVars "") (defintParams "") (evalParams "") (showWork? #f) (sciMode? #f) (acc '()))
            (cond
                ((null? lines)
                    (writeWholeFile outputPath (join-strings (reverse acc) "\n")))
                ((string=? (trim (car lines)) "")
                    (loop (cdr lines) cmd arg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? sciMode? (cons "" acc)))
                ((starts-with? (trim (car lines)) "@@:")
                    (let* ((directiveLine (trim (car lines)))
                           (directiveRest (trim (substring directiveLine 3 (string-length directiveLine))))
                           (directiveParts (split-first-space directiveRest))
                           (directiveName (resolveCommand (car directiveParts)))
                           (restAfterName (cdr directiveParts)))
                        ; One-line override: applies to THIS line only, cmd/arg/
                        ; varValues (the loop's own persistent state) pass through
                        ; unchanged to the next iteration. "setval" is the one
                        ; directiveName needing special handling -- see
                        ; splitOneLineSetval's own comment for why it can't just
                        ; reuse parseSetvalArg directly the way persistent
                        ; "@:setval" does (that form has the whole line to itself;
                        ; this one shares its line with the expression it applies
                        ; to). Every other directiveName is a plain "@@:<mode>
                        ; <expr>" override with no separate arg -- matches
                        ; commands.html's own documented examples, which never show
                        ; an inline differentiate/integrate variable this way.
                        ; sciMode? (if on) still reformats whatever this ONE line
                        ; produces, same as the persistent "@:"/";:" paths below.
                        (if (string=? directiveName "setval")
                            (call-with-values
                                (lambda () (splitOneLineSetval restAfterName))
                                (lambda (pairString exprString)
                                    (loop (cdr lines) cmd arg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? sciMode?
                                          (cons (applySciFormatting
                                                    (safeApplyCommand cmd arg
                                                        (substituteKnownValues exprString (append (parseSetvalArg pairString) varValues)))
                                                    sciMode?)
                                                acc))))
                            (loop (cdr lines) cmd arg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? sciMode?
                                  (cons (applySciFormatting (safeApplyCommand directiveName "" (substituteKnownValues restAfterName varValues)) sciMode?) acc)))))
                ((starts-with? (trim (car lines)) "@:")
                    (let* ((directiveLine (trim (car lines)))
                           (directiveRest (trim (substring directiveLine 2 (string-length directiveLine))))
                           (directiveParts (split-first-space directiveRest))
                           (directiveName (resolveCommand (car directiveParts)))
                           (directiveArg (cdr directiveParts)))
                        (cond
                            ((string=? directiveName "setval")
                                (loop (cdr lines) cmd arg (append (parseSetvalArg directiveArg) varValues) lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? sciMode? acc))
                            ((string=? directiveName "clearval")
                                (loop (cdr lines) cmd arg '() lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? sciMode? acc))
                            ; riemann -- self-contained on this one line ("@:riemann <f(x)>
                            ; <a> <b> <n> <side>", see applyCommand's own riemann branch
                            ; for the full format), so unlike every ambient-setting
                            ; directiveName below, it computes and emits a result
                            ; immediately -- same "acts on this line only" posture as
                            ; "@@:<mode> <expr>" below, just spelled with a single "@:"
                            ; since a Riemann-sum problem is one-off, not a batch of
                            ; expressions sharing a header. Leaves cmd/arg/every other
                            ; register untouched, same as setval/clearval/showwork above.
                            ((string=? directiveName "riemann")
                                (loop (cdr lines) cmd arg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? sciMode?
                                      (cons (applySciFormatting (safeApplyCommand "riemann" "" (substituteKnownValues directiveArg varValues)) sciMode?) acc)))
                            ; riemannlimit -- same self-contained-one-line posture as
                            ; riemann just above, "@:riemannlimit <f(x)> <a> <b>".
                            ((string=? directiveName "riemannlimit")
                                (loop (cdr lines) cmd arg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? sciMode?
                                      (cons (applySciFormatting (safeApplyCommand "riemannlimit" "" (substituteKnownValues directiveArg varValues)) sciMode?) acc)))
                            ; showwork -- "on" turns it on, anything else (including
                            ; a typo) turns it off, same safe-default convention as
                            ; a plain boolean flag elsewhere in this codebase. Leaves
                            ; cmd/arg/every other register untouched, same as
                            ; setval/clearval above.
                            ((string=? directiveName "showwork")
                                (loop (cdr lines) cmd arg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams (string=? (trim directiveArg) "on") sciMode? acc))
                            ; sci/scioff -- the PERSISTENT sci toggle (applySciFormatting's
                            ; own header comment has the full rationale), distinct from
                            ; plain "@:sci" as an ordinary ambient cmd (still set here
                            ; exactly like the 't fallback below would, so "@:sci" followed
                            ; by bare-numeral data lines keeps working exactly as before).
                            ; "@:scioff" leaves cmd/arg untouched, same as clearval/showwork
                            ; above -- it only clears the flag, it doesn't switch mode.
                            ((string=? directiveName "sci")
                                (loop (cdr lines) directiveName directiveArg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? #t acc))
                            ((string=? directiveName "scioff")
                                (loop (cdr lines) cmd arg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? #f acc))
                            ((or (string=? directiveName "scmS") (string=? directiveName "scmL"))
                                (loop (cdr lines) directiveName directiveArg varValues lastSolution directiveArg calcVar limitParams implicitVars defintParams evalParams showWork? sciMode? acc))
                            ((singleVarCalcCommand? directiveName)
                                (loop (cdr lines) directiveName directiveArg varValues lastSolution scmProgram directiveArg limitParams implicitVars defintParams evalParams showWork? sciMode? acc))
                            ((string=? directiveName "limit")
                                (loop (cdr lines) directiveName directiveArg varValues lastSolution scmProgram calcVar directiveArg implicitVars defintParams evalParams showWork? sciMode? acc))
                            ((string=? directiveName "implicit")
                                (loop (cdr lines) directiveName directiveArg varValues lastSolution scmProgram calcVar limitParams directiveArg defintParams evalParams showWork? sciMode? acc))
                            ((string=? directiveName "defint")
                                (loop (cdr lines) directiveName directiveArg varValues lastSolution scmProgram calcVar limitParams implicitVars directiveArg evalParams showWork? sciMode? acc))
                            ((string=? directiveName "eval")
                                (loop (cdr lines) directiveName directiveArg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams directiveArg showWork? sciMode? acc))
                            ('t
                                (loop (cdr lines) directiveName directiveArg varValues lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? sciMode? acc)))))
                ('t
                    (call-with-values
                        (lambda () (applyCommandChain cmd arg (substituteKnownValues (car lines) varValues) lastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork?))
                        (lambda (result newLastSolution)
                            (loop (cdr lines) cmd arg varValues newLastSolution scmProgram calcVar limitParams implicitVars defintParams evalParams showWork? sciMode? (cons (applySciFormatting result sciMode?) acc)))))))))

; Runs generateWorksheet (worksheetGenerator.scm) directly -- it
; already writes <baseFilename>_STUDENT.csv/_TEACHER.csv/_STUDENT.html/
; _TEACHER.html/.tex itself; the caller (PolyProcessor.mm) reads back
; whichever 2 of those 5 files match its requested format.
; Swift's own WorksheetView.swift sends "calculus"/"integration" as the
; literal type strings (confirmed directly from its `types` array),
; which don't match worksheetGenerator.scm's own vocabulary ('diff/
; 'integ) -- translated here rather than in the native bridge, since
; this is easier to test/adjust from the CLI than from Xcode.
(define (mapWorksheetType type)
    (cond
        ((string=? type "calculus") "diff")
        ((string=? type "integration") "integ")
        ('t type)))

(define (runWorksheet type difficulty count baseFilename)
    (generateWorksheet (string->symbol (mapWorksheetType type)) (string->symbol difficulty) count baseFilename)
    (display "ok") (newline))

; File-less counterpart of runWorksheet for PAE-API's HTTP /worksheet
; route: writes a single JSON array line to stdout instead of CSV/HTML/
; LaTeX files, since a server request has no shared filesystem with its
; caller the way the app's file-based worksheet feature does.
(define (runJSONWorksheet type difficulty count)
    (display (generateWorksheetJSON (string->symbol (mapWorksheetType type)) (string->symbol difficulty) count))
    (newline))

; File-based counterpart of runJSONWorksheet, for PAE Bird.app's own local
; HTTP server (LocalServer.swift): writes the same JSON array text to a
; file instead of stdout, so the Swift bridge can reuse the app's existing
; file-based NSTask I/O convention (PolyProcessor.mm never reads a
; subprocess's stdout, deliberately, to sidestep the NSPipe deadlock class
; of bug for larger output -- see that file's own header comment) rather
; than needing a second, pipe-based subprocess pattern just for this one
; call.
(define (runJSONWorksheetFile type difficulty count outputPath)
    (writeWholeFile outputPath (generateWorksheetJSON (string->symbol (mapWorksheetType type)) (string->symbol difficulty) count)))

; File-based matrix<->CSV modes (mirrors runWorksheet's own file-based
; precedent, not the line-oriented process protocol) -- for a dedicated
; matrix-only CSV file a user exported from a spreadsheet selection (see
; matrix.scm's own header comment on parseMatrixCSV for why this needs
; to be a real, whole-file multi-line grid rather than the one-line
; wire format process uses).
(define (runMatrixLoad csvFile outFile)
    (writeWholeFile outFile (csvToBracketString (readWholeFile csvFile))))

(define (runMatrixSave bracketLine csvFile)
    (writeWholeFile csvFile (bracketToCSVString bracketLine)))

; ---- XLSX (real Excel files) via the xlsxtool subprocess ----
;
; Neither MIT nor Chez Scheme has a ZIP/DEFLATE library, so real .xlsx
; reading/writing is done by a small first-party Swift CLI (XLSXKit's
; xlsxtool executable target -- see /Users/rat/Documents/CS/C++/Poly/
; PolySwift/Poly/XLSXKit/) built specifically for this bridge, using
; Apple's own Compression framework for the actual DEFLATE work. Its
; contract is deliberately just "XLSX <-> CSV text" over stdin/stdout,
; so matrix.scm's already-built csvToBracketString/bracketToCSVString
; handle everything past that -- no XLSX-specific logic needed here.
;
; Copied from cppBridge.scm's own shell-quote (that file is not loaded
; here -- see this file's own header -- so this is duplicated, not
; shared, matching this file's existing pattern for small self-
; contained string utilities). This matters because a matrix's bracket
; notation or a file path could in principle contain shell-special
; characters; shell-quote's POSIX single-quote-wrapping (escaping any
; embedded "'" as '\'') makes every argument passed to `process`
; (which runs its string through /bin/sh -c) inert as plain text.
(define (shell-quote s)
    (let loop ((i 0) (acc "'"))
        (if (>= i (string-length s))
            (string-append acc "'")
            (let ((c (string-ref s i)))
                (if (eqv? c #\')
                    (loop (+ i 1) (string-append acc "'\\''"))
                    (loop (+ i 1) (string-append acc (string c))))))))

; $XLSXTOOL env var override, else a known absolute path on this
; machine -- mirrors chez/run-tests.sh's own $CHEZ-or-fallback-path
; pattern for locating the Chez binary itself. Unlike that case, there
; is no useful *relative* fallback here: XLSXKit lives in a completely
; separate project tree (PAE Bird's Xcode project), not a sibling
; directory of this repo.
(define (resolve-xlsxtool-path)
    (or (getenv "XLSXTOOL")
        "/Users/rat/Documents/CS/C++/Poly/PolySwift/Poly/XLSXKit/.build/release/xlsxtool"))

; xlsxtool prefixes every error it reports with this exact marker (see
; its own main.swift for why: this Chez build's `process` merges a
; subprocess's stderr into the same stream read back as stdout, so an
; error can otherwise arrive silently mixed into what looks like valid
; CSV output). Checked BEFORE ever handing output to csvToBracketString
; -- without this, an xlsxtool failure surfaces as a confusing crash
; deep inside matrix.scm's numeral parsing instead of a clear error.
(define xlsxtool-error-prefix "XLSXTOOL_ERROR: ")

; get-string-all returns the eof-object (not "") when the port produced
; zero bytes -- confirmed empirically, hits every successful
; xlsxtool-write call, whose stdout is normally empty. Normalized here
; before the prefix check, since (string-length #!eof) errors.
(define (check-xlsxtool-output raw)
    (let ((s (if (eof-object? raw) "" raw)))
        (if (and (>= (string-length s) (string-length xlsxtool-error-prefix))
                 (string=? (substring s 0 (string-length xlsxtool-error-prefix)) xlsxtool-error-prefix))
            (error #f (string-append "xlsxtool: " (substring s (string-length xlsxtool-error-prefix) (string-length s))))
            s)))

; Runs `xlsxtool read <xlsxFile> [sheet]`, returning its stdout (the
; CSV text) as a string. No stdin needed for this direction.
(define (xlsxtool-read xlsxFile sheet)
    (let* ((cmdline (string-append (shell-quote (resolve-xlsxtool-path)) " read " (shell-quote xlsxFile)
                                   (if sheet (string-append " " (shell-quote sheet)) "")))
           (result (process cmdline))
           (from-out (car result))
           (to-in (cadr result)))
        (close-port to-in)
        (let ((s (get-string-all from-out)))
            (close-port from-out)
            (check-xlsxtool-output s))))

; Runs `xlsxtool write <sheetName> <xlsxFile>`, writing csvText to its
; stdin before closing it -- xlsxtool's contract is CSV on stdin, only
; the file path/sheet name go through argv (shell-quoted regardless).
(define (xlsxtool-write sheetName xlsxFile csvText)
    (let* ((cmdline (string-append (shell-quote (resolve-xlsxtool-path)) " write "
                                   (shell-quote sheetName) " " (shell-quote xlsxFile)))
           (result (process cmdline))
           (from-out (car result))
           (to-in (cadr result)))
        (display csvText to-in)
        (close-port to-in)
        (let ((s (get-string-all from-out)))
            (close-port from-out)
            (check-xlsxtool-output s))))

(define (runMatrixLoadXLSX xlsxFile outFile)
    (writeWholeFile outFile (csvToBracketString (xlsxtool-read xlsxFile #f))))

(define (runMatrixSaveXLSX bracketLine xlsxFile)
    (xlsxtool-write "Matrix" xlsxFile (bracketToCSVString bracketLine)))

; Optional trailing <seed> arg on the worksheet modes: with it, the same
; type/difficulty/count/seed regenerates the identical worksheet; without
; it, a seed is drawn from the startup entropy and recorded (printed as
; the sheet's "Worksheet code") so any worksheet can be regenerated.
(define (maybeSeedWorksheet args idx)
    (let ((n (and (> (length args) idx) (string->number (list-ref args idx)))))
        (if (and n (exact? n) (integer? n))
            (seedWorksheetRandom n)
            ; No (usable) seed given: draw one from the entropy-seeded
            ; generator and apply it, so the worksheet's printed
            ; "Worksheet code" always regenerates that exact sheet.
            (seedWorksheetRandom (random 4294967295)))))

; ---- entry point ----

(let ((args (command-line-arguments)))
    (cond
        ((and (>= (length args) 3) (string=? (car args) "process"))
            (runProcess (cadr args) (caddr args)))
        ((and (>= (length args) 5) (string=? (car args) "worksheet"))
            (maybeSeedWorksheet args 5)
            (runWorksheet (cadr args) (caddr args) (string->number (cadddr args)) (car (cddddr args))))
        ((and (>= (length args) 4) (string=? (car args) "jsonworksheet"))
            (maybeSeedWorksheet args 4)
            (runJSONWorksheet (cadr args) (caddr args) (string->number (cadddr args))))
        ((and (>= (length args) 5) (string=? (car args) "jsonworksheetfile"))
            (maybeSeedWorksheet args 5)
            (runJSONWorksheetFile (cadr args) (caddr args) (string->number (cadddr args)) (car (cddddr args))))
        ((and (>= (length args) 3) (string=? (car args) "matrixload"))
            (runMatrixLoad (cadr args) (caddr args)))
        ((and (>= (length args) 3) (string=? (car args) "matrixsave"))
            (runMatrixSave (cadr args) (caddr args)))
        ((and (>= (length args) 3) (string=? (car args) "matrixloadxlsx"))
            (runMatrixLoadXLSX (cadr args) (caddr args)))
        ((and (>= (length args) 3) (string=? (car args) "matrixsavexlsx"))
            (runMatrixSaveXLSX (cadr args) (caddr args)))
        ; Single-computation mode, for the compute-API server (PAE-API):
        ; one line of output, reusing safeApplyCommand directly (same
        ; error-string convention as the batch `process` mode) -- no new
        ; dispatch logic, this is exactly applyCommand's own cmd/arg/line
        ; parameters taken straight from argv instead of a batch file's
        ; "@:<command>" header. arg may be an empty string ("") when the
        ; command (e.g. differentiate/integrate) has no explicit variable.
        ; The optional 5th argument (previousSolution, default "0") is the
        ; ";:command" chain's Ans register (applyCommandChain above) --
        ; compute is a fresh, stateless process every call, so a caller
        ; wanting to chain off its own last answer (PAE-API/Excel/Mac app,
        ; each tracking that per-session/per-user/per-cell as appropriate)
        ; passes it back in explicitly rather than this process remembering
        ; anything itself.
        ((and (>= (length args) 4) (string=? (car args) "compute"))
            (let ((previousSolution (if (>= (length args) 5) (list-ref args 4) "0")))
                (call-with-values
                    ; compute is a single stateless call, so there's no
                    ; multi-line loop to persist a separate scmProgram/
                    ; calcVar/limitParams/implicitVars/defintParams/
                    ; evalParams register the way runProcess does -- (caddr
                    ; args) (the same ambientArg) doubles as all six, since
                    ; in a one-shot call "the variable/params a caller wants
                    ; for a bare ';:scmS'/';:scmL'/';:dcalc'/';:limit'/
                    ; ';:implicit'/';:defint'/';:eval' embedded in the
                    ; expression can only sensibly be whatever arg they
                    ; already passed.
                    (lambda () (applyCommandChain (cadr args) (caddr args) (cadddr args) previousSolution (caddr args) (caddr args) (caddr args) (caddr args) (caddr args) (caddr args)))
                    (lambda (result newLastSolution)
                        (display result)
                        (newline)))))
        ('t
            (display "Usage: dispatcher.scm process <in> <out> | worksheet <type> <difficulty> <count> <baseFilename> [<seed>] | jsonworksheet <type> <difficulty> <count> [<seed>] | jsonworksheetfile <type> <difficulty> <count> <outFile> [<seed>] | matrixload <csvFile> <outFile> | matrixsave <bracketLine> <csvFile> | matrixloadxlsx <xlsxFile> <outFile> | matrixsavexlsx <bracketLine> <xlsxFile> | compute <cmd> <arg> <expression> [<previousSolution>]")
            (newline)
            (exit 1))))
