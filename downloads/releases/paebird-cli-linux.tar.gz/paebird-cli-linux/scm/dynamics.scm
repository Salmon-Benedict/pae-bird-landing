; dynamics.scm -- physics module Phase 2, part 1: Newton's second law
; and circular motion (project_physics_module.md's Mechanics curriculum
; order, item 2 -- "Newton's Laws, circular motion, drag"; drag needs no
; new command here, see that item's own note in the plan file/physics
; module doc's Phase 2 section for why: dcalc + limit at infinity,
; already shipped, already cover it).
;
; Depends on: physicsUnits.scm (dimForce/dimMass and the shared role
; table), physicsSolve.scm (solvePhysicsCommand). Load this file after
; physicsSolve.scm.

; ---- Newton's second law: F = m*a ----
; 3 variables (f, m, a), 1 equation -- give any 2, solve for the third.
; Always a single linear solution (no branching possible for this
; equation), but goes through the same generic solvePhysicsSystem
; pipeline as everything else for uniformity, rather than a special-
; cased direct-division shortcut.
(define newtonVars '(f m a))
(define newtonEquations (list "f=m*a"))


; ---- Circular motion: centripetal acceleration and force ----
; a*r = v^2 (kinematic -- the standard a=v^2/r rearranged to avoid
; putting a variable in a denominator: solve()/expand() don't support
; that at all, "division by a non-constant isn't supported here" --
; confirmed live during Phase 2 development; SUVAT's own equations
; never happened to hit this since none of them ever divide by a
; variable. a*r=v^2 is mathematically identical and solves cleanly for
; any of a, r, or v.), f = m*a (dynamic -- centripetal force IS
; Newton's second law applied to centripetal acceleration; same
; equation string as newtonEquations above, reused verbatim since it's
; the same physical relation). 5 variables (a, v, r, f, m), 2
; equations -- give any 3, solve for the other 2, same shape as SUVAT
; (Phase 1), including the same possible branching: a*r=v^2 has +/-
; roots for v when v is the first variable solved.
;
; Scope boundary: just these two core relations, matching SUVAT's own
; "the standard equations, not everything possible" scope. Period/
; frequency (v=2*pi*r/T) and combined scenarios (banking angles,
; vertical circular motion combining gravity and normal force) are
; explicitly out of scope for this phase.
(define circularVars '(a v r f m))
(define circularEquations (list "a*r=v^2" "f=m*a"))

