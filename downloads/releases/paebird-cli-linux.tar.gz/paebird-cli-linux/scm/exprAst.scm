; exprAst.scm -- recursive expression AST: the Foundation layer from
; ../calculus.md's plan. Everything downstream (exprParse.scm, diffExpr.scm,
; limitExpr.scm) is built on the node types defined here.
;
; This generalizes past the engine's existing polynomial-only structures --
; recordPoly2.scm's <poly> is a flat monomial (coefficient * variable^power)
; and expandParse.scm's <group>/<addend> are a flat Sum-of-Products list,
; neither of which can represent nested function composition like
; sin(cos(x)) in a way a chain rule could recurse over. This file's nodes
; form a genuine binary/unary tree instead, specifically so diffExpr.scm's
; structural recursion (see calculus.md's Phase 1 rule table) has something
; to recurse over.
;
; Where a subtree turns out to be pure polynomial (no `apply` node anywhere
; in it), callers are expected to bridge OUT to the existing expand()/
; factor()/recordToString machinery for normalization -- this file doesn't
; duplicate that, it just needs to be able to represent a mixed tree that
; contains such a subtree.
;
; Depends on: helperS.scm (for the number->string shim -- exact rationals
; format the same way the rest of the engine already expects, e.g. "1/2"
; not "0.5"), factorial.scm (its `factorial`, for makeExprFactorial's
; own literal-folding case below -- loaded well before this file).
;
; ---- define-record-type note ----
; Chez's top-level define-record-type binding is R6RS's clause-based form,
; not R7RS's positional form -- same fact recordPoly2.scm's own port notes
; document at length. All 9 node types below use that clause syntax
; directly (no porting involved, this file is new).
;
; ---- Naming ----
; Every constructor/predicate/accessor is prefixed "expr" specifically to
; avoid colliding with any Chez builtin -- `apply` is a core R6RS procedure
; (used everywhere as `(apply f args)`), so a node-kind constructor literally
; named `apply` would silently shadow it. This is the same class of bug
; recordPoly2.scm's own header notes call out for its "cd" accessor
; shadowing Chez's builtin cd/change-directory -- avoided here up front by
; prefixing everything rather than fixing it after the fact.
;
; ---- Node kinds ----
; exprNum    -- a literal exact rational, e.g. (makeExprNum 3), (makeExprNum 1/2)
; exprEvar   -- a variable reference, e.g. (makeExprEvar 'x)
; exprAdd    -- left + right
; exprSub    -- left - right
; exprNeg    -- -operand
; exprMul    -- left * right
; exprDiv    -- numer / denom
; exprPow    -- base ^ exponent (exponent is itself a full subtree, not
;               restricted to a literal -- diffExpr.scm's rule dispatch is
;               what distinguishes the constant-exponent case from the
;               constant-base/variable-exponent case, not the node shape)
; exprApply  -- (func arg), func a symbol from '(sin cos tan exp ln log sqrt abs),
;               arg a full subtree (so sin(x^2), sin(cos(x)) etc. all just
;               fall out of ordinary recursion, no special-casing needed)
; exprSum    -- sum(term, indexVar, lower, upper), finite sigma-notation
;               summation. term is a full subtree in indexVar (a bare
;               symbol, not a subtree -- unlike every other field here,
;               it's a BINDER: occurrences of indexVar inside term are
;               bound by this node, not free references the way an evar
;               elsewhere would be). lower/upper are full subtrees too,
;               required (by sumExpr.scm, not this file) to evaluate to
;               literal integers with no free variables at all --
;               sum(n,n,1,N) with a symbolic upper bound is out of scope
;               for now (see sumExpr.scm's own header). Added for
;               calculus2.md's Phase 4 Foundation gap ("no way to even
;               STATE a summation"); this is the finite-sum slice only --
;               infinite series/sequence convergence is a separate,
;               larger piece of that same phase, not built here.
; exprFactorial -- operand! (postfix, single operand). Only defined for
;               a nonnegative integer -- see makeExprFactorial's own
;               folding/domain-check below. Added specifically so
;               sum(...)'s term can express something like 1/n! (a
;               Taylor-series-shaped sum); factorial.scm's existing
;               substituteFactorials only ever rewrote a LITERAL
;               numeral ("3!") at the raw-string level before parsing
;               even starts -- it explicitly declines a bare "n!" where
;               n is a variable, so it can't cover this case at all.
;

; All fields are immutable -- unlike <poly>/<group>/<addend> (which get
; built incrementally by their parsers via mutation), AST nodes here are
; meant to be built once and then transformed functionally (diffExpr
; produces new trees rather than editing existing ones in place). This
; also sidesteps any risk of a subtree object being shared by more than one
; parent (e.g. product rule's u'v + uv' naturally reuses u and v under both
; terms) and then getting mutated out from under one of its sharers.

(define-record-type (<expr-num> makeExprNum exprNum?)
    (fields
        (immutable value exprNumValue)))

(define-record-type (<expr-evar> makeExprEvar exprEvar?)
    (fields
        (immutable name exprEvarName)))

(define-record-type (<expr-add> rawMakeExprAdd exprAdd?)
    (fields
        (immutable left exprAddLeft)
        (immutable right exprAddRight)))

(define-record-type (<expr-sub> rawMakeExprSub exprSub?)
    (fields
        (immutable left exprSubLeft)
        (immutable right exprSubRight)))

(define-record-type (<expr-neg> rawMakeExprNeg exprNeg?)
    (fields
        (immutable operand exprNegOperand)))

(define-record-type (<expr-mul> rawMakeExprMul exprMul?)
    (fields
        (immutable left exprMulLeft)
        (immutable right exprMulRight)))

(define-record-type (<expr-div> rawMakeExprDiv exprDiv?)
    (fields
        (immutable numer exprDivNumer)
        (immutable denom exprDivDenom)))

(define-record-type (<expr-pow> rawMakeExprPow exprPow?)
    (fields
        (immutable base exprPowBase)
        (immutable exponent exprPowExponent)))

; operand! -- see this file's header note above. Raw/smart-wrapper split
; (rawMakeExprFactorial here, makeExprFactorial below alongside the
; other 6 arithmetic-family constructors) for the same reason those do:
; a literal nonnegative-integer operand folds immediately via
; factorial.scm's own `factorial` (loaded well before this file).
(define-record-type (<expr-factorial> rawMakeExprFactorial exprFactorial?)
    (fields
        (immutable operand exprFactorialOperand)))

; sum(term, indexVar, lower, upper) -- see this file's header note above.
; indexVar is a bare symbol (a binder, not a subtree); term/lower/upper
; are exprAst subtrees. No eager simplification at construction time
; (unlike the six arithmetic node kinds above) -- there's no local,
; construction-time identity to eliminate the way exprMul's "times 1"
; is; folding an actual sum with literal bounds down to a number is
; sumExpr.scm's job, done deliberately later (at evaluation time, not
; construction time), so this node can still round-trip through
; exprToString/exprParse unevaluated in the meantime.
(define-record-type (<expr-sum> makeExprSum exprSum?)
    (fields
        (immutable term exprSumTerm)
        (immutable indexVar exprSumIndexVar)
        (immutable lower exprSumLower)
        (immutable upper exprSumUpper)))

; ---- Smart constructors: eager identity elimination + constant folding ----
;
; SICP 2.3.2's make-sum/make-product do exactly this for '+'/'*' (checking
; =number? against 0/1, folding two number literals via +/*) -- framed
; there as the same strategy as rational-number reduction: "we needed to
; change only the constructors and the selectors." Extended here to all 6
; arithmetic node kinds (SICP's base text only has +/*; this engine also
; has explicit sub/neg/div/pow nodes, each with their own identities).
;
; This is a real contract change from a "dumb" 1:1 structural builder:
; makeExprMul(1, x) now returns x itself, NOT an exprMul node wrapping it.
; Any code downstream must not assume "the result of makeExprMul is always
; an exprMul?" -- check exprKind on the result, don't assume the
; constructor's name tells you the result's node kind.
;
; Why bother, beyond tidiness: diffExpr.scm's planned rule dispatch pattern-
; matches on node SHAPE (e.g. "is this pow's exponent a bare exprNum?" to
; pick the constant-exponent power rule vs. the a^u rule). Two places in
; calculus.md's own roadmap feed a diffExpr *output* back in as a new
; diffExpr *input* -- L'Hopital's rule (Phase 2, iterative re-differentiation
; of numerator/denominator) and second derivatives (Phase 3, curve
; sketching). A constant left un-collapsed as exprMul(exprNum 1, exprNum 2)
; instead of plain exprNum 2 could dodge exactly that kind of structural
; check on the next pass. Eager collapse at construction time means every
; intermediate tree diffExpr ever builds is already in this minimal shape,
; not just the final output after some later pass gets to it -- and it
; prevents cruft compounding outward through nested chain-rule calls the
; way an unreduced fraction grows through a multi-step computation.
;
; None of this attempts real polynomial normalization (combining "2x+3x"
; into "5x" needs the existing expand() machinery, out of scope here per
; this file's own header) -- only the purely local, structural identities
; below, mirroring SICP's own explicitly narrow scope for make-sum/
; make-product.

; SICP's =number? helper, adapted to exprNum nodes.
(define (exprIsLiteral? e n) (and (exprNum? e) (= (exprNumValue e) n)))

(define (makeExprAdd a b)
    (cond
        ((exprIsLiteral? a 0) b)
        ((exprIsLiteral? b 0) a)
        ((and (exprNum? a) (exprNum? b)) (makeExprNum (+ (exprNumValue a) (exprNumValue b))))
        ; a+(-b) -> a-b -- see exprToString's own "round-trip hazards" note:
        ; a bare neg rendered as a non-leading add/sub/mul/div operand
        ; produces an unparseable "+-"/"--"/"*-" sequence, not just an
        ; ugly one. exprNegOperand(b) is guaranteed to never itself be a
        ; neg node (makeExprNeg always collapses double negation on the
        ; way in), so this can't bounce back and forth with makeExprSub's
        ; own symmetric case below.
        ((exprNeg? b) (makeExprSub a (exprNegOperand b)))
        ('t (rawMakeExprAdd a b))))

(define (makeExprSub a b)
    (cond
        ((exprIsLiteral? b 0) a)
        ; 0-b simplifies to -b rather than staying a sub node -- a real
        ; simplification SICP has no analog for (it has no sub node at
        ; all, only addition of possibly-negative numbers).
        ((exprIsLiteral? a 0) (makeExprNeg b))
        ((and (exprNum? a) (exprNum? b)) (makeExprNum (- (exprNumValue a) (exprNumValue b))))
        ; a-(-b) -> a+b -- same round-trip-safety reason as makeExprAdd's
        ; symmetric case above.
        ((exprNeg? b) (makeExprAdd a (exprNegOperand b)))
        ('t (rawMakeExprSub a b))))

(define (makeExprNeg a)
    (cond
        ((exprNum? a) (makeExprNum (- (exprNumValue a))))
        ; double negation cancels: -(-x) = x. Another case SICP has no
        ; analog for, same reason as makeExprSub above.
        ((exprNeg? a) (exprNegOperand a))
        ('t (rawMakeExprNeg a))))

(define (makeExprMul a b)
    (cond
        ((or (exprIsLiteral? a 0) (exprIsLiteral? b 0)) (makeExprNum 0))
        ((exprIsLiteral? a 1) b)
        ((exprIsLiteral? b 1) a)
        ; (-1)*b and a*(-1) collapse to a neg node rather than staying a
        ; mul-by-literal-negative-one -- keeps "-1" from ever lingering
        ; around as a multiplicand in output diffExpr builds.
        ((exprIsLiteral? a -1) (makeExprNeg b))
        ((exprIsLiteral? b -1) (makeExprNeg a))
        ((and (exprNum? a) (exprNum? b)) (makeExprNum (* (exprNumValue a) (exprNumValue b))))
        ; Pull a buried negation out to wrap the whole product instead of
        ; leaving it as a non-leading operand -- same round-trip-safety
        ; motivation as makeExprAdd/makeExprSub above, plus it's the
        ; standard CAS normalization of keeping negation as the outermost
        ; operation rather than buried inside a product. Terminates: each
        ; inner makeExprMul call receives an unwrapped (guaranteed
        ; non-neg) operand, and if BOTH a and b were negated, the two
        ; resulting makeExprNeg wraps collapse back to a positive product
        ; via makeExprNeg's own double-negation rule -- (-p)*(-q) reduces
        ; to plain p*q, correctly.
        ((exprNeg? a) (makeExprNeg (makeExprMul (exprNegOperand a) b)))
        ((exprNeg? b) (makeExprNeg (makeExprMul a (exprNegOperand b))))
        ('t (rawMakeExprMul a b))))

(define (makeExprDiv a b)
    (cond
        ; Division by literal zero is a hard error here, not a silently
        ; constructed undefined node -- a well-formed input's constant
        ; denominator can never legitimately be 0, so reaching this means
        ; something upstream (parsing or a differentiation rule) already
        ; went wrong.
        ((exprIsLiteral? b 0) (error #f "makeExprDiv: division by literal zero" a))
        ((exprIsLiteral? a 0) (makeExprNum 0))
        ((exprIsLiteral? b 1) a)
        ((and (exprNum? a) (exprNum? b)) (makeExprNum (/ (exprNumValue a) (exprNumValue b))))
        ; Same buried-negation pull-out as makeExprMul above, same
        ; termination argument.
        ((exprNeg? a) (makeExprNeg (makeExprDiv (exprNegOperand a) b)))
        ((exprNeg? b) (makeExprNeg (makeExprDiv a (exprNegOperand b))))
        ; A literal NEGATIVE denominator has the exact same round-trip
        ; hazard as a buried neg above, just a shape the exprNeg? checks
        ; don't catch -- exprNum(-1) is a plain negative-valued leaf, not
        ; an <expr-neg> record wrapping anything, so e.g. div(x^-1, -1)
        ; (which the power rule's antiderivative formula genuinely
        ; produces) would render as "x^-1/-1" -- not valid syntax this
        ; engine's own grammar can read back, since only "^-<int>" has a
        ; bare-negative-exponent shorthand, never "/-<int>". Pulling the
        ; sign out here avoids ever constructing that shape at all, and
        ; matches ordinary convention (prefer -a/b over a/-b) besides.
        ((and (exprNum? b) (< (exprNumValue b) 0)) (makeExprNeg (makeExprDiv a (makeExprNum (- (exprNumValue b))))))
        ('t (rawMakeExprDiv a b))))

(define (makeExprPow base exponent)
    (cond
        ((exprIsLiteral? exponent 0) (makeExprNum 1))
        ((exprIsLiteral? exponent 1) base)
        ; 1^n = 1 regardless of what n is, even symbolic -- always safe.
        ((exprIsLiteral? base 1) (makeExprNum 1))
        ; 0^n = 0 only safe to fold when n is a literal POSITIVE number --
        ; 0^(-1) is undefined and 0^x for symbolic x could be anything
        ; depending on what x turns out to be, so this stays conservative
        ; (exponent=0 is already handled above, so exponent here is never 0).
        ((and (exprIsLiteral? base 0) (exprNum? exponent) (> (exprNumValue exponent) 0)) (makeExprNum 0))
        ; Constant-folding literal^literal is only safe when the exponent
        ; is an exact INTEGER -- exprNum holds exact rationals generally,
        ; and a fractional exponent on a literal base (e.g. 2^(1/2)) is
        ; irrational in general, which would break exprNum's "exact
        ; rational" invariant. Left as a raw pow node instead; this matches
        ; how fractional powers are handled via the separate `sqrt` apply
        ; node elsewhere in this file rather than through exprPow at all.
        ((and (exprNum? base) (exprNum? exponent) (integer? (exprNumValue exponent)))
            (makeExprNum (expt (exprNumValue base) (exprNumValue exponent))))
        ('t (rawMakeExprPow base exponent))))

; operand! -- factorial is only defined here for a nonnegative integer
; (no Gamma-function generalization -- out of scope, matching this
; engine's posture everywhere else: elementary operations only). A
; literal operand folds immediately (reusing factorial.scm's own
; `factorial`, loaded well before this file) or errors immediately if
; it's a literal but invalid (negative, or a non-integer rational) --
; same "a malformed literal case can never legitimately become valid
; later" reasoning as makeExprDiv's division-by-literal-zero check
; above. A non-literal (symbolic) operand -- "n!", "(n+1)!" -- stays an
; unfolded node; evaluating THAT is limitExpr.scm's evalExprAt's job
; (see its own factorial arm), not this constructor's.
(define (makeExprFactorial operand)
    (cond
        ((and (exprNum? operand) (integer? (exprNumValue operand)) (>= (exprNumValue operand) 0))
            (makeExprNum (factorial (exprNumValue operand))))
        ((exprNum? operand)
            (error #f "makeExprFactorial: factorial is only defined for a nonnegative integer" operand))
        ('t (rawMakeExprFactorial operand))))

; func is a symbol, one of '(sin cos tan sec csc cot exp ln log sqrt abs
; arcsin arccos arctan) -- see exprApplyKnownFuncs below. Not enforced
; by the record type itself (kept
; as a plain symbol field, same discipline ms-symbol's `category` uses --
; see mathSymbolClass.scm's ms-symbol, which validates at the constructor
; wrapper rather than the record type); makeExprApplyChecked below is the
; validating constructor callers should actually use.
(define-record-type (<expr-apply> makeExprApply exprApply?)
    (fields
        (immutable func exprApplyFunc)
        (immutable arg exprApplyArg)))

; abs added for calculus.md's Phase 3 integration extensions (intExpr.scm)
; -- integral tables write ln(x) as ln|x| for a reason: ln is undefined
; for a negative argument, and the antiderivative needs to be valid
; wherever the ORIGINAL integrand was, not just on the positive half of
; x's domain. No differentiation rule for abs exists in diffExpr.scm
; (diffExprApply's own unsupported-function fallback errors cleanly if
; someone tries) -- abs only needs to be constructible/renderable/
; evaluable, not differentiable, for this to be correct.
; sec/csc/cot added for the reciprocal trig functions (differentiation,
; and the specific integration antiderivative pairs intExpr.scm knows --
; see its own header). arcsin/arccos/arctan added so ∫dx/(1+x^2)-shaped
; integrals can produce arctan(x) etc. as real output, and so those
; functions are differentiable for round-trip verification -- asin/acos/
; atan are accepted as PARSER input spellings for the same three
; canonical symbols (see exprParse.scm's exprFuncNameTable), but the
; canonical AST symbol is always the arc- spelling.
(define exprApplyKnownFuncs '(sin cos tan sec csc cot exp ln log sqrt abs arcsin arccos arctan))

; Validating wrapper -- exprParse.scm should build every exprApply node
; through this, not the raw constructor, so a typo'd or unsupported
; function name fails fast at construction instead of surfacing later as a
; silent "unknown function" case falling through some cond in diffExpr.scm.
(define (makeExprApplyChecked func arg)
    (if (memv func exprApplyKnownFuncs)
        (makeExprApply func arg)
        (error #f "makeExprApplyChecked: unsupported function" func)))

; Returns a tag symbol identifying which of the 11 node kinds e is --
; '(num evar add sub neg mul div pow apply sum factorial). Lets callers
; (diffExpr.scm's structural recursion, in particular) dispatch with a
; single `case` rather than an 11-armed `cond` of predicate calls at
; every recursion site.
;
; NOTE for every downstream `case (exprKind e)` this tag feeds: Chez's
; `case` silently returns an unspecified value (not an error) on an
; unmatched datum -- see diffExpr.scm's diffExprApply comment for the bug
; this already caused once. Every exhaustive case-dispatch elsewhere in
; this engine has been swept to add an explicit `sum` arm (either real
; support or a clear "not supported" error) alongside adding this tag --
; do the same for any NEW exhaustive exprKind dispatch written later.
(define (exprKind e)
    (cond
        ((exprNum? e)   'num)
        ((exprEvar? e)  'evar)
        ((exprAdd? e)   'add)
        ((exprSub? e)   'sub)
        ((exprNeg? e)   'neg)
        ((exprMul? e)   'mul)
        ((exprDiv? e)   'div)
        ((exprPow? e)   'pow)
        ((exprApply? e) 'apply)
        ((exprSum? e)   'sum)
        ((exprFactorial? e) 'factorial)
        ('t (error #f "exprKind: not an expr node" e))))

; ---- exprToString: renders an AST back into the engine's ordinary infix
;      notation (the same surface syntax exprParse.scm will accept as
;      input -- round-trippable, not just readable).
;
; Parenthesization is a precedence-driven `wrap`, deliberately erring
; conservative (redundant parens over ambiguous or, worse, silently
; misparsed output) in two places that aren't obvious:
;
;   - A div node's denominator gets parenthesized unless it's a bare atom
;     or a pow -- specifically because this engine's own division grammar
;     (see expandParse.scm's parseProductH, and the live example worked
;     through this session: "(x-2)(x+1)/(x-2)x") binds implicit
;     multiplication AFTER a '/' to the whole quotient, left-to-right, NOT
;     into the denominator. A bare "a/b*c" denominator here would silently
;     round-trip to the WRONG tree if re-parsed -- exprDivDenom must stay
;     parenthesized for any non-atomic case to actually preserve grouping.
;   - exprPow's base and exponent are both parenthesized unless they're
;     bare atoms, even though some of those parens are technically
;     redundant (e.g. sin(x)^2 doesn't need them since apply is already
;     atom-precedence) -- this keeps every ^ case uniformly unambiguous
;     rather than relying on right-associativity edge cases (e.g.
;     distinguishing (x^2)^3 from x^(2^3)) being reasoned about correctly
;     at every call site.
;
; Precedence ranks (higher binds tighter): atom=5 (num/evar/apply),
; pow=4, neg=3, mul/div=2, add/sub=1.

(define (exprPrec e)
    (case (exprKind e)
        ; A NON-INTEGER rational literal prints as "a/b", so it must rank as
        ; a division (2), not an atom (5) (2026-09-19). As an atom it was
        ; printed bare after "/" or as a power base: the derivative quotient
        ; 3/(3x+1) divided by the literal 1/2 printed as "3/(3*x+1)/1/2",
        ; which re-parses left-to-right as 3/(2(3x+1)) -- and exprSimplify
        ; round-trips through that string, silently turning 6/(3x+1) into
        ; 3/(6x+2). Likewise (1/2)^x printed as "1/2^x" = 1/(2^x). At rank 2
        ; it is parenthesized exactly where a division would be.
        ((num) (if (integer? (exprNumValue e)) 5 2))
        ((evar apply sum factorial) 5)
        ((pow) 4)
        ((neg) 3)
        ((mul div) 2)
        ((add sub) 1)))

; Renders child, parenthesizing it if its own precedence is below minPrec.
(define (exprWrap child minPrec)
    (if (< (exprPrec child) minPrec)
        (string-append "(" (exprToString child) ")")
        (exprToString child)))

(define (exprToString e)
    (case (exprKind e)
        ((num)   (number->string (exprNumValue e)))
        ((evar)  (symbol->string (exprEvarName e)))
        ((add)   (string-append (exprWrap (exprAddLeft e) 1) "+" (exprWrap (exprAddRight e) 1)))
        ; right side of '-' needs strictly higher precedence than '+'/'-'
        ; itself (minPrec 2, not 1) -- a-(b+c) is not the same as a-b+c.
        ((sub)   (string-append (exprWrap (exprSubLeft e) 1) "-" (exprWrap (exprSubRight e) 2)))
        ((neg)   (string-append "-" (exprWrap (exprNegOperand e) 2)))
        ((mul)   (string-append (exprWrap (exprMulLeft e) 2) "*" (exprWrap (exprMulRight e) 2)))
        ; numerator only needs to block add/sub (minPrec 2); denominator
        ; needs the much stricter minPrec 4 -- see the div-grouping note
        ; in this file's own header comment above.
        ((div)   (string-append (exprWrap (exprDivNumer e) 2) "/" (exprWrap (exprDivDenom e) 4)))
        ; A non-integer literal exponent (e.g. 1/2) needs FORCED parens even
        ; though exprPrec ranks every exprNum as atom-precedence -- unlike
        ; an integer, "1/2" isn't one token when re-tokenized: "x^1/2"
        ; re-parses as (x^1)/2 (readTokenPower/parseExprFactorPower both
        ; only special-case a bare int or the "^-<int>" shorthand right
        ; after '^', never a bare fraction), silently changing the value.
        ; "x^(1/2)" is required for a correct round-trip. Negative INTEGER
        ; exponents (x^-3) are fine unparenthesized -- both parsers special-
        ; case that shorthand explicitly.
        ((pow)   (string-append (exprWrap (exprPowBase e) 5) "^"
                     (if (and (exprNum? (exprPowExponent e)) (not (integer? (exprNumValue (exprPowExponent e)))))
                         (string-append "(" (exprToString (exprPowExponent e)) ")")
                         (exprWrap (exprPowExponent e) 5))))
        ((apply) (string-append (symbol->string (exprApplyFunc e)) "(" (exprToString (exprApplyArg e)) ")"))
        ((sum)   (string-append "sum(" (exprToString (exprSumTerm e)) "," (symbol->string (exprSumIndexVar e))
                     "," (exprToString (exprSumLower e)) "," (exprToString (exprSumUpper e)) ")"))
        ; minPrec 5 (atom-only) here, NOT 4 -- unlike every other wrap
        ; call in this function, a pow-precedence operand genuinely
        ; needs parens before "!": exprParse.scm attaches a postfix "!"
        ; to a FACTOR'S BASE before "^" is ever applied (see its own
        ; comment), so an unparenthesized "n^2!" would re-parse as
        ; n^(2!), not (n^2)! -- a real round-trip hazard the other
        ; operators here don't have, since none of them sit between "^"
        ; and atom-precedence the way "!" needs to.
        ((factorial) (string-append (exprWrap (exprFactorialOperand e) 5) "!"))))

; ---- Printing AST nodes (2026-09-19) ----
; Every intExpr/diffExpr/limitExpr error passes the offending expression as
; an irritant, and dispatcher.scm's safeApplyCommand formats caught errors
; with display-condition -- so users saw raw record dumps like
;   ... out of scope with irritant #[#{<expr-div> gsrk0thwl5m33v7sg9yzaad40-0} #[#{<expr-num> ...
; for EVERY failed @:icalc (1/(1+cos(x)), sin(x^2)*cos(x), ...). A record
; writer makes write/display (and therefore display-condition) print the
; node as its ordinary rendered expression instead:
;   ... out of scope with irritant 1/(1+cos(x))
; Fixed here, once, for every caller and every command, rather than at each
; of the ~70 error sites or in the shared error formatter -- the text of
; every OTHER error (strings, numbers, symbols as irritants) is unchanged.
; Long expressions are cut at 200 characters so an error message can't
; balloon into a wall of text. The rendering happens at print time
; (exprToString is defined above); if it ever throws, the node prints as
; an opaque <expr> rather than turning one error into another.
(define (exprNodeText e)
    (guard (c (#t "<expr>"))
        (let ((s (exprToString e)))
            (if (> (string-length s) 200)
                (string-append (substring s 0 200) "...")
                s))))

(for-each
    (lambda (rtd) (record-writer rtd (lambda (r p wr) (display (exprNodeText r) p))))
    (list (record-type-descriptor <expr-num>) (record-type-descriptor <expr-evar>)
          (record-type-descriptor <expr-add>) (record-type-descriptor <expr-sub>)
          (record-type-descriptor <expr-neg>) (record-type-descriptor <expr-mul>)
          (record-type-descriptor <expr-div>) (record-type-descriptor <expr-pow>)
          (record-type-descriptor <expr-factorial>) (record-type-descriptor <expr-sum>)
          (record-type-descriptor <expr-apply>)))
