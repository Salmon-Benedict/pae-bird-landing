; exprParse.scm -- char-list -> exprAst.scm AST parser: the second half of
; ../calculus.md's Foundation layer (see exprAst.scm's own header for the
; node types this file builds).
;
; Depends on: helperS.scm (remove-all), mathHelp.scm (var?), PolyStoSymbol.scm
; (PolyStoSymbolH, mergeDigits), expandParse.scm (groupIndexedVars, and --
; reused directly rather than redefined -- addOp?/lparen?/rparen?/sumStop?/
; comma?, the last only used by this file's own sum(...) parsing below),
; exprAst.scm (the node types/smart constructors this file builds),
; mathSymbolClass.scm (ms-sigma-glyph, one of sum(...)'s three accepted
; spellings -- see matchSumPrefix below).
;
; ---- Tokenization: reused wholesale, not reimplemented ----
; The exact same char-list -> token-list pipeline expandParse.scm's own
; parseExpansion uses for its entry point:
;   (mergeDigits (PolyStoSymbolH (groupIndexedVars (remove-all #\space charL))))
; producing a list of exact-integer numbers and single-character symbols
; (multi-digit runs already fused by mergeDigits; indexed variables like
; x_1 already fused by groupIndexedVars). Reusing this rather than writing
; a second tokenizer keeps "3x", "x_1", spacing, etc. behaving identically
; to the existing engine everywhere the two overlap.
;
; ---- Grammar ----
;   ExprSum       ::= ['+'|'-'] ExprProduct (('+'|'-') ExprProduct)*
;   ExprProduct   ::= ExprFactor (['*'|'/'] ExprFactor)*
;   ExprFactor    ::= (FuncName '(' ExprSum ')' | '(' ExprSum ')' | ExprTerm) ['!'] ['^' ExprPowRHS]
;   ExprPowRHS    ::= '-' number        ; bare negative-int shorthand
;                    | ExprFactor       ; anything else, incl. a parenthesized
;                                         (and therefore possibly compound or
;                                         variable-containing) exponent
;   ExprTerm      ::= number | variable
;   FuncName      ::= one of sin cos tan exp ln log sqrt abs, spelled out as
;                     consecutive single-letter tokens immediately followed
;                     by '('
;
; The optional postfix '!' binds tighter than '^' (checked first, in
; parseExprFactorialSuffix below) -- "n^3!" is n^(3!), matching ordinary
; convention. Only sum(...) (exprParse's own sum(term,indexVar,lower,
; upper) matcher, a fourth ExprFactor alternative with its own 4-argument
; comma grammar -- see matchSumPrefix below) and factorial ('!') sit
; outside this summary; both are documented in full where they're parsed.
;
; This is expandParse.scm's own Sum/Product/Factor grammar (see that file's
; header comment) with two changes: a function-call alternative added to
; Factor, and Factor's trailing power generalized from "nonnegative integer
; only" to "any Factor, including a fully parenthesized -- and therefore
; possibly variable-containing -- exponent", since exprPow's exponent field
; (unlike expandParse's <group>'s groupPow) is a full subtree by design, not
; restricted to an integer. Division keeps the EXACT SAME left-to-right,
; implicit-multiplication-binds-like-'*' convention expandParse.scm's own
; parseProductH already documents and that this session worked through live
; ("(x-2)(x+1)/(x-2)x") -- this file does not introduce a second, different
; division convention for calculus input.
;
; Unlike expandParse.scm's parseTerm, ExprTerm here is just a single bare
; number or variable -- no fused "coefficient*variable" term type, since
; that fusion existed there only to serve <poly>'s flat monomial
; representation. Here "3x" is simply two adjacent Factors (3 and x)
; combined by ExprProduct's ordinary implicit multiplication.
;
; A parenthesized exponent is NOT force-evaluated down to a plain rational
; the way expandParse.scm's readParenPower does (which explicitly rejects
; any variable in the exponent) -- "x^(a+1)" and even "x^y" parse just fine
; here; it's diffExpr.scm's later rule dispatch, not this parser, that
; decides which such shapes it actually knows how to differentiate.
;
; ---- Function-name recognition ----
; matchFuncPrefix generalizes trigonometry.scm's findFuncCall (whole-string
; substring search for "sin(" et al.) to this file's token-list
; representation, and to the fuller function set '(sin cos tan exp ln log
; sqrt abs). It only succeeds on a FULL name match immediately followed by
; '(' -- the same requirement findFuncCall itself relies on -- so a bare
; variable sharing a first letter with a function name (a lone 'e', or 's'
; 'i' 'n' as three genuinely separate implicitly-multiplied variables with
; no following '(') still parses as ordinary variable(s), never misfires
; into a function call. None of the eight names is a letter-run prefix of
; another (sin/sqrt both start 's' but diverge at the second letter), so
; plain sequential try-each-entry matching is unambiguous.

; abs added alongside the original seven -- see exprAst.scm's own header
; for why abs exists at all (intExpr.scm's ln(abs(x))-shaped
; antiderivatives). No prefix collision: none of the other seven names
; starts with 'a'.
; sec/csc/cot added for the reciprocal trig functions (diffExpr.scm's
; derivative rules, and the specific antiderivative pairs intExpr.scm
; knows -- see its own header). No prefix collision with sin/cos/tan
; (different first letters) or with sech/csch/coth (still in
; exprUnsupportedFuncNameTable below -- matchFuncPrefix's own immediate-
; '(' requirement means "sech(" can never be mistaken for "sec(...)",
; same non-collision argument as this table's other entries).
;
; arcsin/arccos/arctan added so intExpr.scm's arctan(x)-shaped
; denominator-pattern results (see its own header) are real,
; differentiable output, not just a string. Both the short (asin) and
; long (arcsin) spellings map to the SAME canonical symbol -- a table
; entry is just (symbol . letters), nothing stops two entries sharing a
; symbol. No collision with asinh/acosh/atanh (still unsupported below,
; same immediate-'(' non-collision reasoning) or with abs (diverges at
; the 2nd letter).
(define exprFuncNameTable
    (list (cons 'sin  '(s i n))
          (cons 'cos  '(c o s))
          (cons 'tan  '(t a n))
          (cons 'sec  '(s e c))
          (cons 'csc  '(c s c))
          (cons 'cot  '(c o t))
          (cons 'exp  '(e x p))
          (cons 'ln   '(l n))
          (cons 'log  '(l o g))
          (cons 'sqrt '(s q r t))
          (cons 'abs  '(a b s))
          (cons 'arcsin '(a r c s i n))
          (cons 'arcsin '(a s i n))
          (cons 'arccos '(a r c c o s))
          (cons 'arccos '(a c o s))
          (cons 'arctan '(a r c t a n))
          (cons 'arctan '(a t a n))))

; ---- Unsupported-but-recognizable function names ----
; Without this table, a name like "sec"/"cot"/"sinh"/"asin" immediately
; followed by '(' falls all the way through matchFuncPrefix (below) to
; ordinary implicit multiplication -- "sec(x)" silently parses as the
; three separate one-letter variables s*e*c times (x), producing a
; garbage-but-numeric-looking answer (e.g. "sec(x)^2" integrating as if
; it were literal s*e*c*x^2) instead of any indication the function
; itself isn't supported. This table exists purely to catch that shape
; and fail loudly and specifically -- naming exactly which function
; isn't supported -- rather than the caller discovering it from a wrong
; answer. Checked AFTER exprFuncNameTable (see matchFuncPrefix's own
; call site in parseExprFactorBase); no ambiguity between the two
; tables is possible since every entry in both requires the FULL letter
; run to be immediately followed by '(' (same non-collision argument as
; exprFuncNameTable's own header note).
; sec/csc/cot/asin/acos/atan/arcsin/arccos/arctan REMOVED from here --
; all now genuinely supported, see exprFuncNameTable above. Inverse
; secant/cosecant/cotangent and every hyperbolic function stay
; unsupported (out of scope: no diffExpr/intExpr rules exist for them).
(define exprUnsupportedFuncNameTable
    (list (cons "sinh"   '(s i n h))
          (cons "cosh"   '(c o s h))
          (cons "tanh"   '(t a n h))
          (cons "sech"   '(s e c h))
          (cons "csch"   '(c s c h))
          (cons "coth"   '(c o t h))
          (cons "asec"   '(a s e c))
          (cons "acsc"   '(a c s c))
          (cons "acot"   '(a c o t))
          (cons "asinh"  '(a s i n h))
          (cons "acosh"  '(a c o s h))
          (cons "atanh"  '(a t a n h))
          (cons "arcsec" '(a r c s e c))
          (cons "arccsc" '(a r c c s c))
          (cons "arccot" '(a r c c o t))))

; ---- sum(term,indexVar,lower,upper) -- kept OUT of exprFuncNameTable/
;      matchFuncPrefix above deliberately: every table entry there is a
;      single-arg (func arg) call built via makeExprApplyChecked, but sum
;      needs 4 comma-separated arguments, one of which (indexVar) is a
;      bare variable NAME, not a parsed subtree -- a different enough
;      shape to need its own matcher/parser rather than stretching
;      matchFuncPrefix's contract to fit. No prefix collision with the
;      table above (none of those 8 names starts with 's'-'u'-'m' as a
;      run; sin/sqrt both start 's' but diverge at the 2nd letter, same
;      as matchFuncPrefix's own note already established).
;
; Three interchangeable spellings, all producing the exact same
; <expr-sum> node -- "sum(...)", "sigma(...)" (word form), and
; "∑(...)" (mathSymbolClass.scm's ms-sigma-glyph, the actual U+2211
; summation-operator glyph, NOT the Greek letter Σ -- see that file's
; own note on the distinction). No collision between "sigma" and "sin"/
; "sqrt": both share a "s"/"si" prefix but diverge by the 3rd letter
; ('g' vs 'n'), same non-ambiguity argument as the note above. The
; glyph is a single token on its own (PolyStoSymbolH turns any one
; character it doesn't otherwise recognize into a single-character
; symbol, the same mechanism that makes every other bare-letter token
; here a length-1 symbol), so it's checked the same way as the 3-/5-
; token word forms, just with a 1-token prefix list.
(define sumPrefixSpellings (list '(s u m) '(s i g m a) (list (string->symbol ms-sigma-glyph))))

(define (matchSumPrefix tokL)
    (let try ((spellings sumPrefixSpellings))
        (if (null? spellings)
            #f
            (let* ((prefix (car spellings)) (n (length prefix)))
                (if (and (tokensStartWith? tokL prefix)
                         (> (length tokL) n)
                         (lparen? (list-ref tokL n)))
                    (list-tail tokL (+ n 1))
                    (try (cdr spellings)))))))

; tokL is positioned just after "sum(". Parses term, ',', indexVar
; (required to reduce to a bare exprEvar -- "sum(n^2,n+1,1,10)" is a
; clear error, not a silent misparse), ',', lower, ',', upper, ')'.
(define (expectComma tokL context)
    (if (and (pair? tokL) (comma? (car tokL)))
        (cdr tokL)
        (error #f (string-append "parseExprSumCall: expected ',' " context) tokL)))

(define (parseExprSumCall tokL)
    (let* ((termResult (parseExprSum tokL))
           (afterTerm (expectComma (cdr termResult) "after sum's term"))
           (indexResult (parseExprSum afterTerm))
           (indexExpr (car indexResult)))
        (if (not (exprEvar? indexExpr))
            (error #f "parseExprSumCall: sum's index must be a bare variable, e.g. sum(n^2,n,1,10)" indexExpr))
        (let* ((afterIndex (expectComma (cdr indexResult) "after sum's index variable"))
               (lowerResult (parseExprSum afterIndex))
               (afterLower (expectComma (cdr lowerResult) "after sum's lower bound"))
               (upperResult (parseExprSum afterLower)))
            (if (or (null? (cdr upperResult)) (not (rparen? (car (cdr upperResult)))))
                (error #f "parseExprSumCall: expected a closing ')' after sum's upper bound" tokL))
            (cons (makeExprSum (car termResult) (exprEvarName indexExpr) (car lowerResult) (car upperResult))
                (cdr (cdr upperResult))))))

(define (tokensStartWith? tokL prefixSyms)
    (cond
        ((null? prefixSyms) 't)
        ((null? tokL) #f)
        ((eqv? (car tokL) (car prefixSyms)) (tokensStartWith? (cdr tokL) (cdr prefixSyms)))
        ('t #f)))

; If tokL begins with one of exprFuncNameTable's letter-runs immediately
; followed by '(', returns (cons funcSymbol tokensAfterOpenParen);
; otherwise #f.
(define (matchFuncPrefix tokL)
    (let try ((table exprFuncNameTable))
        (if (null? table)
            #f
            (let* ((func (caar table))
                   (letters (cdar table))
                   (nLetters (length letters)))
                (if (and (tokensStartWith? tokL letters)
                         (> (length tokL) nLetters)
                         (lparen? (list-ref tokL nLetters)))
                    (cons func (list-tail tokL (+ nLetters 1)))
                    (try (cdr table)))))))

; Same shape as matchFuncPrefix, against exprUnsupportedFuncNameTable
; above -- returns the matched name string, or #f.
(define (matchUnsupportedFuncPrefix tokL)
    (let try ((table exprUnsupportedFuncNameTable))
        (if (null? table)
            #f
            (let* ((name (caar table))
                   (letters (cdar table))
                   (nLetters (length letters)))
                (if (and (tokensStartWith? tokL letters)
                         (> (length tokL) nLetters)
                         (lparen? (list-ref tokL nLetters)))
                    name
                    (try (cdr table)))))))

; ---- ExprSum ----

(define (parseExprSum tokL)
    (let* ((hasSign (and (pair? tokL) (addOp? (car tokL))))
           (sign (if hasSign (car tokL) '+))
           (afterSign (if hasSign (cdr tokL) tokL))
           (prodResult (parseExprProduct afterSign))
           (firstTerm (if (eqv? sign '-) (makeExprNeg (car prodResult)) (car prodResult))))
        (parseExprSumTail firstTerm (cdr prodResult))))

(define (parseExprSumTail acc tokL)
    (cond
        ((or (null? tokL) (sumStop? (car tokL))) (cons acc tokL))
        ((addOp? (car tokL))
            (let* ((sign (car tokL))
                   (prodResult (parseExprProduct (cdr tokL))))
                (parseExprSumTail
                    (if (eqv? sign '+) (makeExprAdd acc (car prodResult)) (makeExprSub acc (car prodResult)))
                    (cdr prodResult))))
        ('t (error #f "parseExprSum: expected + or - between terms" tokL))))

; ---- ExprProduct ----

(define (parseExprProduct tokL)
    (let ((factorResult (parseExprFactor tokL)))
        (parseExprProductTail (car factorResult) (cdr factorResult))))

(define (parseExprProductTail acc tokL)
    (cond
        ((null? tokL) (cons acc tokL))
        ((eqv? (car tokL) '*)
            (let ((factorResult (parseExprFactor (cdr tokL))))
                (parseExprProductTail (makeExprMul acc (car factorResult)) (cdr factorResult))))
        ((eqv? (car tokL) '/)
            (let ((factorResult (parseExprFactor (cdr tokL))))
                (parseExprProductTail (makeExprDiv acc (car factorResult)) (cdr factorResult))))
        ((or (addOp? (car tokL)) (sumStop? (car tokL))) (cons acc tokL))
        ('t
            ; Implicit multiplication: whatever comes next (that isn't
            ; +/-/*//)/end) is another factor multiplied in -- including,
            ; per this session's own live example, binding a preceding
            ; '/'-continuation the SAME left-to-right way: "/(x-2)x" means
            ; divide by (x-2), THEN multiply by x, not divide by the whole
            ; product (x-2)x. See this file's own header note.
            (let ((factorResult (parseExprFactor tokL)))
                (parseExprProductTail (makeExprMul acc (car factorResult)) (cdr factorResult))))))

; ---- ExprFactor ----

(define (parseExprFactor tokL)
    (let* ((baseResult (parseExprFactorBase tokL))
           (factorialResult (parseExprFactorialSuffix (car baseResult) (cdr baseResult))))
        (parseExprFactorPower (car factorialResult) (cdr factorialResult))))

; Postfix "!", checked immediately after a base and BEFORE the trailing
; power check below -- so factorial binds tighter than "^" (matching
; ordinary convention: "n^3!" reads as n^(3!), not (n^3)! -- the
; exponent's own recursive parseExprFactor call is what applies this
; same check to "3!" first). Only ONE trailing "!" is consumed here,
; not repeated ones ("n!!") -- double factorial is a different,
; unrelated notation (skip-one product, not literally factorial-of-
; factorial), so silently accepting a second "!" here would risk
; misrepresenting it; a second "!" left over instead falls through to
; parseExprTerm's own "expected a number or variable" error, a clear
; failure rather than a silently wrong one.
(define (parseExprFactorialSuffix base tokL)
    (if (and (pair? tokL) (eqv? (car tokL) '!))
        (cons (makeExprFactorial base) (cdr tokL))
        (cons base tokL)))

; Parses just the "base" part (function call, parenthesized group, or bare
; term), with no trailing power handling -- factored out so the power
; check is written once, uniformly, for all three alternatives.
(define (parseExprFactorBase tokL)
    (let ((sumTail (matchSumPrefix tokL))
          (call (matchFuncPrefix tokL))
          (unsupportedName (matchUnsupportedFuncPrefix tokL)))
        (cond
            (sumTail (parseExprSumCall sumTail))
            (call
                (let* ((func (car call))
                       (afterParen (cdr call))
                       (argResult (parseExprSum afterParen)))
                    (if (or (null? (cdr argResult)) (not (rparen? (car (cdr argResult)))))
                        (error #f "parseExprFactor: expected a closing ')' after function argument" tokL))
                    (cons (makeExprApplyChecked func (car argResult)) (cdr (cdr argResult)))))
            (unsupportedName
                (error #f (string-append "parseExprFactor: '" unsupportedName "' is not a supported function -- only sin/cos/tan/sec/csc/cot/exp/ln/log/sqrt/abs/arcsin/arccos/arctan are supported") tokL))
            ((and (pair? tokL) (lparen? (car tokL)))
                (let ((sumResult (parseExprSum (cdr tokL))))
                    (if (or (null? (cdr sumResult)) (not (rparen? (car (cdr sumResult)))))
                        (error #f "parseExprFactor: expected a closing ')'" tokL))
                    (cons (car sumResult) (cdr (cdr sumResult)))))
            ('t (parseExprTerm tokL)))))

; Checks for a trailing '^' after a base, handling the bare-negative-int
; exponent shorthand ("x^-3", matching expandParse.scm's readTokenPower
; convenience) and otherwise recursing into a full ExprFactor for the
; exponent -- which naturally covers a bare positive number, a bare
; variable, a function call, or (via the parenthesized-group alternative
; recursing back into a full ExprSum) a compound and/or variable-containing
; exponent like "x^(a+1)".
(define (parseExprFactorPower base tokL)
    (cond
        ((or (null? tokL) (not (eqv? (car tokL) '^))) (cons base tokL))
        ((and (pair? (cdr tokL)) (eqv? (cadr tokL) '-)
              (pair? (cddr tokL)) (number? (caddr tokL)))
            (cons (makeExprPow base (makeExprNum (- (caddr tokL)))) (cdddr tokL)))
        ('t
            (let ((expResult (parseExprFactor (cdr tokL))))
                (cons (makeExprPow base (car expResult)) (cdr expResult))))))

(define (parseExprTerm tokL)
    (cond
        ((null? tokL) (error #f "parseExprTerm: expected a number or variable" tokL))
        ((number? (car tokL)) (cons (makeExprNum (car tokL)) (cdr tokL)))
        ((var? (car tokL)) (cons (makeExprEvar (car tokL)) (cdr tokL)))
        ('t (error #f "parseExprTerm: expected a number or variable" tokL))))

; ---- Top-level entry point ----

(define (exprParse charL)
    (let* ((tokL (mergeDigits (PolyStoSymbolH (groupIndexedVars (remove-all #\space charL)))))
           (sumResult (parseExprSum tokL)))
        (if (not (null? (cdr sumResult)))
            (error #f "exprParse: unexpected trailing input" (cdr sumResult)))
        (car sumResult)))
