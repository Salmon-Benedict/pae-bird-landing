; exprSimplify.scm -- exprAst.scm AST simplification, bridging pure-polynomial
; subtrees through the existing engine's own expand()/classifyFrac
; normalization. Moved out of diffExpr.scm (2026-08-15) into its own file so
; it's a genuinely separate, nameable step other control flow -- most
; notably intExpr.scm's Integration By Parts loop -- can call out to
; explicitly, the same way it calls out to integrationByParts.scm for the
; IBP algorithm itself, rather than simplification being an implicit detail
; buried inside whichever caller happens to remember to invoke it.
;
; Named exprSimplify.scm, not simplify.scm -- simplify.scm already exists
; and is a completely unrelated file (the low-level <poly>-record
; simplification pipeline: simplify/applysigns/addem/dropZeros/powers,
; loaded very early, right after PolyStoSymbol.scm). Confirmed live: an
; earlier draft of this file used the name simplify.scm and clobbered that
; file, breaking every command downstream of the polynomial engine
; (surfaced as a load-time "variable dropZeros is not bound" crash) -- keep
; these two files' names distinct.
;
; Depends on: exprAst.scm, exprParse.scm, and polyBridge.scm's
; ms-from-str/ms-poly-str -- which themselves need the full chain
; dispatcher.scm already loads before polyBridge.scm (expandParse.scm,
; mathSymbolClass.scm, etc.). Load this file after exprParse.scm, same
; position it occupied inside diffExpr.scm before the move (that file's own
; header used to carry this same dependency note).
;
; Callers (diffExpr.scm's own diffExpr, implicitDiff.scm, intExpr.scm,
; limitExpr.scm, curveSketch.scm, calcAnalysis.scm, areaBetweenCurves.scm,
; riemannLimitIntegral.scm) are unaffected by this move -- Chez resolves a
; top-level define's free references at CALL time, not load time, so none
; of them needed to change; only load-engine.scm's own load list needed a
; new entry for this file (same reasoning intExpr.scm's own header already
; documents for its forward reference to integrationByParts.scm's
; ibpStep/ibpFirstStep).

; A subtree is bridgeable if it contains no `apply` node anywhere (the
; existing engine has no concept of sin/cos/exp/etc.) AND every pow node's
; exponent is a literal number -- readTokenPower/readParenPower
; (expandParse.scm) only ever accept a numeric exponent, never a variable
; one, so e.g. 2^x must stay an exprAst node, never get bridged.
(define (exprIsPurePoly? e)
    (case (exprKind e)
        ((num evar) 't)
        ((apply) #f)
        ((neg) (exprIsPurePoly? (exprNegOperand e)))
        ((add) (and (exprIsPurePoly? (exprAddLeft e)) (exprIsPurePoly? (exprAddRight e))))
        ((sub) (and (exprIsPurePoly? (exprSubLeft e)) (exprIsPurePoly? (exprSubRight e))))
        ((mul) (and (exprIsPurePoly? (exprMulLeft e)) (exprIsPurePoly? (exprMulRight e))))
        ((div) (and (exprIsPurePoly? (exprDivNumer e)) (exprIsPurePoly? (exprDivDenom e))))
        ((pow) (and (exprIsPurePoly? (exprPowBase e)) (exprNum? (exprPowExponent e))))
        ; A sum(...) is never bridgeable -- same as apply above (the
        ; existing expand()/classifyFrac machinery has no concept of
        ; summation, only of `apply` functions).
        ((sum) #f)
        ; Same reasoning for factorial -- no concept of "!" either.
        ((factorial) #f)))

; Renders e, parses it as a polynomial string via the existing engine
; (ms-from-str: parseExpansion + classifyFrac -- handles genuine rational
; expressions, not just flat polynomials), and renders the normalized
; result back through ms-poly-str's round-trip-safe (parseable?=#t)
; convention, then re-parses THAT into a fresh exprAst tree.
(define (bridgeSimplifyPurePoly e)
    (exprParse (string->list (ms-poly-str (ms-from-str (exprToString e))))))

; Bottom-up, but checks the WHOLE subtree at each node before recursing
; into children -- so the bridge gets the LARGEST possible pure-poly
; chunk in one shot rather than fragmenting it node-by-node (cross-term
; cancellation like "x+1-x -> 1" only happens when expand() sees the
; whole sum at once, not its pieces individually). A node containing an
; `apply` anywhere recurses into its children instead, each independently
; eligible for bridging.
(define (exprSimplify e)
    (if (exprIsPurePoly? e)
        (bridgeSimplifyPurePoly e)
        (case (exprKind e)
            ((num evar) e)
            ((neg) (makeExprNeg (exprSimplify (exprNegOperand e))))
            ((add) (makeExprAdd (exprSimplify (exprAddLeft e)) (exprSimplify (exprAddRight e))))
            ((sub) (makeExprSub (exprSimplify (exprSubLeft e)) (exprSimplify (exprSubRight e))))
            ((mul) (makeExprMul (exprSimplify (exprMulLeft e)) (exprSimplify (exprMulRight e))))
            ((div) (makeExprDiv (exprSimplify (exprDivNumer e)) (exprSimplify (exprDivDenom e))))
            ((pow) (makeExprPow (exprSimplify (exprPowBase e)) (exprSimplify (exprPowExponent e))))
            ((apply) (makeExprApplyChecked (exprApplyFunc e) (exprSimplify (exprApplyArg e))))
            ; sum(...) -- simplify each part independently and rebuild;
            ; term's own indexVar is a binder (exprAst.scm's own header
            ; note), not a free variable simplify needs to treat
            ; specially -- simplifying it in place is correct exactly
            ; the same way simplifying under a lambda would be.
            ((sum) (makeExprSum (exprSimplify (exprSumTerm e)) (exprSumIndexVar e)
                       (exprSimplify (exprSumLower e)) (exprSimplify (exprSumUpper e))))
            ((factorial) (makeExprFactorial (exprSimplify (exprFactorialOperand e)))))))
