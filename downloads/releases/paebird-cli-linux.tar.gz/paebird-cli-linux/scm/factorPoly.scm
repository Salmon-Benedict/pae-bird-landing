; Polynomial factoring, built on top of expandParse.scm's parser and
; expand() (must be loaded first). Handles:
;   - GCF extraction (integer coefficient GCF and, per variable, the
;     minimum shared power across every term -- genuinely multivariable,
;     e.g. "2x^2y+4xy^2" -> "2xy(x+2y)")
;   - Quadratic trinomials ax^2+bx+c via the discriminant/quadratic
;     formula, which subsumes difference of squares (b=0) and perfect
;     square trinomials (discriminant=0) as special cases automatically
;   - The same discriminant/quadratic-formula approach generalized to a
;     homogeneous degree-2 polynomial in exactly two variables,
;     ax^2+bxy+cy^2 (e.g. "4x^2-9y^2" -> "(2x-3y)(2x+3y)") -- see
;     tryFactorHomogeneousTwoVar below
;   - Degree >= 3: searches for a rational root via the rational root
;     theorem and divides it out (Gauss's lemma guarantees an exact
;     integer quotient), recursively re-factoring the quotient. This
;     covers sum/difference of cubes and "biquadratic" x^4 cases as
;     special cases of root-finding, with no dedicated pattern needed
;     for either -- e.g. x^4-5x^2+4 fully factors into 4 linear terms,
;     which the C++ engine's pattern-based factorer cannot do. Still
;     single-variable-only -- there's no multivariable generalization of
;     the rational root theorem used here.
;   - Recursively re-factors any resulting sub-factor that is itself
;     still factorable (e.g. pulling a new GCF out after dividing once)
;   - Rational expressions (a variable denominator, e.g. "(x^2-1)/(x-1)"):
;     factors both sides and cancels their common factors via
;     polyCancellation (below) -- e.g. "(x^2-1)/(x-1)" -> "x+1". This is
;     deliberately factor()-only, not expand()'s -- see expandParse.scm's
;     grammar comment for why expand() leaves fractions uncancelled.
;     Still single-variable-only on both sides (see assertFactorable vs.
;     assertFactorableMulti's own comments for why this one boundary
;     didn't move along with the rest of the file).
;   - A negative integer exponent (e.g. "2x^-2+4") is handled as an
;     ordinary GCF extraction: findGCF now allows a NEGATIVE minimum
;     exponent per variable, so it comes out as its own factor (e.g.
;     "2x^-2(2x^2+1)") instead of erroring. A genuinely fractional
;     exponent (e.g. "x^(1/2)") is still unsupported -- see
;     assertNoFractionalExponent below.
;
; Ported from ../factorPoly.scm (MIT Scheme) to Chez Scheme. Changes:
;   - All 3 `any` calls -> `exists` (MIT's `any` is unbound in Chez).
;   - All 3 `(error "msg" ...)` call sites get an explicit #f who-arg.
;
; Limitations: degree >= 3 polynomials with no rational root (e.g.
; irreducible cubics) are left unfactored -- this matches what's
; mathematically possible without introducing irrational/complex
; coefficients. Beyond GCF extraction and the homogeneous-two-variable-
; quadratic pattern above, multivariable input has no further pattern
; applied (3+ variables, degree>=3 multivariable, or a non-homogeneous
; two-variable polynomial all fall through unfactored past whatever GCF
; was found) -- a genuine multivariate GCD/root-finding algorithm is out
; of scope here, matching this repo's own cpp-vs-scheme-gaps.md reasoning
; for why factor() stayed single-variable-only in the first place (the
; original C++ engine never supported multivariable factoring at all).

; Returns the variable symbol used by termList (assumes single-variable
; throughout this file), or #f if every term is a constant.
(define (polyVariable termList)
    (cond
        ((null? termList) #f)
        ((var? (var (car termList))) (var (car termList)))
        ('t (polyVariable (cdr termList)))))

; The set of every distinct variable used anywhere in termList (across
; all terms, and within a single multivariable term's own extraVars).
(define (allVariablesIn termList)
    (let ((seen '()))
        (for-each
            (lambda (term)
                (for-each
                    (lambda (v) (if (not (memq v seen)) (set! seen (cons v seen))))
                    (map car (termVarAlist term))))
            termList)
        seen))

; Guards factor()/solve()/differentiateExpr()/integrateExpr() against
; multivariable input. Checking whether any single term has non-empty
; extraVars isn't sufficient -- termList as a whole can be multivariable
; even when every individual term is single-variable, e.g. "x+y" (each
; term uses one variable, but the polynomial uses two) -- so this checks
; the distinct-variable count across the whole list instead. This also
; fixes a latent pre-existing bug: polyVariable/coeffAt only ever look at
; the *first* variable-bearing term, so factor("x+y") used to silently
; drop the y term rather than erroring.
; The predicate half of assertSingleVariable below -- pulled out
; separately so tryCancelFraction (this file, further down) can check it
; silently (skip cancellation) instead of erroring, since it runs on
; every expand() division site and must never newly reject input expand()
; already handled fine.
(define (singleVariable? termList) (<= (length (allVariablesIn termList)) 1))

(define (assertSingleVariable termList opName)
    (if (not (singleVariable? termList))
        (error #f (string-append opName ": multivariable expressions aren't supported yet") termList)))

; Guards factor() (and solveHigherDegree, solvePoly.scm) against a
; fractional coefficient reaching GCF extraction/the rational root
; theorem -- both are integer-coefficient algorithms (findGCF's gcd,
; divisorsOf) that silently ignore a term's cd otherwise, rather than
; erroring: e.g. factor("x^2/2-2") used to come back as "(x-2)(x+2)",
; which is a DIFFERENT polynomial (x^2-4, not x^2/2-2) that just
; happens to share the same roots -- a silently wrong answer, not a
; missing-feature one, found via the division feature's own testing
; since a fractional coefficient reaching factor()/solveHigherDegree was
; never previously reachable (there was no way to construct one without
; '/' support). solveLinear/solveQuadraticFull (solvePoly.scm) are NOT
; guarded by this -- both already work correctly on fractional
; coefficients via coeffAt's exact-rational arithmetic (verified), since
; neither uses gcd/divisorsOf.
(define (integerCoefficients? termList) (not (exists (lambda (term) (not (= (cd term) 1))) termList)))

(define (assertIntegerCoefficients termList opName)
    (if (not (integerCoefficients? termList))
        (error #f (string-append opName ": a fractional coefficient here isn't supported yet -- only constant-denominator division reaching a whole-number coefficient is") termList)))

; Guards expand()'s own division-cancellation hook (tryCancelFraction,
; further down) against a negative or fractional exponent reaching
; cancelMonomialTerms -- that function's per-variable "absence means no
; overlap" logic (assq defaulting to 0) is only sound when every
; exponent it sees is already known nonnegative; give it a negative
; exponent (e.g. "x^-1" against a side that doesn't have x at all) and
; min(negativeExp, 0) wrongly computes a nonzero "overlap" where there
; should be none, silently cancelling a variable that was never actually
; shared. factor()/solve() do NOT reach this predicate any more -- they
; use the more permissive assertNoFractionalExponent below instead, since
; their own negative-exponent handling (findGCF/divideOutGCF's GCF
; extraction for factor(), clearNegativeExponent for solve()) was
; specifically fixed to be sound for negative exponents; this stricter
; check stays reserved for the one path that wasn't.
(define (integerExponents? termList)
    (not (exists (lambda (term)
                 (exists (lambda (p) (not (and (integer? (cdr p)) (>= (cdr p) 0))))
                      (termVarAlist term)))
             termList)))

(define (assertIntegerExponents termList opName)
    (if (not (integerExponents? termList))
        (error #f (string-append opName ": a negative or fractional exponent here isn't supported yet") termList)))

; Guards factor()/solve() against a genuinely FRACTIONAL exponent (e.g.
; "x^(1/2)") -- unlike a negative-but-integer one (e.g. "x^-2"), that's
; still unsupported: findGCF/divideOutGCF's GCF extraction and the
; rational-root theorem/degree classification all assume an integer
; degree throughout, and there's no clearing trick analogous to
; negativeExponentShifts that turns a fractional power into an ordinary
; polynomial term. Checks every variable's exponent across the whole
; term list via termVarAlist (also catches a multivariable term's
; extraVars, not just the primary variable).
(define (hasFractionalExponent? termList)
    (exists (lambda (term)
                (exists (lambda (p) (not (integer? (cdr p)))) (termVarAlist term)))
        termList))

(define (assertNoFractionalExponent termList opName)
    (if (hasFractionalExponent? termList)
        (error #f (string-append opName ": a fractional exponent here isn't supported yet") termList)))

; Returns the (possibly fractional, e.g. from dividing by a constant --
; see expandParse.scm's foldConstantDenom) coefficient of the term at the
; given degree, as an exact rational, or 0 if no such term exists. Used
; directly in exact-rational arithmetic by solveLinear/solveQuadraticFull
; (solvePoly.scm), which therefore work correctly on fractional
; coefficients for free; factorPoly.scm's own integer-only algorithms
; (GCF/rational-root-theorem) still require integer coefficients and are
; guarded separately -- see assertIntegerCoefficients below.
(define (coeffAt termList degree)
    (cond
        ((null? termList) 0)
        ((and (var? (var (car termList))) (= (varPn (car termList)) degree) (= (varPd (car termList)) 1))
            (/ (cn (car termList)) (cd (car termList))))
        ((and (= degree 0) (not (var? (var (car termList)))))
            (/ (cn (car termList)) (cd (car termList))))
        ('t (coeffAt (cdr termList) degree))))

(define (polyDegree termList)
    (cond
        ((null? termList) 0)
        ('t (apply max (map (lambda (term) (if (var? (var term)) (varPn term) 0)) termList)))))

(define (gcdL aList) (apply gcd aList))

; A term's exponent for variable v (0 if v doesn't appear in the term at
; all), via termVarAlist (expandParse.scm) -- already multivariable-aware
; (primary var consed onto extraVars), unlike the old var()/varPn()
; single-variable-only accessors this file's degree-2/degree>=3 dispatch
; still uses for genuinely single-variable input.
(define (expOf term v)
    (let ((p (assq v (termVarAlist term))))
        (if p (cdr p) 0)))

; ---- solve()'s own negative-exponent clearing (solvePoly.scm) ----
;
; solve() can't reuse findGCF/divideOutGCF directly the way factor() does
; above: divideOutGCF also divides out the integer coefficient GCD, which
; is fine for factor() (assertFactorable/assertFactorableMulti already
; require integer coefficients before either GCF path runs) but solve()
; itself never requires that -- solveLinear/solveQuadraticFull work
; correctly on fractional coefficients directly via coeffAt's exact-
; rational arithmetic (see coeffAt's own comment above), and findGCF's
; gcd computation only ever looks at a term's cn, silently ignoring cd
; (the same latent bug assertIntegerCoefficients's own comment already
; warns about). The helpers below only ever touch a term's EXPONENT,
; carrying cn/cd through untouched, so they stay correct regardless of
; whether solve()'s equation has a fractional coefficient anywhere.

; The most negative exponent variable v carries anywhere in termList (0
; if v only ever appears with a nonnegative exponent, or not at all) --
; how far short of "an ordinary polynomial" termList currently is for v.
(define (minVarExponent termList v)
    (apply min (cons 0 (map (lambda (term) (expOf term v)) termList))))

; Rebuilds one term with variable v's exponent shifted by `shift` (added
; to whatever v already carries there, 0 if v is absent from this term),
; preserving the term's own coefficient (cn/cd) exactly. The per-term
; core of multiplying a whole term list by v^shift. A shifted exponent
; landing on exactly 0 drops v from the term entirely, mirroring
; mergeVarAlists' own "cancels out" convention (expandParse.scm).
(define (shiftTermVar term v shift)
    (let* ((alist (termVarAlist term))
           (existing (assq v alist))
           (newExp (+ (if existing (cdr existing) 0) shift))
           (rest (filter (lambda (p) (not (eq? (car p) v))) alist))
           (newAlist (if (= newExp 0) rest (cons (cons v newExp) rest))))
        (rebuildTermFrac (cn term) (cd term) newAlist)))

; Same shape as varAlistToTerm (further down), but keeps the term's own
; (possibly fractional) cn/cd pair intact instead of assuming an integer
; coefficient the way every varAlistToTerm caller already gets to (each
; of those is a GCF-divided quotient, always a whole number by
; construction) -- shiftTermVar above needs the general case.
(define (rebuildTermFrac coeffN coeffD alist)
    (cond
        ((null? alist) (makep coeffN coeffD 1 1 1 1 1 '+))
        ((null? (cdr alist))
            (let ((v (caar alist)) (e (cdar alist)))
                (makep coeffN coeffD 1 1 v (numerator e) (denominator e) '+)))
        ('t
            (let ((v (caar alist)) (e (cdar alist)))
                (makepx coeffN coeffD 1 1 v (numerator e) (denominator e) '+ (cdr alist))))))

; Multiplies termList through by v^shift, where shift is exactly enough
; to clear v's most negative exponent (minVarExponent) -- e.g. turns
; "x^-2+x^2-4" into "1+x^4-4x^2" (shift=2). A no-op (returns termList
; unchanged) if v's exponent is never negative to begin with.
;
; This is always safe for solve(): if Q(x) is the result and m = shift,
; the original equation was really x^-m * Q(x) = 0, i.e. equivalent to
; Q(x) = 0 for any x in the original equation's domain (x != 0, which
; the negative-exponent term already required). Q(0) is exactly the
; coefficient of whichever original term achieved the minimum exponent
; -- guaranteed nonzero (that term survived dropZeros) -- so clearing
; the negative exponent this way can never introduce x=0 as a spurious
; extra root; no separate domain-exclusion filtering is needed on the
; results the way an explicit rational-expression denominator needs
; filterExtraneousRoots (solvePoly.scm).
(define (clearNegativeExponent termList v)
    (let ((shift (- (minVarExponent termList v))))
        (if (<= shift 0)
            termList
            (dropZeros (combineLikeTerms (map (lambda (term) (shiftTermVar term v shift)) termList))))))

; Sorts a (variable . exponent) alist alphabetically by variable name --
; the same convention mergeVarAlists (expandParse.scm) already uses so
; expand()'s own multivariable terms always print in a consistent
; variable order. Applied to GCF/quotient alists rebuilt here so a
; multivariable factor()'s output matches that same convention (e.g.
; "xy(x+2y)", never "yx(x+2y)") instead of depending on whatever
; discovery order allVariablesIn happened to produce.
(define (sortVarAlist alist)
    (sort (lambda (a b) (string<? (symbol->string (car a)) (symbol->string (car b)))) alist))

; The first term (in termList's own order) with the maximum total degree
; (termTotalDegree, expandParse.scm) -- generalizes "the leading term"
; from polyDegree's single-variable "highest exponent" to a multivariable
; total-degree sense, reducing to exactly the same term findGCF's old
; coeffAt/polyDegree pairing would have picked when termList is genuinely
; single-variable.
(define (leadingTermMulti termList)
    (let loop ((ts (cdr termList)) (best (car termList)))
        (cond
            ((null? ts) best)
            ((> (termTotalDegree (car ts)) (termTotalDegree best)) (loop (cdr ts) (car ts)))
            ('t (loop (cdr ts) best)))))

; Greatest common (integer) divisor of all coefficients, and -- for every
; variable that appears ANYWHERE in termList -- the minimum exponent it
; carries across the whole list (a term where the variable is absent
; contributes an implicit exponent of 0, same as expOf itself). Returns
; (coeffGCF . varAlist), a direct multivariable generalization of the old
; (coeffGCF . varGCFdeg) single-exponent pair, via termVarAlist/
; allVariablesIn instead of the single-variable var()/varPn() accessors.
; coeffGCF's sign still matches the leading term's sign (see
; leadingTermMulti above) for the same reason the original single-
; variable version did -- see that version's own comment (still
; applicable verbatim: a negative leading coefficient must not get
; silently absorbed into the GCF's sign).
;
; The minimum can itself be NEGATIVE -- e.g. "2x^-2+4" has min(x) = -2,
; since the "4" term's implicit x-exponent (0) is still greater than -2 --
; meaning a negative-exponent GCF entry correctly gets extracted too (the
; filter below only excludes an exponent of exactly 0, not a negative
; one), turning a Laurent term list into an ordinary polynomial GCF piece
; (e.g. "2x^-2") times an ordinary-polynomial quotient (e.g. "2x^2+1") --
; see divideOutGCF just below for the other half of this.
(define (findGCF termList)
    (let* ((coeffs (map (lambda (t) (abs (cn t))) termList))
           (leadSign (if (< (cn (leadingTermMulti termList)) 0) -1 1))
           (allVars (allVariablesIn termList))
           (varGCF (sortVarAlist
                       (filter (lambda (p) (not (= (cdr p) 0)))
                           (map (lambda (v) (cons v (apply min (map (lambda (t) (expOf t v)) termList))))
                                allVars)))))
        (cons (* leadSign (gcdL coeffs)) varGCF)))

; Integer square root if n is a perfect square (n >= 0), else #f.
(define (integerSqrt n)
    (if (< n 0)
        #f
        (let ((r (round (sqrt n))))
            (if (= (* r r) n) r #f))))

; Evaluates termList (true-signed) at a numeric (possibly rational) x.
(define (evalPolyAt termList x)
    (apply + (map (lambda (term)
                       (* (/ (cn term) (cd term))
                          (if (var? (var term)) (expt x (varPn term)) 1)))
                   termList)))

; All positive divisors of |n| (or (1) if n=0), ascending.
(define (divisorsOf n)
    (let ((m (abs n)))
        (if (= m 0)
            '(1)
            (let loop ((d 1) (acc '()))
                (cond
                    ((> d m) (reverse acc))
                    ((= 0 (remainder m d)) (loop (+ d 1) (cons d acc)))
                    ('t (loop (+ d 1) acc)))))))

; Searches for a rational root of termList via the rational root
; theorem: any rational root p/q (lowest terms) has p dividing the
; constant term and q dividing the leading coefficient. Returns the
; root as an exact Scheme rational (numerator/denominator give p, q
; directly, already in lowest terms), 0 if the constant term is 0
; (so x is a factor), or #f if no rational root is found. Capped at
; coefficients up to 10000 in magnitude to avoid a pathological search.
(define (findRationalRoot termList)
    (let* ((deg (polyDegree termList))
           (leadCoeff (coeffAt termList deg))
           (constCoeff (coeffAt termList 0)))
        (cond
            ((= constCoeff 0) 0)
            ((or (> (abs constCoeff) 10000) (> (abs leadCoeff) 10000)) #f)
            ('t
                (let ((ps (divisorsOf constCoeff)) (qs (divisorsOf leadCoeff)))
                    (let loopP ((plist ps))
                        (if (null? plist)
                            #f
                            (let loopQ ((qlist qs))
                                (cond
                                    ((null? qlist) (loopP (cdr plist)))
                                    ((= 0 (evalPolyAt termList (/ (car plist) (car qlist))))
                                        (/ (car plist) (car qlist)))
                                    ((= 0 (evalPolyAt termList (/ (- (car plist)) (car qlist))))
                                        (/ (- (car plist)) (car qlist)))
                                    ('t (loopQ (cdr qlist))))))))))))

; Divides termList (degree >= 1, integer coefficients) by the linear
; factor (q*x - p), where p/q (q > 0, lowest terms) is a verified
; rational root. By Gauss's lemma (q and p are coprime, and q divides
; the leading coefficient by construction), this quotient has exact
; integer coefficients -- the standard synthetic-division-by-(qx-p)
; recurrence: b_(n-1) = a_n/q, b_(i-1) = (a_i + p*b_i)/q.
(define (divideByLinearFactor termList p q)
    (let* ((v (polyVariable termList))
           (deg (polyDegree termList))
           (bTop (/ (coeffAt termList deg) q)))
        (let loop ((i (- deg 2)) (bPrev bTop) (terms (list (cons (- deg 1) bTop))))
            (if (< i 0)
                (map (lambda (pr)
                         (if (= (car pr) 0)
                             (makep (cdr pr) 1 1 1 1 1 1 '+)
                             (makep (cdr pr) 1 1 1 v (car pr) 1 '+)))
                     (reverse terms))
                (let ((bNext (/ (+ (coeffAt termList (+ i 1)) (* p bPrev)) q)))
                    (loop (- i 1) bNext (cons (cons i bNext) terms)))))))

; Divides every term's coefficient and each GCF-shared variable's
; exponent by the GCF found by findGCF, via varAlistToTerm (below -- also
; reused by the fraction-cancellation code for the same alist-to-term
; rebuilding job) instead of the old single-variable makep-by-hand
; construction. A variable whose exponent drops to 0 is dropped from the
; alist entirely (varAlistToTerm's own null-alist case then falls back to
; the non-variable sentinel 1), matching the single-variable version's
; same "don't print a spurious x^0" convention.
;
; `added` handles a case that's only reachable now that findGCF can
; return a NEGATIVE-exponent varGCF entry (e.g. "2x^-2+4" -> x^-2 common
; to both terms): a term that never mentioned that variable at all (the
; "4", an implicit x^0) still needs it divided out, which here means
; SUBTRACTING a negative number, i.e. the variable newly APPEARS in the
; quotient (0 - (-2) = 2, so "4" becomes "4x^2"). `adjusted` alone (which
; only walks a term's own existing alist entries) can't do that -- it
; only ever adjusts a variable the term already carries. For an
; ordinary positive-exponent GCF this never fires: by construction, a
; variable can only reach a positive min (see findGCF) if every single
; term already carries it, so `added` is always empty in that case and
; behavior is unchanged from before this comment.
(define (divideOutGCF termList gcf)
    (let ((coeffGCF (car gcf)) (varGCF (cdr gcf)))
        (map (lambda (term)
                 (let* ((alist (termVarAlist term))
                        (varsHere (map car alist))
                        (adjusted (map (lambda (p)
                                            (let ((g (assq (car p) varGCF)))
                                                (cons (car p) (- (cdr p) (if g (cdr g) 0)))))
                                        alist))
                        (added (filter (lambda (p) p)
                                   (map (lambda (g) (if (memq (car g) varsHere) #f (cons (car g) (- (cdr g)))))
                                        varGCF)))
                        (newAlist (sortVarAlist (filter (lambda (p) (> (cdr p) 0)) (append adjusted added)))))
                     (varAlistToTerm (/ (cn term) coeffGCF) newAlist)))
             termList)))

; Factors a GCF-free degree-2 true-signed term list ax^2+bx+c into two
; linear true-signed term lists, using the quadratic formula: if the
; discriminant b^2-4ac is a perfect square, the roots are rational, and
; each root R = -B/A (A>0, lowest terms) corresponds to a linear factor
; (A*x + B). A1*A2 = a and B1*B2 = c automatically by Vieta's formulas.
; Returns #f if the discriminant isn't a non-negative perfect square.
(define (tryFactorQuadratic termList)
    (let* ((v (polyVariable termList))
           (a (coeffAt termList 2))
           (b (coeffAt termList 1))
           (c (coeffAt termList 0))
           (disc (- (* b b) (* 4 a c))))
        (let ((sq (integerSqrt disc)))
            (if (not sq)
                #f
                (let* ((r1 (/ (+ (- b) sq) (* 2 a)))
                       (r2 (/ (- (- b) sq) (* 2 a)))
                       (A1 (denominator r1)) (B1 (- (numerator r1)))
                       (A2 (denominator r2)) (B2 (- (numerator r2))))
                    (list
                        (list (makep A1 1 1 1 v 1 1 '+) (makep B1 1 1 1 1 1 1 '+))
                        (list (makep A2 1 1 1 v 1 1 '+) (makep B2 1 1 1 1 1 1 '+))))))))

; Factors a GCF-free degree>=3 true-signed term list by finding one
; rational root via the rational root theorem and dividing it out,
; returning the corresponding linear factor and the (degree-1)
; quotient for the caller to recursively re-factor. This naturally
; subsumes sum/difference of cubes (e.g. x^3-8 has root 2) and even
; "biquadratic" cases the discriminant method alone can't reach (e.g.
; x^4-5x^2+4 has roots ±1, ±2) -- no dedicated pattern needed for
; either. Returns #f if no rational root is found.
(define (tryFactorByRationalRoot termList)
    (let ((root (findRationalRoot termList)))
        (if (not root)
            #f
            (let* ((p (numerator root)) (q (denominator root))
                   (v (polyVariable termList))
                   (linearFactor (list (makep q 1 1 1 v 1 1 '+) (makep (- p) 1 1 1 1 1 1 '+)))
                   (quotient (divideByLinearFactor termList p q)))
                (list linearFactor quotient)))))

; Converts a true-signed term list into its printable boundary-signed
; string, reusing the existing simplify.scm/PolyStoSymbol.scm machinery.
;
; Works on a COPY (2026-09-19). unapplysigns mutates its argument in place
; (it rewrites each term's cn and sgn to the boundary convention), so
; printing a list used to silently turn the caller's own true-signed list
; into a boundary-signed one -- after which coeffAt reads the wrong sign for
; every non-leading term. solveHigherDegreeSteps hit this for real: it
; narrates (termsToString quotient) and then keeps solving with that same
; quotient, so a cubic like x^3-7x+6=0 was narrated as "apply the quadratic
; formula to x^2+x+6 = 0 ... the roots are complex" (the quotient is
; x^2+x-6, roots 2 and -3); the appended tidy-up step then papered over it
; with the true answer. Several callers (expandParse.scm) already wrapped
; their call in copy-termlist to dodge this; that is now redundant but
; harmless.
(define (termsToString termList)
    (let* ((noZeros (dropZeros termList))
           (final (if (null? noZeros) (list (makep 0 1 1 1 1 1 1 '+)) noZeros)))
        (recordToString (unapplysigns (copy-termlist final)))))

; ---- Multivariable pattern: homogeneous degree-2 in exactly two
;      variables (ax^2+bxy+cy^2) ----
; A direct generalization of tryFactorQuadratic above: the same
; discriminant/Vieta's-formula approach, treating the second variable y
; as a second "unit" alongside the bare-constant sentinel 1 that
; tryFactorQuadratic's own B_i coefficient already multiplies against.
; Subsumes two-variable difference of squares (b=0, e.g. 4x^2-9y^2 ->
; (2x-3y)(2x+3y)) and perfect-square trinomials (discriminant=0, e.g.
; x^2+2xy+y^2 -> (x+y)(x+y)) as special cases automatically -- the exact
; same way the single-variable version already does for its own b=0/
; discriminant=0 special cases, with no separate pattern needed for
; either. Genuinely multivariable degree>=3 polynomials, and 2-variable
; polynomials that aren't homogeneous degree-2, have no further pattern
; applied anywhere in this file -- see factorReduced below.

; True if termList uses exactly two distinct variables and every term's
; total degree (termTotalDegree, expandParse.scm) is exactly 2 -- i.e.
; genuinely ax^2+bxy+cy^2 shape (a, b, and/or c may individually be 0;
; a term with degree 0 or 1 anywhere disqualifies it, same as
; tryFactorQuadratic only ever applying to a genuinely degree-2 term
; list, never a mixed-degree one).
(define (homogeneousTwoVarQuadratic? termList)
    (let ((vs (allVariablesIn termList)))
        (and (= (length vs) 2)
             (for-all (lambda (t) (= (termTotalDegree t) 2)) termList))))

; The coefficient of the term matching EXACTLY x^xe * y^ye among
; termList's terms (0 if no such term is present) -- mirrors coeffAt but
; keyed by a two-variable exponent pair instead of a single-variable
; degree.
(define (homogeneousCoeff termList x y xe ye)
    (cond
        ((null? termList) 0)
        ((and (= (expOf (car termList) x) xe) (= (expOf (car termList) y) ye)) (cn (car termList)))
        ('t (homogeneousCoeff (cdr termList) x y xe ye))))

(define (tryFactorHomogeneousTwoVar termList)
    (let* ((vs (sort (lambda (a b) (string<? (symbol->string a) (symbol->string b))) (allVariablesIn termList)))
           (x (car vs)) (y (cadr vs))
           (a (homogeneousCoeff termList x y 2 0))
           (b (homogeneousCoeff termList x y 1 1))
           (c (homogeneousCoeff termList x y 0 2)))
        (if (= a 0)
            ; No x^2 term -- e.g. every term shares y as a common factor,
            ; which findGCFmulti (via findGCF) should already have pulled
            ; out before factorReduced ever gets called with this
            ; quotient. Bail rather than divide by zero below.
            #f
            (let* ((disc (- (* b b) (* 4 a c)))
                   (sq (integerSqrt disc)))
                (if (not sq)
                    #f
                    (let* ((r1 (/ (+ (- b) sq) (* 2 a)))
                           (r2 (/ (- (- b) sq) (* 2 a)))
                           (A1 (denominator r1)) (B1 (- (numerator r1)))
                           (A2 (denominator r2)) (B2 (- (numerator r2))))
                        (list
                            (list (makep A1 1 1 1 x 1 1 '+) (makep B1 1 1 1 y 1 1 '+))
                            (list (makep A2 1 1 1 x 1 1 '+) (makep B2 1 1 1 y 1 1 '+)))))))))

; Tries one level of pattern factoring on a GCF-free true-signed term
; list. Single-variable input dispatches on degree exactly as before
; (unchanged); a genuinely two-variable, homogeneous-degree-2 quotient
; tries the pattern above; anything else (3+ variables, degree>=3
; multivariable, non-homogeneous two-variable) has no further pattern
; here and returns #f, same graceful "leave it unfactored" behavior the
; single-variable path already falls back to when no rational root is
; found -- extending to a genuine multivariate GCD/root-finding algorithm
; is out of scope (matches the reasoning cpp-vs-scheme-gaps.md already
; documented for why this stayed single-variable-only in the first
; place).
(define (factorReduced termList)
    (cond
        ((singleVariable? termList)
            (let ((deg (polyDegree termList)))
                (cond
                    ((= deg 2) (tryFactorQuadratic termList))
                    ((>= deg 3) (tryFactorByRationalRoot termList))
                    ('t #f))))
        ((homogeneousTwoVarQuadratic? termList) (tryFactorHomogeneousTwoVar termList))
        ('t #f)))

; Fully factors a true-signed term list: pull out the GCF, try one
; level of pattern factoring on what's left, and recursively re-factor
; any resulting sub-factor that's itself still factorable (this always
; terminates, since each recursive call is on a strictly smaller-degree
; or otherwise irreducible piece). Returns a flat list of "pieces" to
; print and multiply together -- each piece is a true-signed term list,
; printed bare (no parens) if it's a single term, or parenthesized
; otherwise.
(define (fullyFactorPieces termList)
    (if (null? (dropZeros termList))
        ; A pure-zero term list -- findGCF would compute (gcd 0 0 ...) = 0
        ; and fullyFactorPieces below unconditionally divides by that GCF,
        ; which crashes ("Exception in /: undefined for 0"). Nothing to
        ; factor about zero -- short-circuit to a single piece wrapping
        ; the (still zero) term list; piecesToFactoredString's own
        ; single-piece case renders it via termsToString's existing
        ; zero-fallback, same as every other "0" result in this engine.
        (list termList)
    (let* ((gcf (findGCF termList))
           (coeffGCF (car gcf)) (varGCF (cdr gcf))
           (hasGCF (or (not (= coeffGCF 1)) (not (null? varGCF))))
           (quotient (if hasGCF (divideOutGCF termList gcf) termList))
           (gcfPiece (if hasGCF (list (list (varAlistToTerm coeffGCF varGCF))) '()))
           (subFactors (factorReduced quotient)))
        (cond
            (subFactors (append gcfPiece (apply append (map fullyFactorPieces subFactors))))
            ((and (not (null? gcfPiece)) (= (length quotient) 1) (= (cn (car quotient)) 1) (= (cd (car quotient)) 1) (eqv? (var (car quotient)) 1))
                gcfPiece)  ; quotient is just the constant 1 -- nothing left to print (e.g. factor(x^2) = x^2, not x^2*1)
            ('t (append gcfPiece (list quotient)))))))

(define (pieceToString piece)
    (if (= (length piece) 1)
        (termsToString piece)
        (string-append "(" (termsToString piece) ")")))

; Runs factor()'s three input guards (single variable, integer
; coefficients, integer exponents -- see each one's own comment above)
; in order and returns termList unchanged, so a call site needing all
; three can do so in one let* binding instead of three throwaway ones.
; Used only by factor()'s numerator/denominator rational-expression path
; below, which stays single-variable-only even though the plain
; whole-polynomial path (assertFactorableMulti, next) no longer is --
; see that function's own comment for why.
(define (assertFactorable termList opName)
    (assertSingleVariable termList opName)
    (assertIntegerCoefficients termList opName)
    (assertNoFractionalExponent termList opName)
    termList)

; Same as assertFactorable but WITHOUT the single-variable guard, for
; factor()'s plain whole-polynomial path -- multivariable input is now
; genuinely supported there (GCF extraction and the homogeneous-two-
; variable-quadratic pattern above both go through termVarAlist, not the
; single-variable var()/varPn() accessors). The numerator/denominator
; rational-expression path just below keeps requiring single-variable on
; both sides via assertFactorable: extending polyCancellation's own
; monomial-cancellation logic (foldMonomialPieces/cancelMonomials) to
; track more than one variable per side is separate, unstarted work --
; that code currently reads only a term's primary var()/varPn(), ignoring
; extraVars() entirely, so a multivariable monomial GCF piece reaching it
; would silently cancel the wrong thing rather than erroring, the same
; class of silent-wrong-answer bug assertIntegerCoefficients's own
; comment above warns about for a different case.
(define (assertFactorableMulti termList opName)
    (assertIntegerCoefficients termList opName)
    (assertNoFractionalExponent termList opName)
    termList)

; Joins a list of fully-factored pieces (see fullyFactorPieces) into the
; final printed product, e.g. [2, (x+1), (x+2)] -> "2(x+1)(x+2)". A
; single piece prints bare (pieceToString/termsToString already decide
; parens). An empty piece list -- everything canceled out via
; polyCancellation below -- prints as "1", the multiplicative identity
; that list represents.
(define (piecesToFactoredString pieces)
    (cond
        ((null? pieces) "1")
        ((null? (cdr pieces)) (termsToString (car pieces)))
        ('t (let loop ((ps pieces) (result "") (first #t))
                (cond
                    ((null? ps) result)
                    ((= (length (car ps)) 1)
                        (loop (cdr ps) (string-append result (if first "" "*") (pieceToString (car ps))) #f))
                    ('t
                        (loop (cdr ps) (string-append result (pieceToString (car ps))) #f)))))))

; ---- polynomial factor cancellation ----
; Cancels common factors between a numerator's and a denominator's
; fully-factored piece lists (fullyFactorPieces), the reusable core
; behind factor()'s rational-expression support below. A standalone
; function (not inlined into factor()) so any other caller that ends up
; with two piece lists to cancel against each other can reuse it too.
;
; fullyFactorPieces' pieces come in two shapes, and each needs different
; cancellation logic:
;   - Monomial pieces (a single term, e.g. the "2x" in
;     factor("2x^2+2x") = "2x(x+1)") -- only ever the GCF piece, but
;     folding EVERY single-term piece on a side into one combined
;     monomial first (rather than assuming there's at most one) keeps
;     this correct even if that stops being true. Cancellation here is
;     genuine GCD-style: coefficients cancel by their gcd, and a shared
;     variable's exponent cancels by the smaller of the two exponents --
;     e.g. numerator monomial x^2 against denominator monomial x leaves
;     x in the numerator and nothing in the denominator. This is what
;     makes "x^2/x" -> "x" work; an exact-match check alone would only
;     catch the two monomials being identical.
;   - Polynomial pieces (2+ terms, e.g. "(x+1)") -- only cancel on an
;     exact structural match. There's no general polynomial GCD here,
;     matching the rest of this file's scope (factor() only ever finds
;     GCF/quadratic/rational-root factors, never a general poly GCD).

; Combines every single-term piece in pieceList into one (coeff . exp)
; pair: coeff is the product of all their coefficients, exp is the sum
; of all their variable exponents (a bare constant piece contributes 0).
; (1 . 0) -- the identity, safe to "cancel" with anything for a no-op --
; if pieceList has no single-term pieces at all.
(define (foldMonomialPieces pieceList)
    (let loop ((ps pieceList) (coeff 1) (exp 0))
        (cond
            ((null? ps) (cons coeff exp))
            ((> (length (car ps)) 1) (loop (cdr ps) coeff exp))
            ('t (let ((term (car (car ps))))
                    (loop (cdr ps) (* coeff (cn term)) (+ exp (if (var? (var term)) (varPn term) 0))))))))

; The single variable symbol used across pieceList's terms, or #f if
; pieceList is purely constant pieces -- mirrors allVariablesIn's
; single-variable assumption, already guaranteed for each side
; separately by assertSingleVariable before pieces ever reach here.
(define (piecesVariable pieceList)
    (let ((vs (allVariablesIn (apply append pieceList))))
        (if (null? vs) #f (car vs))))

; Rebuilds a single-term piece from a (coeff . exp) pair and the
; variable symbol to use when exp != 0 (exp CAN be negative now, e.g.
; "x^-2/(x+1)" leaves a numerator monomial piece of x^-2 with nothing to
; cancel it -- an earlier `(if (> exp 0) v 1)` check here wrongly treated
; any exp <= 0 as "no variable survives", silently dropping a genuine
; negative-exponent piece down to a bare coefficient), or #f meaning
; "nothing survives" -- coeff=1 and exp=0 is the identity, dropped rather
; than printed as a spurious "*1".
(define (monomialToPiece coeffExp v)
    (let ((coeff (car coeffExp)) (exp (cdr coeffExp)))
        (if (and (= coeff 1) (= exp 0))
            #f
            (list (makep coeff 1 1 1 (if (= exp 0) 1 v) (if (= exp 0) 1 exp) 1 '+)))))

; Cancels the shared monomial factor out of a numerator (coeff . exp)
; and denominator (coeff . exp) pair, returning (cons newNumer newDenom).
; Coefficients always cancel by their gcd, independent of the variable;
; the variable's exponent only cancels when it's the same variable on
; both sides -- a numerator in x and a denominator in y can still cancel
; a shared numeric coefficient without either side's exponent being
; touched. min(ne, de) is the right overlap regardless of sign (e.g.
; ne=-1, de=3 -- "x^-1 over x^3" -- correctly leaves 0 upstairs and 4
; downstairs, i.e. 1/x^4): an earlier `(> ne 0) (> de 0)` guard here
; assumed both exponents were always positive (true before negative
; exponents reached this code) and skipped cancellation entirely
; whenever either side was negative or zero, which is wrong once a
; negative exponent is actually possible on either side.
(define (cancelMonomials numerCE denomCE numerVar denomVar)
    (let* ((nc (car numerCE)) (ne (cdr numerCE))
           (dc (car denomCE)) (de (cdr denomCE))
           (g (gcd (abs nc) (abs dc)))
           (sameVar (and numerVar denomVar (eqv? numerVar denomVar)))
           (eOverlap (if sameVar (min ne de) 0)))
        (cons (cons (/ nc g) (- ne eOverlap))
              (cons (/ dc g) (- de eOverlap)))))

; Removes the first element of lst satisfying pred, returning (cons #t
; rest) if one was found and removed, or (cons #f lst) unchanged if not.
(define (removeFirstMatch pred lst)
    (cond
        ((null? lst) (cons #f lst))
        ((pred (car lst)) (cons #t (cdr lst)))
        ('t (let ((rec (removeFirstMatch pred (cdr lst))))
                (cons (car rec) (cons (car lst) (cdr rec)))))))

; Pure structural equality between two true-signed terms. Deliberately
; NOT termsToString-based: termsToString calls unapplysigns (simplify.scm),
; which MUTATES its argument's term records in place (bakes the boundary-
; sign print convention back into cn/sign) as a side effect of
; stringifying -- fine for a one-shot render, but calling it merely to
; *compare* two pieces here would corrupt whichever ones survive
; uncancelled before they ever reach their real render in
; piecesToFactoredString (found live: factor("(x^2-1)/(x-2)") -- no
; shared factor, so every piece should survive untouched -- came back as
; "((x+1)(x+1)) / (x+2)", both sides' signs scrambled by exactly this).
(define (termEqual? t1 t2)
    (and (= (cn t1) (cn t2))
         (= (cd t1) (cd t2))
         (eqv? (var t1) (var t2))
         (= (varPn t1) (varPn t2))
         (= (varPd t1) (varPd t2))
         (equal? (xvars t1) (xvars t2))))

; Pure structural equality between two true-signed term-list pieces (see
; termEqual? above for why this can't just be termsToString comparison):
; same length and pairwise-equal terms in order.
(define (pieceEqual? p1 p2)
    (and (= (length p1) (length p2))
         (for-all termEqual? p1 p2)))

; Cancels every numerator polynomial (multi-term) piece against the
; first structurally-identical denominator piece it finds. A piece with
; no match survives in the returned numerator list; a matched denominator
; piece is consumed (removed) one-for-one, so e.g. a repeated root's
; duplicate factor only cancels as many times as it's actually shared.
(define (cancelPolyPieces numerPolys denomPolys)
    (if (null? numerPolys)
        (cons '() denomPolys)
        (let* ((p (car numerPolys))
               (found (removeFirstMatch (lambda (q) (pieceEqual? p q)) denomPolys)))
            (if (car found)
                (cancelPolyPieces (cdr numerPolys) (cdr found))
                (let ((rest (cancelPolyPieces (cdr numerPolys) denomPolys)))
                    (cons (cons p (car rest)) (cdr rest)))))))

; Top-level entry point for this section: splits numerPieces/denomPieces
; into their monomial and polynomial pieces, cancels each kind by its
; own rule above, and reassembles the survivors -- monomial piece (if
; any survives) first, matching fullyFactorPieces' own GCF-piece-first
; convention. Returns (cons remainingNumerPieces remainingDenomPieces).
(define (polyCancellation numerPieces denomPieces)
    (let* ((numerMonos (filter (lambda (p) (= (length p) 1)) numerPieces))
           (denomMonos (filter (lambda (p) (= (length p) 1)) denomPieces))
           (numerPolys (filter (lambda (p) (> (length p) 1)) numerPieces))
           (denomPolys (filter (lambda (p) (> (length p) 1)) denomPieces))
           (numerVar (piecesVariable numerMonos))
           (denomVar (piecesVariable denomMonos))
           (cancelledMono (cancelMonomials (foldMonomialPieces numerMonos) (foldMonomialPieces denomMonos) numerVar denomVar))
           (numerMonoPiece (monomialToPiece (car cancelledMono) numerVar))
           (denomMonoPiece (monomialToPiece (cdr cancelledMono) denomVar))
           (cancelledPoly (cancelPolyPieces numerPolys denomPolys)))
        (cons
            (append (if numerMonoPiece (list numerMonoPiece) '()) (car cancelledPoly))
            (append (if denomMonoPiece (list denomMonoPiece) '()) (cdr cancelledPoly)))))

; Reconstitutes one flat, combined, true-signed term list by multiplying
; together every piece in pieceList (see fullyFactorPieces) -- the
; reverse of factoring, needed by tryCancelFraction below since expand()'s
; own machinery (unlike factor()) works with flat term lists, not
; factored pieces. Reuses the same multiplyTermLists/combineLikeTerms
; idiom expandParse.scm's own fracMultiplyScalar already uses for
; ordinary polynomial multiplication. An empty pieceList (everything
; canceled) reconstitutes to the constant 1.
(define (recombinePieces pieceList)
    (if (null? pieceList)
        (list (makep 1 1 1 1 1 1 1 '+))
        (combineLikeTerms
            (let loop ((rest (cdr pieceList)) (acc (car pieceList)))
                (if (null? rest)
                    acc
                    (loop (cdr rest) (multiplyTermLists acc (car rest))))))))

; Rebuilds a single <poly> term from a coefficient and a full (variable
; . exponent) alist (termVarAlist's own shape) -- the first entry becomes
; the term's primary variable, any rest become extraVars. Mirrors
; multiplyTerms' own three-way null/single/multi split (expandParse.scm)
; so a fully-cancelled (empty alist) or single-variable leftover comes
; out byte-identical to what the rest of the engine already builds.
(define (varAlistToTerm coeff alist)
    (cond
        ((null? alist) (makep coeff 1 1 1 1 1 1 '+))
        ((null? (cdr alist))
            (let ((v (caar alist)) (e (cdar alist)))
                (makep coeff 1 1 1 v (numerator e) (denominator e) '+)))
        ('t
            (let ((v (caar alist)) (e (cdar alist)))
                (makepx coeff 1 1 1 v (numerator e) (denominator e) '+ (cdr alist))))))

; Cancels a shared variable factor between two single-term monomials, even
; when one or both carry a variable the other doesn't -- e.g. numerator
; "x" against denominator "xy" cancels the shared x, leaving numerator 1
; and denominator y (the untouched extra variable just carries through).
; A variable only cancels where it appears on BOTH sides, by the smaller
; of the two exponents, same rule as cancelMonomials above but generalized
; over every variable in either term instead of one shared primary
; variable -- monomial-by-monomial division needs no general polynomial
; GCD or factoring, so this doesn't go through fullyFactorPieces/
; polyCancellation at all (those assume single-variable input throughout,
; per this file's own scope comment).
(define (cancelMonomialTerms numerTerm denomTerm)
    (let* ((numerVars (termVarAlist numerTerm))
           (denomVars (termVarAlist denomTerm))
           (g (gcd (cn numerTerm) (cn denomTerm)))
           (cancelAgainst (lambda (vars other)
                               (filter (lambda (p) (> (cdr p) 0))
                                   (map (lambda (p)
                                            (let ((otherExp (cond ((assq (car p) other) => cdr) ('t 0))))
                                                (cons (car p) (- (cdr p) (min (cdr p) otherExp)))))
                                        vars)))))
        (cons (list (varAlistToTerm (/ (cn numerTerm) g) (cancelAgainst numerVars denomVars)))
              (list (varAlistToTerm (/ (cn denomTerm) g) (cancelAgainst denomVars numerVars))))))

; Best-effort factor cancellation for one already-expanded, non-matrix
; (numer . denom) scalar fraction pair, as produced by expandParse.scm's
; expandProductFrac for a single addend's Product -- the reusable hook
; that lets expand() cancel a division site's numerator/denominator
; BEFORE that Product is folded into the rest of the expression via
; fracAdd/fracNegate (expandSumFrac, expandParse.scm), rather than
; during that folding or as a pass over the final combined result.
; Reduces via the same fullyFactorPieces/polyCancellation machinery
; factor() uses, wherever both sides happen to be single-variable,
; integer-coefficient, integer-exponent polynomials (factor()'s own
; scope) with a genuine (non-constant, non-zero) denominator.
;
; One narrower case is handled even OUTSIDE that single-variable scope:
; when both sides are already a single monomial term each (e.g. "x/xy" or
; "x/x/y"), cancelMonomialTerms above cancels their shared variable(s)
; directly -- no polynomial factoring needed for a monomial/monomial
; division regardless of how many distinct variables are involved, so the
; single-variable restriction (which exists for the *polynomial*-piece
; path's factoring algorithms) doesn't need to apply here.
;
; Returns f UNCHANGED -- never errors -- for anything outside both scopes:
; this runs on every division site in expand()'s own arithmetic and must
; keep handling every input expand() always has, cancellation-eligible or
; not.
(define (tryCancelFraction f)
    (if (fracMatrix? f)
        f
        (let ((numer (dropZeros (car f))) (denom (dropZeros (cdr f))))
            (cond
                ((or (null? numer) (null? denom)
                     (and (= (length denom) 1) (not (var? (var (car denom))))))
                    f)
                ((not (and (integerCoefficients? numer) (integerCoefficients? denom)
                           (integerExponents? numer) (integerExponents? denom)))
                    f)
                ((and (singleVariable? numer) (singleVariable? denom))
                    (let ((cancelled (polyCancellation (fullyFactorPieces numer) (fullyFactorPieces denom))))
                        (cons (recombinePieces (car cancelled)) (recombinePieces (cdr cancelled)))))
                ((and (= (length numer) 1) (= (length denom) 1))
                    (cancelMonomialTerms (car numer) (car denom)))
                ('t f)))))

; Top-level entry point: fully expands then factors a polynomial
; expression (the same syntax parseExpansion/expand accept), e.g.
; "2x^2+6x+4" -> "2(x+1)(x+2)". If nothing factors out at all, returns
; the same plain string expand() would.
;
; Also handles a genuine rational expression (a variable denominator,
; e.g. "(x^2-1)/(x-1)"): both sides are independently factored (each
; subject to the same single-variable/integer-coefficient/integer-
; exponent guards as the plain case), then polyCancellation removes
; their shared factors, e.g. "(x^2-1)/(x-1)" -> "x+1". A zero numerator
; short-circuits to "0" before either side is factored, both because the
; answer is immediate and because fullyFactorPieces (findGCF's gcd/min)
; assumes a nonempty term list.
;
; expand() itself now ALSO cancels, but more narrowly and via a
; different path -- tryCancelFraction above, hooked into
; expandParse.scm's expandSumFrac, cancels one addend's own division
; site before that addend is combined with the rest of the expression,
; not the fully-combined result the way factor() does here on its whole
; input. See expandSumFrac's own comment for why.
(define (factor charL)
    (let* ((addends (parseExpansion charL))
           (classified (classifyFrac addends)))
        (cond
            ((eqv? (car classified) 'matrix)
                (error #f "factor: matrix input isn't supported here -- use expand() for matrix expressions" #f))
            ((eqv? (car classified) 'whole)
                (piecesToFactoredString (fullyFactorPieces (assertFactorableMulti (cdr classified) "factor"))))
            ('t
                (let ((numer (cadr classified)) (denom (cddr classified)))
                    (if (null? numer)
                        "0"
                        (let* ((numerPieces (fullyFactorPieces (assertFactorable numer "factor")))
                               (denomPieces (fullyFactorPieces (assertFactorable denom "factor")))
                               (cancelled (polyCancellation numerPieces denomPieces))
                               (numerFinal (car cancelled))
                               (denomFinal (cdr cancelled)))
                            (if (null? denomFinal)
                                (piecesToFactoredString numerFinal)
                                (string-append "(" (piecesToFactoredString numerFinal) ") / (" (piecesToFactoredString denomFinal) ")")))))))))
