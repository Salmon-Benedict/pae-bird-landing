; gravitation.scm -- physics module Phase 7: Gravitation --
; project_physics_module.md's Mechanics curriculum order, item 7, the
; LAST phase completing first-semester scope. Five thin
; solvePhysicsCommand wrappers, same zero-multi-equation-risk single-
; equation shape every phase since Phase 3's `power` lesson has used.
;
; ---- One new symbol, everything else reused ----
; Phase 6 (Oscillations) proved indexed variables work end-to-end,
; resolving Phase 5's letter-budget exhaustion for good -- this phase
; needs only ONE new symbol, g_c (the gravitational constant G): 'g'
; itself is already gravitational acceleration (physicsRoleTable,
; physicsUnits.scm), and uppercase isn't a valid variable at all
; (mathHelp.scm's var? only accepts single lowercase letters). Every
; other symbol below is reused directly from an existing role: f
; (force), m/n (the two masses, reused from Phase 4's collision roles),
; r (distance, reused from circular motion/torque), g (gravitational
; field strength -- Earth's surface value is just this phase's general
; field formula evaluated at Earth's own G/M/r, not a different
; quantity), v (velocity), e (potential energy, reused from
; gravpe/springpe's own precedent of reusing e for a dimensionally-
; identical-but-differently-sourced energy).
;
; ---- New: scientific-notation input (physicsUnits.scm) ----
; G's SI value (6.674e-11 N*m^2/kg^2) is impractically small to type as
; a plain decimal, so physicsUnits.scm's parsePhysicsQuantity now
; accepts "6.674e-11"-style input (splitPhysicsNumericPrefix/
; parsePhysicsNumeral) -- see that file's own comments for why this was
; kept local to physics-quantity parsing rather than added to the
; shared general-purpose numeral parser.
;
; ---- Kepler's third law: still out of scope, same reason as Phase 6 ----
; T^2=4*pi^2*r^3/(G*M) is NOT buildable here: solve()'s polynomial
; engine has no symbolic pi, and can't accept sqrt(...) as equation
; input (only ever as output, from the quadratic formula) -- the exact
; same two limitations that excluded SHM's period formulas in Phase 6.
; A genuine representational limit, not a scope choice to revisit
; casually.
;
; Depends on: physicsUnits.scm (dimGravConstant, the g_c role),
; physicsSolve.scm (solvePhysicsCommand). Load this file after
; physicsSolve.scm.

; ---- Newton's law of universal gravitation: f = g_c*m*n/r^2 ----
; Solving for r branches (+/-) since r only appears squared -- same
; "branch on every real root, never guess" precedent as every prior
; phase, even though a negative distance isn't physically meaningful
; (no existing command filters non-physical roots either, e.g.
; circular's own negative-velocity branch).
(define gravforceVars '(f g_c m n r))
(define gravforceEquations (list "f=g_c*m*n/r^2"))

; ---- Gravitational field/acceleration: g = g_c*n/r^2 ----
; Field strength due to a source mass n at distance r. Linear -- never branches.
(define gravfieldVars '(g g_c n r))
(define gravfieldEquations (list "g=g_c*n/r^2"))

; ---- Circular orbital velocity: v^2*r = g_c*n ----
; Derived from setting gravitational force equal to centripetal force:
; g_c*n*m/r^2 = m*v^2/r => v^2=g_c*n/r => v^2*r=g_c*n. Solving for v branches (+/-).
(define orbitalvelocityVars '(v r g_c n))
(define orbitalvelocityEquations (list "v^2*r=g_c*n"))

; ---- Escape velocity: v^2*r = 2*g_c*n ----
; Same variable set as orbitalvelocity but a physically distinct
; relation (extra factor of 2) -- kept as its own independent command
; rather than bundled, matching the power-lesson precedent every phase
; since Phase 3 has followed. Solving for v branches (+/-).
(define escapevelocityVars '(v r g_c n))
(define escapevelocityEquations (list "v^2*r=2*g_c*n"))

; ---- General two-body gravitational potential energy: e = -1*g_c*m*n/r ----
; Named universalgravpe (not gravpe) to avoid clashing with the
; existing gravpe command (Phase 3's near-surface m*g*h approximation)
; -- genuinely a different formula for a different regime, not a
; replacement. Linear -- never branches.
(define universalgravpeVars '(e g_c m n r))
(define universalgravpeEquations (list "e=-1*g_c*m*n/r"))
