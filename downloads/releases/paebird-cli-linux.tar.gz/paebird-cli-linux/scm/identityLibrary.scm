; identityLibrary.scm -- a centralized table of verified trigonometric
; and logarithmic/exponential identities, for calculus2.md's Phase 1
; (trig integrals/trig substitution need exactly these facts) and for
; whatever future rule-engine eventually consults a shared identity
; table instead of having each feature hardcode its own (see
; calculus2.md's own note on this).
;
; NOT YET CONSUMED BY ANYTHING -- this is verified DATA only, the same
; "prep data, ready for a consumer that doesn't exist yet" status
; derivativeGoldenTable.scm/limitGoldenTable.scm both started in before
; Phase 1/Phase 2 actually wired them in (see that history in
; test-golden.scm's own comments at each). Unlike that history, though,
; this library's own correctness is verified HERE, in this file's own
; identityHoldsAt? plus test-golden.scm's loop over it -- not left
; sitting untested the way those two tables originally were.
;
; Deliberately expressed using ONLY this engine's existing function
; vocabulary (sin, cos, tan, exp, ln, log, sqrt) -- no sec/csc/cot,
; since those aren't parseable input anywhere in this engine yet (an
; identity library entry that used them would be untestable and
; unusable as this engine actually stands); e.g. "1 + tan²x = sec²x" is
; stored as "1+tan(x)^2 = 1/cos(x)^2" instead.

; ---- Verification: numeric sampling (evalExprAt, limitExpr.scm) ----
; #t if lhsStr and rhsStr evaluate to the same value (within a small
; tolerance -- either side can legitimately be an inexact decimal, e.g.
; sin/cos at a non-special-angle point) at every point in samplePoints
; for the single free variable var. 'undefined on BOTH sides at a given
; point is treated as consistent (a shared domain restriction, not a
; mismatch, e.g. an identity involving 1/cos(x) at a point where cos
; happens to be 0 in both the LHS and RHS forms); 'undefined on only
; ONE side is a genuine mismatch. This is the same "symbolic result,
; verify numerically at several sample points" technique recommended
; for verifying an integration result against its own integrand --
; reusable for that later, not just for this library's own trig
; entries below.
(define identityTolerance 1e-6)

(define (valuesApproxEqual? v1 v2)
    (cond
        ((and (eqv? v1 'undefined) (eqv? v2 'undefined)) 't)
        ((or (eqv? v1 'undefined) (eqv? v2 'undefined)) #f)
        ('t (< (abs (- v1 v2)) identityTolerance))))

(define (identityHoldsAt? lhsStr rhsStr var samplePoints)
    (let ((lhs (exprParse (string->list lhsStr))) (rhs (exprParse (string->list rhsStr))))
        (for-all
            (lambda (pt) (valuesApproxEqual? (evalExprAt lhs var pt) (evalExprAt rhs var pt)))
            samplePoints)))

; A handful of rational sample points spanning negative/positive/
; fractional -- enough to catch a genuinely wrong identity (a wrong
; identity essentially never happens to agree at 8 unrelated points by
; coincidence) without needing to reason about each entry's own domain
; restrictions up front; valuesApproxEqual?'s shared-'undefined
; handling above means a point landing on a removable singularity for
; a given entry (e.g. tan(x) at a point where cos(x)=0) is skipped as
; consistent rather than flagged, so this same fixed list works for
; every trig entry below without per-entry tuning.
(define identitySamplePoints (list -2 -1 -1/2 0 1/3 1 3/2 2))

; ---- Trig identities: single free variable (x) ----
; (list name lhsString rhsString description)
(define trigIdentityLibrary
    (list
        (list 'pythagorean "sin(x)^2+cos(x)^2" "1"
            "Pythagorean identity: sin²x + cos²x = 1")
        (list 'pythagorean-tan-sec "1+tan(x)^2" "1/cos(x)^2"
            "1 + tan²x = sec²x (sec²x written as 1/cos²x -- no separate sec function exists in this engine)")
        (list 'double-angle-sin "sin(2x)" "2*sin(x)*cos(x)"
            "Double angle: sin(2x) = 2 sin(x) cos(x)")
        (list 'double-angle-cos-diff "cos(2x)" "cos(x)^2-sin(x)^2"
            "Double angle: cos(2x) = cos²x - sin²x")
        (list 'double-angle-cos-2cos "cos(2x)" "2*cos(x)^2-1"
            "Double angle, alternate form: cos(2x) = 2cos²x - 1")
        (list 'double-angle-cos-1sin "cos(2x)" "1-2*sin(x)^2"
            "Double angle, alternate form: cos(2x) = 1 - 2sin²x")
        (list 'power-reduction-sin "sin(x)^2" "(1-cos(2x))/2"
            "Power-reduction (half-angle): sin²x = (1 - cos(2x))/2 -- needed for ∫sin²x dx (Phase 1's trig integrals)")
        (list 'power-reduction-cos "cos(x)^2" "(1+cos(2x))/2"
            "Power-reduction (half-angle): cos²x = (1 + cos(2x))/2 -- needed for ∫cos²x dx (Phase 1's trig integrals)")
        (list 'tan-quotient "tan(x)" "sin(x)/cos(x)"
            "Definitional: tan(x) = sin(x)/cos(x)")))

; ---- Log/exp identities: TWO free variables (a, b), or one value plus
;      an integer exponent n -- evalExprAt only ever substitutes ONE
;      variable at a time (confirmed directly: its own `evar` case
;      returns whatever `point` it was given UNCONDITIONALLY, for ANY
;      variable node, not just the one matching `var` -- a genuine
;      single-free-variable assumption baked into this engine's whole
;      Calc I scope, not a bug to work around here). So these are
;      verified differently from the trig table above: each entry is a
;      FUNCTION from concrete sample numbers to a closed (no free
;      variable at all) lhsString/rhsString pair, evaluated directly
;      via evalExprAt with an arbitrary/unused var symbol (harmless,
;      since a variable that doesn't actually appear in the expression
;      is never substituted for). test-golden.scm calls each of these
;      at several small positive sample values directly, rather than
;      through identityHoldsAt? (which is symbolic-substitution-based
;      and doesn't apply here).
; (list name templateFn description) -- templateFn : (a, b) -> (cons lhsString rhsString)
(define logIdentityLibrary
    (list
        (list 'log-product
            (lambda (a b) (cons (string-append "ln(" (number->string a) "*" (number->string b) ")")
                                 (string-append "ln(" (number->string a) ")+ln(" (number->string b) ")")))
            "Product rule: ln(ab) = ln(a) + ln(b)")
        (list 'log-quotient
            (lambda (a b) (cons (string-append "ln(" (number->string a) "/" (number->string b) ")")
                                 (string-append "ln(" (number->string a) ")-ln(" (number->string b) ")")))
            "Quotient rule: ln(a/b) = ln(a) - ln(b)")
        (list 'log-power
            (lambda (a n) (cons (string-append "ln(" (number->string a) "^" (number->string n) ")")
                                 (string-append (number->string n) "*ln(" (number->string a) ")")))
            "Power rule: ln(a^n) = n*ln(a) (n a positive integer here -- the identity itself holds for any real n, but this test avoids confounding a genuine identity failure with an unrelated exponent-handling edge case)")
        (list 'exp-ln-inverse
            (lambda (a b) (cons (string-append "exp(ln(" (number->string a) "))") (number->string a)))
            "Inverse: exp(ln(a)) = a, for a > 0")
        (list 'ln-exp-inverse
            (lambda (a b) (cons (string-append "ln(exp(" (number->string a) "))") (number->string a)))
            "Inverse: ln(exp(a)) = a")))

; Evaluates a CLOSED expression string (no free variables at all,
; e.g. "ln(2*3)") to a number -- evalExprAt with a var symbol
; guaranteed not to appear works for this directly (see logIdentityLibrary's
; own header comment for why).
(define (evalClosedExprString s) (evalExprAt (exprParse (string->list s)) '_unused_ 0))
