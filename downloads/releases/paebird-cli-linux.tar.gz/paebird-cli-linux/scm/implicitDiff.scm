; implicitDiff.scm -- calculus.md's Phase 3: implicit differentiation.
;
; Depends on: diffExpr.scm (diffExprRaw, exprSimplify), exprAst.scm/
; exprParse.scm, solvePoly.scm (findCharPos, extract -- reused directly
; for splitting "LHS=RHS", NOT parseEquationToZero itself, since that
; goes through expandParse.scm's polynomial-only parser and an implicit
; equation may contain transcendental functions, e.g. "sin(y)+x^2=1").
;
; ---- Method: partial derivatives, not chain-rule injection ----
; The textbook technique is "differentiate both sides, treating y as a
; function of x, so every y-term picks up a dy/dx factor via the chain
; rule, then solve the resulting (linear-in-dy/dx) equation for dy/dx."
; That's equivalent to -- and, critically, gives an IDENTICAL result to
; -- the implicit function theorem's direct formula:
;
;   dy/dx = -(dF/dx) / (dF/dy)
;
; where each partial derivative treats the OTHER variable as a constant.
; diffExprRaw ALREADY does exactly that for any symbol besides its own
; target variable (see diffExpr.scm's own evar case: anything that isn't
; the differentiation variable differentiates to 0) -- so this needs no
; new differentiation logic at all, just two ordinary diffExprRaw calls
; combined.
;
; This also sidesteps a real problem with the textbook approach as
; literally described: "solve the resulting equation for dy/dx" would
; need to call solve() (solvePoly.scm) on an equation that ALSO contains
; x and y as free variables, but solve() requires genuinely single-
; variable input -- assertSingleVariable would reject that outright. The
; partial-derivative formula never needs solve() at all, and gives the
; same answer (the resulting equation actually being solved -- 0 =
; Fx + Fy*(dy/dx) -- is guaranteed linear in dy/dx by construction, since
; differentiating once can never square or re-nest it, which is exactly
; why isolating it algebraically, dy/dx = -Fx/Fy, is valid here).
;
; Result is run through exprSimplify (same as diffExpr itself) -- pure-
; polynomial equations (e.g. the circle x^2+y^2=25) come back fully
; reduced (dy/dx = -x/y, not -2x/2y); an equation involving a
; transcendental function stays as a division of un-bridged subtrees,
; simplified piecewise wherever a pure-polynomial chunk exists within it.
; #t if e contains var anywhere in its tree. A small local copy of
; intExpr.scm's own containsVar? (same exprKind/case-dispatch pattern)
; rather than a new cross-file dependency on a file that loads AFTER
; this one -- matches this codebase's established small-self-contained-
; utility-per-file convention (see e.g. physicsSolve.scm's joinStrs).
(define (implicitDiffContainsVar? e var)
    (case (exprKind e)
        ((num) #f)
        ((evar) (eqv? (exprEvarName e) var))
        ((neg) (implicitDiffContainsVar? (exprNegOperand e) var))
        ((add) (or (implicitDiffContainsVar? (exprAddLeft e) var) (implicitDiffContainsVar? (exprAddRight e) var)))
        ((sub) (or (implicitDiffContainsVar? (exprSubLeft e) var) (implicitDiffContainsVar? (exprSubRight e) var)))
        ((mul) (or (implicitDiffContainsVar? (exprMulLeft e) var) (implicitDiffContainsVar? (exprMulRight e) var)))
        ((div) (or (implicitDiffContainsVar? (exprDivNumer e) var) (implicitDiffContainsVar? (exprDivDenom e) var)))
        ((pow) (or (implicitDiffContainsVar? (exprPowBase e) var) (implicitDiffContainsVar? (exprPowExponent e) var)))
        ((apply) (implicitDiffContainsVar? (exprApplyArg e) var))
        ; sum(...) -- same capture-avoiding reasoning as diffExpr.scm's
        ; exprContainsVar?/intExpr.scm's containsVar? (both have the same
        ; arm, with the fuller comment); indexVar is a binder, so an
        ; occurrence only counts if var isn't the index variable itself.
        ((sum) (or (and (not (eqv? var (exprSumIndexVar e))) (implicitDiffContainsVar? (exprSumTerm e) var))
                   (implicitDiffContainsVar? (exprSumLower e) var)
                   (implicitDiffContainsVar? (exprSumUpper e) var)))
        ((factorial) (implicitDiffContainsVar? (exprFactorialOperand e) var))))

(define (implicitDiff eqChars xVar yVar)
    (let ((eqIdx (findCharPos #\= eqChars 0)))
        (if (not eqIdx)
            (error #f "implicitDiff: expected an equation containing '='" eqChars)
            (let* ((lhsChars (if (> eqIdx 0) (extract 0 (- eqIdx 1) eqChars) '()))
                   (rhsChars (if (< (+ eqIdx 1) (length eqChars)) (extract (+ eqIdx 1) (- (length eqChars) 1) eqChars) '()))
                   (f (makeExprSub (exprParse lhsChars) (exprParse rhsChars))))
                (if (not (implicitDiffContainsVar? f yVar))
                    (error #f (string-append "implicitDiff: " (symbol->string yVar) " does not appear in this equation") eqChars)
                    (let* ((fx (diffExprRaw f xVar))
                           (fy (diffExprRaw f yVar)))
                        (exprSimplify (makeExprDiv (makeExprNeg fx) fy))))))))
