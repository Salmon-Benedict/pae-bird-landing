; intExpr.scm -- calculus.md's Phase 3: integration extensions. Basic
; indefinite integrals (the dual of Phase 1's diffExpr rule table),
; linearity (sum/difference/constant-multiple), a curated linear-
; substitution case (constant argument scaling: sin(3x), exp(2x+1),
; 1/(2x+3), (2x+1)^5, ...), Integration By Parts as the automatic
; fallback for a product neither factor of which is constant (see
; intExprMul's own comment), and definite integrals via the Fundamental
; Theorem of Calculus.
;
; Depends on: exprAst.scm, exprParse.scm, exprSimplify.scm (exprIsPurePoly?,
; exprSimplify), limitExpr.scm (evalExprAt, pureExprToTermList,
; exprEqual?), factorPoly.scm (polyDegree, coeffAt), integrationByParts.scm
; (ibpStep, ibpFirstStep, splitForIByPContinuation), trigPowerIntegrals.scm
; (trigPowerProductResult, trigPowerBaseResult). The latter two are
; genuine two-way dependencies, not a clean one-way layering --
; integrationByParts.scm's own ibpStep already calls back into this
; file's diffExpr/intExpr to compute each round's du/v, and
; trigPowerIntegrals.scm calls back into this file's
; scaleByLinearArgInverse/exprIsApplyOf?. Fine in Scheme's single global
; namespace, just worth being honest about. load-engine.scm still loads
; both files AFTER this one; that's fine too -- intExprMul's/intExprPow's
; own references to them only need to resolve by the time they're
; actually CALLED (well after every file is loaded), not by the time
; this file itself loads.
;
; ---- Integration By Parts: control lives HERE, not in
;      integrationByParts.scm ----
; integrationByParts.scm is a library of pure, non-recursive "compute one
; IBP step" functions (see its own header). This file is what decides
; WHETHER to use IBP, WHEN to stop trying, and what to do with each
; step's result -- intExprMul tries ibpFirstStep whenever it hits a
; product neither of its own curated shapes resolves; intExprIBPRound
; (below intExprMul) is the actual round-by-round loop: simplify the
; remainder (exprSimplify, exprSimplify.scm -- an explicit, named step, not
; a detail buried inside the algorithm), check whether IT already
; integrates via intExpr, and if not, ask integrationByParts.scm for one
; more step and recurse, up to maxIByPRounds. This also means IBP now
; applies at EVERY product node in the tree, not just when the WHOLE
; integrand's own top-level node happens to be a product (that used to
; be dispatcher.scm's job) -- which fixes a real gap the old top-level-
; only gate had: "x+x*sin(x)" used to fail outright (top-level node is
; 'add, so IBP was never even attempted on the x*sin(x) subterm), even
; though "x*sin(x)" alone always worked fine.
;
; Two more things the round loop watches for, both added 2026-08-15
; (constantMultipleOf?/resolveIBPBoomerang and the prevB1 size check,
; both in intExprIBPRound below):
;   - Cyclic ("boomerang") chains, e.g. exp(x)*sin(x): round 2's own
;     remainder is a constant multiple of the ORIGINAL integrand, not a
;     smaller sub-problem -- recursing on it would just repeat the same
;     shape forever. Recognized via constantMultipleOf? against the
;     original integrand (threaded through every recursive call), then
;     solved algebraically (I = knownExpr + coeff*I) once control
;     returns to depth 0, via resolveIBPBoomerang.
;   - Round-over-round GROWTH: if a round's own remaining integral
;     (b1, after simplify) is a strictly BIGGER expression than the
;     PREVIOUS round's (chooser3.scm's own numeric-coefficient-aware
;     exprSize), the chain is diverging, not converging -- bails out
;     immediately with a clean error instead of compounding all the way
;     to maxIByPRounds (a real, confirmed cost: a genuinely mixed-family
;     case like sin(x)*cos(x)*tan(x) used to take the full 8 rounds,
;     ~1 minute, before this). Distinct from chooser3.scm's OWN size
;     check, which only compares candidates WITHIN a single round
;     against that round's starting size, not across rounds.
;
; ---- Scope: deliberately NOT general integration ----
; calculus.md's own plan frames u-substitution as "recognizing a curated
; set of common f'(g(x))*g'(x) patterns, not full general u-sub (that's a
; much harder pattern-matching problem)". This file's curated set is
; exactly one pattern: g(x) LINEAR (ax+b). That covers the overwhelming
; majority of a first integration unit's u-sub problems (sin(3x),
; exp(2x+1), 1/(2x+3), (2x+1)^5, ...) with a single, unambiguous,
; mechanically-checkable rule -- extract (a . b) from a linear
; expression via the SAME pure-polynomial bridge diffExpr.scm/
; limitExpr.scm already use (pureExprToTermList), not a new parser.
;
; Two things are explicitly, permanently out of scope here, and both
; fail with a CLEAR error naming what's missing rather than a silently
; wrong answer:
;   - u-substitution beyond a linear argument (e.g. sin(x^2), where g(x)
;     isn't linear).
;   - Anything needing a technique beyond linearity + the basic table +
;     linear substitution + Integration By Parts + trig powers/products
;     (trigPowerIntegrals.scm, below) -- e.g. partial fractions, trig
;     SUBSTITUTION (as in x=a*sin(theta), a different technique from
;     trig INTEGRALS despite the similar name -- Stewart 7.3, not 7.2).
;
; ---- Stewart 7.2: trig powers and products ----
; sin^m(x)*cos^n(x), tan^m(x)*sec^n(x), cot^m(x)*csc^n(x) for ANY
; nonnegative integer exponents (sin(x)*cos(x), sin^3(x), sec^4(x),
; tan^2(x)*sec(x)^4, ...) are handled by trigPowerIntegrals.scm's own
; reduction techniques -- wired in via intExprMul (products, checked
; after the sec*tan/csc*cot shortcuts above) and intExprPow (bare
; powers, checked after the sec^2/csc^2 shortcuts). Most of those
; techniques are genuinely ITERATIVE (a reduction formula, or a
; power-reduction identity, that only makes ONE step of progress before
; there's a smaller sub-problem left) -- trigPowerIntegrals.scm never
; recurses into itself for that; every reduction step builds the smaller
; sub-problem as a plain expr and hands it BACK to (intExpr subExpr var),
; which re-examines it from scratch and routes it wherever it belongs
; next (often straight back into trigPowerIntegrals.scm's own hooks, one
; degree smaller). Established 2026-08-15 as the standing shape for any
; multi-step integration technique in this file: THIS file is always the
; one iterating and deciding what happens next; helper files (this one,
; integrationByParts.scm) only ever compute one step and hand control
; back. See trigPowerIntegrals.scm's own header for the technique
; breakdown and which few cases are legitimately one-shot instead
; (a single substitution with no smaller sub-problem left over, same
; reasoning as the sec^2(u)/sec(u)*tan(u) curated shortcuts above).
;
; ---- abs, added to exprAst.scm for this file ----
; ln(x) becomes ln(abs(x)) here, not ln(x) -- ln is undefined for a
; negative argument, and the antiderivative needs to be valid wherever
; the ORIGINAL integrand was, not just where x happens to be positive.
; See exprAst.scm's own comment on why abs has no diffExpr rule (not
; needed for producing this shape as OUTPUT, only for constructing/
; rendering/evaluating it).

; #t if e contains var anywhere in its tree.
(define (containsVar? e var)
    (case (exprKind e)
        ((num) #f)
        ((evar) (eqv? (exprEvarName e) var))
        ((neg) (containsVar? (exprNegOperand e) var))
        ((add) (or (containsVar? (exprAddLeft e) var) (containsVar? (exprAddRight e) var)))
        ((sub) (or (containsVar? (exprSubLeft e) var) (containsVar? (exprSubRight e) var)))
        ((mul) (or (containsVar? (exprMulLeft e) var) (containsVar? (exprMulRight e) var)))
        ((div) (or (containsVar? (exprDivNumer e) var) (containsVar? (exprDivDenom e) var)))
        ((pow) (or (containsVar? (exprPowBase e) var) (containsVar? (exprPowExponent e) var)))
        ((apply) (containsVar? (exprApplyArg e) var))
        ; sum(...) -- same capture-avoiding reasoning as diffExpr.scm's
        ; own exprContainsVar? (its own sum arm's comment has the full
        ; explanation); duplicated here rather than shared since this
        ; file's containsVar? is intExpr.scm's own local helper, not a
        ; call to diffExpr.scm's version.
        ((sum) (or (and (not (eqv? var (exprSumIndexVar e))) (containsVar? (exprSumTerm e) var))
                   (containsVar? (exprSumLower e) var)
                   (containsVar? (exprSumUpper e) var)))
        ((factorial) (containsVar? (exprFactorialOperand e) var))))

; (a . b) if e is exactly a*var+b (a, b exact rationals, a possibly 0)
; for the given var; #f if e isn't pure-polynomial or has degree >1 or
; involves any OTHER variable. Reuses limitExpr.scm's own bridge to the
; existing engine (pureExprToTermList) and factorPoly.scm's
; polyDegree/coeffAt/polyVariable rather than writing a second linear-
; expression parser.
;
; exprIsPurePoly? alone isn't enough of a gate: its div case only checks
; "no apply nodes, only literal pow exponents" on numerator AND
; denominator, so 1/x passes as "pure" (it's the right gate for
; bridgeSimplifyPurePoly above, which goes through classifyFrac and DOES
; handle genuine rational expressions -- not appropriate to tighten
; there). But pureExprToTermList itself expects a strictly flat
; polynomial and throws ("expected a whole polynomial, not a fraction")
; the moment it hits a real division -- e.g. sin(1/x)'s linearCoeffs
; check used to crash with that raw exception instead of cleanly
; reporting "not linear". Guarding here converts that into #f, which is
; exactly what this function's own contract already promises for
; anything that isn't usable as a linear expression.
(define (linearCoeffs e var)
    (if (not (exprIsPurePoly? e))
        #f
        (guard (c (#t #f))
            (let* ((terms (pureExprToTermList e)) (deg (polyDegree terms)) (v (polyVariable terms)))
                (cond
                    ((> deg 1) #f)
                    ((and v (not (eqv? v var))) #f)
                    ; trueSignedTerms (limitExpr.scm / riemannLimitIntegral.scm,
                    ; identical copies): pureExprToTermList is "boundary-
                    ; signed" -- each term's real sign lives on the PRECEDING
                    ; term's sgn field, so coeffAt on the raw list is right
                    ; only for the leading term. Until 2026-09-18 nothing read
                    ; b, so "3x-2" quietly gave (3 . 2); trig-power's Fourier
                    ; step and product-to-sum both need the true offset.
                    ('t (let ((signed (trueSignedTerms terms)))
                            (cons (coeffAt signed 1) (coeffAt signed 0)))))))))

; ---- Basic antiderivative table (the dual of diffExpr.scm's chain-rule
;      table), applied to a general arg (bare var or linear-in-var,
;      handled uniformly by intExprApply below via the 1/a scaling) ----
(define (antiderivativeOfKnownFunc func arg)
    (case func
        ((sin)  (makeExprNeg (makeExprApplyChecked 'cos arg)))
        ((cos)  (makeExprApplyChecked 'sin arg))
        ((tan)  (makeExprNeg (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprApplyChecked 'cos arg)))))
        ; sec/csc/cot -- the standard textbook antiderivative pairs.
        ; ∫sec=ln|sec+tan|, ∫csc=-ln|csc+cot| (both memorized results, not
        ; derivable from this file's own linear-substitution/basic-table
        ; rules alone -- taken as given, same as sin/cos/tan's own entries
        ; above); ∫cot=ln|sin| mirrors ∫tan=-ln|cos| exactly (cot=cos/sin,
        ; same du/u pattern with sin as u instead of cos).
        ((sec)  (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprAdd (makeExprApplyChecked 'sec arg) (makeExprApplyChecked 'tan arg)))))
        ((csc)  (makeExprNeg (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprAdd (makeExprApplyChecked 'csc arg) (makeExprApplyChecked 'cot arg))))))
        ((cot)  (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprApplyChecked 'sin arg))))
        ((exp)  (makeExprApplyChecked 'exp arg))
        ((sqrt) (makeExprMul (makeExprDiv (makeExprNum 2) (makeExprNum 3)) (makeExprPow arg (makeExprDiv (makeExprNum 3) (makeExprNum 2)))))
        ; ln/log/arcsin/arccos/arctan: this table has no DIRECT rule for
        ; any of them (unlike sin/cos/exp/etc. above) -- every one of
        ; them needs Integration By Parts with an implicit dv=1 (u=the
        ; function itself, dv=dx), which is a different shape of work
        ; than "look up F for this f". intExprApply below intercepts ONLY
        ; ln BEFORE this table is ever consulted for it and routes it
        ; through the same IBP machinery intExprMul uses -- ln(x)
        ; resolves completely that way (∫ln(x)dx=x*ln(x)-x). log/arcsin/
        ; arccos/arctan are NOT given the same treatment even though the
        ; identical construction is mathematically well-defined for them
        ; too -- see intExprApply's own comment for why (exprSimplify's
        ; pure-poly gate can't cancel a var-free-but-apply-wrapped
        ; constant like ln(10), so attempting it for log/arcsin produces
        ; a confusing or outright misleading error instead of a clean
        ; one; arccos/arctan fail cleanly either way since their own
        ; second round needs a technique -- a variable numerator over a
        ; non-linear denominator -- this file doesn't have regardless).
        ; So all five still reach this table's own error below whenever
        ; IBP wasn't attempted (log/arcsin/arccos/arctan always; ln only
        ; when intExprAllowIBPFallback is already #f, i.e. IBP already
        ; being tried and failed further up the call stack).
        ((ln)   (error #f "intExpr: integrating ln(...) needs integration by parts, out of scope" arg))
        ((log)  (error #f "intExpr: integrating log(...) needs integration by parts, out of scope" arg))
        ((abs)  (error #f "intExpr: integrating abs(...) is out of scope" arg))
        ((arcsin) (error #f "intExpr: integrating arcsin(...) needs integration by parts, out of scope" arg))
        ((arccos) (error #f "intExpr: integrating arccos(...) needs integration by parts, out of scope" arg))
        ((arctan) (error #f "intExpr: integrating arctan(...) needs integration by parts, out of scope" arg))
        ; else, not ('t ...) -- see diffExpr.scm's diffExprApply for the
        ; full story on why (case silently returns an unspecified value
        ; for an unmatched key when the fallback clause is written as a
        ; quoted-symbol datum instead of `else`). Currently unreachable
        ; in practice (this case is already exhaustive over
        ; exprApplyKnownFuncs), kept as a defensive fallback in case that
        ; list ever grows without this table being updated to match.
        (else (error #f "intExpr: unsupported function" func))))

; ---- Main dispatch ----

; Whether intExprMul's fallback below is allowed to try IBP at all.
; Defaults to #t (every ordinary call site wants IBP as the last
; resort); intExprIBPRound's own internal "does b1 already integrate
; via existing techniques" check (below) parameterizes this to #f
; around itself -- WITHOUT that, that check's (intExpr b1 var) call
; could itself hit an unresolved product and trigger a FRESH, depth-0
; IBP attempt on b1, nested inside the round already in progress; each
; nested attempt resets depth to 0 instead of inheriting the caller's,
; so maxIByPRounds's guard never actually bounds the total work --
; confirmed live as a real hang (sin(x)*cos(x), which never resolves,
; went from a ~1s clean "exceeded max rounds" error to a 2+ minute
; timeout the moment intExprMul grew its own unconditional IBP
; fallback). Parameterizing this to #f for that one check restores the
; original fast-fail behavior there (b1 either integrates directly or
; doesn't; if it doesn't, THIS check isn't the place that's supposed to
; resolve it via IBP -- intExprIBPRound's own depth-tracked recursion,
; right below the check, already is) while leaving it #t (the default)
; for every other call, including ordinary recursion through intExpr's
; own add/sub/neg/div dispatch below -- so e.g. "x+x*sin(x)" still gets
; IBP applied to its x*sin(x) subterm.
(define intExprAllowIBPFallback (make-parameter #t))

; Cycle/runaway guard for intExprIBPRound's own recursion below (e.g. a
; factor like 1/t never bottoms out under repeated differentiation the
; way a polynomial does). Every textbook IBP problem resolves in 1-3
; rounds; this is a generous ceiling, not a tuned bound. The give-up
; threshold is control policy, so it lives here with the rest of the
; control loop, not in integrationByParts.scm alongside the mechanical
; step functions it bounds.
(define maxIByPRounds 8)

; ---- Governor: hard wall-clock cap, the final safety net ----
; Every OTHER bound in this file (maxIByPRounds above, chooser3.scm's
; own per-round candidate cap, intExprIBPRound's growth check) targets
; a SPECIFIC known failure shape. This one doesn't -- it catches
; whatever those don't, e.g. trigPowerIntegrals.scm's own peel-based
; odd-power reduction (sinCosPeelSinStep and its tan/sec, cot/csc
; mirrors), confirmed live to blow up EXPONENTIALLY once BOTH exponents
; in a trig-power product are nonzero and large (sin(x)^41 took over 11
; seconds; sin(x)^51 didn't finish in over 2 minutes) -- a real hang
; risk for a perfectly plausible input a student might type, and not
; something maxIByPRounds bounds at all (that only counts IBP rounds;
; this recursion is entirely inside trigPowerIntegrals.scm's own peel
; calls back into intExpr, no IBP involved).
;
; intExprDeadline holds the absolute wall-clock time (Chez's own
; (real-time), milliseconds) after which to give up -- established
; ONCE, by intExpr's own OUTERMOST call in a chain (the parameterize
; below fires only when no deadline is active yet); every recursive
; call anywhere in this file, or in the two other files that call back
; into intExpr (integrationByParts.scm's ibpStep computing v,
; trigPowerIntegrals.scm's peel steps), sees the SAME deadline already
; set via ordinary dynamic-extent parameter scoping and just checks it
; -- cheap, and checked at nearly every AST node (intExpr recurses that
; often), so a runaway computation is caught within a small, bounded
; overshoot of the 3-second budget. The one real exception: a single
; non-intExpr operation that itself runs long between two intExpr
; calls (e.g. exprSimplify on an already-huge expression) won't be
; interrupted mid-flight -- not a concern for the motivating case
; above, which never calls exprSimplify during the peel recursion
; itself.
(define maxIntExprMillis 3000)
(define intExprDeadline (make-parameter #f))

(define (intExpr e var)
    (if (intExprDeadline)
        (intExprDispatch e var)
        (parameterize ((intExprDeadline (+ (real-time) maxIntExprMillis)))
            (intExprDispatch e var))))

(define (intExprDispatch e var)
    (if (> (real-time) (intExprDeadline))
        (error #f "intExpr: exceeded the 3-second computation budget -- this expression is too large or complex for these integration techniques; giving up rather than hanging")
        (if (not (containsVar? e var))
            ; Whole subtree is a constant w.r.t. var (a bare number, another
            ; variable, or a var-free composite like sin(5)) -- integral(c)dx = c*x.
            (makeExprMul e (makeExprEvar var))
            (case (exprKind e)
                ((evar) (makeExprDiv (makeExprPow e (makeExprNum 2)) (makeExprNum 2)))
                ((add) (makeExprAdd (intExpr (exprAddLeft e) var) (intExpr (exprAddRight e) var)))
                ((sub) (makeExprSub (intExpr (exprSubLeft e) var) (intExpr (exprSubRight e) var)))
                ((neg) (makeExprNeg (intExpr (exprNegOperand e) var)))
                ((mul) (intExprMul e var))
                ((div) (intExprDiv e var))
                ((pow) (intExprPow e var))
                ((apply) (intExprApply e var))
                ; else, not ('t ...) -- see diffExprApply's own note. Also
                ; currently unreachable (num is the only exprKind missing from
                ; this list, and it's always caught by the containsVar? check
                ; above before ever reaching here) -- defensive fallback.
                (else (error #f "intExpr: unsupported node for integration" e))))))

; e is exactly funcName(something) -- an apply node for that specific
; function -- returns the argument, else #f.
(define (exprIsApplyOf? e funcName)
    (and (eqv? (exprKind e) 'apply) (eqv? (exprApplyFunc e) funcName) (exprApplyArg e)))

; (1/a)*result, where a is u's own linear coefficient in var -- the
; shared "undo the chain rule's u'=a scaling" step every trig-function
; antiderivative here needs, whether from a bare function
; (intExprApply) or one of the curated sec*tan/csc*cot/sec^2/csc^2
; product-and-power shapes below.
(define (scaleByLinearArgInverse u var result)
    (let ((ab (linearCoeffs u var)))
        (if (not ab)
            (error #f "intExpr: u-substitution beyond a linear argument is out of scope" u)
            (makeExprMul (makeExprDiv (makeExprNum 1) (makeExprNum (car ab))) result))))

; sec(u)*tan(u) [either order] -> sec(u); csc(u)*cot(u) [either order]
; -> -csc(u) -- same u required on both factors (exprEqual?,
; limitExpr.scm). Two more curated, memorized antiderivative pairs
; (matching antiderivativeOfKnownFunc's own sec/csc/cot entries), not a
; general "recognize any f'(x)-times-f(x)-related-thing" search -- see
; this file's header for why that's permanently out of scope.
(define (secTanProductArg l r)
    (or (and (exprIsApplyOf? l 'sec) (exprIsApplyOf? r 'tan) (exprEqual? (exprApplyArg l) (exprApplyArg r)) (exprApplyArg l))
        (and (exprIsApplyOf? l 'tan) (exprIsApplyOf? r 'sec) (exprEqual? (exprApplyArg l) (exprApplyArg r)) (exprApplyArg l))))

(define (cscCotProductArg l r)
    (or (and (exprIsApplyOf? l 'csc) (exprIsApplyOf? r 'cot) (exprEqual? (exprApplyArg l) (exprApplyArg r)) (exprApplyArg l))
        (and (exprIsApplyOf? l 'cot) (exprIsApplyOf? r 'csc) (exprEqual? (exprApplyArg l) (exprApplyArg r)) (exprApplyArg l))))

; e = m*target (any rational m, including negative/fractional), by
; peeling a numeric-literal coefficient off e (via neg/mul-by-literal/
; div-by-literal, either side) and checking exprEqual? at each layer --
; returns m, or #f if e isn't a constant multiple of target this way.
; Used only by the boomerang check below: e/target are always full
; expressions here (may contain apply nodes throughout), not flattened
; IBP factors, so this is deliberately its own small helper rather than
; reusing chooser3.scm's stripNumericCoeff (that one only ever sees a
; SINGLE flattened factor, never a whole product).
(define (constantMultipleOf? e target)
    (cond
        ((exprEqual? e target) 1)
        ((eqv? (exprKind e) 'neg)
            (let ((inner (constantMultipleOf? (exprNegOperand e) target))) (and inner (- inner))))
        ((and (eqv? (exprKind e) 'mul) (exprNum? (exprMulLeft e)))
            (let ((inner (constantMultipleOf? (exprMulRight e) target))) (and inner (* (exprNumValue (exprMulLeft e)) inner))))
        ((and (eqv? (exprKind e) 'mul) (exprNum? (exprMulRight e)))
            (let ((inner (constantMultipleOf? (exprMulLeft e) target))) (and inner (* (exprNumValue (exprMulRight e)) inner))))
        ((and (eqv? (exprKind e) 'div) (exprNum? (exprDivDenom e)) (not (= (exprNumValue (exprDivDenom e)) 0)))
            (let ((inner (constantMultipleOf? (exprDivNumer e) target))) (and inner (/ inner (exprNumValue (exprDivDenom e))))))
        ('t #f)))

; The IBP control loop: processes one round's outcome. a=u*v and
; b1raw=v*du are already computed (integrationByParts.scm's ibpStep/
; ibpFirstStep -- pure mechanics, no recursion).
;
; Returns (cons knownExpr coeffOfOriginal): THIS round's own integral
; (∫u dv for this round's u/dv pair) equals knownExpr +
; coeffOfOriginal*(the ORIGINAL integral this whole chain started
; from) -- coeffOfOriginal is 0 for an ordinary, fully-resolved round
; (knownExpr is then the complete answer), nonzero only when the
; "boomerang" case below fires somewhere in the recursion and the
; original integral I itself is still an unknown on both sides of the
; equation -- resolveIBPBoomerang (below intExprMul) solves for I once
; this returns all the way up to depth 0. This pair-returning
; convention threads that unknown-coefficient bookkeeping through the
; SAME recursion that already combines each round's a/inner via
; makeExprSub/makeExprNeg -- see the a_j = a_j - (if negate? ...)
; combination below, now applied to (K . c) pairs instead of plain
; exprs.
;
; original -- the FULL integrand this whole IBP chain started from
; (intExprMul's own `e`), unchanged through every recursive call;
; compared against each round's own b1 for the boomerang check.
;
; prevB1 -- the PREVIOUS round's own (simplified) b1, or #f at depth 0
; (no previous round yet). If THIS round's b1 is a strictly BIGGER
; expression (chooser3.scm's own numeric-coefficient-aware exprSize,
; not a raw node count -- same reasoning as chooser3's own candidate
; size check) than prevB1, the chain is diverging rather than
; converging and this bails out immediately with a clean error
; (referencing prevB1, the last reasonable state, as the irritant)
; instead of continuing to grow all the way to maxIByPRounds -- e.g.
; sin(x)*cos(x)*tan(x) (a genuinely mixed trig family, no valid
; cluster) used to take the full 8 rounds (~1 minute) compounding a
; growing remainder before finally giving up; this catches that same
; non-convergence in 1-2 rounds instead. A round that's the SAME size
; or SMALLER than the previous one is allowed to continue regardless
; of how it compares to the very first round's size (that's chooser3's
; own, separate, per-candidate concern within a single round) -- this
; check is purely about the round-over-round trend.
(define (intExprIBPRound a b1raw var depth original prevB1)
    (if (>= depth maxIByPRounds)
        (error #f "intExpr: exceeded max recursive IBP rounds without resolving -- likely a non-terminating case (a factor that never bottoms out under repeated differentiation)" b1raw)
        ; The explicit simplify step (exprSimplify.scm) -- e.g. (t^2/2)*(1/t)
        ; is algebraically just t/2, but intExprMul's var-dependence
        ; check is purely syntactic per factor and would otherwise call
        ; this "two var-dependent factors, out of scope" and send it
        ; needlessly into another IBP round.
        (let* ((b1 (exprSimplify b1raw))
               ; Does b1 already integrate via EXISTING (non-IBP)
               ; techniques? intExprAllowIBPFallback is parameterized to
               ; #f here -- see its own comment above for why (prevents
               ; a fresh, depth-0 nested IBP attempt on b1 from defeating
               ; maxIByPRounds's bound). If it still throws (can't handle
               ; this yet), catch it as #f rather than letting the whole
               ; round crash.
               (direct (guard (c (#t #f)) (parameterize ((intExprAllowIBPFallback #f)) (intExpr b1 var)))))
            (cond
                (direct (cons (makeExprSub a direct) 0))
                ; Boomerang/cyclic case: b1 is itself a constant multiple
                ; of the ORIGINAL integrand (e.g. exp(x)*sin(x)'s second
                ; round produces -exp(x)*sin(x), a constant multiple
                ; (m=-1) of the original exp(x)*sin(x)) -- ∫b1 dx = m*I
                ; directly, no need to recurse further; solved
                ; algebraically once this reaches depth 0 (see
                ; resolveIBPBoomerang). Checked AFTER the direct check
                ; (an ordinary resolution is simpler/preferred when both
                ; apply, though in practice if the original needed IBP at
                ; all, a constant multiple of it does too) and BEFORE
                ; continuation (no point recursing deeper once this
                ; closes the loop).
                ((constantMultipleOf? b1 original) => (lambda (m) (cons a (- m))))
                ((and prevB1 (> (exprSize b1) (exprSize prevB1)))
                    (error #f "intExpr: this IBP round's remaining integral grew larger than the previous round's -- diverging, not converging, giving up early rather than compounding all the way to the max-rounds limit" prevB1))
                ((splitForIByPContinuation b1) =>
                    (lambda (parts)
                        (let* ((innerExpr (car parts)) (negate? (cadr parts))
                               ; ibpFirstStep's own diffExpr/intExpr
                               ; calls can themselves throw (e.g. a
                               ; pre-existing exprSimplify/ms-poly-str
                               ; round-trip bug on certain rational-
                               ; function shapes, found via a 90-case
                               ; sweep on x*ln(2x+1)) -- guard this so
                               ; failure becomes our own clean "can't
                               ; recurse" error instead of an unrelated
                               ; raw crash. Fresh LIATE every round now
                               ; (ibpFirstStep, not a "keep roles"
                               ; special case) -- see that function's
                               ; own comment for why.
                               (step (guard (c (#t #f)) (ibpFirstStep innerExpr var))))
                            (if (not step)
                                (error #f "intExpr: computing the next round's du/v failed -- can't recurse" b1)
                                (let* ((inner (intExprIBPRound (car step) (cdr step) var (+ depth 1) original b1))
                                       (innerK (car inner)) (innerC (cdr inner)))
                                    (cons
                                        (makeExprSub a (if negate? (makeExprNeg innerK) innerK))
                                        (- (if negate? (- innerC) innerC))))))))
                ('t (error #f "intExpr: v*du did not integrate with existing techniques, and isn't a product either -- can't recurse" b1))))))

; Unwraps intExprIBPRound's (knownExpr . coeffOfOriginal) pair once it
; returns all the way to depth 0: coeffOfOriginal=0 means knownExpr IS
; the answer (the ordinary case); otherwise the boomerang case fired
; somewhere below, and I (the original integral, = this depth-0 call's
; own result) satisfies I = knownExpr + coeffOfOriginal*I, solved as
; I = knownExpr/(1-coeffOfOriginal). coeffOfOriginal=1 would mean
; 0*I = knownExpr -- no unique solution via this path -- a clean error
; rather than a division by zero.
(define (resolveIBPBoomerang kc)
    (let ((k (car kc)) (c (cdr kc)))
        (cond
            ((= c 0) k)
            ((= c 1) (error #f "intExpr: this IBP chain's cyclic case has no unique solution (the original integral's own coefficient came back exactly 1)" k))
            ('t (makeExprDiv k (makeExprNum (- 1 c)))))))

; A product where exactly one factor is constant w.r.t. var integrates by
; pulling the constant out. Curated shapes beyond that: secTanProductArg/
; cscCotProductArg above (the two specific pairs with an implicit power
; of exactly 1 on each side), then trigPowerProductResult
; (trigPowerIntegrals.scm) for the general Stewart-7.2 case -- ANY power
; of sin*cos, tan*sec, or cot*csc with a matching argument (sin(x)*
; cos(x), sin(x)^3, tan(x)^2*sec(x)^4, ...), checked AFTER the specific
; pairs above so an already-tested exact match (e.g. sec(x)*tan(x)) still
; takes the simpler direct path rather than the general one (both give
; the same answer regardless -- verified live -- this is purely about
; not disturbing an already-working fast path). Anything else -- a
; product of two genuinely var-dependent factors that isn't any of
; these -- falls back to Integration By Parts (intExprIBPRound above,
; seeded by integrationByParts.scm's ibpFirstStep) rather than erroring
; immediately here. If IBP itself can't resolve it either, ITS error
; (more specific about why -- e.g. "exceeded max recursive IBP rounds")
; is what propagates, not a generic one from this clause. exprSimplify
; wraps the FINAL combined result exactly once, here at the top of a
; fresh chain -- not inside intExprIBPRound's own recursive calls, which
; would re-simplify the same growing expression once per round for no
; benefit (exprSimplify itself already walks the entire tree bottom-up
; in one pass). This is the one place in this file that calls out to
; integrationByParts.scm -- see this file's own header for the (mutual)
; dependency note (also now shared with trigPowerIntegrals.scm).
(define (intExprMul e var)
    (let ((l (exprMulLeft e)) (r (exprMulRight e)))
        (cond
            ((not (containsVar? l var)) (makeExprMul l (intExpr r var)))
            ((not (containsVar? r var)) (makeExprMul (intExpr l var) r))
            ((secTanProductArg l r) => (lambda (u) (scaleByLinearArgInverse u var (makeExprApplyChecked 'sec u))))
            ((cscCotProductArg l r) => (lambda (u) (scaleByLinearArgInverse u var (makeExprNeg (makeExprApplyChecked 'csc u)))))
            ((trigPowerProductResult l r var) => (lambda (result) result))
            ((trigProductToSumResult l r var) => (lambda (result) result))
            ((trigMonomialResult e var) => (lambda (result) result))
            ((intExprAllowIBPFallback)
                (let ((step (ibpFirstStep e var)))
                    (exprSimplify (resolveIBPBoomerang (intExprIBPRound (car step) (cdr step) var 0 e #f)))))
            ('t (error #f "intExpr: product of two var-dependent factors needs integration by parts, out of scope" e)))))

; Whether e is exactly (pow var 2) for the given var -- the "x^2" half
; of the arctan/arcsin denominator patterns below.
(define (exprIsVarSquared? e var)
    (and (eqv? (exprKind e) 'pow) (exprEvar? (exprPowBase e)) (eqv? (exprEvarName (exprPowBase e)) var)
         (exprIsLiteral? (exprPowExponent e) 2)))

; c, for a positive LITERAL constant c, if e is exactly "c+x^2" or
; "x^2+c" -- the classic ∫dx/(x^2+c) = (1/sqrt(c))*arctan(x/sqrt(c))
; denominator shape. Bare var only (not a linear-in-var argument like
; (2x+1)^2 -- that would need u-substitution layered on top, out of
; scope, same boundary as everywhere else in this file), and c a
; literal number (not a compound constant expression) -- the curated
; common textbook shape, not a general constant-recognizer.
(define (varSquaredPlusConstCoeff e var)
    (cond
        ((and (eqv? (exprKind e) 'add) (exprIsVarSquared? (exprAddLeft e) var) (exprNum? (exprAddRight e)) (> (exprNumValue (exprAddRight e)) 0))
            (exprNumValue (exprAddRight e)))
        ((and (eqv? (exprKind e) 'add) (exprIsVarSquared? (exprAddRight e) var) (exprNum? (exprAddLeft e)) (> (exprNumValue (exprAddLeft e)) 0))
            (exprNumValue (exprAddLeft e)))
        ('t #f)))

; c, for a positive LITERAL constant c, if e is exactly "c-x^2" or
; "-x^2+c" -- the classic ∫dx/sqrt(c-x^2) = arcsin(x/sqrt(c))
; denominator shape (once wrapped in sqrt(...) by the caller below).
; Same bare-var/literal-constant scope as varSquaredPlusConstCoeff.
(define (constMinusVarSquaredCoeff e var)
    (cond
        ((and (eqv? (exprKind e) 'sub) (exprNum? (exprSubLeft e)) (> (exprNumValue (exprSubLeft e)) 0) (exprIsVarSquared? (exprSubRight e) var))
            (exprNumValue (exprSubLeft e)))
        ((and (eqv? (exprKind e) 'add) (eqv? (exprKind (exprAddLeft e)) 'neg) (exprIsVarSquared? (exprNegOperand (exprAddLeft e)) var)
              (exprNum? (exprAddRight e)) (> (exprNumValue (exprAddRight e)) 0))
            (exprNumValue (exprAddRight e)))
        ('t #f)))

; sqrt(c) as an AST node -- an exact literal when c is a perfect square
; (Chez's own numeric tower already returns an exact result there, same
; as limitExpr.scm's own evalKnownFunc relies on for sqrt), otherwise
; the symbolic sqrt(c) apply node -- kept irrational rather than
; converted to a lossy decimal, same "stay exact" posture as the rest
; of this file.
(define (sqrtConstNode c)
    (let ((sq (sqrt c)))
        (if (exact? sq) (makeExprNum sq) (makeExprApplyChecked 'sqrt (makeExprNum c)))))

; (1/sqrt(c))*arctan(x/sqrt(c)), specialized to plain arctan(x) when
; c=1 (the flagship "∫dx/(1+x^2)=arctan(x)" case) so the common case
; renders cleanly instead of the more general "(1/sqrt(1))*arctan(x/
; sqrt(1))" shape.
(define (arctanAntiderivative c var)
    (if (= c 1)
        (makeExprApplyChecked 'arctan (makeExprEvar var))
        (let ((sqrtC (sqrtConstNode c)))
            (makeExprMul (makeExprDiv (makeExprNum 1) sqrtC) (makeExprApplyChecked 'arctan (makeExprDiv (makeExprEvar var) sqrtC))))))

; arcsin(x/sqrt(c)), specialized to plain arcsin(x) when c=1 -- same
; reasoning as arctanAntiderivative above. No leading 1/sqrt(c) factor
; here (unlike arctan's): d/dx[arcsin(x/a)] = (1/a)/sqrt(1-(x/a)^2) =
; 1/sqrt(a^2-x^2) already, with no extra scaling needed.
(define (arcsinAntiderivative c var)
    (if (= c 1)
        (makeExprApplyChecked 'arcsin (makeExprEvar var))
        (makeExprApplyChecked 'arcsin (makeExprDiv (makeExprEvar var) (sqrtConstNode c)))))

; Constant/constant already folds to a literal before this is ever
; reached (exprAst's own smart constructor). Recognized shapes: constant
; denominator (pull it out, integrate the numerator); constant numerator
; over a LINEAR denominator (the ln|linear| pattern); constant numerator
; over a linear denominator raised to a power (rewrite as a negative-
; exponent pow and hand off to intExprPow); numerator exactly 1 over
; "c+x^2" (arctan) or over "sqrt(c-x^2)" (arcsin), c a positive literal
; constant. Anything else -- e.g. a genuinely var-dependent numerator
; over a var-dependent denominator -- is out of scope.
(define (intExprDiv e var)
    (let ((n (exprDivNumer e)) (d (exprDivDenom e)))
        (cond
            ((not (containsVar? d var)) (makeExprDiv (intExpr n var) d))
            ; Trig quotients (1/cos(x)^2, sin(x)/cos(x), sin(x)^2/cos(x), ...):
            ; trigRationalIntegrals.scm. Checked before the generic errors
            ; below, which used to reject every one of them.
            ((trigMonomialResult e var) => (lambda (result) result))
            ((trigDivRewriteResult e var) => (lambda (result) result))
            ((containsVar? n var) (error #f "intExpr: a genuinely var-dependent numerator over a var-dependent denominator is out of scope" e))
            ((linearCoeffs d var) =>
                (lambda (ab) (makeExprMul (makeExprDiv n (makeExprNum (car ab))) (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs d)))))
            ((and (exprPow? d) (linearCoeffs (exprPowBase d) var) (exprNum? (exprPowExponent d)))
                (intExprPow (makeExprPow (exprPowBase d) (makeExprNeg (exprPowExponent d))) var
                    (lambda (result) (makeExprMul n result))))
            ((and (exprIsLiteral? n 1) (varSquaredPlusConstCoeff d var)) => (lambda (c) (arctanAntiderivative c var)))
            ((and (exprIsLiteral? n 1) (exprIsApplyOf? d 'sqrt) (constMinusVarSquaredCoeff (exprApplyArg d) var)) =>
                (lambda (c) (arcsinAntiderivative c var)))
            ('t (error #f "intExpr: denominator isn't constant, linear, or a power of a linear expression -- out of scope" e)))))

; base^n: only base LINEAR-in-var (ax+b, a<>0) with a literal constant
; exponent n is handled -- the generalized power rule with linear
; substitution: n<>-1 -> (1/a) * base^(n+1)/(n+1); n=-1 -> (1/a)*ln|base|
; (same ln pattern intExprDiv's own linear-denominator case produces, so
; "x^-1" and "1/x" integrate identically regardless of which shape the
; input happened to parse as). A non-constant exponent (e.g. var^var) or
; a non-linear base (e.g. (x^2+1)^5) is out of scope -- no elementary
; antiderivative exists via these rules alone.
;
; The optional third argument lets intExprDiv's power-of-linear-
; denominator case reuse this rule and then wrap the result (multiplying
; by the original numerator) without duplicating the whole n=-1/n<>-1
; branch here.
(define intExprPow
    (case-lambda
        ((e var) (intExprPow e var (lambda (result) result)))
        ((e var wrap)
            (let ((base (exprPowBase e)) (exponent (exprPowExponent e)))
                (cond
                    ((containsVar? exponent var) (error #f "intExpr: a variable exponent has no elementary antiderivative via these rules" e))
                    ((not (exprNum? exponent)) (error #f "intExpr: only a literal constant exponent is supported" e))
                    ; sec(u)^2 -> tan(u), csc(u)^2 -> -cot(u) -- the other
                    ; standard memorized pair (matching secTanProductArg/
                    ; cscCotProductArg's own sibling shapes above), checked
                    ; before the "base must be linear" rule below since
                    ; sec(u)/csc(u) themselves are never a linear base.
                    ((and (exprIsApplyOf? base 'sec) (exprIsLiteral? exponent 2))
                        (wrap (scaleByLinearArgInverse (exprApplyArg base) var (makeExprApplyChecked 'tan (exprApplyArg base)))))
                    ((and (exprIsApplyOf? base 'csc) (exprIsLiteral? exponent 2))
                        (wrap (scaleByLinearArgInverse (exprApplyArg base) var (makeExprNeg (makeExprApplyChecked 'cot (exprApplyArg base))))))
                    ; The general Stewart-7.2 case (trigPowerIntegrals.scm):
                    ; ANY literal nonnegative integer power of a bare
                    ; sin/cos/tan/sec/cot/csc call -- sin(x)^3, sec(x)^4,
                    ; cot(x)^5, and so on -- checked after the sec^2/csc^2
                    ; shortcuts above (same reasoning as intExprMul's own
                    ; trigPowerProductResult check: doesn't disturb the
                    ; already-tested fast path for exactly those two).
                    ((and (exprApply? base) (memv (exprApplyFunc base) '(sin cos tan sec cot csc))
                          (exprNum? exponent) (integer? (exprNumValue exponent)) (>= (exprNumValue exponent) 0))
                        (wrap (trigPowerBaseResult (exprApplyFunc base) (exprNumValue exponent) (exprApplyArg base) var)))
                    ; Negative-integer or fractional power of a trig function
                    ; (sec(x)^(-2), sin(x)^(1/2)): trigRationalIntegrals.scm.
                    ((trigMonomialResult e var) => wrap)
                    ((not (linearCoeffs base var)) (error #f "intExpr: only a linear base (ax+b) is supported -- u-substitution beyond a linear argument is out of scope" e))
                    ('t
                        (let ((a (makeExprNum (car (linearCoeffs base var)))))
                            (wrap
                                (if (exprIsLiteral? exponent -1)
                                    (makeExprMul (makeExprDiv (makeExprNum 1) a) (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs base)))
                                    (makeExprMul (makeExprDiv (makeExprNum 1) a)
                                        (makeExprDiv (makeExprPow base (makeExprAdd exponent (makeExprNum 1))) (makeExprAdd exponent (makeExprNum 1)))))))))))))

; f(g(x)): only g LINEAR-in-var (ax+b) is handled -- f(g(x))'s
; antiderivative is (1/a)*F(g(x)), where F is antiderivativeOfKnownFunc's
; table entry for f. a=1,b=0 (bare var) is the ordinary case, handled by
; the exact same formula (1/1 folds away via the smart constructors).
;
; ln(x) is the one antiderivativeOfKnownFunc entry that can be made to
; fully resolve via the SAME round-by-round IBP loop intExprMul uses
; (ibpStep/intExprIBPRound/resolveIBPBoomerang/exprSimplify -- exactly
; intExprMul's own final line, just seeded from an explicit (u . dv)
; pair instead of ibpFirstStep's LIATE split, since there's no product
; here to split): u=ln(x), implicit dv=1*dx, v=x, du=1/x dx -- b1raw =
; x*(1/x) is pure-poly (no apply node anywhere in it), so exprSimplify's
; existing bridge cancels it to the literal constant 1 without needing
; any new machinery, and ∫1 dx=x closes the loop cleanly:
; ∫ln(x)dx=x*ln(x)-x.
;
; log/arcsin/arccos/arctan don't get this same treatment, even though
; the identical construction is mathematically well-defined for all of
; them (confirmed live, 2026-08-17): log(x)'s b1raw is x/(x*ln(10)) --
; algebraically 1/ln(10), but ln(10) is a CONSTANT wrapped in an apply
; node, and exprSimplify's pure-poly gate (exprSimplify.scm) treats ANY
; subtree containing an apply node as entirely unbridgeable, so that
; cancellation never happens and IBP's own continuation logic then
; misreads the un-cancelled x/(x*ln(10)) as a further-splittable
; product, failing with a confusing internal error ("computing the next
; round's du/v failed") instead of a clean one. arcsin(x) fares even
; worse -- exprSimplify's same gate leaves its b1 unrecognized as a
; constant multiple of the original integrand, and it spuriously trips
; the boomerang-detection path instead, erroring "this IBP chain's
; cyclic case has no unique solution" (misleading -- there's no genuine
; cycle here at all). arccos(x)/arctan(x) happen to fail cleanly (their
; SECOND round needs a var-dependent-numerator rational-function
; technique this file doesn't have at all, same reasoning
; antiderivativeOfKnownFunc's own comment already gives), so those two
; are message-neutral either way. Given three of the four regress
; either silently-confusing or outright misleading error text for no
; resolving benefit, and fixing the root cause (exprSimplify treating a
; var-FREE apply-containing subtree as an opaque atom rather than
; entirely unbridgeable) is a real structural change belonging to
; exprSimplify.scm itself, not this call site -- only ln is special-
; cased here. Revisit log/arcsin/arccos/arctan once that gap closes.
;
; Gated on intExprAllowIBPFallback the same way intExprMul's own
; fallback is (see that parameter's own comment) -- without this guard,
; intExprIBPRound's "does the remainder already integrate via existing
; techniques" check (which deliberately calls intExpr with the fallback
; OFF, precisely to avoid this) could recurse into a fresh, depth-0 IBP
; attempt on a b1 that happens to contain ln(...), defeating
; maxIByPRounds' bound the same way an unguarded intExprMul fallback
; would. With the fallback off, falls through to the ordinary table
; lookup below, which errors for ln exactly as it used to.
(define (intExprApply e var)
    (let ((func (exprApplyFunc e)) (arg (exprApplyArg e)))
        (if (and (eqv? func 'ln) (intExprAllowIBPFallback))
            (let ((step (ibpStep e (makeExprNum 1) var)))
                (exprSimplify (resolveIBPBoomerang (intExprIBPRound (car step) (cdr step) var 0 e #f))))
            (scaleByLinearArgInverse arg var (antiderivativeOfKnownFunc func arg)))))

; ---- Cross-transcendental-boundary simplification (icalc's OWN final
;      polish pass -- NOT a change to exprSimplify.scm itself) ----
;
; exprSimplify's own exprIsPurePoly? gate (exprSimplify.scm) treats ANY
; subtree containing an apply node (exp(x), sin(x), ...) as entirely
; unbridgeable AT THAT LEVEL, so it recurses into children instead of
; running the real normalizer (bridgeSimplifyPurePoly, which distributes/
; combines via ms-from-str/ms-poly-str) on the whole thing -- e.g.
; "x^2*exp(x)-(2*x*exp(x)-exp(x)*2)" never gets its outer subtraction
; distributed or its coefficient ordering cleaned up, even after
; exprSimplify already ran (it's a fixed point -- calling it again does
; nothing). Confirmed live (2026-08-19) that this gate is load-bearing,
; not overcautious: ms-from-str's own tokenizer (expandParse.scm's
; parseExpansion, the LEGACY string-based engine, unlike exprParse.scm's
; newer function-call-aware grammar) has no concept of "exp"/"sin"/etc.
; as function names at all -- fed "exp(x)*2" directly it does NOT error,
; it silently misreads "exp" as three implicitly-multiplied one-letter
; variables and returns "2epx^2", a plausible-looking but meaningless
; polynomial. So bridgeSimplifyPurePoly can NEVER be handed a tree
; containing an apply node, under any circumstance.
;
; Fix: swap each DISTINCT maximal apply-subtree for a fresh placeholder
; variable ms-from-str already understands as an ordinary indeterminate,
; run the placeholder-only tree through bridgeSimplifyPurePoly (now safe
; -- genuinely multivariable, confirmed live via test-golden.scm's own
; multivariable expand() coverage), then substitute the original
; subtrees back in. Repeated occurrences of the IDENTICAL apply-subtree
; (exprEqual?-deduplicated) share ONE placeholder -- that sharing is
; exactly what lets the normalizer combine terms across them.
;
; Placeholders are "q_0", "q_1", ... -- groupIndexedVars (expandParse.scm)
; fuses "q_<digits>" into one token/symbol that round-trips cleanly
; through exprToString/exprParse with no involvement from dispatcher.scm's
; UNRELATED x_1<->x₁ subscript DISPLAY notation (that conversion only
; ever runs at dispatcher.scm's own I/O boundary). "q" is essentially
; never a variable a real calculus problem integrates with respect to,
; and the mandatory "_N" suffix makes collision with any bare
; single-letter input variable structurally impossible regardless (q
; alone and q_0 are different symbols outright).
;
; This lives here, not in exprSimplify.scm -- zero risk to that file's
; other 7 callers (diffExpr.scm, implicitDiff.scm, limitExpr.scm,
; curveSketch.scm, calcAnalysis.scm, areaBetweenCurves.scm,
; riemannLimitIntegral.scm), which keep their exact current behavior.
;
; What this fixes: undistributed parens and inconsistent coefficient
; ordering around a repeated transcendental factor. What it does NOT fix:
; it doesn't additionally FACTOR the result (combineLikeTerms merges
; identical variable-exponent signatures, it doesn't factor a shared
; variable out of dissimilar-degree terms -- that's factorPoly.scm's job,
; and it's single-variable-only regardless); and it doesn't resolve
; trig-identity messiness (cos(x)^2 vs cos(2x)/sin(2x) are structurally
; DIFFERENT apply subtrees to this pass -- unifying them needs actual
; trig-identity knowledge, not polynomial normalization).

; (subtree . placeholder-symbol) pair for e itself, if e (exprEqual?) is
; already present in atoms -- else #f. atoms is a list of such pairs.
(define (findApplyAtom e atoms)
    (cond
        ((null? atoms) #f)
        ((exprEqual? (caar atoms) e) (car atoms))
        ('t (findApplyAtom e (cdr atoms)))))

; Walks e, collecting one (subtree . placeholder) pair per DISTINCT
; maximal apply subtree, first-seen order. Does NOT recurse into an
; apply node's own argument -- the whole exp(x)/sin(2*x)/etc. is one
; opaque atom; its internal structure already went through exprSimplify's
; own recursive apply-arg case and is irrelevant to this pass.
(define (collectApplyAtoms e atoms)
    (case (exprKind e)
        ((num evar) atoms)
        ((apply)
            (if (findApplyAtom e atoms)
                atoms
                (append atoms (list (cons e (string->symbol (string-append "q_" (number->string (length atoms)))))))))
        ((neg) (collectApplyAtoms (exprNegOperand e) atoms))
        ((add) (collectApplyAtoms (exprAddRight e) (collectApplyAtoms (exprAddLeft e) atoms)))
        ((sub) (collectApplyAtoms (exprSubRight e) (collectApplyAtoms (exprSubLeft e) atoms)))
        ((mul) (collectApplyAtoms (exprMulRight e) (collectApplyAtoms (exprMulLeft e) atoms)))
        ((div) (collectApplyAtoms (exprDivDenom e) (collectApplyAtoms (exprDivNumer e) atoms)))
        ((pow) (collectApplyAtoms (exprPowExponent e) (collectApplyAtoms (exprPowBase e) atoms)))
        (else atoms)))

; Rebuilds e, replacing every matched apply-subtree occurrence with its
; placeholder evar node. Guaranteed apply-free on return -- every apply
; node in e was captured into atoms by collectApplyAtoms first.
; The atom lookup is only attempted at APPLY nodes (2026-09-19): atoms are
; by construction always apply subtrees, so an add/mul/etc. node can never
; match one, and exprEqual? (limitExpr.scm) renders BOTH sides to strings on
; every call. Trying it at every node of the tree rendered each nested
; subtree once per atom -- ~k^2 characters per atom for a k-term nested sum
; -- which made this one pass take 2.8s on cos(x)^200's 100-atom result
; while the polynomial bridge it feeds took 23ms.
(define (substituteApplyAtoms e atoms)
    (let ((found (and (eqv? (exprKind e) 'apply) (findApplyAtom e atoms))))
        (if found
            (makeExprEvar (cdr found))
            (case (exprKind e)
                ((num evar) e)
                ((neg) (makeExprNeg (substituteApplyAtoms (exprNegOperand e) atoms)))
                ((add) (makeExprAdd (substituteApplyAtoms (exprAddLeft e) atoms) (substituteApplyAtoms (exprAddRight e) atoms)))
                ((sub) (makeExprSub (substituteApplyAtoms (exprSubLeft e) atoms) (substituteApplyAtoms (exprSubRight e) atoms)))
                ((mul) (makeExprMul (substituteApplyAtoms (exprMulLeft e) atoms) (substituteApplyAtoms (exprMulRight e) atoms)))
                ((div) (makeExprDiv (substituteApplyAtoms (exprDivNumer e) atoms) (substituteApplyAtoms (exprDivDenom e) atoms)))
                ((pow) (makeExprPow (substituteApplyAtoms (exprPowBase e) atoms) (substituteApplyAtoms (exprPowExponent e) atoms)))
                (else e)))))

; placeholder-symbol -> subtree lookup (the reverse direction of
; findApplyAtom, used by restoreApplyAtoms below).
(define (findOriginalForPlaceholder sym atoms)
    (cond
        ((null? atoms) #f)
        ((eqv? (cdar atoms) sym) (car atoms))
        ('t (findOriginalForPlaceholder sym (cdr atoms)))))

; Walks a (post-bridge) tree, replacing each placeholder evar back with
; its original apply-subtree.
(define (restoreApplyAtoms e atoms)
    (case (exprKind e)
        ((num) e)
        ((evar)
            (let ((found (findOriginalForPlaceholder (exprEvarName e) atoms)))
                (if found (car found) e)))
        ((neg) (makeExprNeg (restoreApplyAtoms (exprNegOperand e) atoms)))
        ((add) (makeExprAdd (restoreApplyAtoms (exprAddLeft e) atoms) (restoreApplyAtoms (exprAddRight e) atoms)))
        ((sub) (makeExprSub (restoreApplyAtoms (exprSubLeft e) atoms) (restoreApplyAtoms (exprSubRight e) atoms)))
        ((mul) (makeExprMul (restoreApplyAtoms (exprMulLeft e) atoms) (restoreApplyAtoms (exprMulRight e) atoms)))
        ((div) (makeExprDiv (restoreApplyAtoms (exprDivNumer e) atoms) (restoreApplyAtoms (exprDivDenom e) atoms)))
        ((pow) (makeExprPow (restoreApplyAtoms (exprPowBase e) atoms) (restoreApplyAtoms (exprPowExponent e) atoms)))
        ((apply) (makeExprApplyChecked (exprApplyFunc e) (restoreApplyAtoms (exprApplyArg e) atoms)))
        (else e)))

; The driving function -- a no-op (returns e unchanged) if e contains no
; apply node at all (ordinary exprSimplify already fully handled that
; whole-tree case, nothing to close here). Otherwise substitutes
; placeholders in, bridges through exprSimplify.scm's existing
; bridgeSimplifyPurePoly (guaranteed apply-free input, so its own
; exprIsPurePoly? gate passes unconditionally), and restores the
; original subtrees. Wrapped in guard -- if anything about this extra
; pass goes wrong (an edge case the pure-poly bridge chokes on once fed
; synthetic multivariable input), fail SOFT back to the already-
; simplified e rather than raising -- this is a polish step, never
; allowed to turn a correct-but-ugly answer into an outright error.
(define (simplifyAcrossApplyBoundaries e)
    (let ((atoms (collectApplyAtoms e '())))
        (if (null? atoms)
            e
            (guard (c (#t e))
                (restoreApplyAtoms (bridgeSimplifyPurePoly (substituteApplyAtoms e atoms)) atoms)))))

; ---- Definite integrals via the Fundamental Theorem of Calculus ----
;
; Mechanical once the antiderivative exists: evaluate it at both bounds
; (reusing limitExpr.scm's own point-evaluator) and subtract. lower/upper
; are exact rationals (same point representation limitExpr.scm uses for
; a finite limit -- an infinite bound, i.e. an improper integral, is out
; of scope here). simplifyAcrossApplyBoundaries here is the same no-op-
; safe polish icalc's own dispatcher.scm handler applies -- doesn't
; change the numeric RESULT (algebraically equivalent forms evaluate
; identically), but a cleaner, fully-distributed antiderivative is
; less likely to spuriously evaluate to 'undefined at a boundary where
; an uncancelled term would otherwise divide by zero.
; Bounds must be finite real numbers (2026-09-19). Before this check an
; infinite or non-numeric bound (the dispatcher's string->number gives #f for
; "inf"/"+infinity") flowed into evalExprAt and died with a raw Chez
; exception ("Exception in =: #f is not a number"). Improper integrals --
; an infinite bound, or an integrand undefined at a bound -- are Stewart
; 7.8 and not implemented yet; say so specifically.
(define (definiteIntegral e var lower upper)
    (if (not (and (real? lower) (real? upper)))
        (error #f "definiteIntegral: both bounds must be finite numbers -- improper integrals (an infinite bound) aren't supported yet"))
    (let* ((antideriv (simplifyAcrossApplyBoundaries (exprSimplify (intExpr e var))))
           (atUpper (evalExprAt antideriv var upper))
           (atLower (evalExprAt antideriv var lower)))
        (if (or (eqv? atUpper 'undefined) (eqv? atLower 'undefined))
            (error #f "definiteIntegral: the antiderivative is undefined at one of the given bounds (if the integrand blows up there, this is an improper integral, which isn't supported yet)")
            (- atUpper atLower))))
