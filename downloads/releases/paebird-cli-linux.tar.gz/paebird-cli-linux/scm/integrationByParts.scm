;;; integrationByParts.scm -- pure, non-recursive Integrate By Parts
;;; building blocks: splitting a product into factors, LIATE (deciding
;;; which factor is u vs. dv for a FRESH product), and computing one
;;; round of ∫ u dv = uv - ∫ v du. Every function here is a single
;;; mechanical step -- no recursion, no depth/round tracking, no giving
;;; up. intExpr.scm's own intExprMul/intExprIBPRound are the control
;;; loop that calls out to these repeatedly and decides when to stop;
;;; see that file's header for the resulting two-way dependency (this
;;; file's ibpStep calls back into intExpr.scm's own diffExpr/intExpr).
;;; liateCategory ALSO calls into trigPowerIntegrals.scm
;;; (trigPowerProductShape?) so a trig-power PRODUCT (sin(x)*cos(x), not
;;; just a bare sin(x)) is correctly classified Trigonometric rather
;;; than falling through to the Algebraic default -- a third genuine
;;; two-way dependency, same shape as the intExpr.scm one. ibpFirstStep
;;; further calls into chooser3.scm (flattenMulFactors/exprSize/
;;; chooser3Candidates) whenever a product has 3+ factors -- ordinary
;;; 2-factor LIATE can't regroup a chain like x^2*sin(x)*cos(x) into the
;;; split that actually converges; see chooser3.scm's own header. A
;;; fourth genuine two-way dependency, same shape as the other three.
;;;
;;; The integrand e is expected to already be a parsed AST (exprParse.scm's
;;; output) whose top-level node is a product (exprKind e => 'mul) -- so
;;; splitting it into its two factors is just exprMulLeft/exprMulRight, not
;;; a token-by-token walk. du and v aren't parsed out of anything either --
;;; they're computed from u and dv via the engine's existing diffExpr/intExpr.

; Splits a product AST node into its two factors, left and right.
(define (splitIByPFactors e)
    (if (not (eqv? (exprKind e) 'mul))
        (error #f "splitIByPFactors: integrand is not a product" e)
        (cons (exprMulLeft e) (exprMulRight e))))

; ---- One mechanical step of the IBP formula ----
; ∫ u dv = uv - ∫ v du. This file only ever computes ONE step at a time
; (no recursion, no depth tracking, no "does the remainder resolve"
; check) -- intExpr.scm's own intExprMul/intExprIBPRound own the control
; loop that decides whether/how to keep going. See that file's header
; for the two-way dependency this implies.

; One step for an EXPLICIT (u . dv) pair -- the caller decides how u/dv
; were chosen (LIATE, via ibpFirstStep below, for a fresh product;
; "keep roles" -- reusing the previous round's v/du as the next
; dv/u directly, no new heuristic needed -- for continuing an existing
; chain, intExpr.scm's own job). Returns (cons a b1): a=u*v, and
; b1=v*du is the new integral still needing to be solved.
(define (ibpStep u dv var)
    (let ((du (diffExpr u var)) (v (intExpr dv var)))
        (cons (makeExprMul u v) (makeExprMul v du))))

; ---- LIATE: decide which factor is u, which is dv ----
;
; Priority order (earlier = more likely to be u): Logarithmic, Inverse
; trig, Algebraic, Trigonometric, Exponential. arcsin/arccos/arctan are
; now real functions (exprAst.scm's exprApplyKnownFuncs), so 'I' does
; genuinely match below -- e.g. x*arctan(x) correctly picks arctan(x) as
; u ahead of the algebraic x, matching the usual textbook LIATE choice
; (though the resulting ∫(x^2/(1+x^2))dx from THAT round still has no
; elementary rule in this engine -- no polynomial/rational simplification
; exists here -- so it fails cleanly on the next round rather than
; completing; still the mathematically correct u/dv choice, just not a
; fully solvable example with this engine's other limitations).
(define liateOrder '(L I A T E))

; Classifies a single factor's top-level shape. ln/log -> L (and MUST be
; u -- intExpr.scm has no antiderivative rule for either, so picking one
; as dv would always fail downstream in ibpStep's own (intExpr dv var)).
; arcsin/arccos/arctan -> I, same "MUST be u" reasoning (intExpr.scm has
; no antiderivative rule for any of them either). sin/cos/tan/sec/csc/
; cot -> T. exp -> E. A pow node whose base is itself transcendental
; (e.g. sin(x)^2) inherits the base's category. A mul node shaped like a
; trig-power PRODUCT (sin(x)*cos(x), tan(x)^2*sec(x), ...) is ALSO T --
; trigPowerProductShape? (trigPowerIntegrals.scm), a genuine forward
; reference (same reasoning as this file's own two-way dependency on
; intExpr.scm) -- without this, such a product falls through to the
; Algebraic default below and can tie against a genuinely algebraic
; factor, letting LIATE pick the WRONG u/dv (confirmed live: this
; produced a non-terminating IBP chain for x*sin(x)*cos(x) instead of
; routing sin(x)*cos(x) straight through trigPowerIntegrals.scm as dv).
; Everything else -- bare var, polynomial, sqrt/abs, other +/-/*//
; combos -- is Algebraic.
(define (liateCategory e)
    (case (exprKind e)
        ((apply)
            (case (exprApplyFunc e)
                ((ln log) 'L)
                ((arcsin arccos arctan) 'I)
                ((sin cos tan sec csc cot) 'T)
                ((exp) 'E)
                (else 'A)))
        ((pow) (liateCategory (exprPowBase e)))
        ((mul) (if (trigPowerProductShape? e) 'T 'A))
        (else 'A)))

; Position of e's category in liateOrder -- lower means more u-like.
(define (liateRank e)
    (let loop ((remaining liateOrder) (i 0))
        (cond
            ((null? remaining) (error #f "liateRank: unrecognized LIATE category" (liateCategory e)))
            ((eqv? (car remaining) (liateCategory e)) i)
            ('t (loop (cdr remaining) (+ i 1))))))

; Given splitIByPFactors' (left . right) pair, returns (u . dv): whichever
; factor ranks earlier in L-I-A-T-E is u, the other is dv. A tie (both
; factors in the same category -- e.g. x*x^2, or sin(x)*cos(x)) keeps
; left as u -- an arbitrary but deterministic tie-break.
(define (pickUDv factors)
    (let ((l (car factors)) (r (cdr factors)))
        (if (<= (liateRank l) (liateRank r))
            (cons l r)
            (cons r l))))

;;; -------------------------------------------------------------------

; One step of an IBP chain, fresh or continuing: picks u/dv via LIATE
; from a product, then delegates to ibpStep above. Used both for the
; FIRST step of a chain and for every continuation round -- earlier this
; session, continuations reused the previous round's (v . du) as the
; next (dv . u) directly ("keep roles", no fresh LIATE call), on the
; reasoning that v already carries the "integrates cleanly" role and du
; already carries the "differentiates cleanly" role. That reasoning
; breaks down once exprSimplify (called on b1 before this is reached --
; intExpr.scm's own intExprIBPRound) reshuffles the product's literal
; factor structure: "keep roles" then blindly assigns u/dv based on
; which SIDE of the reshuffled product a factor landed on, not what it
; actually is -- confirmed live as a real bug: x^2*sin(x)*cos(x)'s
; second IBP round produced "-x*cos(x)^2" after simplification, and
; "keep roles" assigned u=cos(x)^2/dv=x (backwards -- x*cos(x)^2 alone
; correctly picks u=x/dv=cos(x)^2 via fresh LIATE), sending the chain
; into an ever-growing, non-terminating remainder instead of resolving.
; Always re-deriving u/dv from LIATE, every round, is what a human
; solving this by hand would do too -- fixed by removing "keep roles"
; entirely; see splitForIByPContinuation below, now just a shape check
; instead of a role-picker.
;
; e's own TWO top-level factors (exprMulLeft/Right) are all ordinary
; 2-factor LIATE ever sees -- fine for a genuine 2-factor product, but
; e may flatten (chooser3.scm's flattenMulFactors) into THREE OR MORE
; factors nested under the AST's own left-associative parsing (e.g.
; x^2*sin(x)*cos(x) parses as (x^2*sin(x))*cos(x)): 2-factor LIATE only
; ever sees {x^2*sin(x), cos(x)} as the two choices, never the
; regrouping {x^2, sin(x)*cos(x)} that actually converges. When there
; are 3+ factors, chooser3.scm's own candidates (best guess first) are
; tried via ibpStep until one doesn't grow the problem past its
; starting size (chooser3.scm's own header explains why, and what
; "grow" means here) -- if NONE do, degrade to the plain 2-factor
; LIATE split on e's own literal top-level factors instead of picking
; a candidate anyway (see ibpTryChooser3Candidates's own comment on why
; NOT falling back to "the first candidate regardless" matters here).
; Uses normalizedFlattenMulFactors (chooser3.scm), not the raw
; flattenMulFactors, for both the length check and the candidates
; themselves -- a numeric coefficient left stranded on one factor by a
; PRIOR round (e.g. "cos(x)^2/2*2*x") can mask a genuine 3+-factor
; trig-cluster shape underneath ("cos(x)^2*x" once "1/2*2" cancels);
; normalizedFlattenMulFactors pulls that apart before classification.
; When normalization collapses the count back down to exactly 2 (the
; coefficient canceled entirely, as in that example), rebuild a clean
; 2-factor product from the normalized list and hand it to the plain
; LIATE path instead of going through chooser3 at all -- see
; chooser3.scm's own header on normalizedFlattenMulFactors.
(define (ibpFirstStep e var)
    (let ((factors (normalizedFlattenMulFactors e)))
        (cond
            ; Degenerate: normalization can only collapse below 2
            ; factors if every factor but one was purely numeric,
            ; folding entirely into a coefficient of 1 (e.g.
            ; "cos(x)^2/2 * 2" -> just cos(x)^2) -- not expected for a
            ; genuine var-containing product, but multiplyFactors/
            ; splitIByPFactors need an actual 2-factor mul node, so
            ; fall back to e itself (unnormalized) rather than risk it.
            ((< (length factors) 2) (ibpPlainStep e var))
            ((> (length factors) 2)
                (or (ibpTryChooser3Candidates (chooser3Candidates factors) (exprSize e) var)
                    (ibpPlainStep (multiplyFactors factors) var)))
            ('t (ibpPlainStep (multiplyFactors factors) var)))))

; The ordinary 2-factor LIATE split, straight off e's own literal
; exprMulLeft/Right -- factored out so both ibpFirstStep's plain path
; and its chooser3 degrade-to-plain fallback share it.
(define (ibpPlainStep e var)
    (let ((ud (pickUDv (splitIByPFactors e))))
        (ibpStep (car ud) (cdr ud) var)))

; Tries chooser3.scm's candidates in order (each already an actual
; (u . dv) expr pair); returns the first whose resulting remainder
; (the cdr of ibpStep's result, b1) doesn't exceed originalSize --
; "if the result is larger, try the next alternative" (chooser3.scm's
; own header). A candidate whose own ibpStep call fails outright (e.g.
; diffExpr/intExpr choke on that particular grouping) is skipped, not
; fatal, same guarded-failure posture as splitForIByPContinuation's own
; caller in intExpr.scm.
;
; Returns #f -- NOT the first candidate that merely computed
; successfully -- when NO candidate satisfies the size check.
; Confirmed live as a real performance regression when this used to
; fall back to "the first one that computed at all, regardless of
; size": for a genuinely unsolvable mixed case (sin(x)*cos(x)*tan(x) --
; no clean cluster, tan isn't in sin/cos's family), every candidate
; here gets rejected by the size check, but silently accepting one
; anyway let the remainder keep GROWING every round instead of
; terminating -- over a minute of compounding work across
; maxIByPRounds's up to 8 rounds before finally (correctly) giving up.
; Returning #f here instead lets ibpFirstStep degrade to the plain
; 2-factor path (ibpPlainStep) for that round, which is no worse than
; chooser3 not existing at all, and stops the compounding.
; The size check compares against exprSimplify'd b1, not the raw
; ibpStep result -- confirmed live as a real bug: raw b1 can carry
; uncombined constants straight from v/du (e.g. "-cos(x)^2/2*2*x", size
; 11, before "1/2" and "2" ever get folded together) that make an
; otherwise-good candidate look BIGGER than it really is, rejecting the
; correct choice (x^2*sin(x)*cos(x)'s own cluster candidate, whose
; simplified b1 -x*cos(x)^2 is genuinely smaller than the original, was
; being thrown out this way). intExprIBPRound (intExpr.scm) simplifies
; b1 again anyway once a candidate is chosen -- this duplicate work is
; the cost of comparing candidates fairly.
(define (ibpTryChooser3Candidates candidates originalSize var)
    (let loop ((remaining candidates))
        (if (null? remaining)
            #f
            (let* ((c (car remaining))
                   (step (guard (cc (#t #f)) (ibpStep (car c) (cdr c) var))))
                (if (and step (<= (exprSize (exprSimplify (cdr step))) originalSize))
                    step
                    (loop (cdr remaining)))))))

; Given an already-simplified b1 that did NOT integrate directly,
; returns (list innerExpr negate?) if b1 is shaped as a product IBP can
; keep going on (via ibpFirstStep, fresh LIATE -- see that function's
; own comment) -- either b1 IS the product directly, or it's wrapped in
; a negation: makeExprMul's own smart constructor (exprAst.scm) pulls a
; negated factor out to wrap the WHOLE product -- e.g. v=-cos(x) makes
; b1 come back as (neg (mul cos(x) du)), kind 'neg, not 'mul. Still a
; product underneath, just negated: ∫b1 = ∫-(inner) = -∫inner, so the
; caller should continue on the unwrapped inner product and negate the
; eventual result (the second list element, negate?). Returns #f if b1
; is neither shape -- IBP has nothing left to try.
(define (splitForIByPContinuation b1)
    (cond
        ((eqv? (exprKind b1) 'mul) (list b1 #f))
        ((and (eqv? (exprKind b1) 'neg) (eqv? (exprKind (exprNegOperand b1)) 'mul)) (list (exprNegOperand b1) #t))
        ('t #f)))