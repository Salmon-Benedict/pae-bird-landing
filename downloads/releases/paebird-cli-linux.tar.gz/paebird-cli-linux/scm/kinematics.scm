; kinematics.scm -- calculus.md's sibling for physics: the "Two solving
; modes kinematics needs" from project_physics_module.md.
;
; Depends on: exprAst.scm, exprParse.scm, diffExpr.scm (velocity/
; acceleration), physicsUnits.scm (parsePhysicsKnowns et al.),
; physicsSolve.scm (solvePhysicsCommand). Load this file after
; physicsSolve.scm.
;
; ---- Function-based mode: velocity/acceleration ----
; Physics vocabulary over the EXISTING dcalc engine (diffExpr.scm) --
; almost no new math, per the plan doc's own framing. Deliberately
; unitless: symbolic unit-propagation THROUGH differentiation is Stage
; 3 work (project_physics_module.md), not this file's. Added to
; dispatcher.scm's singleVarCalcCommand? so they get ";:velocity"/
; ";:acceleration" chaining and "@:velocity <var>" persistence for free
; via the existing calcVar register -- same single-bare-variable-arg
; shape as dcalc itself, no new plumbing needed.
(define (velocity e var) (diffExpr e var))
(define (acceleration e var) (diffExpr (diffExpr e var) var))

; ---- SUVAT mode ----
; Constant-acceleration kinematics: given exactly 3 of {s, u, v, a, t}
; as unit-annotated values, find the other 2 via the 4 standard
; kinematic equations. Stored as plain strings (SI-stripped values
; substitute in directly) rather than any new equation representation.
; The actual solving (greedy equation selection, branching over
; multiple real roots) is physicsSolve.scm's generic
; solvePhysicsSystem, proven correct here in Phase 1 and now shared by
; every physics topic -- see that file's own header for why the
; extraction is safe (same logic, just parameterized).
(define suvatVars '(s u v a t))
(define suvatEquations
    (list "v=u+a*t" "s=u*t+1/2*a*t^2" "v^2=u^2+2*a*s" "s=1/2*(u+v)*t"))

; Top-level entry point (physicsDispatch.scm's applyPhysicsCommand):
; argString is the whole "u=5m/s a=2m/s^2 t=3s" data line. suvat has no
; separate directive arg the way dcalc/limit do -- everything it needs
; is already in the data line, so it needs no new @:/;: persistence
; register at all (see dispatcher.scm's own comment on this).
