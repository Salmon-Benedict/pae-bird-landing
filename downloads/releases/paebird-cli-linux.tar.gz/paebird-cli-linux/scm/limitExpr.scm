; limitExpr.scm -- symbolic limits over exprAst.scm's AST: calculus.md's
; Phase 2. See that file's own "Phase 2 -- Limits" section for the full
; five-item plan; THIS FILE covers items 1-3 only (direct substitution,
; indeterminate-form detection, and the four finite two-sided resolution
; strategies: factor-and-cancel, rationalization, named trig limits,
; L'Hopital) -- items 4-5 (limits at infinity, one-sided limits) are an
; explicit follow-on, per the plan's own guidance that they're "meaningfully
; harder and lower-frequency... not a blocker to shipping 1-3". The
; `direction` parameter is threaded through every function's signature
; already (matching the plan's stated limitExpr: AST x var x point x
; direction -> result shape) but nothing in this file branches on it yet.
;
; Depends on: exprAst.scm, exprParse.scm, diffExpr.scm (L'Hopital),
; mathSymbolClass.scm/polyBridge.scm (ms-from-str/ms-poly-str/ms-fraction,
; same bridge diffExpr.scm's exprSimplify already established), recordPoly2.scm
; (makep/makepx), factorPoly.scm (divideByLinearFactor, polyVariable).
; Load this file after diffExpr.scm.
;
; ---- Result representation ----
; (cons 'exact <exact-rational>)    -- an exact value
; (cons 'decimal <string>)          -- a rounded-decimal fallback (see
;                                      evalKnownFunc below)
; (cons 'infinity '+ or '-)         -- a genuine signed infinite limit
;                                      (rationalLimitAtInfinity, or a
;                                      one-sided vertical asymptote)
; (cons 'undefined <reason-string>) -- couldn't be resolved (includes a
;                                      two-sided limit through a vertical
;                                      asymptote, which genuinely has no
;                                      single value, not just a scope gap)
; (cons 'exp-power <exact-rational c>) -- the value e^c, c nonzero: what an
;                                      indeterminate power 1^inf / inf^0 /
;                                      0^0 resolves to via lim g*ln(f) = c
;                                      (Stewart 4.4). Printed symbolically
;                                      ("e", "1/e", "e^4", "1/e^2",
;                                      "e^(1/2)"), the way the textbook states
;                                      it; c=0 is just (exact . 1).
(define (limitResultToString r)
    (case (car r)
        ((exact) (number->string (cdr r)))
        ((decimal) (cdr r))
        ((infinity) (if (eqv? (cdr r) '+) "+infinity" "-infinity"))
        ((exp-power) (expPowerToString (cdr r)))
        ((undefined) "undefined")))

(define (expPowerToString c)
    (let* ((mag (abs c))
           (body (cond ((= mag 1) "e")
                       ((integer? mag) (string-append "e^" (number->string mag)))
                       ('t (string-append "e^(" (number->string mag) ")")))))
        (if (< c 0) (string-append "1/" body) body)))

; Tags a computed numeric value 'exact or 'decimal based on its actual
; exactness, rather than assuming every arithmetic result stays exact --
; a direct substitution or L'Hopital step can legitimately land on a
; transcendental value with no exact form (e.g. sin(2)). 6 significant
; figures matches trigonometry.scm's own evaluateTrig decimal fallback,
; the precedent calculus.md's plan cites for this exact convention.
(define (numericResult v) (if (exact? v) (cons 'exact v) (cons 'decimal (roundToSigFigs v 6))))

; ---- Point evaluation ----
;
; Evaluates e at var=point. Returns an exact rational, an inexact decimal
; (for a transcendental value that isn't exactly the function's value at
; 0 or 1 -- see evalKnownFunc), or the symbol 'undefined (division by
; zero anywhere, or a domain violation like ln of a nonpositive number).
;
; Trig here is evaluated in RADIANS via Chez's own native sin/cos/tan --
; deliberately NOT trigonometry.scm's evaluateTrig table, which is
; degree-based (built for degree-mode equation solving) and would give
; the wrong answer for calculus (lim x->0 sin(x)/x = 1 is a radian-mode
; fact; in degrees it would be pi/180). This also sidesteps needing to
; represent pi symbolically at all -- exprNum only ever holds exact
; rationals, so a limit point can never literally BE pi/6 etc. in this
; representation; evaluateTrig's degree-indexed special-angle table has
; no rational-argument analogue worth reusing here.
(define (evalExprAt e var point)
    (case (exprKind e)
        ((num) (exprNumValue e))
        ((evar) point)
        ((add) (evalCombine2 + (exprAddLeft e) (exprAddRight e) var point))
        ((sub) (evalCombine2 - (exprSubLeft e) (exprSubRight e) var point))
        ((neg) (let ((v (evalExprAt (exprNegOperand e) var point))) (if (eqv? v 'undefined) 'undefined (- v))))
        ((mul) (evalCombine2 * (exprMulLeft e) (exprMulRight e) var point))
        ((div) (evalExprDivAt e var point))
        ((pow) (evalExprPowAt e var point))
        ((apply) (evalExprApplyAt e var point))
        ; sum(...) -- deliberately NOT supported here (limits/point-
        ; evaluation of an expression containing a summation subtree is
        ; out of scope for this Foundation-layer file, same posture as
        ; diffExpr.scm's own sum arm) -- clear error rather than a
        ; silent void. sumExpr.scm (loaded after this file) is a
        ; consumer of evalExprAt, not the other way around; keeping that
        ; dependency direction one-way is why this stays unsupported
        ; here rather than reaching forward into a later-loaded file.
        ((sum) (error #f "evalExprAt: evaluating a summation expression isn't supported here -- use the sumcalc command" e))
        ; operand! -- factorial.scm's own `factorial` (loaded well
        ; before this file, unlike sumExpr.scm above -- no dependency-
        ; direction concern here). A domain violation (negative or
        ; non-integer) is 'undefined, same convention as sqrt of a
        ; negative/ln of a nonpositive number just above -- this is
        ; what makes sum(1/n!,n,0,10)-shaped sums (sumExpr.scm's
        ; sumDirectEvaluate calls this once per term) actually work.
        ((factorial)
            (let ((v (evalExprAt (exprFactorialOperand e) var point)))
                (if (and (not (eqv? v 'undefined)) (integer? v) (>= v 0))
                    (factorial v)
                    'undefined)))))

(define (evalCombine2 op leftNode rightNode var point)
    (let ((l (evalExprAt leftNode var point)) (r (evalExprAt rightNode var point)))
        (if (or (eqv? l 'undefined) (eqv? r 'undefined)) 'undefined (op l r))))

(define (evalExprDivAt e var point)
    (let ((n (evalExprAt (exprDivNumer e) var point)) (d (evalExprAt (exprDivDenom e) var point)))
        (cond
            ((or (eqv? n 'undefined) (eqv? d 'undefined)) 'undefined)
            ((= d 0) 'undefined)
            ('t (/ n d)))))

(define (evalExprPowAt e var point)
    (let ((b (evalExprAt (exprPowBase e) var point)) (n (evalExprAt (exprPowExponent e) var point)))
        (cond
            ((or (eqv? b 'undefined) (eqv? n 'undefined)) 'undefined)
            ((and (= b 0) (< n 0)) 'undefined)
            ; 0^0 with a VARIABLE exponent is an indeterminate form, not the
            ; value 1: substituting it as 1 made (exp(x)-exp(x))^(2x) at 0
            ; "converge" to 1 (its right-hand limit is 0). 'undefined sends
            ; the limit through tryIndeterminatePower. A literal x^0 stays 1.
            ((and (= b 0) (= n 0) (containsVar? (exprPowExponent e) var)) 'undefined)
            ('t (expt b n)))))

(define (evalExprApplyAt e var point)
    (let ((u (evalExprAt (exprApplyArg e) var point)))
        (if (eqv? u 'undefined) 'undefined (evalKnownFunc (exprApplyFunc e) u))))

; u=0 (sin/cos/tan/exp) or u=1 (ln/log) are special-cased to exact values
; -- everything else is a native Chez transcendental call on an inexact
; argument. sqrt is the one case Chez's own numeric tower already returns
; exact results for automatically (an exact rational whose numerator and
; denominator are both perfect squares), so no special-casing is needed
; there at all.
(define (evalKnownFunc func u)
    (case func
        ((sin)  (if (= u 0) 0 (sin (exact->inexact u))))
        ((cos)  (if (= u 0) 1 (cos (exact->inexact u))))
        ((tan)  (if (= u 0) 0 (tan (exact->inexact u))))
        ; sec/csc/cot -- reuse this same function's own sin/cos cases
        ; (which already special-case u=0 exactly) rather than
        ; duplicating that logic; 'undefined wherever the reciprocal
        ; partner is 0, matching every other domain-edge case here.
        ((sec)  (let ((c (evalKnownFunc 'cos u))) (if (= c 0) 'undefined (/ 1 c))))
        ((csc)  (let ((s (evalKnownFunc 'sin u))) (if (= s 0) 'undefined (/ 1 s))))
        ((cot)  (let ((s (evalKnownFunc 'sin u)) (c (evalKnownFunc 'cos u))) (if (= s 0) 'undefined (/ c s))))
        ((exp)  (if (= u 0) 1 (exp (exact->inexact u))))
        ((ln)   (cond ((<= u 0) 'undefined) ((= u 1) 0) ('t (log (exact->inexact u)))))
        ((log)  (cond ((<= u 0) 'undefined) ((= u 1) 0) ('t (/ (log (exact->inexact u)) (log 10.0)))))
        ((sqrt) (if (< u 0) 'undefined (sqrt u)))
        ((abs)  (abs u))
        ((arcsin) (if (or (< u -1) (> u 1)) 'undefined (if (= u 0) 0 (asin (exact->inexact u)))))
        ((arccos) (if (or (< u -1) (> u 1)) 'undefined (if (= u 1) 0 (acos (exact->inexact u)))))
        ((arctan) (if (= u 0) 0 (atan (exact->inexact u))))))

; ---- Direct point evaluation, for the "eval" dispatcher command ----
; Formats evalExprAt's raw result the same way limitResultToString/
; numericResult already format limitExpr's own result (exact rational ->
; 'exact, transcendental -> 6-sig-fig 'decimal), but WITHOUT
; limitExprFinite/limitExprDiv's indeterminate-form resolution --
; "eval" reports the expression's actual value at var=point, full stop.
; A genuine domain violation there (division by zero, ln of a
; nonpositive number, etc.) is "undefined" here, not something to
; resolve via L'Hopital/one-sided-asymptote analysis the way a
; legitimate limit legitimately would (a limit and a value-at-a-point
; are different questions -- lim_{x->0} sin(x)/x = 1 even though the
; expression itself is undefined AT x=0). Physics-motivated: dcalc's
; output can be a transcendental expression (e.g. differentiating a SHM
; position function), and @:setval (variableSubstitution.scm) is
; polynomial-only, so there was previously no way to evaluate a
; transcendental result at a specific point at all.
(define (evalExprAtToString e var point)
    (let ((v (evalExprAt e var point)))
        (if (eqv? v 'undefined) "undefined" (limitResultToString (numericResult v)))))

; ---- Term-list bridge (mirrors diffExpr.scm's exprSimplify bridge) ----

; Converts a pure-polynomial exprAst subtree into its <poly> term list.
; Errors if the subtree isn't a genuine whole polynomial -- callers only
; use this on numerator/denominator subtrees already confirmed
; pure-polynomial via exprIsPurePoly? (diffExpr.scm).
(define (pureExprToTermList e)
    (let ((ms (ms-from-str (exprToString e))))
        (if (not (ms-whole? ms))
            (error #f "pureExprToTermList: expected a whole polynomial, not a fraction" e)
            (ms-numer ms))))

; Reverse direction, through ms-poly-str's round-trip-safe rendering
; (same reason diffExpr.scm's bridge uses it instead of plain expand() --
; see that file's own header note on the "1/2x" re-parse ambiguity).
;
; termList (from divideByKnownRoot/divideByLinearFactor) is "true-signed"
; -- a term's own negativity lives directly in its cn -- but
; recordToString (which ms-poly-str calls) expects "boundary-signed" input
; (magnitude-only cn, sign carried in a separate field), same convention
; factorPoly.scm's own termsToString converts through via unapplysigns
; before rendering. Skipping this produced a genuinely broken render for
; any quotient with a negative trailing term (e.g. "x-1" came out as
; something parseExprTerm choked on, not just cosmetically wrong) --
; caught live via limitGoldenTable.scm's (x^2-1)/(x+1) @ x->-1 entry.
(define (termListToExpr termList)
    (exprParse (string->list (ms-poly-str (ms-fraction (unapplysigns termList) (list (makep 1 1 1 1 1 1 1 '+)))))))

; pureExprToTermList's output is "boundary-signed" -- magnitude-only cn,
; each term's OWN true sign instead recorded on the PRECEDING term's sgn
; field (see riemannLimitIntegral.scm's own trueSignedTerms, which first
; diagnosed this: factorPoly.scm's coeffAt just reads cn/cd raw, so it's
; only ever correct for the LEADING term). divideByLinearFactor's
; synthetic-division recurrence reads coeffAt at every degree, not just
; the leading one, so it silently computes a wrong quotient whenever a
; non-leading coefficient is negative -- confirmed live:
; (-2x^3-4x^2-2x-4)/(x+2) at x->-2 gave -38 instead of the correct -10
; before this fix (the mathematically correct quotient, -2x^2-2, matches
; SymPy and manual polynomial long division both). Fixed here, locally
; (same scoping choice riemannLimitIntegral.scm's own comment made),
; rather than in the shared coeffAt/divideByLinearFactor themselves,
; which have other established callers this fix hasn't been checked
; against.
(define (trueSignedTerms terms)
    (let loop ((ts terms) (positive? 't))
        (if (null? ts)
            '()
            (let ((term (car ts)))
                (cons (makep (if positive? (cn term) (- (cn term))) (cd term) (pn term) (pd term)
                             (var term) (varPn term) (varPd term) (sgn term))
                      (loop (cdr ts) (not (eqv? (sgn term) '-))))))))

; termList is already confirmed to evaluate to 0 at point (p/q in lowest
; terms) by the caller. Divides out the linear factor (q*x - p) via the
; same synthetic-division recurrence factorPoly.scm's divideByLinearFactor
; implements. Reused directly even though that function's own doc comment
; frames it around a root VERIFIED VIA SEARCH with integer coefficients
; (factor()'s own use case): the recurrence is just exact rational
; arithmetic and produces a correct quotient for any already-confirmed
; root, integer coefficients or not -- here the root is known outright
; (it's the limit's own point), no search needed at all.
(define (divideByKnownRoot termList point)
    (divideByLinearFactor (trueSignedTerms termList) (numerator point) (denominator point)))

; ---- Top-level entry point ----
;
; point is either an exact rational (finite limit) or one of the two
; symbols '+infinity / '-infinity -- exprNum itself can never hold
; infinity, so this is the one place a limit point isn't just "a number
; fed to evalExprAt" and needs its own dispatch branch.
(define (limitExpr e var point direction)
    (if (limitDeadline)
        (limitExprDispatch e var point direction)
        ; Outermost call: start the time budget the indeterminate-form
        ; strategies below (recursive L'Hopital etc.) share -- see
        ; limitBudgetMillis.
        (parameterize ((limitDeadline (+ (real-time) limitBudgetMillis)) (limitDepth 0))
            (limitExprDispatch e var point direction))))

(define (limitExprDispatch e var point direction)
    (cond
        ((> (real-time) (limitDeadline))
            (cons 'undefined "limit: exceeded the computation time budget"))
        ((or (eqv? point '+infinity) (eqv? point '-infinity))
            (limitExprAtInfinity e var point direction))
        ('t (limitExprFinite e var point direction))))

(define (limitExprFinite e var point direction)
    (if (exprDiv? e)
        (limitExprDiv e var point direction)
        (let ((v (evalExprAt e var point)))
            (if (eqv? v 'undefined)
                (or (tryLnDomainBoundary e var point direction)
                    (tryIndeterminateForms e var point direction)
                    (cons 'undefined "direct substitution failed and this expression isn't a top-level fraction this file knows how to resolve further"))
                (numericResult v)))))

; Indeterminate-form detection is scoped to the WHOLE EXPRESSION being a
; top-level div node, not general recursive detection anywhere in the
; tree -- every entry in this file's scope (limitGoldenTable.scm's
; sections 1, 3a-3d finite-point) is structured as exactly one top-level
; fraction, matching how these problems are always textbook-posed. A
; genuinely nested indeterminate subexpression is out of scope here.
;
; A THIRD case beyond 0/0 and "plain nonzero/nonzero" is handled here too:
; nonzero numerator over a zero denominator is a genuine vertical
; asymptote, not an error. If direction is one-sided, sign-of-approach
; analysis (asymptoteSignFor below) resolves it to a signed infinity
; directly. If direction is two-sided, the two one-sided signs are BOTH
; computed and compared: when they agree (e.g. 1/x^2 at x->0, both sides
; ->+infinity), the two-sided limit genuinely IS that signed infinity, not
; undefined -- only a genuine disagreement (e.g. 1/x at x->0) makes the
; two-sided limit not exist. (Previously this branch unconditionally
; returned undefined for direction='two-sided without ever checking
; agreement, which was wrong for any even-order pole.)
(define (limitExprDiv e var point direction)
    (let ((n (evalExprAt (exprDivNumer e) var point))
          (d (evalExprAt (exprDivDenom e) var point)))
        (cond
            ((and (not (eqv? n 'undefined)) (not (eqv? d 'undefined)) (not (= d 0)))
                (numericResult (/ n d)))
            ((and (not (eqv? n 'undefined)) (not (eqv? d 'undefined)) (= n 0) (= d 0))
                (resolveZeroOverZero e var point direction))
            ((and (not (eqv? n 'undefined)) (not (eqv? d 'undefined)) (not (= n 0)) (= d 0))
                (or (tryVerticalAsymptote e var point direction)
                    (cons 'undefined "vertical asymptote: the two-sided limit does not exist (one-sided limits disagree, or call with direction 'left or 'right for the one-sided value)")))
            ; An undefined numerator/denominator at the point (ln(x)/(1/x) at 0+,
            ; an infinite/infinite quotient): recursive L'Hopital (below).
            ((tryIndeterminateForms e var point direction))
            ('t (cons 'undefined "not a recognized indeterminate form, or this file doesn't yet handle every one-sided/infinite case (see this file's own header)")))))

; ---- Vertical asymptotes (one-sided directly; two-sided via agreement) ----
;
; Small enough that, for the low-degree denominators this heuristic is
; scoped to (calculus.md: "sign-of-approach analysis for the rational-
; function case"), no other root of the denominator lies strictly between
; point and point +/- approachEpsilon -- exact rational, not a float, so
; this stays consistent with the rest of the engine's exact arithmetic.
(define approachEpsilon 1/1000000)

; The sign-of-approach computation itself, for ONE specific side --
; direction must already be 'left or 'right (callers enforce this: either
; the caller's own direction already is, one-sided, or tryVerticalAsymptote
; below calls this twice with 'left/'right explicitly for the two-sided
; agreement check).
(define (asymptoteSignFor e var point direction)
    (let* ((offset (if (eqv? direction 'right) approachEpsilon (- approachEpsilon)))
           (numerVal (evalExprAt (exprDivNumer e) var point))
           (denomNearby (evalExprAt (exprDivDenom e) var (+ point offset))))
        (if (or (eqv? numerVal 'undefined) (eqv? denomNearby 'undefined) (= numerVal 0) (= denomNearby 0))
            #f
            (cons 'infinity (if (> (* numerVal denomNearby) 0) '+ '-)))))

(define (tryVerticalAsymptote e var point direction)
    (cond
        ((or (eqv? direction 'left) (eqv? direction 'right)) (asymptoteSignFor e var point direction))
        ('t (let ((l (asymptoteSignFor e var point 'left)) (r (asymptoteSignFor e var point 'right)))
                (if (and l r (eqv? (cdr l) (cdr r))) l #f)))))

; ---- Domain-boundary limits for non-fraction expressions (e.g. ln(x) as
;      x->0+) ----
;
; The vertical-asymptote logic above only fires for a top-level N/0
; division -- ln(u)/log(u) hitting the edge of its domain (u(point)=0, so
; ln(0) is undefined) is a different shape entirely, and previously fell
; straight through limitExprFinite's plain evalExprAt with no
; direction-awareness at all. Deliberately narrow, matching this file's
; existing pattern-not-general-algorithm philosophy: only fires when u,
; evaluated AT point, is EXACTLY 0 (the textbook boundary-of-domain case --
; ln(x) at x=0, ln(3-x) as x->3) -- a genuinely negative u(point) is a real
; domain violation with no limit to find, not something this heuristic
; guesses at. ln(t)/log(t) -> -infinity as t->0+ regardless of base, so the
; result is always a '- infinity when it fires at all. Reuses
; exprIsLogLike? (defined below, in the limits-at-infinity section) --
; forward reference is fine here since neither is actually CALLED until
; the dispatcher invokes a limit after this whole file is loaded.
(define (lnBoundarySignFor e var point direction)
    (let* ((offset (if (eqv? direction 'right) approachEpsilon (- approachEpsilon)))
           (uNearby (evalExprAt (exprApplyArg e) var (+ point offset))))
        (if (or (eqv? uNearby 'undefined) (<= uNearby 0))
            #f
            (cons 'infinity '-))))

(define (tryLnDomainBoundary e var point direction)
    (if (not (exprIsLogLike? e))
        #f
        (let ((uAtPoint (evalExprAt (exprApplyArg e) var point)))
            (if (or (eqv? uAtPoint 'undefined) (not (= uAtPoint 0)))
                #f
                (cond
                    ((or (eqv? direction 'left) (eqv? direction 'right)) (lnBoundarySignFor e var point direction))
                    ('t (let ((l (lnBoundarySignFor e var point 'left)) (r (lnBoundarySignFor e var point 'right)))
                            (and l r l))))))))

; ---- Limits at infinity ----

; exprIsPurePoly? (exprSimplify.scm) accepts ANY literal exponent, so x^-2 and
; x^(1/2) count as "polynomial", and the degree-comparison code below then
; treated x^-2 as a positive-degree term: lim x^-2 at +infinity came out as
; +infinity instead of 0. For end-behavior purposes only NONNEGATIVE INTEGER
; powers are polynomial; anything else falls through to the general
; strategies (tryNumericPowerLimit etc.).
(define (exprHasNonPolyExponent? e)
    (case (exprKind e)
        ((num evar) #f)
        ((neg) (exprHasNonPolyExponent? (exprNegOperand e)))
        ((add) (or (exprHasNonPolyExponent? (exprAddLeft e)) (exprHasNonPolyExponent? (exprAddRight e))))
        ((sub) (or (exprHasNonPolyExponent? (exprSubLeft e)) (exprHasNonPolyExponent? (exprSubRight e))))
        ((mul) (or (exprHasNonPolyExponent? (exprMulLeft e)) (exprHasNonPolyExponent? (exprMulRight e))))
        ((div) (or (exprHasNonPolyExponent? (exprDivNumer e)) (exprHasNonPolyExponent? (exprDivDenom e))))
        ((pow) (or (not (and (exprNum? (exprPowExponent e)) (integer? (exprNumValue (exprPowExponent e))) (>= (exprNumValue (exprPowExponent e)) 0)))
                   (exprHasNonPolyExponent? (exprPowBase e))))
        (else #t)))

(define (exprIsLimitPoly? e) (and (exprIsPurePoly? e) (not (exprHasNonPolyExponent? e))))

(define (limitExprAtInfinity e var point direction)
    (cond
        ((and (exprDiv? e) (exprIsLimitPoly? (exprDivNumer e)) (exprIsLimitPoly? (exprDivDenom e)))
            ; pureLimitAtInfinity bridges the whole fraction, so nested fractions
            ; (1/(1/x), (1+1/x)/(2-1/x)) work too, not just a plain poly/poly.
            (pureLimitAtInfinity e point))
        ; A BARE pure polynomial (x^2, x^3, not written as a fraction at
        ; all) previously matched none of this cond's branches -- every one
        ; of them either required a div node outright or (tryGrowthRateHeuristic/
        ; tryInfinityMinusInfinity/tryZeroTimesInfinity) required exprDiv?/
        ; exprSub?/exprMul? specifically, so even the most basic textbook
        ; limit at infinity (lim x->-infinity of x^3) fell through to
        ; undefined. polyLimitAtInfinity below reuses rationalLimitAtInfinity's
        ; own even/odd-degree sign-flip logic for a single polynomial.
        ((exprIsLimitPoly? e) (pureLimitAtInfinity e point))
        ; A literal negative coefficient (e.g. "-3") is a leaf exprNum
        ; and needs no help here, but exprAst.scm's smart constructors
        ; pull a buried neg out to wrap a whole containing node (e.g.
        ; "-3*(1-exp(-t))" parses as neg(mul(3, sub(1,exp(-t)))), not
        ; mul(-3, ...)) -- exprIsPurePoly? already unwraps neg for the
        ; ALL-polynomial case just above, but a neg wrapping something
        ; that needs tryAddSubAtInfinity/tryMulAtInfinity below (a
        ; transcendental combination) fell through to 'undefined with no
        ; case handling bare negation at all. Recurse and negate via the
        ; same negateInfinityResult tryAddSubAtInfinity already uses for
        ; subtraction's sign flip.
        ((exprNeg? e)
            (let ((inner (limitExprAtInfinity (exprNegOperand e) var point direction)))
                (if (eqv? (car inner) 'undefined) inner (negateInfinityResult inner))))
        ((tryGrowthRateHeuristic e var point direction))
        ; Same gap as the bare-polynomial case above, but for a bare
        ; exp(u)/ln(u)/log(u) with no denominator at all (lim x->+infinity
        ; of exp(x) fell through the same way -- tryGrowthRateHeuristic only
        ; compares exp/ln against a polynomial DENOMINATOR).
        ((tryBareTranscendentalAtInfinity e var point direction))
        ((tryInfinityMinusInfinity e var point direction))
        ((tryZeroTimesInfinity e var point direction))
        ((tryAddSubAtInfinity e var point direction))
        ((tryMulAtInfinity e var point direction))
        ; Everything above is a narrow pattern; this is the general Stewart
        ; 4.4 machinery (recursive L'Hopital, 0*inf, inf-inf, indeterminate
        ; powers) -- tried only after every existing strategy declined.
        ((tryIndeterminateForms e var point direction))
        ('t (cons 'undefined "limit at infinity: not a pure-polynomial rational function, and no growth-rate/infinity-infinity/zero-times-infinity/add-sub-or-mul-combination pattern matched (see this file's own scope note -- common textbook forms only)"))))

; Degree-comparison for a rational function's end behavior: numerator
; degree less than denominator's -> 0; equal -> ratio of leading
; coefficients (the horizontal asymptote, same value approaching from
; either infinity); numerator degree greater -> a signed infinity, sign
; = (sign of the leading-coefficient ratio) combined with (whether x is
; heading toward +infinity, or toward -infinity through an odd-degree-
; difference term, which flips it). (eqv? ratioPositive? approachPositive?)
; is an XNOR: they agree -> positive result, disagree -> negative.
(define (rationalLimitAtInfinity numer denom point)
    (rationalTermsLimitAtInfinity (pureExprToTermList numer) (pureExprToTermList denom) point))

; The same degree comparison on ALREADY-converted term lists, so a pure
; apply-free expression that is a rational function but not literally one
; top-level division (1+1/x, 2-3/x^2, ...) can reuse it (pureLimitAtInfinity).
(define (rationalTermsLimitAtInfinity numerTerms denomTerms point)
    (let* ((dp (polyDegree numerTerms)) (dq (polyDegree denomTerms))
           (lcP (coeffAt numerTerms dp)) (lcQ (coeffAt denomTerms dq)))
        (cond
            ((< dp dq) (cons 'exact 0))
            ((= dp dq) (cons 'exact (/ lcP lcQ)))
            ('t
                (let* ((ratioPositive? (> (/ lcP lcQ) 0))
                       (approachPositive? (or (eqv? point '+infinity) (even? (- dp dq)))))
                    (cons 'infinity (if (eqv? ratioPositive? approachPositive?) '+ '-)))))))

; An apply-free expression's end behavior: a whole polynomial, OR a rational
; function that isn't literally one top-level division. exprIsPurePoly?
; accepts anything without an apply node, so 1+1/x used to reach
; pureExprToTermList and die with "expected a whole polynomial, not a
; fraction" (masked while the top-level result was just 'undefined; exposed
; once limits of a base like 1+1/x started to matter for (1+1/x)^x).
(define (pureLimitAtInfinity e point)
    (let ((ms (ms-from-str (exprToString e))))
        (if (ms-whole? ms)
            (polyLimitAtInfinity (ms-numer ms) point)
            (rationalTermsLimitAtInfinity (ms-numer ms) (ms-denom ms) point))))

; A single polynomial's own end behavior (not a ratio) -- same even/odd-
; degree sign-flip fact as rationalLimitAtInfinity's final branch (there,
; effectively against an implicit denominator of degree 0, coefficient 1),
; factored out standalone so both the bare-polynomial limitExprAtInfinity
; case and tryBareTranscendentalAtInfinity's argument-direction lookup
; below can share it. Degree 0 (a genuine constant) isn't "at infinity" at
; all -- it's just that constant value, returned as an exact finite result.
(define (polyLimitAtInfinity terms point)
    (let* ((d (polyDegree terms)) (lc (coeffAt terms d)))
        (if (= d 0)
            (cons 'exact lc)
            (let ((approachPositive? (or (eqv? point '+infinity) (even? d))))
                (cons 'infinity (if (eqv? (> lc 0) approachPositive?) '+ '-))))))

; ---- Limits at infinity: exp/ln growth-rate heuristics ----
;
; Deliberately narrow ("common textbook forms only, not a general
; algorithm" per calculus.md) -- only the exp-vs-polynomial and log-vs-
; power shapes limitGoldenTable.scm actually exercises, and only for
; x->+infinity (as x->-infinity, exp(x)->0 behaves entirely differently
; and isn't covered here).
(define (exprIsExp? e) (and (exprApply? e) (eqv? (exprApplyFunc e) 'exp)))
(define (exprIsLogLike? e) (and (exprApply? e) (memv (exprApplyFunc e) '(ln log))))
(define (exprIsPositiveDegreePoly? e)
    (and (exprIsPurePoly? e)
         (guard (c (#t #f)) (> (polyDegree (pureExprToTermList e)) 0))))
(define (exprIsPowerLikeGrowth? e) (or (and (exprApply? e) (eqv? (exprApplyFunc e) 'sqrt)) (exprIsPositiveDegreePoly? e)))

; exp(u) only "dominates any polynomial" when u itself heads to +infinity.
; This heuristic used to assume that of EVERY exp(...), so exp(-x)/x^3 at
; +infinity came out as +infinity (it is 0) and x^2/exp(-x) as 0 (it is
; +infinity) -- found by a randomized SymPy cross-check, 2026-09-19. A
; decaying exp now declines here and is resolved by the general machinery.
(define (expArgGrowsToPositiveInfinity? e)
    (and (exprIsExp? e) (exprIsLimitPoly? (exprApplyArg e))
         (let ((r (guard (c (#t #f)) (pureLimitAtInfinity (exprApplyArg e) '+infinity))))
             (and r (eqv? (car r) 'infinity) (eqv? (cdr r) '+)))))

(define (tryGrowthRateHeuristic e var point direction)
    (if (not (and (exprDiv? e) (eqv? point '+infinity)))
        #f
        (let ((numer (exprDivNumer e)) (denom (exprDivDenom e)))
            (cond
                ((and (expArgGrowsToPositiveInfinity? numer) (exprIsPositiveDegreePoly? denom)) (cons 'infinity '+))
                ((and (expArgGrowsToPositiveInfinity? denom) (exprIsPurePoly? numer)) (cons 'exact 0))
                ((and (exprIsLogLike? numer) (exprIsPowerLikeGrowth? denom)) (cons 'exact 0))
                ((and (exprIsLogLike? denom) (exprIsPowerLikeGrowth? numer)) (cons 'infinity '+))
                ('t #f)))))

; A bare exp(u)/ln(u)/log(u) with no denominator at all (e.g. plain exp(x)
; as x->+-infinity) -- resolves u's own end behavior via polyLimitAtInfinity
; first (so this also covers e.g. exp(3-x) as x->+infinity, not just
; exp(x) itself), then applies exp/ln's own well-known behavior at each of
; u's three possible outcomes: a finite constant (evalKnownFunc handles
; ln/log's domain check the same way point-evaluation already does
; elsewhere in this file), u->+infinity (exp/ln/log all grow without
; bound), or u->-infinity (exp(u)->0; ln/log(u) has no limit at all --
; u is eventually negative throughout the approach, a genuine domain
; violation, not just a scope gap).
(define (tryBareTranscendentalAtInfinity e var point direction)
    (if (not (and (exprApply? e) (memv (exprApplyFunc e) '(exp ln log)) (exprIsLimitPoly? (exprApplyArg e))))
        #f
        (let* ((func (exprApplyFunc e))
               (argLimit (pureLimitAtInfinity (exprApplyArg e) point)))
            (cond
                ((eqv? (car argLimit) 'exact)
                    (let ((v (evalKnownFunc func (cdr argLimit))))
                        (if (eqv? v 'undefined) (cons 'undefined "ln/log of a nonpositive constant") (numericResult v))))
                ((eqv? (cdr argLimit) '+) (cons 'infinity '+))
                ((eqv? func 'exp) (cons 'exact 0))
                ('t (cons 'undefined "ln/log: argument heads to -infinity, a genuine domain violation throughout the approach"))))))

; ---- Limits at infinity: infinity-infinity (conjugate rationalization) ----
;
; Same conjugate-multiplication identity as the finite-point
; tryRationalize/rationalizeWith (sqrtSide-otherSide)*(sqrtSide+otherSide)
; = (sqrt's argument) - otherSide^2 -- but here the resulting
; newNumer/(sqrtSide+otherSide) needs an INFINITY-limit analysis, since
; the denominator still contains a sqrt (not something
; rationalLimitAtInfinity's pure-polynomial-only scope covers).
;
; Deliberately narrow to exactly limitGoldenTable.scm's two stretch
; entries: the sqrt's argument must be degree exactly 2 (sqrt of a
; degree-2 polynomial grows like sqrt(leadingCoeff)*x as x->+infinity,
; giving the denominator an EFFECTIVE degree of 1) and otherSide must be
; degree <=1. A general "asymptotic degree of sqrt(polynomial)" system
; (needed for e.g. a degree-4 argument) is out of scope. Also restricted
; to point='+infinity specifically -- sqrt is always non-negative, so
; the x->-infinity case needs a sign flip this narrow heuristic doesn't
; attempt.
(define (tryInfinityMinusInfinity e var point direction)
    (cond
        ((not (and (exprSub? e) (eqv? point '+infinity))) #f)
        ((exprApplyIsSqrt? (exprSubLeft e)) (infinityRationalizeWith (exprSubLeft e) (exprSubRight e) 't))
        ((exprApplyIsSqrt? (exprSubRight e)) (infinityRationalizeWith (exprSubRight e) (exprSubLeft e) #f))
        ('t #f)))

(define (infinityRationalizeWith sqrtSide otherSide sqrtFirst?)
    (let* ((arg (exprApplyArg sqrtSide))
           (otherSq (makeExprPow otherSide (makeExprNum 2)))
           (newNumer (if sqrtFirst? (makeExprSub arg otherSq) (makeExprSub otherSq arg))))
        (if (or (not (exprIsPurePoly? newNumer)) (not (exprIsPurePoly? arg)) (not (exprIsPurePoly? otherSide))
                (not (= (polyDegree (pureExprToTermList arg)) 2))
                (> (polyDegree (pureExprToTermList otherSide)) 1))
            #f
            (limitSqrtPlusPolyDenominator newNumer arg otherSide))))

; newNumer's own degree (dn) compared against the denominator's
; EFFECTIVE degree of 1 (see the guard above): dn<1 -> 0; dn=1 -> ratio
; of leading coefficients, where the denominator's effective leading
; coefficient is sqrt(arg's leading coefficient) plus otherSide's own
; leading coefficient (0 if otherSide is only degree 0).
(define (limitSqrtPlusPolyDenominator newNumer arg otherSide)
    (let* ((newNumerTerms (pureExprToTermList newNumer)) (dn (polyDegree newNumerTerms))
           (argTerms (pureExprToTermList arg)) (sqrtLeadCoeff (sqrt (coeffAt argTerms 2)))
           (otherTerms (pureExprToTermList otherSide)) (otherDeg (polyDegree otherTerms))
           (denomEffectiveLC (+ sqrtLeadCoeff (if (= otherDeg 1) (coeffAt otherTerms 1) 0))))
        (cond
            ((< dn 1) (cons 'exact 0))
            ((= dn 1) (numericResult (/ (coeffAt newNumerTerms 1) denomEffectiveLC)))
            ('t (cons 'undefined "infinity-infinity rationalization: numerator degree too high for this narrow heuristic")))))

; ---- Limits at infinity: zero-times-infinity ----
;
; Narrowly recognizes var*sin(1/var) -> 1 as var->+/-infinity: rewriting
; as sin(u)/u with u=1/var->0 is the SAME named-trig-limit fact
; tryNamedTrigLimit already encodes for the finite-point case, just
; reached via a different substitution (u=1/var rather than var itself
; approaching 0). Deliberately narrow to this one shape (matching
; limitGoldenTable.scm's single 0*infinity stretch entry), not a general
; 0*infinity algorithm -- e.g. var*(1-cos(1/var)) or a scaled variant
; aren't recognized here.
(define (tryZeroTimesInfinity e var point direction)
    (if (not (exprMul? e))
        #f
        (let ((l (exprMulLeft e)) (r (exprMulRight e)))
            (cond
                ((varTimesSinReciprocal? l r var) (cons 'exact 1))
                ((varTimesSinReciprocal? r l var) (cons 'exact 1))
                ('t #f)))))

(define (varTimesSinReciprocal? factorNode otherNode var)
    (and (exprEvar? factorNode) (eqv? (exprEvarName factorNode) var)
         (exprApply? otherNode) (eqv? (exprApplyFunc otherNode) 'sin)
         (let ((arg (exprApplyArg otherNode)))
             (and (exprDiv? arg) (exprIsLiteral? (exprDivNumer arg) 1)
                  (exprEvar? (exprDivDenom arg)) (eqv? (exprEvarName (exprDivDenom arg)) var)))))

; ---- Limits at infinity: add/sub of two independently-determinate
;      pieces ----
;
; A gap distinct from tryInfinityMinusInfinity above (which resolves the
; genuinely INDETERMINATE infinity-infinity form via conjugate
; rationalization): this handles the DETERMINATE case where each side of
; an add/sub node already has its own well-defined limitExprAtInfinity
; result on its own (e.g. a constant polynomial piece and a decaying
; exponential piece), and the whole limit is just their ordinary
; sum/difference -- e.g. "5-exp(-t)" as t->+infinity is not remotely
; indeterminate (5, minus something heading to 0, is just 5), but
; previously fell through every heuristic above straight to 'undefined,
; since none of them combine two already-resolved sides at all. Found
; live while documenting physics module Phase 2's drag/terminal-velocity
; workflow (commands.temp.html §9.5) -- the textbook terminal-velocity
; form v(t)=(mg/b)(1-exp(-bt/m)) is exactly this shape once expanded.
;
; Only fires for add/sub (mul has its own narrow zero-times-infinity
; heuristic above; a general infinity*infinity/infinity*finite combiner
; isn't needed by anything reachable yet, so isn't added speculatively).
; Recurses through limitExprAtInfinity itself for each side -- so this
; also naturally covers e.g. a rational-function piece added to a
; transcendental piece, not just the constant+exp case that motivated
; it, without being a new special-cased pattern of its own. Cleanly
; returns #f (deferring to whatever's left in the cond, ultimately the
; final 'undefined) whenever either side doesn't resolve on its own, or
; both resolve to an infinity of opposite effective sign (a genuine
; infinity-infinity indeterminate form this function does NOT attempt
; to resolve -- that's tryInfinityMinusInfinity's job, for the one
; narrow shape it covers).
(define (tryAddSubAtInfinity e var point direction)
    (if (not (or (exprAdd? e) (exprSub? e)))
        #f
        (let* ((left (if (exprAdd? e) (exprAddLeft e) (exprSubLeft e)))
               (right (if (exprAdd? e) (exprAddRight e) (exprSubRight e)))
               (lRes (limitExprAtInfinity left var point direction))
               (rRes (limitExprAtInfinity right var point direction)))
            (if (or (eqv? (car lRes) 'undefined) (eqv? (car rRes) 'undefined))
                #f
                (combineAtInfinity lRes (if (exprSub? e) (negateInfinityResult rRes) rRes))))))

; The raw numeric value behind an 'exact or 'decimal result tag (a
; 'decimal payload is already a formatted STRING -- see numericResult's
; own comment -- so it needs converting back before arithmetic).
(define (resultNumericValue r)
    (case (car r)
        ((exact) (cdr r))
        ((decimal) (string->number (cdr r)))
        ((exp-power) (exp (exact->inexact (cdr r))))))

(define (negateInfinityResult r)
    (case (car r)
        ((exact) (cons 'exact (- (cdr r))))
        ((decimal) (numericResult (- (resultNumericValue r))))
        ((infinity) (cons 'infinity (if (eqv? (cdr r) '+) '- '+)))
        (else r)))

; Combines two ALREADY-RESOLVED (never 'undefined -- callers check
; first) limit-at-infinity results with ordinary limit arithmetic:
; finite+finite sums directly; finite+infinite is that same infinity
; (a finite piece never changes an infinite one's sign); infinity+
; infinity of the SAME sign is that infinity; infinity+infinity of
; OPPOSITE sign is the genuine indeterminate case this function
; declines to resolve (#f). rRes is expected to already have subtraction's
; sign flip applied by the caller (negateInfinityResult), so this only
; ever needs to ADD the two.
(define (combineAtInfinity lRes rRes)
    (cond
        ((and (memv (car lRes) '(exact decimal)) (memv (car rRes) '(exact decimal)))
            (numericResult (+ (resultNumericValue lRes) (resultNumericValue rRes))))
        ((and (eqv? (car lRes) 'infinity) (memv (car rRes) '(exact decimal))) lRes)
        ((and (memv (car lRes) '(exact decimal)) (eqv? (car rRes) 'infinity)) rRes)
        ((and (eqv? (car lRes) 'infinity) (eqv? (car rRes) 'infinity))
            (if (eqv? (cdr lRes) (cdr rRes)) lRes #f))
        ('t #f)))

; ---- Limits at infinity: mul of two independently-determinate pieces ----
;
; Same idea as tryAddSubAtInfinity just above, but for multiplication --
; needed for the REAL textbook terminal-velocity shape
; v(t)=(mg/b)*(1-exp(-bt/m)) (a constant TIMES a sum, not a bare sum) --
; mg/b is a finite constant, (1-exp(-bt/m)) resolves to 1 via
; tryAddSubAtInfinity's own new combiner, and finite*finite is just
; their ordinary product. Recurses through limitExprAtInfinity for each
; side, so this also naturally covers e.g. a rational-function piece
; times a transcendental piece, not just the constant*(...) case that
; motivated it. Declines (#f) whenever either side doesn't resolve, or
; the combination is the genuinely indeterminate 0*infinity form (a
; finite ZERO times an infinite result) -- tryZeroTimesInfinity above
; already owns the one narrow 0*infinity shape this file resolves; a
; general 0*infinity algorithm (rewriting as a quotient, L'Hopital-
; style) is out of scope here, same as everywhere else in this file.
(define (tryMulAtInfinity e var point direction)
    (if (not (exprMul? e))
        #f
        (let ((lRes (limitExprAtInfinity (exprMulLeft e) var point direction))
              (rRes (limitExprAtInfinity (exprMulRight e) var point direction)))
            (if (or (eqv? (car lRes) 'undefined) (eqv? (car rRes) 'undefined))
                #f
                (combineMulAtInfinity lRes rRes)))))

; Combines two ALREADY-RESOLVED (never 'undefined -- callers check
; first) limit-at-infinity results with ordinary limit multiplication:
; finite*finite is their direct product; finite(nonzero)*infinite is an
; infinity whose sign is the product of the two signs (the same XNOR
; pattern rationalLimitAtInfinity's own end-behavior sign logic already
; uses); finite(ZERO)*infinite is the genuine 0*infinity indeterminate
; case this function declines to resolve (#f); infinite*infinite is
; always an infinity, sign likewise the product of the two.
(define (combineMulAtInfinity lRes rRes)
    (cond
        ((and (memv (car lRes) '(exact decimal)) (memv (car rRes) '(exact decimal)))
            (numericResult (* (resultNumericValue lRes) (resultNumericValue rRes))))
        ((and (eqv? (car lRes) 'infinity) (memv (car rRes) '(exact decimal)))
            (if (= (resultNumericValue rRes) 0)
                #f
                (cons 'infinity (if (eqv? (> (resultNumericValue rRes) 0) (eqv? (cdr lRes) '+)) '+ '-))))
        ((and (memv (car lRes) '(exact decimal)) (eqv? (car rRes) 'infinity))
            (if (= (resultNumericValue lRes) 0)
                #f
                (cons 'infinity (if (eqv? (> (resultNumericValue lRes) 0) (eqv? (cdr rRes) '+)) '+ '-))))
        ((and (eqv? (car lRes) 'infinity) (eqv? (car rRes) 'infinity))
            (cons 'infinity (if (eqv? (cdr lRes) (cdr rRes)) '+ '-)))
        ('t #f)))

; Tries each finite two-sided resolution strategy in the order
; calculus.md's Phase 2 item 3 lists them; each returns a result or #f
; (try the next). L'Hopital is deliberately last and general enough to
; ALSO catch several shapes tryNamedTrigLimit doesn't specifically
; pattern-match (sin(3x)/x, sin(2x)/sin(5x), (1-cos(x))/x^2, tan(x)/x) --
; see tryNamedTrigLimit's own comment for why those are left to it
; on purpose rather than adding a pattern for every one.
(define (resolveZeroOverZero e var point direction)
    (or (tryFactorAndCancel e var point direction)
        (tryRationalize e var point direction)
        (tryNamedTrigLimit e var point direction)
        (tryLHopital e var point direction)
        ; Last resort: L'Hopital by RECURSIVE LIMIT (handles a step whose
        ; derivative quotient is itself an infinite/indeterminate form).
        (tryLHopitalRecursive e var point direction)
        (cons 'undefined "0/0 form: none of factor-and-cancel, rationalization, named trig limits, or L'Hopital's rule (capped iterations) resolved it")))

; ---- Resolution: factor-and-cancel ----

(define (tryFactorAndCancel e var point direction)
    (let ((numer (exprDivNumer e)) (denom (exprDivDenom e)))
        (if (or (not (exprIsPurePoly? numer)) (not (exprIsPurePoly? denom)))
            #f
            (let* ((numerQuot (divideByKnownRoot (pureExprToTermList numer) point))
                   (denomQuot (divideByKnownRoot (pureExprToTermList denom) point)))
                (limitExpr (makeExprDiv (termListToExpr numerQuot) (termListToExpr denomQuot)) var point direction)))))

; ---- Resolution: rationalization (conjugate multiplication) ----

(define (exprApplyIsSqrt? e) (and (exprApply? e) (eqv? (exprApplyFunc e) 'sqrt)))

; Only fires when the numerator is literally (sqrtNode - otherNode) or
; (otherNode - sqrtNode) -- calculus.md scopes this as "a targeted pattern
; rule, not a general algorithm", matching limitGoldenTable.scm's own
; three rationalization entries, all of exactly this shape.
(define (tryRationalize e var point direction)
    (let ((numer (exprDivNumer e)))
        (cond
            ((not (exprSub? numer)) #f)
            ((exprApplyIsSqrt? (exprSubLeft numer))
                (rationalizeWith e (exprSubLeft numer) (exprSubRight numer) 't var point direction))
            ((exprApplyIsSqrt? (exprSubRight numer))
                (rationalizeWith e (exprSubRight numer) (exprSubLeft numer) #f var point direction))
            ('t #f))))

; sqrtFirst? is 't when numer was (sqrtSide - otherSide) -- conjugate
; multiplication gives (sqrt's argument) - otherSide^2 via difference of
; squares. #f when numer was (otherSide - sqrtSide) instead, which flips
; the sign: otherSide^2 - (sqrt's argument).
;
; The conjugate identity is applied DIRECTLY here (building
; arg-otherSide^2 explicitly) rather than literally constructing
; mul(numer, conjugate) and hoping a later pass recognizes sqrt(u)^2 = u
; -- no such general identity exists anywhere in this engine (exprAst's
; smart constructors only do LOCAL identity elimination, not this kind of
; algebraic recognition), so without doing this substitution directly,
; the sqrt would never actually leave the expression.
;
; After eliminating the sqrt, newNumer/denom is a pure-polynomial 0/0 in
; its own right -- resolved via the SAME factor-and-cancel machinery
; before recombining with the conjugate (which is then safely nonzero at
; point, evaluable by plain substitution on the recursive limitExpr call).
(define (rationalizeWith e sqrtSide otherSide sqrtFirst? var point direction)
    (let* ((denom (exprDivDenom e))
           (conjugate (makeExprAdd sqrtSide otherSide))
           (arg (exprApplyArg sqrtSide))
           (otherSq (makeExprPow otherSide (makeExprNum 2)))
           (newNumer (if sqrtFirst? (makeExprSub arg otherSq) (makeExprSub otherSq arg))))
        (if (or (not (exprIsPurePoly? newNumer)) (not (exprIsPurePoly? denom)))
            (cons 'undefined "rationalize: the denominator itself isn't pure-polynomial -- outside this targeted pattern rule's scope")
            (let* ((numerQuot (divideByKnownRoot (pureExprToTermList newNumer) point))
                   (denomQuot (divideByKnownRoot (pureExprToTermList denom) point)))
                (limitExpr
                    (makeExprDiv (termListToExpr numerQuot) (makeExprMul (termListToExpr denomQuot) conjugate))
                    var point direction)))))

; ---- Resolution: named trig limits ----

; Structural equality via rendered-string comparison -- sound because
; exprToString is a deterministic, canonicalizing renderer (see its own
; header): two subtrees built the same way always render identically.
(define (exprEqual? a b) (string=? (exprToString a) (exprToString b)))

; Only sin(u)/u -> 1 and (1-cos(u))/u -> 0 are pattern-matched here,
; exactly the two calculus.md names explicitly ("textbook-standard,
; recognized rather than derived") -- both restricted to point=0, the
; only point these facts hold at. tan(u)/u is deliberately NOT a third
; pattern here (see limitGoldenTable.scm's own note on that entry: it's
; derived from sin(x)/x and cos(x)->1, not a separately memorized fact),
; and scaled/ratio/squared variants (sin(3x)/x, sin(2x)/sin(5x),
; (1-cos(x))/x^2) are deliberately left for tryLHopital to catch instead
; of trying to generalize this pattern-matcher to cover them.
(define (tryNamedTrigLimit e var point direction)
    (let ((numer (exprDivNumer e)) (denom (exprDivDenom e)))
        (cond
            ((and (= point 0) (exprApply? numer) (eqv? (exprApplyFunc numer) 'sin)
                  (exprEqual? (exprApplyArg numer) denom))
                (cons 'exact 1))
            ((and (= point 0) (exprSub? numer) (exprIsLiteral? (exprSubLeft numer) 1)
                  (exprApply? (exprSubRight numer)) (eqv? (exprApplyFunc (exprSubRight numer)) 'cos)
                  (exprEqual? (exprApplyArg (exprSubRight numer)) denom))
                (cons 'exact 0))
            ('t #f))))

; ---- Resolution: L'Hopital's rule ----

; "Capped at a small iteration limit" per calculus.md -- every entry
; actually in this file's scope needs at most 2 (see
; (exp(x)-1-x)/x^2 and (1-cos(x))/x^2 in limitGoldenTable.scm, both
; needing two rounds of differentiation before substitution succeeds).
(define lHopitalMaxIterations 5)

(define (tryLHopital e var point direction) (tryLHopitalH e var point direction lHopitalMaxIterations))

; Differentiates via the full diffExpr (WITH exprSimplify's bridging),
; not diffExprRaw -- this is exactly the "L'Hopital re-differentiates its
; own output" scenario diffExpr.scm's own header already calls out as the
; reason eager simplification matters: a second iteration's structural
; checks (here, is the new denominator's value at point nonzero) need a
; canonically-shaped tree, not a raw, un-simplified one.
(define (tryLHopitalH e var point direction iterationsLeft)
    (if (<= iterationsLeft 0)
        #f
        (let* ((numerDeriv (diffExpr (exprDivNumer e) var))
               (denomDeriv (diffExpr (exprDivDenom e) var))
               (nv (evalExprAt numerDeriv var point))
               (dv (evalExprAt denomDeriv var point)))
            (cond
                ((or (eqv? nv 'undefined) (eqv? dv 'undefined)) #f)
                ((not (= dv 0)) (numericResult (/ nv dv)))
                ((and (= nv 0) (= dv 0))
                    ; makeExprDiv can simplify the derivative quotient into a
                    ; NON-division node (e.g. (-sin(x)/cos(x))/(2*x) -> a mul),
                    ; and the next round's exprDivNumer then died with a raw
                    ; type error. Decline instead; tryLHopitalRecursive (below)
                    ; takes the new limit through limitExpr itself.
                    (let ((q (makeExprDiv numerDeriv denomDeriv)))
                        (and (exprDiv? q) (tryLHopitalH q var point direction (- iterationsLeft 1)))))
                ('t #f)))))

; ===========================================================================
; ---- Indeterminate forms via recursive limits (Stewart 4.4, 2026-09-19) ----
; ===========================================================================
; Everything above resolves L'Hopital by evaluating derivatives AT the point,
; which cannot work at infinity, nor when a derivative quotient is itself
; infinite/indeterminate; and the infinity resolvers are narrow patterns
; (exp/ln vs polynomial, a sqrt conjugate). This section is the general
; machinery, tried only AFTER every strategy above declines, so no result
; that worked before can change:
;
;   tryLHopitalRecursive  N/D with N,D both -> 0 or both -> +-infinity:
;                         lim N/D = lim N'/D', taking the NEW limit through
;                         limitExpr itself (so it works at infinity too and
;                         chains through further indeterminate forms).
;   tryProductForm        0*infinity: rewrite u*v as a quotient (the factor
;                         that simplifies under differentiation goes on top:
;                         ln before polynomial before trig before exp),
;                         then L'Hopital. x ln x at 0+ -> ln x/(1/x);
;                         x e^-x at infinity -> x/e^x.
;   tryInfMinusInf        infinity-infinity: two fractions combine over a
;                         common denominator; otherwise u-v = u(1 - v/u),
;                         decided by lim v/u (x - ln x -> +infinity).
;   tryIndeterminatePower f^g: 1^infinity, infinity^0, 0^0 via
;                         lim g*ln f = L, answer e^L; plus the determinate
;                         b^infinity cases (2^x/3^x -> (2/3)^x -> 0).
;
; Safety: every nested limit goes through limitNested (depth cap) and the
; whole computation shares limitBudgetMillis, so a form that never resolves
; ends as 'undefined instead of recursing or hanging.

(define limitDepth (make-parameter 0))
(define limitDeadline (make-parameter #f))
(define limitMaxDepth 6)
(define limitBudgetMillis 2500)

(define (limitNested e var point direction)
    (if (>= (limitDepth) limitMaxDepth)
        (cons 'undefined "limit: nesting depth exceeded")
        (parameterize ((limitDepth (+ (limitDepth) 1)))
            (limitExpr e var point direction))))

(define (limUndef? r) (eqv? (car r) 'undefined))
(define (limInf? r) (eqv? (car r) 'infinity))
(define (limFinite? r) (and (memv (car r) '(exact decimal)) #t))
(define (limZero? r) (and (eqv? (car r) 'exact) (= (cdr r) 0)))
(define (limInfSign r) (if (eqv? (cdr r) '+) 1 -1))
(define (signedInfinity sgn) (cons 'infinity (if (> sgn 0) '+ '-)))

(define (tryIndeterminateForms e var point direction)
    (or (tryIndeterminateFormsOnce e var point direction)
        ; A two-sided limit whose pieces only exist one-sidedly ((1+x)^(1/x):
        ; the exponent 1/x is +infinity from the right, -infinity from the
        ; left): resolve each side, and accept if they agree.
        (and (eqv? direction 'two-sided) (not (eqv? point '+infinity)) (not (eqv? point '-infinity))
             (let ((l (limitNested e var point 'left)) (r (limitNested e var point 'right)))
                 (and (not (limUndef? l)) (not (limUndef? r))
                      (equal? l r)
                      l)))))

(define (tryIndeterminateFormsOnce e var point direction)
    (cond
        ; -(...) : take the limit of the operand and negate it. L'Hopital
        ; steps routinely come back simplified into a negation wrapping the
        ; real quotient, and nothing at a finite point unwrapped it.
        ((exprNeg? e)
            (let ((r (limitNested (exprNegOperand e) var point direction)))
                (and (not (limUndef? r)) (memv (car r) '(exact decimal infinity))
                     (negateInfinityResult r))))
        ((exprPow? e) (tryIndeterminatePower e var point direction))
        ((exprMul? e) (tryProductForm e var point direction))
        ((exprDiv? e) (tryLHopitalRecursive e var point direction))
        ((or (exprSub? e) (exprAdd? e)) (tryInfMinusInf e var point direction))
        ('t #f)))

; ---- L'Hopital by recursive limit ----

; a^u / b^u for positive numeric bases a,b is (a/b)^u -- without this the
; quotient 2^x/3^x differentiates into the same infinity/infinity shape
; forever.
(define (constBasePowRatio n d var point direction)
    (and (exprPow? n) (exprPow? d)
         (exprNum? (exprPowBase n)) (exprNum? (exprPowBase d))
         (> (exprNumValue (exprPowBase n)) 0) (> (exprNumValue (exprPowBase d)) 0)
         (exprEqual? (exprPowExponent n) (exprPowExponent d))
         (let ((r (limitNested (makeExprPow (makeExprNum (/ (exprNumValue (exprPowBase n)) (exprNumValue (exprPowBase d))))
                                            (exprPowExponent n))
                               var point direction)))
             (and (not (limUndef? r)) r))))

(define (tryLHopitalRecursive e var point direction)
    (and (exprDiv? e)
         (let ((n (exprDivNumer e)) (d (exprDivDenom e)))
             (or (constBasePowRatio n d var point direction)
                 (let ((ln (limitNested n var point direction))
                       (ld (limitNested d var point direction)))
                     (and (not (limUndef? ln)) (not (limUndef? ld))
                          (cond
                              ; Not indeterminate once each side has resolved:
                              ((and (limFinite? ln) (limInf? ld)) (cons 'exact 0))
                              ((and (limInf? ln) (limFinite? ld) (not (= (resultNumericValue ld) 0)))
                                  (signedInfinity (* (limInfSign ln) (if (> (resultNumericValue ld) 0) 1 -1))))
                              ((and (limFinite? ln) (limFinite? ld) (not (= (resultNumericValue ld) 0)))
                                  (numericResult (/ (resultNumericValue ln) (resultNumericValue ld))))
                              ; nonzero-or-infinite over ZERO: an infinity whose sign is the
                              ; denominator's sign just off the point (x^2/exp(-x) at +infinity:
                              ; exp(-x) -> 0 from above, so +infinity). Declines if the sign
                              ; can't be read off.
                              ((and (limZero? ld) (or (limInf? ln) (and (limFinite? ln) (not (limZero? ln)))))
                                  (let ((sgD (signNearPoint d var point direction))
                                        (sgN (if (limInf? ln) (limInfSign ln) (if (> (resultNumericValue ln) 0) 1 -1))))
                                      (and sgD (signedInfinity (* sgN sgD)))))
                              ; 0/0 or infinity/infinity: differentiate, take the NEW limit.
                              ((or (and (limZero? ln) (limZero? ld)) (and (limInf? ln) (limInf? ld)))
                                  (let ((nd (guard (c (#t #f))
                                                (simplifyAcrossApplyBoundaries (exprSimplify (makeExprDiv (diffExpr n var) (diffExpr d var)))))))
                                      (and nd
                                           (let ((r (limitNested nd var point direction)))
                                               (and (not (limUndef? r)) r)))))
                              ('t #f))))))))

; ---- 0 * infinity ----

; Which factor to put on TOP when rewriting u*v as a quotient: the one that
; simplifies under differentiation (ln) before ones that stay put
; (polynomials), before trig, before exp.
(define (factorRank f)
    (cond
        ((exprIsLogLike? f) 0)
        ((exprIsExp? f) 3)
        ((exprPow? f) (if (exprNum? (exprPowExponent f)) 1 3))
        ((exprApply? f) 2)
        ('t 1)))

; 1/w, with the two rewrites that keep later derivatives tidy: 1/exp(z) =
; exp(-z) and 1/w^n = w^-n.
(define (reciprocalOf w)
    (cond
        ((exprDiv? w) (makeExprDiv (exprDivDenom w) (exprDivNumer w)))
        ((exprIsExp? w) (makeExprApplyChecked 'exp (makeExprNeg (exprApplyArg w))))
        ((and (exprPow? w) (exprNum? (exprPowExponent w)))
            (makeExprPow (exprPowBase w) (makeExprNum (- (exprNumValue (exprPowExponent w))))))
        ('t (makeExprDiv (makeExprNum 1) w))))

(define (tryProductForm e var point direction)
    (and (exprMul? e)
         (let* ((u (exprMulLeft e)) (v (exprMulRight e))
                (lu (limitNested u var point direction))
                (lv (limitNested v var point direction)))
             (and (not (limUndef? lu)) (not (limUndef? lv))
                  ; Determinate combinations first (finite*finite, nonzero
                  ; finite*infinite, infinite*infinite) -- the same combiner
                  ; the at-infinity code already uses; it declines 0*infinity.
                  (or (combineMulAtInfinity lu lv)
                      (and (or (and (limZero? lu) (limInf? lv)) (and (limInf? lu) (limZero? lv)))
                           (tryProductAsQuotient u v var point direction)))))))

; 0*infinity: rewrite u*v as a quotient (the factor that simplifies under
; differentiation on top), then L'Hopital by recursive limit; if that
; ordering doesn't resolve, try the other one.
(define (tryProductAsQuotient u v var point direction)
    (let* ((uFirst? (<= (factorRank u) (factorRank v)))
           (candidates (if uFirst? (list (cons u v) (cons v u)) (list (cons v u) (cons u v)))))
        (let try ((cs candidates))
            (cond
                ((null? cs) #f)
                ((tryLHopitalRecursive (makeExprDiv (caar cs) (reciprocalOf (cdar cs))) var point direction))
                ('t (try (cdr cs)))))))

; ---- infinity - infinity ----

(define (tryInfMinusInf e var point direction)
    (let* ((sub? (exprSub? e))
           (u (if sub? (exprSubLeft e) (exprAddLeft e)))
           (v (if sub? (exprSubRight e) (exprAddRight e)))
           (w (if sub? v (makeExprNeg v)))            ; u + v = u - w
           (lu (limitNested u var point direction))
           (lv (limitNested v var point direction))
           (lw (limitNested w var point direction)))
        (and (not (limUndef? lu)) (not (limUndef? lv)) (not (limUndef? lw))
             (or
                 ; Determinate sums first (finite +- finite, finite +- infinite,
                 ; same-sign infinities): the at-infinity combiner declines only
                 ; the genuinely indeterminate opposite-infinities case.
                 (combineAtInfinity lu (if sub? (negateInfinityResult lv) lv))
                 (tryInfMinusInfIndeterminate u v w lu lw sub? var point direction)))))

(define (tryInfMinusInfIndeterminate u v w lu lw sub? var point direction)
        (and (limInf? lu) (limInf? lw) (eqv? (cdr lu) (cdr lw))
             (or
                 ; Two fractions: a/b - c/d = (ad - cb)/(bd), then any strategy.
                 (and (exprDiv? u) (exprDiv? v)
                      (let* ((a (exprDivNumer u)) (b (exprDivDenom u)) (c (exprDivNumer v)) (d (exprDivDenom v))
                             (num (if sub? (makeExprSub (makeExprMul a d) (makeExprMul c b))
                                             (makeExprAdd (makeExprMul a d) (makeExprMul c b))))
                             (combined (guard (x (#t #f)) (exprSimplify (makeExprDiv num (makeExprMul b d))))))
                          (and combined
                               (let ((r (limitNested combined var point direction)))
                                   (and (not (limUndef? r)) r)))))
                 ; u - w = u(1 - w/u): decided by r = lim w/u.
                 (let ((r (limitNested (makeExprDiv w u) var point direction)))
                     (cond
                         ((limUndef? r) #f)
                         ((limInf? r) (signedInfinity (* (limInfSign lu) (- (limInfSign r)))))
                         ((limFinite? r)
                             (let ((rv (resultNumericValue r)))
                                 (cond ((= rv 1) #f)
                                       ('t (signedInfinity (* (limInfSign lu) (if (< rv 1) 1 -1)))))))
                         ('t #f))))))

; ---- indeterminate and determinate powers ----

; Sign of a base that heads to 0, looking just off the point in the direction
; of approach: +1, -1, or #f (two-sided disagreement / not determinable).
(define (baseSignNearPoint base var point direction)
    (if (or (eqv? point '+infinity) (eqv? point '-infinity))
        #f
        (let ((side (lambda (off) (let ((v (evalExprAt base var (+ point off))))
                                      (cond ((eqv? v 'undefined) #f) ((> v 0) 1) ((< v 0) -1) ('t #f))))))
            (cond
                ((eqv? direction 'right) (side approachEpsilon))
                ((eqv? direction 'left) (side (- approachEpsilon)))
                ('t (let ((l (side (- approachEpsilon))) (r (side approachEpsilon))) (and l r (= l r) l)))))))

; Sign of e far out toward +-infinity, read off floating-point samples over a
; wide spread of magnitudes (50 ... 1e6). Zero and non-finite samples are
; IGNORED -- exp(-1000.) underflows to 0.0, and a sign check that treated that
; as "not positive" refused x^2/exp(-x) -- but a sign is only accepted when at
; least 3 nonzero samples exist and ALL agree, so an expression that changes
; sign somewhere in that range (x-100) declines instead of guessing.
(define (signAtLarge e var toPositive?)
    (let* ((xs (map (lambda (m) (if toPositive? m (- m))) '(50. 100. 200. 400. 1000. 10000. 1000000.)))
           (vals (filter (lambda (v) (and (real? v) (= v v) (not (= v 0)) (< (abs v) +inf.0)))
                         (map (lambda (x0) (guard (c (#t 'undefined)) (evalExprAt e var x0))) xs))))
        (cond ((< (length vals) 3) #f)
              ((for-all (lambda (v) (> v 0)) vals) 1)
              ((for-all (lambda (v) (< v 0)) vals) -1)
              ('t #f))))

; Sign of expr just off the point: like baseSignNearPoint, but also handles
; infinity (sampled in floating point -- see signAtLarge).
(define (signNearPoint e var point direction)
    (cond
        ((eqv? point '+infinity) (signAtLarge e var #t))
        ((eqv? point '-infinity) (signAtLarge e var #f))
        ('t (baseSignNearPoint e var point direction))))

; base^n for a literal exponent n when the BASE's own limit is 0 or infinite
; (x^-2 at 0, ln(x)^2 at infinity): the pieces plain substitution and the
; rational-function code can't reach.
(define (tryNumericPowerLimit e var point direction)
    (let* ((n (exprNumValue (exprPowExponent e)))
           (lb (limitNested (exprPowBase e) var point direction)))
        (and (not (limUndef? lb))
             (cond
                 ((and (limFinite? lb) (not (= (resultNumericValue lb) 0)))
                     (numericResult (expt (resultNumericValue lb) n)))
                 ((limZero? lb)
                     (cond
                         ((> n 0) (cons 'exact 0))
                         ((and (integer? n) (even? n)) (cons 'infinity '+))
                         ((integer? n) (let ((sg (baseSignNearPoint (exprPowBase e) var point direction)))
                                           (and sg (signedInfinity sg))))
                         ('t (let ((sg (baseSignNearPoint (exprPowBase e) var point direction)))
                                 (and sg (> sg 0) (cons 'infinity '+))))))
                 ((limInf? lb)
                     (cond
                         ((< n 0) (cons 'exact 0))
                         ((eqv? (cdr lb) '+) (cons 'infinity '+))
                         ((integer? n) (signedInfinity (if (even? n) 1 -1)))
                         ('t #f)))
                 ('t #f)))))

(define (tryIndeterminatePower e var point direction)
    (let ((base (exprPowBase e)) (ex (exprPowExponent e)))
        (if (exprNum? ex) (tryNumericPowerLimit e var point direction) (tryIndeterminatePowerVarExp e var point direction ex base))))

; The log trick (f^g = exp(g*ln f)) is only valid where f > 0. Sample the
; base just off the point in the direction of approach (finite point), or far
; out (infinity), and require it strictly positive and defined at every
; sample -- otherwise decline. Catches a base that is identically 0 or dips
; negative (e.g. (exp(x)-exp(x))^(2x) used to come out as 1).
; Samples far out at infinity are FLOATING POINT on purpose: evalExprAt on an
; exact 10^8 turns 2^x into a bignum with ~30 million digits and hangs (found
; by the randomized cross-check on ((2^x)^(2*x))^(1/x^2)); inexact arithmetic
; overflows harmlessly to +inf.0 instead. Every evaluation is also guarded.
(define (basePositiveNearPoint? base var point direction)
    (if (or (eqv? point '+infinity) (eqv? point '-infinity))
        (eqv? (signAtLarge base var (eqv? point '+infinity)) 1)
        (basePositiveNearFinitePoint? base var point direction)))

(define (basePositiveNearFinitePoint? base var point direction)
    (let* ((samples
               (cond
                   ((eqv? direction 'right) (list (+ point 1/1000) (+ point 1/100000)))
                   ((eqv? direction 'left) (list (- point 1/1000) (- point 1/100000)))
                   ('t (list (+ point 1/1000) (- point 1/1000) (+ point 1/100000) (- point 1/100000)))))
           (vals (map (lambda (x0) (guard (c (#t 'undefined)) (evalExprAt base var x0))) samples)))
        (for-all (lambda (v) (and (real? v) (= v v) (> v 0))) vals)))

(define (tryIndeterminatePowerVarExp e var point direction ex base)
    (let ()
        (and (not (exprNum? ex))
             (let ((lb (limitNested base var point direction))
                   (lg (limitNested ex var point direction)))
                 (and (not (limUndef? lb)) (not (limUndef? lg))
                      (cond
                          ; 1^infinity, infinity^0, 0^0: L = lim g*ln(f), answer e^L.
                          ((or (and (eqv? (car lb) 'exact) (= (cdr lb) 1) (limInf? lg))
                               (and (limInf? lb) (eqv? (cdr lb) '+) (limZero? lg))
                               (and (limZero? lb) (limZero? lg)))
                              (let ((L (and (basePositiveNearPoint? base var point direction)
                                            (limitNested (makeExprMul ex (makeExprApplyChecked 'ln base)) var point direction))))
                                  (cond
                                      ((not L) #f)
                                      ((limUndef? L) #f)
                                      ((limInf? L) (if (eqv? (cdr L) '+) L (cons 'exact 0)))
                                      ((eqv? (car L) 'exact) (if (= (cdr L) 0) (cons 'exact 1) (cons 'exp-power (cdr L))))
                                      ((eqv? (car L) 'decimal) (numericResult (exp (resultNumericValue L))))
                                      ('t #f))))
                          ; b^g with b > 0 finite and g finite: plain value.
                          ((and (limFinite? lb) (limFinite? lg) (> (resultNumericValue lb) 0))
                              (numericResult (expt (resultNumericValue lb) (resultNumericValue lg))))
                          ; determinate infinite exponents.
                          ((and (limFinite? lb) (> (resultNumericValue lb) 0) (limInf? lg))
                              (let ((b (resultNumericValue lb)) (up? (eqv? (cdr lg) '+)))
                                  (cond ((= b 1) #f)
                                        ((> b 1) (if up? (cons 'infinity '+) (cons 'exact 0)))
                                        ('t (if up? (cons 'exact 0) (cons 'infinity '+))))))
                          ((and (limInf? lb) (eqv? (cdr lb) '+) (limInf? lg))
                              (if (eqv? (cdr lg) '+) (cons 'infinity '+) (cons 'exact 0)))
                          (else #f)))))))
