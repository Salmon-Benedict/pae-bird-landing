; oscillations.scm -- physics module Phase 6: Oscillations (SHM) --
; project_physics_module.md's Mechanics curriculum order, item 6. Five
; independent, single-equation commands, each a thin wrapper over
; physicsSolve.scm's solvePhysicsCommand -- same zero-multi-equation-risk
; shape as every phase since Phase 3's `power` lesson.
;
; ---- Letter budget: exhausted by Phase 5, resolved via indexed variables ----
; physicsRoleTable (physicsUnits.scm) had all 25 usable single letters
; (a-z minus the permanently-forbidden i) assigned by the end of Phase 5,
; with nothing left for this phase's two genuinely new dimensioned
; quantities (frequency, spring constant). Resolved by using indexed
; variables (base_subscript, e.g. f_s, k_s) instead of new plain
; letters -- the engine's parser already fuses `letter_letter` into one
; atomic token (expandParse.scm's groupIndexedVars) for ordinary
; expression input, but this physics layer had never exercised that path
; before this phase. Verified live (not assumed) before writing any of
; the equations below: parsePhysicsKnowns accepts an indexed symbol as a
; role key with no changes needed (it just does string->symbol on the
; raw text before "="), and substituteKnownValues/solve() both correctly
; treat "f_s"/"k_s" as single atomic symbols distinct from bare f/k --
; e.g. (substituteKnownValues "f_s=1/t" '((t . 5))) -> "f_s=1/5", and
; k_s*x=10 is correctly rejected as genuinely multivariable (proving k_s
; isn't silently mis-tokenized into two symbols). This unblocks not just
; this phase but every future one -- indexed variables give the naming
; scheme effectively unlimited room.
;
; f_s = frequency (f is already force); k_s = spring constant (k is
; already kinetic/potential energy). s/a/o/d are all reused directly
; from existing roles: s as amplitude (already length-dimensioned), a as
; maximum acceleration (already acceleration-dimensioned), o as angular
; frequency (already angular-velocity-dimensioned, reused directly from
; Rotation -- genuinely the same dimension and the same quantity
; conceptually), d as displacement from equilibrium (already
; length-dimensioned, already reused this way by work/springpe-style
; commands).
;
; ---- Two formulas deliberately out of scope: no symbolic pi, no sqrt-as-input ----
; The natural SHM period formulas (T=2*pi/omega, T=2*pi*sqrt(m/k),
; T=2*pi*sqrt(L/g)) are NOT buildable with this engine as it exists,
; for reasons unrelated to the letter budget: solve()'s polynomial
; engine has no symbolic pi at all (only exact rationals and
; quadratic-formula-derived symbolic square roots), and solve() cannot
; accept sqrt(...) as EQUATION INPUT -- sqrt only ever appears as
; output (irrational quadratic-root formatting), never as something a
; user's equation can contain for solve() to work with. Both are
; genuine representational limits, not a scope choice to revisit
; casually -- see the physics module doc's Phase 6 section.
;
; Note: SHM's function-based mode (given x(t) = 5*cos(2*t), find
; velocity/acceleration as functions of t) is ALREADY fully covered by
; the existing @:velocity/@:acceleration commands (kinematics.scm) --
; diffExpr's trig chain rule is fully general, so no new code is needed
; for that workflow; see commands.temp.html's Phase 6 note.
;
; Depends on: physicsUnits.scm (the 2 new Phase 6 dimensions/roles),
; physicsSolve.scm (solvePhysicsCommand). Load this file after
; physicsSolve.scm.

; ---- Period-frequency: t = 1/f_s ----
; Reciprocal relation -- pi-free, sqrt-free. Linear in t once f_s is
; known; solving for f_s from t is likewise a simple reciprocal (never
; branches -- solve() handles 1/x=const directly, one real root).
(define periodVars '(t f_s))
(define periodEquations (list "t=1/f_s"))

; ---- Hooke's law: f = k_s*d ----
; (spring force = spring constant * displacement from equilibrium).
; Linear -- never branches.
(define hookeslawVars '(f k_s d))
(define hookeslawEquations (list "f=k_s*d"))

; ---- Spring potential energy: e = 1/2*k_s*d^2 ----
; Reuses e -- SAME energy dimension as gravitational PE (gravpe), same
; reuse pattern rotke used for k in Phase 5. Solving for d can branch
; (+/-), same reasoning as kinetic's own v-branching.
(define springpeVars '(e k_s d))
(define springpeEquations (list "e=1/2*k_s*d^2"))

; ---- Maximum SHM velocity: v = s*o ----
; (max velocity = amplitude * angular frequency). Named maxvelocity, not
; velocity, to avoid confusion with the EXISTING velocity command (a
; diffExpr wrapper for a position function) -- see this file's header
; note. Linear -- never branches.
(define maxvelocityVars '(v s o))
(define maxvelocityEquations (list "v=s*o"))

; ---- Maximum SHM acceleration: a = s*o^2 ----
; Solving for o can branch (+/-), same reasoning as circular motion's
; own o/omega-squared term.
(define maxaccelerationVars '(a s o))
(define maxaccelerationEquations (list "a=s*o^2"))
