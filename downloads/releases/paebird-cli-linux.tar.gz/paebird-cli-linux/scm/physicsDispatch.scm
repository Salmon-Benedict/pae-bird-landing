; physicsDispatch.scm -- the single dispatcher.scm hook velocity/
; acceleration reach through (project_physics_module.md's locked-in
; decision: "New physics commands get their own namespace/prefix in the
; dispatcher rather than growing the general applyCommand cond table").
;
; Used to also route the other 26 physics commands (suvat/newton/
; circular/.../universalgravpe) by cmd-string, one case per command --
; replaced by @:physics's single auto-detecting mode (physicsRegistry.scm's
; physicsMatchAndSolve), per PHYSICS-EXPERT-SYSTEM-PLAN.md. velocity/
; acceleration stay here unchanged: they're a fundamentally different
; feature (differentiating a position FUNCTION via dcalc's AST engine,
; not a "give some quantities, solve for the rest" line), so they were
; never part of that registry/matcher to begin with.
;
; Depends on: kinematics.scm (velocity, acceleration), exprAst.scm/
; exprParse.scm (exprToString/exprParse). Load this file after those.

(define (physicsCommand? cmd)
    (or (string=? cmd "velocity") (string=? cmd "acceleration")))

; cmd/arg/charL match applyCommand's own three parameters exactly --
; charL is a CHAR LIST (string->list line, already past matrix/factorial
; substitution), the same shape dcalc/icalc/etc. hand straight to
; exprParse. Both commands need arg (the variable, required, same
; convention as dcalc).
(define (applyPhysicsCommand cmd arg charL)
    (cond
        ((string=? cmd "velocity")
            (if (string=? arg "")
                (error #f "velocity: a variable is required, e.g. \"compute velocity t <expr>\"")
                (exprToString (velocity (exprParse charL) (string->symbol arg)))))
        ((string=? cmd "acceleration")
            (if (string=? arg "")
                (error #f "acceleration: a variable is required, e.g. \"compute acceleration t <expr>\"")
                (exprToString (acceleration (exprParse charL) (string->symbol arg)))))))
