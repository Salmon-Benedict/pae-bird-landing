; physicsRegistry.scm -- @:physics's relation registry + matcher
; (PHYSICS-EXPERT-SYSTEM-PLAN.md). Replaces the 26 separate physics
; command names (suvat/newton/circular/.../universalgravpe) with ONE
; mode, "@:physics", that auto-detects which relation applies from the
; variables given (plus an optional "?"-marked target, see
; physicsUnits.scm's parsePhysicsKnownsAndTarget) instead of the user
; already knowing and typing the exact command name for it.
;
; Depends on: every topic file's own *Vars/*Equations bindings
; (kinematics.scm, dynamics.scm, workEnergy.scm, collisions.scm,
; rotation.scm, oscillations.scm, gravitation.scm -- all loaded before
; this file), physicsSolve.scm (solvePhysicsCommandFromKnowns,
; joinStrs), physicsUnits.scm (parsePhysicsKnownsAndTarget). Load this
; file after all of those, in place of the old physicsDispatch.scm's
; 26-way table (velocity/acceleration -- a completely different,
; function-based feature -- keep their own small dispatch separately).
;
; ---- Why this needs no new solving logic at all ----
; Every one of the 26 old commands was ALREADY nothing but
; "(solvePhysicsCommand fooEquations fooVars argString)" -- a single
; generic engine (physicsSolve.scm), parameterized per topic only by
; its own (vars, equations) pair. This registry just collects those 26
; existing pairs (zero duplication -- the bindings themselves are
; untouched); the only genuinely new code is the matcher below that
; picks which pair applies.
(define physicsRegistry
    (list
        (list 'suvat suvatVars suvatEquations)
        (list 'newton newtonVars newtonEquations)
        (list 'circular circularVars circularEquations)
        (list 'work workVars workEquations)
        (list 'kinetic kineticVars kineticEquations)
        (list 'gravpe gravpeVars gravpeEquations)
        (list 'power powerVars powerEquations)
        (list 'workenergy workenergyVars workenergyEquations)
        (list 'momentum momentumVars momentumEquations)
        (list 'impulse impulseVars impulseEquations)
        (list 'impulsemomentum impulsemomentumVars impulsemomentumEquations)
        (list 'collision collisionVars collisionEquations)
        (list 'inelastic inelasticVars inelasticEquations)
        (list 'torque torqueVars torqueEquations)
        (list 'rotnewton rotnewtonVars rotnewtonEquations)
        (list 'angularmomentum angularmomentumVars angularmomentumEquations)
        (list 'rotke rotkeVars rotkeEquations)
        (list 'period periodVars periodEquations)
        (list 'hookeslaw hookeslawVars hookeslawEquations)
        (list 'springpe springpeVars springpeEquations)
        (list 'maxvelocity maxvelocityVars maxvelocityEquations)
        (list 'maxacceleration maxaccelerationVars maxaccelerationEquations)
        (list 'gravforce gravforceVars gravforceEquations)
        (list 'gravfield gravfieldVars gravfieldEquations)
        (list 'orbitalvelocity orbitalvelocityVars orbitalvelocityEquations)
        (list 'escapevelocity escapevelocityVars escapevelocityEquations)
        (list 'universalgravpe universalgravpeVars universalgravpeEquations)))

; #t if every element of small is a member of big (order-independent).
(define (listSubset? small big)
    (cond
        ((null? small) 't)
        ((not (memq (car small) big)) #f)
        ('t (listSubset? (cdr small) big))))

(define (listSetEqual? a b) (and (listSubset? a b) (listSubset? b a)))

; Elements of big not in small.
(define (listDifference big small) (filter (lambda (x) (not (memq x small))) big))

; A registry entry is a candidate if every GIVEN role belongs to its
; vars (it recognizes every variable the caller supplied), it has at
; LEAST ONE variable left to actually solve for (otherwise it's not
; solving anything -- just vacuously "matching" because every given
; role happens to also be one of its own, e.g. giving inelastic's full
; 5-variable set as input is coincidentally a SUBSET of collision's own
; 6, but inelastic itself would have nothing left to solve and isn't a
; real answer to show), and -- only when the caller named a target via
; "?" -- the target set belongs to its vars AND equals EXACTLY what's
; left over once the given roles are removed. That last "exactly", not
; "at least", matters: a relation that would ALSO leave some other,
; unnamed variable unsolved isn't a match for "solve for exactly this"
; (see PHYSICS-EXPERT-SYSTEM-PLAN.md's matcher section).
(define (physicsRelationCandidate? entry givenKeys targetVars)
    (let* ((vars (cadr entry)) (missing (listDifference vars givenKeys)))
        (and (listSubset? givenKeys vars)
             (not (null? missing))
             (or (null? targetVars)
                 (and (listSubset? targetVars vars)
                      (listSetEqual? targetVars missing))))))

(define (physicsCandidates knownsAlist targetVars)
    (let ((givenKeys (map car knownsAlist)))
        (filter (lambda (entry) (physicsRelationCandidate? entry givenKeys targetVars)) physicsRegistry)))

; Tries one candidate entry against knownsAlist, catching any error
; (most commonly "could not solve -- no equation has exactly one
; remaining unknown", i.e. this candidate's OWN vars need more givens
; than were actually supplied -- physicsSolve.scm's existing
; underdetermined-system guard, reused here for free instead of this
; file separately precomputing "how many variables does topic X need").
; Returns (cons name answerString) on success, #f otherwise.
(define (tryPhysicsCandidate entry knownsAlist)
    (guard (c (#t #f))
        (let* ((name (car entry)) (vars (cadr entry)) (equations (caddr entry))
               (answer (solvePhysicsCommandFromKnowns equations vars knownsAlist)))
            (cons name answer))))

; Top-level entry point for the "@:physics" mode (dispatcher.scm).
; argString is the whole data line, e.g. "u=0m/s a=9.8m/s^2 t=2s" or,
; with a named target, "k=? m=2kg v=3m/s".
;
;   - exactly one candidate solves: returns its plain answer string,
;     byte-identical in shape to what the old dedicated command
;     (e.g. suvatCommand) would have returned for the same input.
;   - zero candidates solve: a clear error naming the given roles,
;     rather than guessing.
;   - two or more candidates solve (a genuine ambiguity -- either the
;     caller didn't mark a target at all, or a target was marked but
;     multiple relations still tie on it, e.g. orbital vs. escape
;     velocity's identical variable set): every candidate's answer is
;     returned, each labeled by relation name, joined with " | " -- a
;     DIFFERENT separator than the "; " formatPhysicsBranch already
;     uses between a single topic's own multiple branches (e.g.
;     orbital velocity's own ± roots), so nesting the two never
;     becomes ambiguous about where one candidate's answer ends and
;     the next begins -- e.g. "kinetic: k = 9J | momentum: q = 6kg*m/s".
(define (physicsMatchAndSolve argString)
    (let* ((parsed (parsePhysicsKnownsAndTarget argString))
           (knownsAlist (car parsed))
           (targetVars (cdr parsed))
           (candidates (physicsCandidates knownsAlist targetVars))
           (successes (filter (lambda (x) x) (map (lambda (e) (tryPhysicsCandidate e knownsAlist)) candidates))))
        (cond
            ((null? successes)
                (error #f "physics: no known relation matches these variables" (map car knownsAlist)))
            ((null? (cdr successes)) (cdr (car successes)))
            ('t (joinStrs (map (lambda (r) (string-append (symbol->string (car r)) ": " (cdr r))) successes) " | ")))))
