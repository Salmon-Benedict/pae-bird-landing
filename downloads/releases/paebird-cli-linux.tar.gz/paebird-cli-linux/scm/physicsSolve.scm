; physicsSolve.scm -- generic greedy multi-equation solver shared by
; every physics topic (kinematics.scm's suvat, dynamics.scm's newton/
; circular, and whatever topic comes after). Extracted and generalized
; from kinematics.scm's original SUVAT-specific solveSuvat/
; solveSuvatStep/trySuvatEquation/etc. (Phase 1) -- same strategy, now
; parameterized by an equation list and a variable count instead of
; hardcoded SUVAT globals. Phase 1's 5 SUVAT golden tests are the
; regression check that this extraction preserved behavior exactly.
;
; Depends on: solvePoly.scm (solve), variableSubstitution.scm
; (substituteKnownValues), linearSystems.scm (parseFractionOrDecimal),
; equationVariants.scm (findStringCharPos, stripSpaces), chemistry.scm
; (findSubstring), physicsUnits.scm (formatPhysicsQuantity). Load this
; file after physicsUnits.scm and before any topic file that uses it.

; join-strings lives in dispatcher.scm/chain.scm, neither of which is
; loaded before this file -- a small local copy, matching this
; codebase's own established precedent for small self-contained string
; utilities (see dispatcher.scm's shell-quote comment) rather than
; reordering either loader.
(define (joinStrs strs sep)
    (cond
        ((null? strs) "")
        ((null? (cdr strs)) (car strs))
        ('t (string-append (car strs) sep (joinStrs (cdr strs) sep)))))

; True if s (a solve()-style "var = value" result string) names a
; complex result -- same "i"-substring check curveSketch.scm's own
; parseRadicalValue already uses to filter these out (see that file's
; header). A complex time/velocity/force/etc isn't physically
; meaningful here -- unlike curveSketch, which just drops the one
; point, this treats the WHOLE equation as inapplicable and tries the
; next one, since a different equation might still give a genuine real
; answer for physically-consistent input.
(define (physicsComplexResult? s) (findSubstring s "i" 0))

; True if s actually has the "var = value" shape a real solve() root
; produces. Needed because an equation can become FULLY DETERMINED
; after substitution -- e.g. power's "p=f*v" with p, f, AND v all
; already known -- which isn't multivariable (so solve() doesn't error)
; but also has no variable left at all; solve() then falls into
; solveDegree0 and returns a plain "All real numbers are solutions" or
; "No solution" string, neither containing "=". Found by hand-tracing
; every 3-knowns/2-unknowns combination for the power command (Phase 3)
; -- circular motion's own combinations (Phase 2) never happened to
; land on this case, so it went unnoticed until now. Deliberately a
; SEPARATE check from physicsComplexResult? above (not folded into one
; filter) -- the "i"-substring check would have accidentally caught both
; solveDegree0 strings too (English "solution"/"solutions" both contain
; "i"), which is exactly the kind of accidental, non-obvious safety net
; this file shouldn't rely on going forward.
(define (physicsResultShape? s) (findStringCharPos #\= s 0))

; Attempts solve() on eqStr after substituting knownsAlist -- returns
; the list of real "var = value" result strings on success (with any
; complex root, or a non-"var = value"-shaped fully-determined-equation
; result, filtered out), or #f if solve() itself failed (still
; multivariable after substitution, or any other reason), every root it
; found was complex, or the equation turned out to be fully determined
; with nothing left to solve.
(define (tryPhysicsEquation eqStr knownsAlist)
    (let ((result (guard (c (#t #f)) (solve (string->list (substituteKnownValues eqStr knownsAlist))))))
        (and result
             (let ((real (filter (lambda (r) (and (physicsResultShape? r) (not (physicsComplexResult? r)))) result)))
                 (and (pair? real) real)))))

; Finds the first of `equations` with exactly one remaining real-
; solvable unknown given knownsAlist, returning ALL its roots as a list
; of "var = value" strings -- #f if none apply. Reuses solve()'s own
; assertSingleVariable guard (via tryPhysicsEquation's catch) to
; DISCOVER which equation currently has one unknown, rather than hand-
; deriving that algebraically for each topic separately -- see
; kinematics.scm's own header comment (from Phase 1) for the proof this
; always finds a usable equation for SUVAT's specific 4-equation system;
; each topic file is responsible for its own equations actually having
; this property (every topic built so far -- SUVAT, Newton's second law,
; circular motion -- does).
(define (solvePhysicsStep equations knownsAlist)
    (let loop ((eqs equations))
        (if (null? eqs)
            #f
            (or (tryPhysicsEquation (car eqs) knownsAlist) (loop (cdr eqs))))))

; Splits a solve()-style "var = value" string into (cons varSymbol valueString).
(define (parsePhysicsResult s)
    (let* ((eqIdx (findStringCharPos #\= s 0))
           (varSym (string->symbol (stripSpaces (substring s 0 eqIdx))))
           (valStr (stripSpaces (substring s (+ eqIdx 1) (string-length s)))))
        (cons varSym valStr)))

; Converts a solve()-result value string to an exact rational, for
; feeding a just-solved unknown into a LATER solving step -- errors
; clearly if it isn't a plain rational (e.g. an irrational "√2" root
; reached here, rather than only ever being a final displayed answer),
; instead of silently mishandling it arithmetically. Only ever called
; when there's a further unknown left to solve (see solvePhysicsSystem
; below) -- an irrational root that's the LAST/only unknown is a
; perfectly fine final answer, no conversion needed.
(define (physicsValueToRational varSym valStr)
    (guard (c (#t (error #f "physics: an irrational intermediate result can't be used to solve the remaining unknown" (cons varSym valStr))))
        (parseFractionOrDecimal valStr)))

; Full generic solve. `equations` is a topic's fixed list of equation
; strings (using the shared physicsUnits.scm role letters);
; `knownsAlist` is the currently-known (var . valueInSI) pairs;
; `missingVars` is the list of variables still to solve, in no
; particular order. Solves one variable at a time (via
; solvePhysicsStep), branching over EVERY real root found at each step
; -- a root of an earlier-solved variable can change a later one's
; value (e.g. two valid times, each pairing with its own velocity), so
; this is genuine branching, not "just pick a root and move on."
; Returns a list of "branches," each a list of (var . valueString)
; pairs for every variable in missingVars, in the order they were
; solved. missingVars='() (nothing left to solve) returns a single
; empty branch -- the recursion's base case.
(define (solvePhysicsSystem equations knownsAlist missingVars)
    (if (null? missingVars)
        (list '())
        (let ((step (solvePhysicsStep equations knownsAlist)))
            (if (not step)
                (error #f "physics: could not solve -- no equation has exactly one remaining unknown given these values" knownsAlist)
                (apply append
                    (map (lambda (rString)
                             (let* ((root (parsePhysicsResult rString))
                                    (remaining (filter (lambda (v) (not (eq? v (car root)))) missingVars)))
                                 (if (null? remaining)
                                     (list (list root))
                                     (let* ((knownVal (physicsValueToRational (car root) (cdr root)))
                                            (knowns2 (cons (cons (car root) knownVal) knownsAlist))
                                            (restBranches (solvePhysicsSystem equations knowns2 remaining)))
                                         (map (lambda (restBranch) (cons root restBranch)) restBranches)))))
                         step))))))

; Renders one branch as "<var> = <value><unit>, <var> = <value><unit>, ...".
(define (formatPhysicsBranch branch)
    (joinStrs
        (map (lambda (p) (string-append (symbol->string (car p)) " = " (formatPhysicsQuantity (cdr p) (car p))))
             branch)
        ", "))

; Top-level convenience: parses knowns, determines the missing physics
; roles from allVars, solves, and formats every branch -- the common
; body every topic's own <topic>Command function reduces to.
(define (solvePhysicsCommand equations allVars argString)
    (solvePhysicsCommandFromKnowns equations allVars (parsePhysicsKnowns argString)))

; Same as solvePhysicsCommand, but takes an already-parsed knowns alist
; directly instead of a raw argString -- @:physics's matcher
; (physicsRegistry.scm) parses the line ONCE (parsePhysicsKnownsAndTarget,
; physicsUnits.scm, which also understands "role=?" target-marking) and
; tries it against several candidate relations, so re-parsing the same
; string per candidate via parsePhysicsKnowns would be both redundant and
; wrong (it doesn't understand "?" tokens at all).
(define (solvePhysicsCommandFromKnowns equations allVars knowns)
    (let ((missing (filter (lambda (v) (not (assq v knowns))) allVars)))
        (joinStrs (map formatPhysicsBranch (solvePhysicsSystem equations knowns missing)) "; ")))
