; physicsUnits.scm -- Stage 1 of the physics module's unit-handling
; architecture (see /Users/rat/Documents/Business/Polly/Journa, lab,
; agenda, etc./project_physics_module.md's "Unit-handling architecture"
; section for the full staged plan this implements the first stage of).
; Dimension vectors, a curated unit table, and role-based
; validation/display -- deliberately NOT a general compositional unit
; parser (combining/deriving units algebraically is Stage 2's
; "Quantity" arithmetic type, not this file's job). Units are stripped
; to plain SI-base-unit exact rationals before anything reaches the
; existing algebra engine; no existing engine file is touched by this
; file's own existence.
;
; Depends on: equationVariants.scm (stripSpaces, parseNumeralToRational).

; ---- Dimension vectors ----
; A dimension is a list of (baseSymbol . exponent) pairs, only nonzero
; exponents listed, always built by makeDim below in a fixed M, L, T
; order -- so two dimensions with the same nonzero exponents are always
; `equal?`, with no separate canonicalizing sort needed (unlike
; expandParse.scm's mergeVarAlists, which sorts because its variable set
; is open-ended; this file's is a fixed 3-symbol basis).
;
; Two decisions locked in by the plan doc, both honored here even though
; Kinematics itself never uses M: the basis stays (M L T) through all of
; Mechanics and extends additively (M L T I) for E&M later -- adding a
; 4th slot to makeDim when that day comes is additive, not a migration,
; since every existing dimension constant here just keeps omitting it.
(define (makeDim m l t)
    (filter (lambda (p) (not (= (cdr p) 0)))
        (list (cons 'M m) (cons 'L l) (cons 'T t))))

(define dimDimensionless (makeDim 0 0 0))
(define dimLength        (makeDim 0 1 0))
(define dimTime          (makeDim 0 0 1))
(define dimVelocity      (makeDim 0 1 -1))
(define dimAcceleration  (makeDim 0 1 -2))
(define dimMass          (makeDim 1 0 0))
(define dimForce         (makeDim 1 1 -2))
(define dimEnergy        (makeDim 1 2 -2))
(define dimPower         (makeDim 1 2 -3))
(define dimMomentum      (makeDim 1 1 -1))
; Phase 5 (Rotation) additions. Angular quantities are dimensionless in
; the angle itself -- a radian carries no (M L T) dimension -- so
; angular velocity/acceleration are genuinely DIFFERENT dimensions from
; their linear namesakes (angular accel is T⁻² alone, not L¹T⁻² like
; dimAcceleration), not reuses of them.
(define dimAngularVelocity   (makeDim 0 0 -1))
(define dimAngularAccel      (makeDim 0 0 -2))
(define dimMomentOfInertia   (makeDim 1 2 0))
; Same dimensional formula as dimEnergy (M¹L²T⁻²) -- torque and energy
; are dimensionally identical but physically distinct, and N·m/J are
; conventionally kept visually separate, so this stays its own entry
; rather than aliasing dimEnergy.
(define dimTorque            (makeDim 1 2 -2))
(define dimAngularMomentum   (makeDim 1 2 -1))
; Phase 6 (Oscillations) additions. Frequency is dimensionally identical
; to dimAngularVelocity (both T⁻¹) but kept as its own entry for the
; same "conceptually distinct" reason dimTorque stayed separate from
; dimEnergy in Phase 5 -- frequency (cycles/s) and angular velocity
; (radians/s) are different quantities that happen to share a dimension.
(define dimFrequency         (makeDim 0 0 -1))
(define dimSpringConstant    (makeDim 1 0 -2))
; Phase 7 (Gravitation) addition. Derived from F=Gmn/r^2: G's dimension
; is [F][r^2]/([m][n]) = (M^1 L^1 T^-2)(L^2)/(M^2) = M^-1 L^3 T^-2.
(define dimGravConstant      (makeDim -1 3 -2))

(define (dimEqual? d1 d2) (equal? d1 d2))

; Readable name for an error message -- only the dimensions this file's
; own unit table actually produces need an entry.
(define (dimensionName d)
    (cond
        ((dimEqual? d dimLength) "length")
        ((dimEqual? d dimTime) "time")
        ((dimEqual? d dimVelocity) "velocity")
        ((dimEqual? d dimAcceleration) "acceleration")
        ((dimEqual? d dimMass) "mass")
        ((dimEqual? d dimForce) "force")
        ((dimEqual? d dimEnergy) "energy")
        ((dimEqual? d dimPower) "power")
        ((dimEqual? d dimMomentum) "momentum")
        ((dimEqual? d dimAngularVelocity) "angular velocity")
        ((dimEqual? d dimAngularAccel) "angular acceleration")
        ((dimEqual? d dimMomentOfInertia) "moment of inertia")
        ((dimEqual? d dimTorque) "torque")
        ((dimEqual? d dimAngularMomentum) "angular momentum")
        ((dimEqual? d dimFrequency) "frequency")
        ((dimEqual? d dimSpringConstant) "spring constant")
        ((dimEqual? d dimGravConstant) "gravitational constant")
        ('t "physics")))

; ---- Unit table ----
; name -> (list dimension exactSIConversionFactor). A flat, curated set
; covering what Kinematics problems actually use -- not a general
; "parse any compound unit expression" grammar (that's Stage 2's job).
; Imperial conversions use their EXACT rational definitions (1 ft =
; 0.3048 m exactly, 1 mi = 1609.344 m exactly -- both are international-
; standard exact definitions, not measured/rounded), matching this
; engine's exact-rational convention everywhere else rather than
; introducing floats.
(define physicsUnitTable
    (list
        (list "m"  dimLength 1)
        (list "km" dimLength 1000)
        (list "cm" dimLength 1/100)
        (list "ft" dimLength 381/1250)      ; 0.3048
        (list "mi" dimLength 201168/125)    ; 1609.344

        (list "s"   dimTime 1)
        (list "min" dimTime 60)
        (list "hr"  dimTime 3600)

        (list "m/s"   dimVelocity 1)
        (list "km/hr" dimVelocity 5/18)     ; 1000/3600
        (list "mph"   dimVelocity 201168/450000) ; 1609.344/3600
        (list "ft/s"  dimVelocity 381/1250)

        (list "m/s^2"  dimAcceleration 1)
        (list "ft/s^2" dimAcceleration 381/1250)

        (list "kg" dimMass 1)
        (list "g"  dimMass 1/1000)

        (list "N" dimForce 1)

        (list "J" dimEnergy 1)
        (list "W" dimPower 1)

        (list "kg*m/s" dimMomentum 1)

        (list "rad/s"    dimAngularVelocity 1)
        (list "rad/s^2"  dimAngularAccel 1)
        (list "kg*m^2"   dimMomentOfInertia 1)
        (list "N*m"      dimTorque 1)
        (list "kg*m^2/s" dimAngularMomentum 1)

        (list "Hz"   dimFrequency 1)
        (list "N/m"  dimSpringConstant 1)

        ; Phase 7 (Gravitation). N*m^2/kg^2 = (kg*m/s^2)*m^2/kg^2 =
        ; kg^-1*m^3*s^-2 exactly -- already in this table's base-unit
        ; convention, factor 1.
        (list "N*m^2/kg^2" dimGravConstant 1)))

; ---- Parsing "5m/s", "10ft", "2.5s" ----

; Returns the index just past a valid "e"/"E" scientific-notation
; exponent starting at position i in s (e.g. i pointing at 'e' in
; "6.674e-11"), or #f if no valid exponent starts there -- an optional
; '+'/'-' followed by AT LEAST ONE digit is required, so a hypothetical
; unit starting with 'e'/'E' would correctly fail this check and fall
; through to being read as ordinary unit text instead (no such unit
; exists in physicsUnitTable today, but this keeps the split unambiguous
; either way, without needing to know the unit table at all -- same
; "split by pure lookahead" design splitPhysicsNumericPrefix already
; uses for the digit/dot loop below).
(define (physicsExponentEnd s i len)
    (if (and (< i len) (or (eqv? (string-ref s i) #\e) (eqv? (string-ref s i) #\E)))
        (let* ((signStart (+ i 1))
               (digitsStart (if (and (< signStart len)
                                      (or (eqv? (string-ref s signStart) #\+) (eqv? (string-ref s signStart) #\-)))
                                 (+ signStart 1) signStart)))
            (let loop ((j digitsStart))
                (if (and (< j len) (char-numeric? (string-ref s j)))
                    (loop (+ j 1))
                    (if (> j digitsStart) j #f))))
        #f))

; Splits s into (cons numericPrefix unitSuffix) -- the numeric prefix is
; an optional leading '-' followed by digits and at most one '.', now
; optionally followed by a scientific-notation exponent (see
; physicsExponentEnd above -- added Phase 7, for G's impractically small
; SI value); unit names never start with a digit, '-', 'e', or 'E', so
; this split is unambiguous without looking at the unit table at all.
; Deliberately does NOT accept a "num/den" fraction here (unlike
; parseNumeralToRational's own caller elsewhere) -- a compound unit like
; "m/s" already uses '/', and allowing a fractional VALUE too (e.g.
; "1/2m/s") would make the split genuinely ambiguous.
(define (splitPhysicsNumericPrefix s)
    (let* ((len (string-length s))
           (start (if (and (> len 0) (eqv? (string-ref s 0) #\-)) 1 0)))
        (let loop ((i start) (seenDot #f))
            (cond
                ((and (< i len) (char-numeric? (string-ref s i))) (loop (+ i 1) seenDot))
                ((and (< i len) (eqv? (string-ref s i) #\.) (not seenDot)) (loop (+ i 1) #t))
                ((physicsExponentEnd s i len) => (lambda (endIdx) (cons (substring s 0 endIdx) (substring s endIdx len))))
                ('t (cons (substring s 0 i) (substring s i len)))))))

; Parses a numeric-prefix string that may contain a scientific-notation
; exponent (e.g. "6.674e-11") into an exact rational -- splits on
; "e"/"E", parses the mantissa via the EXISTING parseNumeralToRational
; (equationVariants.scm, unmodified) and the exponent via
; string->number, combines via (* mantissa (expt 10 exponent)). Stays
; an exact rational the whole way, same convention as every other
; numeric value in this engine (verified: "6.674e-11" ->
; 3337/50000000000000, never a float). Deliberately kept LOCAL to this
; file rather than added to equationVariants.scm's shared
; parseNumeralToRational -- 'e' is already an ordinary single-letter
; variable in the general algebra engine (and physics's own energy
; role, physicsRoleTable below), so teaching the SHARED numeral parser
; to treat a trailing 'e' specially would risk misreading "3e" (meaning
; "3*e") elsewhere in the app. This keeps the blast radius confined to
; physics-quantity parsing.
(define (parsePhysicsNumeral numStr)
    (let ((eIdx (or (findStringCharPos #\e numStr 0) (findStringCharPos #\E numStr 0))))
        (if (not eIdx)
            (parseNumeralToRational numStr)
            (let ((mantissa (parseNumeralToRational (substring numStr 0 eIdx)))
                  (exponent (string->number (substring numStr (+ eIdx 1) (string-length numStr)))))
                (* mantissa (expt 10 exponent))))))

; Parses a "<number><unit>" token (e.g. "5m/s", "10 ft", "6.674e-11N*m^2/kg^2"
; -- an internal space, if any, is stripped) into (cons
; valueInSIBaseUnits dimensionAlist). Errors clearly if the numeric
; prefix is empty or the unit suffix isn't in physicsUnitTable, rather
; than silently producing a meaningless quantity.
(define (parsePhysicsQuantity rawS)
    (let* ((s (stripSpaces rawS))
           (split (splitPhysicsNumericPrefix s))
           (numStr (car split))
           (unitStr (cdr split))
           (entry (assoc unitStr physicsUnitTable)))
        (if (or (= (string-length numStr) 0) (not entry))
            (error #f "physics: expected a number followed by a known unit (e.g. \"5m/s\", \"10ft\", \"2.5s\")" rawS)
            (let ((value (parsePhysicsNumeral numStr))
                  (dim (cadr entry))
                  (factor (caddr entry)))
                (cons (* value factor) dim)))))

; Errors clearly if quantity's dimension doesn't match expectedDim;
; returns quantity unchanged otherwise, so a call site can thread it
; through a let* the same way factorPoly.scm's assertFactorable does
; for its own guards.
(define (assertPhysicsDimension quantity expectedDim roleName)
    (if (not (dimEqual? (cdr quantity) expectedDim))
        (error #f (string-append "physics: " roleName " needs a " (dimensionName expectedDim) " value") quantity)
        quantity))

; ---- Shared variable-role table ----
; A single-letter variable role's meaning is topic-independent -- `a`
; always names an acceleration, `m` always a mass, whether the caller is
; kinematics.scm's suvat or dynamics.scm's newton/circular. Kept here
; (not per-topic) so every physics command shares one growing table
; instead of repeating its own dimension-lookup `case` form; each entry
; is (role . (dimension . defaultDisplayUnit)) -- default-unit-only
; display for v1, same reasoning as before this table existed.
(define physicsRoleTable
    (list
        (cons 's (cons dimLength "m"))
        (cons 'u (cons dimVelocity "m/s"))
        (cons 'v (cons dimVelocity "m/s"))
        (cons 'a (cons dimAcceleration "m/s^2"))
        (cons 't (cons dimTime "s"))
        (cons 'f (cons dimForce "N"))
        (cons 'm (cons dimMass "kg"))
        (cons 'r (cons dimLength "m"))
        ; Phase 3 (Work, Energy, Power) additions -- w/k/e share the
        ; energy dimension (work, kinetic energy, gravitational PE
        ; respectively -- distinct symbols so each command's own output
        ; reads clearly even though they're dimensionally the same
        ; thing), g is gravitational acceleration as its OWN symbol
        ; (same dimension as a, but deliberately not reusing a itself --
        ; g always means "the constant," not "the acceleration in this
        ; problem," and is never given a special-cased default value,
        ; matching every other variable's "always typed explicitly"
        ; convention), h is height (same dimension as s/r), d is
        ; distance for work (same dimension as s/r/h -- a distinct
        ; symbol purely so "w=f*d" reads naturally), p is power.
        (cons 'w (cons dimEnergy "J"))
        (cons 'k (cons dimEnergy "J"))
        (cons 'e (cons dimEnergy "J"))
        (cons 'g (cons dimAcceleration "m/s^2"))
        (cons 'h (cons dimLength "m"))
        (cons 'd (cons dimLength "m"))
        (cons 'p (cons dimPower "W"))
        ; Phase 4 (Linear Momentum, Collisions) additions -- q is
        ; momentum (p is already power, so a different letter is needed;
        ; picked for lack of a better free mnemonic single letter), j is
        ; impulse (SAME dimension as momentum -- impulse literally IS a
        ; change in momentum -- shares q's dimension the same way
        ; w/k/e shared dimEnergy above), n is a second object's mass in
        ; a two-body collision (shares m's dimension), x/y are a second
        ; object's initial/final velocity (share u/v's dimension -- u/v
        ; themselves stay object-1's initial/final, reused directly).
        ; NOTE: 'i' is deliberately never used as a role anywhere in this
        ; table -- physicsSolve.scm's physicsComplexResult? filters any
        ; solve() result string containing the letter "i" as a (usually
        ; accidental) complex-number marker, and a variable literally
        ; named i would have every one of its own results ("i = 5")
        ; incorrectly caught by that same check.
        (cons 'q (cons dimMomentum "kg*m/s"))
        (cons 'j (cons dimMomentum "kg*m/s"))
        (cons 'n (cons dimMass "kg"))
        (cons 'x (cons dimVelocity "m/s"))
        (cons 'y (cons dimVelocity "m/s"))
        ; Phase 5 (Rotation) additions -- the LAST 5 free single letters
        ; (b, c, l, o, z; i is permanently off-limits, see the note
        ; above) exactly cover this phase's 5 new dimensioned
        ; quantities, with no slack left for anything past its core four
        ; relations (see rotation.scm's own header for the letter-budget
        ; reasoning and what's deliberately deferred as a result). l is
        ; angular momentum (direct match to the standard symbol L); o is
        ; angular velocity (omega starts with o); z is moment of inertia
        ; and b is angular acceleration and c is torque -- all three
        ; arbitrary, since i/I (moment of inertia's actual standard
        ; symbol) is forbidden and no other free letter has a natural
        ; mnemonic tie to any of the three.
        (cons 'l (cons dimAngularMomentum "kg*m^2/s"))
        (cons 'o (cons dimAngularVelocity "rad/s"))
        (cons 'z (cons dimMomentOfInertia "kg*m^2"))
        (cons 'b (cons dimAngularAccel "rad/s^2"))
        (cons 'c (cons dimTorque "N*m"))
        ; Phase 6 (Oscillations) additions -- the plain-letter budget
        ; (a-z minus i) was fully exhausted by Phase 5, so these use
        ; indexed variables (base_subscript, fused into one atomic
        ; symbol by expandParse.scm's groupIndexedVars) instead, verified
        ; end-to-end through parsePhysicsKnowns/substituteKnownValues/
        ; solve() before committing to this approach -- see
        ; oscillations.scm's own header. f_s is frequency (f is already
        ; force); k_s is spring constant (k is already kinetic energy).
        ; s/a/o/d are all reused directly from existing roles (amplitude,
        ; max acceleration, angular frequency, displacement -- see
        ; oscillations.scm for how each is reused).
        (cons 'f_s (cons dimFrequency "Hz"))
        (cons 'k_s (cons dimSpringConstant "N/m"))
        ; Phase 7 (Gravitation) addition -- another indexed variable
        ; (see Phase 6's note above; the plain-letter budget stays
        ; exhausted, but indexed variables give unlimited room now that
        ; they're proven end-to-end). g_c is the gravitational constant
        ; G: 'g' itself is already gravitational acceleration/field
        ; strength (reused directly by gravitation.scm's own commands,
        ; not redefined), and uppercase isn't a valid variable at all
        ; (mathHelp.scm's var? only accepts single lowercase letters).
        ; f/m/n/r/v/e are all reused directly from existing roles (see
        ; gravitation.scm's own header for how each maps onto its
        ; formulas) -- no other new symbol needed this phase.
        (cons 'g_c (cons dimGravConstant "N*m^2/kg^2"))))

(define (physicsRoleEntry role)
    (let ((entry (assq role physicsRoleTable)))
        (if (not entry)
            (error #f "physics: unknown variable role (expected one of s, u, v, a, t, f, m, r, w, k, e, g, h, d, p, q, j, n, x, y, l, o, z, b, c, f_s, k_s, g_c)" role)
            (cdr entry))))

(define (physicsRoleDim role) (car (physicsRoleEntry role)))
(define (physicsRoleDefaultUnit role) (cdr (physicsRoleEntry role)))

; valueStr is a plain rational's number->string, OR a solve()-style
; irrational radical string ("√2") -- either way it's already the
; correct display text, this just appends the role's default unit.
(define (formatPhysicsQuantity valueStr role)
    (string-append valueStr (physicsRoleDefaultUnit role)))

; ---- Shared "var=value+unit" line parser ----
; Parses "u=5m/s a=2m/s^2 t=3s"-shaped text into an alist of (var .
; valueInSI), validating each value against physicsRoleTable's expected
; dimension for that role as it goes. One parser shared by every physics
; command (suvat/newton/circular/...) instead of a near-identical copy
; per command.
(define (parsePhysicsKnowns argString)
    (map (lambda (piece)
             (let ((eqIdx (findStringCharPos #\= piece 0)))
                 (if (not eqIdx)
                     (error #f "physics: expected \"var=value\" tokens, e.g. \"u=5m/s\"" piece)
                     (let* ((varSym (string->symbol (substring piece 0 eqIdx)))
                            (valStr (substring piece (+ eqIdx 1) (string-length piece)))
                            (q (parsePhysicsQuantity valStr)))
                         (assertPhysicsDimension q (physicsRoleDim varSym) (symbol->string varSym))
                         (cons varSym (car q))))))
         (splitOnSpaces argString)))

; ---- @:physics's own "?" target-marking extension (PHYSICS-EXPERT-
;      SYSTEM-PLAN.md) ----
; Same "var=value" line shape parsePhysicsKnowns already parses, but a
; token's RHS may also be the literal "?" -- e.g. "k=? m=2kg v=3m/s" --
; marking that role as the one the caller wants SOLVED FOR, disambiguating
; between relations that would otherwise tie on the same given variables
; (e.g. {m,v} alone is ambiguous between kinetic energy and momentum;
; naming k vs q as the target picks one). Returns (cons knownsAlist
; targetVars): knownsAlist is exactly parsePhysicsKnowns's own return
; shape (only the non-"?" tokens); targetVars is the list of "?"-marked
; roles, in no particular order, '() if none were marked (the ordinary
; "give some, infer the rest" style every existing physics command
; already used). Every role (marked or not) still goes through
; physicsRoleDim's existing lookup -- an unrecognized role errors
; immediately either way, same as parsePhysicsKnowns, which is what lets
; physicsQuantityLine? (dispatcher.scm) use this same parse to cheaply
; decide "is this even a physics-shaped line" for a mode line entirely
; on its own, before any relation-matching happens.
(define (parsePhysicsKnownsAndTarget argString)
    (let loop ((pieces (splitOnSpaces argString)) (knowns '()) (targets '()))
        (if (null? pieces)
            (cons (reverse knowns) (reverse targets))
            (let* ((piece (car pieces))
                   (eqIdx (findStringCharPos #\= piece 0)))
                (if (not eqIdx)
                    (error #f "physics: expected \"var=value\" (or \"var=?\") tokens, e.g. \"u=5m/s\"" piece)
                    (let* ((varSym (string->symbol (substring piece 0 eqIdx)))
                           (valStr (substring piece (+ eqIdx 1) (string-length piece))))
                        ; Force the role lookup even for a "?" token (physicsRoleDim
                        ; errors on an unrecognized role) -- an unknown variable name
                        ; should reject the same way whether or not it's the target.
                        (physicsRoleDim varSym)
                        (if (string=? valStr "?")
                            (loop (cdr pieces) knowns (cons varSym targets))
                            (let ((q (parsePhysicsQuantity valStr)))
                                (assertPhysicsDimension q (physicsRoleDim varSym) (symbol->string varSym))
                                (loop (cdr pieces) (cons (cons varSym (car q)) knowns) targets)))))))))
