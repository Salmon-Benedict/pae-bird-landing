; riemannLimitIntegral.scm -- evaluates a definite integral exactly via
; Theorem 4 + Equations 5-11 (theoremLibrary.scm), i.e. Stewart's own
; "definition" method: Deltax=(b-a)/n, x_i=a+i*Deltax (right endpoints),
; expand f(x_i)*Deltax as a polynomial in i, replace sum(i^k) with its
; closed form (Equations 5-7, plus 8 for the constant term), and take
; the n->infinity limit -- reproducing Example 2b's hand computation of
; integral(x^3-6x, 0, 3) = -6.75 exactly (RiemannSum.scm's own
; riemannSumToString only ever gives a fixed-n numeric APPROXIMATION;
; this file's whole reason to exist is the exact n->infinity answer).
;
; Scope, directly inherited from what Equations 5-7 actually cover:
; degree <= 3 polynomials only. A degree-4 term would need a sum(i^4)
; closed form (Faulhaber's formula) that Stewart doesn't give in this
; section -- and, importantly, (sum(i^2))^2 is NOT sum(i^4) (checked
; directly: at n=2, sum(i^4)=17 but (sum(i^2))^2=25), so there's no way
; to reach degree 4 by recombining Equations 5-7 either. A degree > 3 f
; is therefore a clear error here, same posture as RiemannSum.scm's own
; "side must be 'left or 'right" etc.
;
; Depends on: exprAst.scm/exprParse.scm (the expr tree), diffExpr.scm
; (exprIsPurePoly?, exprInferredVariable), limitExpr.scm
; (pureExprToTermList, the exprAst<->legacy-poly bridge), factorPoly.scm
; (polyDegree, coeffAt, polyVariable), factorial.scm (factorial, for the
; binomial coefficients in the expansion below). Load after all of
; these -- alongside RiemannSum.scm, its nearest relative.
;
; ---- The algebra, worked out once here rather than re-derived by the
;      engine at runtime (a, b, and f's own coefficients are already
;      plain numbers, so this is ordinary exact-rational arithmetic,
;      not symbolic expression manipulation): ----
;
; f(x) = sum(c_j * x^j, j, 0, deg).  x_i = a + i*Deltax.
;
; Binomial-expand (a+i*Deltax)^j = sum(C(j,m) * a^(j-m) * (i*Deltax)^m, m, 0, j),
; so f(x_i) = sum(i^m * Deltax^m * B_m, m, 0, deg)
;   where B_m = sum(c_j * C(j,m) * a^(j-m), j, m, deg)   -- riemannLimitB below.
;
; term_i = f(x_i)*Deltax = sum(i^m * Deltax^(m+1) * B_m, m, 0, deg).
; Deltax=(b-a)/n, so the coefficient of i^m is M_m/n^(m+1) where
; M_m = B_m*(b-a)^(m+1) -- a plain number, n nowhere inside it.
;
; sum(term_i, i, 1, n) = sum((M_m/n^(m+1)) * sum(i^m, i, 1, n), m, 0, deg).
; Equations 5-7 (plus 8 for m=0, sum(1,i,1,n)=n) give sum(i^m,i,1,n) as
; a degree-(m+1) polynomial in n whose leading term is n^(m+1)/(m+1) --
; so sum(i^m,i,1,n)/n^(m+1) -> 1/(m+1) as n->infinity, termwise, with
; every lower-order n contribution vanishing in the limit. Hence
;
;   integral(f(x),x,a,b) = sum(M_m/(m+1), m, 0, deg).
;
; (Sanity check against Example 2b, f=x^3-6x, [a,b]=[0,3]: c_3=1, c_1=-6,
; c_0=c_2=0. B_0=f(a)=f(0)=0, B_1=3c_3*a^2+2c_2*a+c_1=-6, B_2=3c_3*a+c_2=0,
; B_3=c_3=1. M_0=0, M_1=-6*3^2=-54, M_2=0, M_3=1*3^4=81. Sum M_m/(m+1) =
; 0 + -54/2 + 0/3 + 81/4 = -27+20.25 = -6.75. Matches the book exactly.)

; pureExprToTermList (limitExpr.scm) bridges through the legacy MIT
; polynomial engine's string parser, whose output is "boundary-signed"
; -- magnitude-only cn, with each term's OWN true sign instead recorded
; on the PRECEDING term's sgn field (see simplify.scm's unapplysigns,
; which builds exactly this shape for recordToString's own rendering
; needs). coeffAt (factorPoly.scm) just reads cn/cd raw, so it's only
; ever correct for the LEADING term (index 0, whose cn is never
; touched by unapplysigns) -- confirmed directly: coeffAt on
; pureExprToTermList("x^3-6x") gives 6 for the linear coefficient, not
; -6. Harmless everywhere else in this engine so far (intExpr.scm's
; linearCoeffs computes a "b" the same wrong way, but not one single
; caller ever reads it -- only its leading-coefficient "a"); THIS file
; needs every coefficient c_0..c_deg, not just the leading one, so it's
; the first caller this bug actually reaches. Fixed here, locally,
; rather than in the shared bridge/coeffAt themselves, since those have
; other established callers (limitExpr.scm's own rational-function
; machinery) this fix hasn't been checked against.
(define (trueSignedTerms terms)
    (let loop ((ts terms) (positive? 't))
        (if (null? ts)
            '()
            (let ((term (car ts)))
                (cons (makep (if positive? (cn term) (- (cn term))) (cd term) (pn term) (pd term)
                             (var term) (varPn term) (varPd term) (sgn term))
                      (loop (cdr ts) (not (eqv? (sgn term) '-))))))))

(define (binomialCoeff j m) (/ (factorial j) (* (factorial m) (factorial (- j m)))))

; B_m (see header derivation) -- terms is f's own coefficient list
; (pureExprToTermList), deg its degree, a the lower bound.
(define (riemannLimitB terms deg a m)
    (let loop ((j m) (acc 0))
        (if (> j deg)
            acc
            (loop (+ j 1) (+ acc (* (coeffAt terms j) (binomialCoeff j m) (expt a (- j m))))))))

(define (definiteIntegralByRiemannLimit f var a b)
    (if (not (exprIsPurePoly? f))
        (error #f "definiteIntegralByRiemannLimit: f must be a polynomial (Theorem 4/Equations 5-11 give no closed form otherwise)" (exprToString f))
        (let* ((terms (trueSignedTerms (pureExprToTermList f)))
               (v (polyVariable terms))
               (deg (polyDegree terms)))
            (cond
                ((and v (not (eqv? v var)))
                    (error #f "definiteIntegralByRiemannLimit: f must depend only on the given variable" (exprToString f)))
                ((> deg 3)
                    (error #f "definiteIntegralByRiemannLimit: degree > 3 is out of scope -- Equations 5-7 only give closed forms up to sum(i^3)" deg))
                ('t
                    (let loop ((m 0) (acc 0))
                        (if (> m deg)
                            acc
                            (loop (+ m 1) (+ acc (/ (* (riemannLimitB terms deg a m) (expt (- b a) (+ m 1))) (+ m 1)))))))))))
