; rotation.scm -- physics module Phase 5: Rotation (torque, rotational
; inertia, angular momentum) -- project_physics_module.md's Mechanics
; curriculum order, item 5. Four independent, single-equation commands,
; each a thin wrapper over physicsSolve.scm's solvePhysicsCommand --
; same zero-branching-risk shape as newton/gravpe/work, matching Phase
; 4's own lesson (no multi-equation bundling unless hand-verified
; necessary -- none of these needed it).
;
; ---- Letter budget, exactly exhausted by this phase ----
; physicsRoleTable (physicsUnits.scm) had 20 single-letter roles
; assigned across Phases 1-4. Combined with the two standing
; constraints (mathHelp.scm's var? only accepts single lowercase
; letters -- no multi-character names -- and 'i' is permanently
; off-limits since physicsSolve.scm's complex-number filter matches the
; letter "i" anywhere in a result string), that left exactly 5 free
; letters: b, c, l, o, z. This phase's vocabulary needs exactly 5
; genuinely new dimensioned quantities (moment of inertia, angular
; velocity, angular acceleration, torque, angular momentum -- each
; dimensionally distinct from every existing role, since radians carry
; no (M L T) dimension: angular acceleration is T⁻² alone, NOT the same
; dimension as linear acceleration a's L¹T⁻², even though both are
; colloquially "acceleration"). Exactly 5 needed, exactly 5 free -- no
; slack left for a rotational-kinematics ("angular SUVAT") 4-equation
; bundle, which would need at least 1-2 MORE new symbols (angular
; position, a second angular-velocity endpoint) than remain. That, and
; rolling-without-slipping (v=r*omega, a=r*alpha, which would need v/a
; to mean something dimensionally DIFFERENT than they already do), and
; rotational work/power (need angular position), and the parallel axis
; theorem (relates two DIFFERENT moments of inertia, not something
; solvePhysicsCommand's one-value-per-role model represents cleanly)
; are all deliberately deferred -- a real letter-budget-driven scope
; boundary, not laziness; the underlying algebra is no harder than
; SUVAT's own equations.
;
; l=angular momentum (direct match to standard symbol L), o=angular
; velocity (omega starts with o), z=moment of inertia, b=angular
; acceleration, c=torque (the last three arbitrary -- i/I, moment of
; inertia's actual standard symbol, is forbidden, and no other free
; letter has a natural mnemonic tie to any of the three).
;
; Depends on: physicsUnits.scm (the 5 new Phase 5 dimensions/roles),
; physicsSolve.scm (solvePhysicsCommand). Load this file after
; physicsSolve.scm.

; ---- Torque: c = f*r ----
; Force perpendicular to the lever arm only -- the angled case
; (c=f*r*sin(theta)) is out of scope, same reasoning as work's own
; cos(theta) exclusion (solve() has no trig-equation-solving concept).
; Reuses f (force) and r (already "a radius/lever-arm-length" from
; circular motion) directly.
(define torqueVars '(c f r))
(define torqueEquations (list "c=f*r"))

; ---- Rotational Newton's second law: c = z*b ----
; (torque = moment of inertia * angular acceleration). Linear -- never branches.
(define rotnewtonVars '(c z b))
(define rotnewtonEquations (list "c=z*b"))

; ---- Angular momentum: l = z*o ----
; (angular momentum = moment of inertia * angular velocity). Linear --
; never branches.
(define angularmomentumVars '(l z o))
(define angularmomentumEquations (list "l=z*o"))

; ---- Rotational kinetic energy: k = 1/2*z*o^2 ----
; Reuses k -- SAME energy dimension as linear kinetic energy (1/2*I*omega^2
; is genuinely in Joules). Solving for o can branch (+/-), same reasoning
; as kinetic's own v-branching.
(define rotkeVars '(k z o))
(define rotkeEquations (list "k=1/2*z*o^2"))
