; setOperations.scm -- finite sets of atomic elements: union, intersection,
; difference, subset, and membership. A first "intro to sets" slice --
; elements are atomic tokens (a plain number or a bare word/symbol), not
; nested/recursive set-valued elements or algebraic expressions.
;
; Depends on: chemistry.scm (splitOnChar, trimSpaces, findSubstring),
; helperS.scm (remove-all), expandParse.scm (joinCommaStrings). Load
; after all three.
;
; ---- Input grammar ----
; A set literal is "{e1,e2,...}", or "{}"/"∅" for the empty set. A full
; set expression is "<left> <op> <right>", where op is one of (both a
; glyph and one or more ASCII word spellings accepted, same dual-spelling
; convention as expandParse.scm's sqrt(/√( support -- see that file's own
; header for the same idea applied to radicals):
;   ∪ / union                 -- setUnion,        both sides set literals
;   ∩ / intersect / intersection -- setIntersection, both sides set literals
;   \ / difference / diff / minus -- setDifference,  both sides set literals
;   ⊆ / subset                -- setSubset?,       both sides set literals
;   ∈ / member / element      -- setMember?,       LEFT is a bare element,
;                                                    right is a set literal
; No space is required around the operator (spaces are stripped before
; anything else runs, same as expand()'s own preprocessing).
;
; ---- Scope note ----
; The operator is located via a plain substring scan, skipped over any
; {...}-enclosed region (maskBraces) so a set literal that happens to
; CONTAIN an element spelled like an operator word (e.g. {a,union,b})
; can't be mistaken for the real top-level operator. This does NOT
; protect a bare (non-set) membership LEFT-hand element that happens to
; be spelled like an operator word (e.g. "union∈{a,union,b}" would
; misparse) -- a narrow, accepted limitation of string-level
; preprocessing, not something this file tries to fully solve.

; ---- Parsing ----

(define (parseSetElement str)
    (or (string->number str) (string->symbol str)))

(define (dedupeSet lst)
    (cond
        ((null? lst) lst)
        ((member (car lst) (cdr lst)) (dedupeSet (cdr lst)))
        ('t (cons (car lst) (dedupeSet (cdr lst))))))

(define (parseSetLiteral str)
    (cond
        ((or (string=? str "∅") (string=? str "{}")) '())
        ((and (> (string-length str) 1)
              (eqv? (string-ref str 0) #\{)
              (eqv? (string-ref str (- (string-length str) 1)) #\}))
            (let ((inner (substring str 1 (- (string-length str) 1))))
                (if (string=? inner "")
                    '()
                    (dedupeSet (map parseSetElement (splitOnChar inner #\,))))))
        ('t (error #f "set: expected a set literal like {1,2,3} or {}/∅ for the empty set" str))))

; ---- Operations ----

(define (setUnion a b) (dedupeSet (append a b)))
(define (setIntersection a b) (filter (lambda (e) (member e b)) a))
(define (setDifference a b) (filter (lambda (e) (not (member e b))) a))
(define (setSubset? a b) (for-all (lambda (e) (member e b)) a))
(define (setMember? x a) (and (member x a) 't))

; ---- Rendering ----
;
; Numbers sorted ascending, then symbols sorted alphabetically -- a
; deterministic, intuitively-ordered display regardless of input order
; or duplicates (already deduped by parseSetLiteral/setUnion).
(define (setElementToString e) (if (number? e) (number->string e) (symbol->string e)))

(define (setToString lst)
    (if (null? lst)
        "∅"
        (let* ((nums (sort < (filter number? lst)))
               (syms (sort (lambda (a b) (string<? (symbol->string a) (symbol->string b))) (filter symbol? lst))))
            (string-append "{" (joinCommaStrings (map setElementToString (append nums syms))) "}"))))

; ---- Operator detection ----

(define setOperatorSpellings
    (list
        (cons 'union        (list "∪" "union"))
        (cons 'intersection (list "∩" "intersect" "intersection"))
        (cons 'difference   (list "\\" "difference" "diff" "minus"))
        (cons 'subset       (list "⊆" "subset"))
        (cons 'member       (list "∈" "member" "element"))))

; Replaces every character strictly inside a {...} region with '#' --
; same length as s, so indices found by scanning the masked string are
; still valid indices into the ORIGINAL s.
(define (maskBraces s)
    (list->string
        (let loop ((i 0) (depth 0))
            (if (>= i (string-length s))
                '()
                (let ((c (string-ref s i)))
                    (cond
                        ((eqv? c #\{) (cons c (loop (+ i 1) (+ depth 1))))
                        ((eqv? c #\}) (cons c (loop (+ i 1) (max 0 (- depth 1)))))
                        ((> depth 0) (cons #\# (loop (+ i 1) depth)))
                        ('t (cons c (loop (+ i 1) depth)))))))))

(define (flattenSetOperatorSpellings)
    (apply append
        (map (lambda (p) (map (lambda (sp) (cons (car p) sp)) (cdr p))) setOperatorSpellings)))

; Each candidate: (opSym spellingStr matchIdx). Filters out spellings
; that don't occur at all.
(define (setOperatorCandidates maskedS)
    (filter (lambda (c) (caddr c))
        (map (lambda (p) (list (car p) (cdr p) (findSubstring maskedS (cdr p) 0)))
             (flattenSetOperatorSpellings))))

; Leftmost match wins; ties (one spelling is a prefix of another, e.g.
; "intersect" vs "intersection") resolve to the LONGER spelling.
(define (betterSetOperatorCandidate a b)
    (cond
        ((< (caddr a) (caddr b)) a)
        ((> (caddr a) (caddr b)) b)
        ((>= (string-length (cadr a)) (string-length (cadr b))) a)
        ('t b)))

(define (bestSetOperatorCandidate candidates)
    (if (null? candidates)
        #f
        (let loop ((rest (cdr candidates)) (best (car candidates)))
            (if (null? rest)
                best
                (loop (cdr rest) (betterSetOperatorCandidate best (car rest)))))))

; ---- Top-level entry point (dispatcher.scm's "set" compute command) ----

(define (evalSetExpr charL)
    (let* ((s (list->string (remove-all #\space charL)))
           (best (bestSetOperatorCandidate (setOperatorCandidates (maskBraces s)))))
        (if (not best)
            (error #f "set: expected a set expression like {1,2,3}∪{2,3,4} (word form: {1,2,3} union {2,3,4}) -- recognized operators: ∪/union, ∩/intersect(ion), \\/difference/diff/minus, ⊆/subset, ∈/member/element (as in 2∈{1,2,3})" s)
            (let* ((opSym (car best)) (matchIdx (caddr best)) (matchLen (string-length (cadr best)))
                   (leftStr (substring s 0 matchIdx))
                   (rightStr (substring s (+ matchIdx matchLen) (string-length s))))
                (case opSym
                    ((union)        (setToString (setUnion (parseSetLiteral leftStr) (parseSetLiteral rightStr))))
                    ((intersection) (setToString (setIntersection (parseSetLiteral leftStr) (parseSetLiteral rightStr))))
                    ((difference)   (setToString (setDifference (parseSetLiteral leftStr) (parseSetLiteral rightStr))))
                    ((subset)       (if (setSubset? (parseSetLiteral leftStr) (parseSetLiteral rightStr)) "true" "false"))
                    ((member)       (if (setMember? (parseSetElement leftStr) (parseSetLiteral rightStr)) "true" "false"))
                    (else (error #f "set: internal error -- unrecognized operator" opSym)))))))
