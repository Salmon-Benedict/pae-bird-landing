; Single-variable equation solving, built on top of expandParse.scm and
; factorPoly.scm (both must be loaded first). Handles:
;   - Linear: ax+b=0 -> x = -b/a
;   - Quadratic: ax^2+bx+c=0 via the quadratic formula, covering all
;     three cases: rational roots (discriminant a perfect square),
;     irrational real roots (printed symbolically as p ± q√n, with the
;     largest perfect square factor of the discriminant extracted so n
;     is square-free), and complex roots (printed as p ± qi when the
;     discriminant's magnitude is a perfect square, falling back to a
;     decimal approximation for q otherwise -- same convention as the
;     C++ engine, see note below)
;   - Degree >= 3: repeatedly finds a rational root (factorPoly.scm's
;     findRationalRoot/divideByLinearFactor) and divides it out until
;     the remaining factor is degree <= 2, then solves that with the
;     same quadratic/linear logic. If no rational root exists for the
;     remaining factor while its degree is still >= 3, that factor is
;     reported as unsolved rather than guessed at (true general
;     cubic/quartic radical formulas aren't implemented).
;   - A negative integer exponent (e.g. "x^-2+x^2=4") is supported by
;     clearing it first (factorPoly.scm's clearNegativeExponent -- see
;     its own comment for why this never needs a domain-exclusion filter
;     for the resulting v=0), then solving the resulting ordinary
;     polynomial equation with the same logic above. A fractional
;     exponent (e.g. "x^(1/2)=4") is still unsupported.
;
; Ported from ../solvePoly.scm (MIT Scheme) to Chez Scheme. Changes: the
; one `(error "msg")` call site gets an explicit #f who-arg.
;
; Output format was matched against the C++ engine's `solve` command
; case by case. Two notable divergences, both deliberate:
;   - The C++ engine has a real bug: for an irrational quadratic root
;     (discriminant positive but not a perfect square), it returns the
;     repeated-root answer -b/2a twice instead of -b/2a ± sqrt(disc)/2a
;     (verified e.g. on x^2+4x-4=0, which should be -2±2√2). This file
;     does NOT replicate that bug -- it returns the correct roots.
;   - The C++ engine also has a real bug with cubics/quartics: passing
;     a degree>=3 equation to its quadratic-only solve path produces
;     nonsense complex output instead of using rational-root division
;     (verified on x^3-6x^2+11x-6=0, which should solve to x=1,2,3).
;     This file's degree>=3 handling is unaffected by that bug.

; Finds the (0-based) index of the first occurrence of ch in charL, or
; #f if absent. Used to split an equation string on '=' before any
; tokenization happens, since '=' isn't part of expandParse's grammar.
(define (findCharPos ch charL idx)
    (cond
        ((null? charL) #f)
        ((eqv? (car charL) ch) idx)
        ('t (findCharPos ch (cdr charL) (+ idx 1)))))

; Parses "LHS = RHS" into (cons numerTermList denomTermListOrFalse):
; numerTermList is "(LHS)-(RHS)"'s numerator (combined/reduced, "... =
; 0" form); denomTermListOrFalse is #f for an ordinary polynomial
; equation (no variable denominator anywhere -- the overwhelmingly
; common case), or the denominator's own term list when LHS-RHS is a
; genuine rational expression (a variable in a denominator, e.g. "3/x=6"
; or physics module Phase 2's original "a=v^2/r" before that was
; rewritten to avoid needing this at all). solve() uses numerTermList
; for all its usual degree/root-finding logic (a fraction equals zero
; iff its numerator does) and denomList, when present, to filter out any
; "solution" that's actually extraneous -- a root of the numerator that
; ALSO zeroes the denominator, meaning the original equation is
; undefined there, not satisfied (e.g. "(x-3)/(x-3)=0" must not report
; x=3).
;
; Combines both sides into ONE expression "(LHS)-(RHS)" and classifies
; THAT via classifyFrac (expandParse.scm) -- the same function factor()'s
; own rational-expression path already uses -- rather than the old
; approach of expandSum-ing each side separately, which couldn't
; represent a fraction at all and unconditionally errored the moment
; either side had a variable denominator ("division by a non-constant
; isn't supported here"). Found genuinely reachable live via circular
; motion's a=v^2/r equation (physics module Phase 2): solving for r
; previously errored even though the equation is perfectly solvable.
;
; dropZeros/combineLikeTerms still matter here, not just for tidiness:
; without them, a term whose coefficient cancels to exactly 0 (e.g. the
; x-term in "2x-2=2x+3") could still sit in the returned list, and
; polyDegree (factorPoly.scm) reports the MAX exponent present
; regardless of whether that term's coefficient is zero -- so solve()
; would route a genuinely degree-0 equation into solveLinear, which then
; divides by that zero coefficient and crashes ("Exception in /:
; undefined for 0") instead of solveDegree0 correctly reporting "No
; solution" (found via this session's Excel test-workbook generation,
; which happened to include that exact degenerate case). classifyFrac's
; own expandSumFrac already combines like terms during expansion, but
; the extra pass here is cheap, safe (idempotent), and keeps this
; function's own output guarantee explicit rather than relying on an
; upstream implementation detail.
(define (parseEquationToZero charL)
    (let ((eqPos (findCharPos #\= charL 0)))
        (if (not eqPos)
            (error #f "solve: expected an equation containing '='")
            (let* ((lhsChars (if (> eqPos 0) (extract 0 (- eqPos 1) charL) '()))
                   (rhsChars (if (< (+ eqPos 1) (length charL)) (extract (+ eqPos 1) (- (length charL) 1) charL) '()))
                   (combinedChars (string->list (string-append "(" (list->string lhsChars) ")-(" (list->string rhsChars) ")")))
                   (classified (classifyFrac (parseExpansion combinedChars))))
                (cond
                    ((eqv? (car classified) 'matrix)
                        (error #f "solve: matrix input isn't supported here -- use expand() for matrix expressions"))
                    ((eqv? (car classified) 'whole)
                        (cons (dropZeros (combineLikeTerms (cdr classified))) #f))
                    ('t (cons (dropZeros (combineLikeTerms (car (cdr classified)))) (cdr (cdr classified)))))))))

; Extracts the numeric value from a solve()-style "v = value" string as
; an exact rational, or #f if it isn't one (an irrational "√2" or
; complex "p+qi" result).
(define (trySolveResultRational s)
    (let* ((eqIdx (findStringCharPos #\= s 0))
           (valStr (stripSpaces (substring s (+ eqIdx 1) (string-length s)))))
        (guard (c (#t #f))
            (let ((v (parseFractionOrDecimal valStr)))
                (if (and (number? v) (rational? v) (exact? v)) v #f)))))

; Drops any solve() result string whose value is an exact rational that
; would make denomList's own polynomial evaluate to zero -- see
; parseEquationToZero's own comment for why this matters. Irrational/
; complex results are left unfiltered -- precisely checking those
; against denomList would need exact irrational/complex arithmetic this
; doesn't have; the common case (a rational extraneous root) is what
; this guards against. Falls back to "No solution" (matching
; solveDegree0's own convention, factorPoly.scm) rather than an empty
; list if filtering removes every candidate.
(define (filterExtraneousRoots results denomList)
    (let ((kept (filter (lambda (r)
                             (let ((val (trySolveResultRational r)))
                                 (or (not val) (not (= (evalPolyAt denomList val) 0)))))
                         results)))
        (if (null? kept) (list "No solution") kept)))

; Formats an exact rational as "p" or "p/q" (q always positive, since
; Scheme keeps exact rationals in lowest terms with positive denominator).
(define (ratToString r)
    (if (= (denominator r) 1)
        (number->string (numerator r))
        (string-append (number->string (numerator r)) "/" (number->string (denominator r)))))

; Largest exact integer r such that r*r <= n (n >= 0). Computed via
; Newton's method (quadratically convergent, O(log n) iterations) --
; NOT a naive "increment by 1 from 0" search, which is O(sqrt(n)) and
; becomes computationally infeasible once n has 20+ digits (found live
; via Phase 7/Gravitation's astronomical-scale inputs -- see
; extractSquareFactor's own header for the fuller story). Avoids
; floating point entirely so any caller's divisibility test on the
; result stays exact.
(define (introot-floor n)
    (if (= n 0)
        0
        (let loop ((x n))
            (let ((y (quotient (+ x (quotient n x)) 2)))
                (if (< y x) (loop y) x)))))

; Bound on the trial-division candidates extractSquareFactor tries --
; large enough that every square factor in any classroom-scale or
; realistic real-world physics discriminant gets found (at most ~10^6
; iterations, well under a second), small enough to stay fast even when
; the input has no square factor at all (the search still runs to
; completion in that case).
(define extractSquareFactorBound 1000000)

; Returns (coeff . radicand) such that coeff^2 * radicand = n -- i.e.
; simplifies sqrt(n) to coeff*sqrt(radicand). Trial-divides candidate
; factors p=2,3,4,... upward, at each p dividing out as many pairs of p
; as divide evenly, until p*p exceeds either the bound or whatever's
; left of n.
;
; Older implementation (Phase 1-6 era) searched candidate COEFFICIENTS
; downward from floor(sqrt(n)) looking for the first one whose square
; divides n -- correct, but O(sqrt(n)) in the worst case (a square-free
; or nearly-square-free n), which is exactly what a real discriminant
; built from astronomical-scale physics inputs turns out to be: found
; live via Phase 7's orbitalvelocity/escapevelocity (gravitation.scm) --
; "g_c=6.674e-11N*m^2/kg^2 n=5.97e24kg r=6.771e6m" produces a ~10^22
; discriminant, and the old algorithm hung (confirmed live: it still
; hung even after speeding up introot-floor alone, since the outer
; downward scan -- not its starting point -- was the actual bottleneck).
;
; This trial-division approach is fast (bounded by
; extractSquareFactorBound candidates, not by n's own magnitude) and
; produces IDENTICAL output to the old algorithm for every existing
; test case in this codebase (every one is well under the bound --
; verified via the full regression suite). It intentionally does not
; guarantee a fully square-free radicand in the pathological case of a
; genuine square factor whose root exceeds the bound (e.g. two
; equal-or-near-equal prime factors both over 10^6) -- mathematically
; equivalent to factoring a large semiprime, computationally infeasible
; in general, and not a shape that occurs in any classroom or realistic
; physics input this engine targets. The result is always still a VALID
; (if theoretically under-simplified in that edge case) representation
; of sqrt(n), never an incorrect one.
(define (extractSquareFactor n)
    (let loop ((remaining n) (p 2) (coeff 1))
        (cond
            ((or (> p extractSquareFactorBound) (> (* p p) remaining)) (cons coeff remaining))
            ((= 0 (remainder remaining (* p p))) (loop (/ remaining (* p p)) p (* coeff p)))
            ('t (loop remaining (+ p 1) coeff)))))

; Formats "x = realPart ± coeff*symbolStr", omitting realPart entirely
; if it's 0 (so "2i" not "0 + 2i") and omitting an explicit "1"
; coefficient UNLESS symbolStr is exactly "i" (matching the C++
; engine's own inconsistent-but-replicated convention: coefficient 1
; is omitted before a radical, e.g. "√2", but kept before i, e.g. "1i").
(define (formatSignedTerm realPart coeff symbolStr)
    (let* ((mag (abs coeff))
           (omitOne (and (= mag 1) (not (string=? symbolStr "i"))))
           (magStr (if omitOne "" (ratToString mag)))
           (term (string-append magStr symbolStr)))
        (cond
            ((= realPart 0) (if (< coeff 0) (string-append "-" term) term))
            ('t (string-append (ratToString realPart) (if (< coeff 0) " - " " + ") term)))))

; Same as formatSignedTerm, but coeff is an inexact (floating-point)
; magnitude, rounded to 5 decimal places -- used for the complex-root
; decimal fallback when the discriminant's magnitude isn't a perfect
; square (see solveQuadraticComplex).
(define (decimalToString x)
    (number->string (/ (round (* x 100000)) 100000.0)))

(define (formatSignedTermDecimal realPart coeff symbolStr)
    (let* ((mag (abs coeff))
           (term (string-append (decimalToString mag) symbolStr)))
        (cond
            ((= realPart 0) (if (< coeff 0) (string-append "-" term) term))
            ('t (string-append (ratToString realPart) (if (< coeff 0) " - " " + ") term)))))

(define (solveDegree0 termList)
    (if (= (coeffAt termList 0) 0)
        (list "All real numbers are solutions")
        (list "No solution")))

; varPrefix builds "v = " from the equation's actual variable symbol
; (found via factorPoly.scm's polyVariable), rather than hardcoding
; "x = " -- a real bug fixed after the worksheet generator's use of
; varied variable names (e.g. solving "2y+3=7" must print "y = 2", not
; "x = 2"; verified this matches the C++ engine's own behavior).
(define (varPrefix v) (string-append (symbol->string v) " = "))

(define (solveLinear termList v)
    (let* ((a (coeffAt termList 1)) (b (coeffAt termList 0))
           (root (/ (- b) a)))
        (list (string-append (varPrefix v) (ratToString root)))))

; Discriminant is a non-negative perfect square: roots are rational.
(define (solveQuadraticRational v negB sq twoA)
    (list (string-append (varPrefix v) (ratToString (/ (+ negB sq) twoA)))
          (string-append (varPrefix v) (ratToString (/ (- negB sq) twoA)))))

; Discriminant is positive but not a perfect square: roots are
; irrational, printed symbolically with the radical simplified.
(define (solveQuadraticIrrational v negB disc twoA)
    (let* ((ext (extractSquareFactor disc))
           (radCoeff (car ext))
           (radicand (cdr ext))
           (realPart (/ negB twoA))
           (coeff1 (/ radCoeff twoA))
           (symbolStr (string-append "√" (number->string radicand))))
        (list (string-append (varPrefix v) (formatSignedTerm realPart coeff1 symbolStr))
              (string-append (varPrefix v) (formatSignedTerm realPart (- coeff1) symbolStr)))))

; Discriminant is negative: roots are complex. If |discriminant| is a
; perfect square the imaginary part is rational and prints
; symbolically; otherwise falls back to a decimal approximation
; (matching the C++ engine's own convention for this sub-case).
(define (solveQuadraticComplex v negB absDisc twoA)
    (let* ((sq (integerSqrt absDisc))
           (realPart (/ negB twoA)))
        (if sq
            (let ((coeff1 (/ sq twoA)))
                (list (string-append (varPrefix v) (formatSignedTerm realPart coeff1 "i"))
                      (string-append (varPrefix v) (formatSignedTerm realPart (- coeff1) "i"))))
            (let ((magnitude (/ (sqrt (exact->inexact absDisc)) (abs twoA))))
                (list (string-append (varPrefix v) (formatSignedTermDecimal realPart magnitude "i"))
                      (string-append (varPrefix v) (formatSignedTermDecimal realPart (- magnitude) "i")))))))

(define (solveQuadraticFull termList v)
    (let* ((a (coeffAt termList 2))
           (b (coeffAt termList 1))
           (c (coeffAt termList 0))
           (disc (- (* b b) (* 4 a c)))
           (twoA (* 2 a))
           (negB (- b)))
        (if (>= disc 0)
            (let ((sq (integerSqrt disc)))
                (if sq
                    (solveQuadraticRational v negB sq twoA)
                    (solveQuadraticIrrational v negB disc twoA)))
            (solveQuadraticComplex v negB (- disc) twoA))))

; Degree >= 3: repeatedly factor out one rational root (reusing
; factorPoly.scm's machinery) until degree drops to <= 2, then finish
; with the linear/quadratic solver. Stops and reports the remainder as
; unsolved if no further rational root exists while degree is still
; >= 3 (no general cubic/quartic radical formula is implemented).
;
; Guarded against a fractional coefficient (assertIntegerCoefficients)
; since findRationalRoot/divideByLinearFactor are integer-only, same
; reasoning as factor()'s own guard -- only checked once at entry, not
; per loop iteration, since divideByLinearFactor's synthetic division is
; only exact (Gauss's lemma) when the input is already integer-
; coefficient, so every subsequent quotient stays integer-coefficient too.
(define (solveHigherDegree termList v)
    (assertIntegerCoefficients termList "solve")
    (let loop ((current termList) (roots '()))
        (let ((deg (polyDegree current)))
            (cond
                ((<= deg 1)
                    (append roots (if (= deg 1) (solveLinear current v) (solveDegree0 current))))
                ((= deg 2)
                    (append roots (solveQuadraticFull current v)))
                ('t
                    (let ((root (findRationalRoot current)))
                        (if (not root)
                            (append roots (list (string-append "(no further rational roots found for: " (termsToString current) ")")))
                            (let* ((p (numerator root)) (q (denominator root))
                                   (quotient (divideByLinearFactor current p q)))
                                (loop quotient (append roots (list (string-append (varPrefix v) (ratToString root)))))))))))))

; Removes duplicate solution strings (exact match), preserving order of
; first occurrence -- a degree>=3 equation with a repeated root (e.g.
; "x^3+3x^2-4=0", which factors to (x-1)(x+2)(x+2)) would otherwise
; list that root once per linear factor it came from (e.g. "x=-2"
; twice). Matches the equivalent fix in the C++ engine's solve(),
; applied for the same reason: a root's multiplicity is a property of
; the factored form, not a second distinct solution to report.
(define (dedupSolutions solutions)
    (let loop ((remaining solutions) (seen '()) (acc '()))
        (cond
            ((null? remaining) (reverse acc))
            ((member (car remaining) seen) (loop (cdr remaining) seen acc))
            ('t (loop (cdr remaining) (cons (car remaining) seen) (cons (car remaining) acc))))))

; Top-level entry point: solves a single-variable equation (e.g.
; "x^2-5x+6=0"), returning a list of "v = ..." solution strings, where
; v is whichever variable the equation actually uses. denomList (from
; parseEquationToZero, #f for an ordinary polynomial equation) is
; folded into the SAME single-variable check as combined -- a
; denominator referencing a second variable (e.g. "x/y=0") is exactly
; as unsupported here as it would be if that second variable showed up
; in the numerator, and must be rejected the same way rather than
; slipping through because assertSingleVariable only ever looked at
; combined on its own.
(define (solveSingleVar charL)
    (let* ((parsed (parseEquationToZero charL))
           (rawCombined (car parsed))
           (denomList (cdr parsed))
           (checked (assertSingleVariable (if denomList (append rawCombined denomList) rawCombined) "solve"))
           ; A genuinely fractional exponent (e.g. "x^(1/2)") is still
           ; unsupported; a negative-but-integer one (e.g. "x^-2") isn't
           ; rejected here any more -- clearNegativeExponent below turns it
           ; into an ordinary polynomial before polyDegree/coeffAt ever see
           ; it (both look for an EXACT integer degree match, so a
           ; negative-exponent term would otherwise silently be dropped
           ; from consideration rather than erroring or solving correctly).
           (checked2 (assertNoFractionalExponent rawCombined "solve"))
           (v (or (polyVariable rawCombined) 'x))
           (combined (clearNegativeExponent rawCombined v))
           (deg (polyDegree combined))
           (rawResults (dedupSolutions
                           (cond
                               ((= deg 0) (solveDegree0 combined))
                               ((= deg 1) (solveLinear combined v))
                               ((= deg 2) (solveQuadraticFull combined v))
                               ('t (solveHigherDegree combined v))))))
        (if denomList (filterExtraneousRoots rawResults denomList) rawResults)))

; ---- solve for a named variable in a genuinely multivariable equation
;      (e.g. "@:solve x" on "ax+b=c" -> "x = (c-b)/a") ----
;
; solveSingleVar above (and every existing caller of the original
; single-arg solve()) is untouched -- this is purely additive, reached
; only via the new 2-arg (solve charL targetVar) case below, and only
; when the equation genuinely uses more than one variable.
;
; Scope: v must appear with exponent EXACTLY 1 in every term it's part
; of -- an ordinary "isolate the linear term" solve, generalized to let
; every OTHER variable stay symbolic instead of demanding it be a plain
; number the way physicsSolve.scm's substitute-then-solve strategy does.
; v at degree >= 2 (a symbolic quadratic formula) is out of scope, same
; linear-only boundary equationVariants.scm's solveInequality already
; draws for the analogous reason -- reported as a clear error rather
; than attempted.
;
; Reuses factorPoly.scm's expOf/shiftTermVar (already exactly "this
; term's exponent for v" / "rebuild this term with v's exponent shifted
; by n, dropping v entirely at exponent 0, promoting a new primary
; variable from extraVars if needed") and expandParse.scm's
; renderFracCell (already exactly "print this numer/denom term-list pair
; as a fraction, or fold it to a plain polynomial string when the
; denominator turns out constant") -- both already multivariable-aware,
; built for expand()/factor()'s own rational-expression paths.
(define (solveLinearMultivar rawCombined v)
    (let loop ((terms rawCombined) (coeffTerms '()) (constTerms '()))
        (if (null? terms)
            (let ((coeffTerms (dropZeros (combineLikeTerms coeffTerms)))
                  (negConst (map negateTerm (dropZeros (combineLikeTerms constTerms)))))
                (if (null? coeffTerms)
                    (error #f (string-append "solve: " (symbol->string v) " does not appear in this equation"))
                    (list (string-append (varPrefix v) (renderFracCell (cons negConst coeffTerms))))))
            (let* ((term (car terms)) (e (expOf term v)))
                (cond
                    ((= e 0) (loop (cdr terms) coeffTerms (cons term constTerms)))
                    ((= e 1) (loop (cdr terms) (cons (shiftTermVar term v -1) coeffTerms) constTerms))
                    ('t (error #f (string-append "solve: " (symbol->string v) " appears with exponent " (ratToString e)
                            " here -- only linear-in-" (symbol->string v) " multivariable solving is supported"))))))))

; Public entry point. (solve charL) is exactly solveSingleVar, unchanged
; for every existing caller. (solve charL targetVar) additionally
; supports a genuinely multivariable equation, so long as targetVar
; itself only ever appears linearly -- see solveLinearMultivar above. A
; single-variable equation (or one where targetVar is the ONLY variable
; present) still gets the full solveSingleVar treatment (quadratic/
; higher-degree included), not just the linear path -- this only takes
; over once a second variable is genuinely present.
(define solve
    (case-lambda
        ((charL) (solveSingleVar charL))
        ((charL targetVar)
            (let* ((parsed (parseEquationToZero charL))
                   (rawCombined (car parsed))
                   (denomList (cdr parsed))
                   (vars (allVariablesIn (if denomList (append rawCombined denomList) rawCombined))))
                (cond
                    ((null? vars) (solveSingleVar charL))
                    ((and (= (length vars) 1) (eq? (car vars) targetVar)) (solveSingleVar charL))
                    ((not (memq targetVar vars))
                        (error #f (string-append "solve: " (symbol->string targetVar) " does not appear in this equation")))
                    (denomList
                        (error #f "solve: multivariable solving with a variable denominator isn't supported yet"))
                    ('t (solveLinearMultivar rawCombined targetVar)))))))

; ---- solveWithSteps: STEPS-FEATURE-PLAN.md's step-logging sibling ----
;
; Unlike diffExprWithSteps (diffExpr.scm), which rebuilds the SAME tree
; structure diffExprRaw does so the invariant holds by construction,
; solve()'s own top-level dedupSolutions/filterExtraneousRoots make that
; approach awkward here (a peeled-root sequence's later duplicate-
; removal, or a denominator-based extraneous-root filter, can change
; which strings survive into the final joined answer in a way that
; doesn't cleanly decompose per branch). Instead: call the EXISTING
; solve() directly for the guaranteed-correct final joined string (so
; the invariant holds trivially, by construction, no matter how
; dedup/filtering behaves), and separately build a narration-only
; step trace using the SAME already-computed quantities (discriminant,
; extractSquareFactor's radical simplification, each rational-root-
; division loop iteration) that solveLinear/solveQuadraticFull/
; solveHigherDegree themselves compute. If that narration trace's own
; last step already happens to equal the real final string (the common
; case), it's used as-is; otherwise one tidy "solve for v" step with the
; true final string is appended, so the invariant always holds.

; Small join-strings copy, same as chain.scm's/dispatcher.scm's own
; (neither is loaded by load-engine.scm, which this file is loaded
; under for tests) -- joins with sep, no trailing sep.
(define (joinSolveStrings strs sep)
    (cond
        ((null? strs) "")
        ((null? (cdr strs)) (car strs))
        ('t (string-append (car strs) sep (joinSolveStrings (cdr strs) sep)))))

(define (solveLinearSteps termList v)
    (let* ((a (coeffAt termList 1)) (b (coeffAt termList 0)))
        (list (makeStep 'isolate-variable
            (string-append "Solve " (termsToString termList) " = 0 for " (symbol->string v)
                " by isolating it: " (symbol->string v) " = " (ratToString (- b)) "/" (ratToString a))
            (joinSolveStrings (solveLinear termList v) ", ")))))

(define (solveQuadraticSteps termList v)
    (let* ((a (coeffAt termList 2)) (b (coeffAt termList 1)) (c (coeffAt termList 0))
           (disc (- (* b b) (* 4 a c)))
           (twoA (* 2 a))
           (negB (- b))
           (discStep (makeStep 'quadratic-formula
                         (string-append "Apply the quadratic formula to " (termsToString termList)
                             " = 0 (a=" (ratToString a) ", b=" (ratToString b) ", c=" (ratToString c)
                             "): the discriminant is b^2-4ac = " (number->string disc))
                         (number->string disc))))
        (list discStep
            (cond
                ((>= disc 0)
                    (let ((sq (integerSqrt disc)))
                        (if sq
                            (makeStep 'quadratic-formula
                                (string-append "The discriminant " (number->string disc)
                                    " is a perfect square (√" (number->string disc) " = " (ratToString sq)
                                    "), so the roots are rational")
                                (joinSolveStrings (solveQuadraticRational v negB sq twoA) ", "))
                            (let* ((ext (extractSquareFactor disc)))
                                (makeStep 'simplify-radical
                                    (string-append "The discriminant " (number->string disc)
                                        " isn't a perfect square; simplify √" (number->string disc) " to "
                                        (ratToString (car ext)) "√" (number->string (cdr ext)))
                                    (joinSolveStrings (solveQuadraticIrrational v negB disc twoA) ", "))))))
                ('t
                    (makeStep 'quadratic-formula
                        (string-append "The discriminant " (number->string disc) " is negative, so the roots are complex")
                        (joinSolveStrings (solveQuadraticComplex v negB (- disc) twoA) ", ")))))))

(define (solveHigherDegreeSteps termList v)
    (assertIntegerCoefficients termList "solve")
    (let loop ((current termList) (steps '()))
        (let ((deg (polyDegree current)))
            (cond
                ((<= deg 1) (append steps (if (= deg 1) (solveLinearSteps current v) '())))
                ((= deg 2) (append steps (solveQuadraticSteps current v)))
                ('t
                    (let ((root (findRationalRoot current)))
                        (if (not root)
                            (append steps (list (makeStep 'rational-root-divide
                                (string-append "No further rational root exists for " (termsToString current) " = 0")
                                (string-append "(no further rational roots found for: " (termsToString current) ")"))))
                            (let* ((p (numerator root)) (q (denominator root))
                                   (quotient (divideByLinearFactor current p q)))
                                (loop quotient
                                    (append steps (list (makeStep 'rational-root-divide
                                        (string-append "By the rational root theorem, " (varPrefix v) (ratToString root)
                                            " is a root of " (termsToString current) " = 0; dividing out ("
                                            (symbol->string v) " - " (ratToString root) ") leaves "
                                            (termsToString quotient) " = 0")
                                        (string-append (varPrefix v) (ratToString root))))))))))))))

; Public entry point. Always returns a nonempty list of <step>; the
; last step's expr always equals (join-strings (solve charL) ", ").
(define (solveWithSteps charL)
    (let* ((parsed (parseEquationToZero charL))
           (rawCombined (car parsed))
           (denomList (cdr parsed))
           (checked (assertSingleVariable (if denomList (append rawCombined denomList) rawCombined) "solve"))
           (checked2 (assertNoFractionalExponent rawCombined "solve"))
           (v (or (polyVariable rawCombined) 'x))
           (combined (clearNegativeExponent rawCombined v))
           (deg (polyDegree combined))
           (reasoningSteps
               (cond
                   ((= deg 0) '())
                   ((= deg 1) (solveLinearSteps combined v))
                   ((= deg 2) (solveQuadraticSteps combined v))
                   ('t (solveHigherDegreeSteps combined v))))
           (finalStr (joinSolveStrings (solve charL) ", ")))
        (if (or (null? reasoningSteps) (not (string=? (stepExpr (last reasoningSteps)) finalStr)))
            (append reasoningSteps (list (makeStep 'isolate-variable
                (string-append "Solve for " (symbol->string v)) finalStr)))
            reasoningSteps)))
