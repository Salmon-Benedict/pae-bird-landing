; steps.scm -- shared step representation for "show your work" (.STEPS)
; functions. See ../STEPS-FEATURE-PLAN.md for the full spec this
; implements. Defines ONLY the <step> record type (no other
; dependencies), so it can load early, right after helperS.scm, and be
; available to every later file. The actual *WithSteps functions
; (diffExprWithSteps, solveWithSteps, expandWithSteps) live in each
; operation's own existing file (diffExpr.scm, solvePoly.scm,
; expandParse.scm respectively) instead of being centralized here,
; since each needs machinery (exprAst's constructors, the poly engine,
; etc.) that loads much later than this file does.
;
; - rule: a stable symbol (e.g. 'power-rule, 'chain-rule,
;   'product-rule) -- what golden-table tests assert on and what a
;   future task-pane icon/formatting choice keys off. NOT free text.
; - narration: the human-readable sentence. Free text, can be edited
;   without breaking tests.
; - expr: the expression's string form AFTER this step.
(define-record-type (<step> makeStep step?)
    (fields
        (immutable rule stepRule)
        (immutable narration stepNarration)
        (immutable expr stepExpr)))
