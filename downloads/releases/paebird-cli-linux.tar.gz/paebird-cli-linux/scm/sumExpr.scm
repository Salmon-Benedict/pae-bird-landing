; sumExpr.scm -- calculus2.md's Phase 4 Foundation gap, finite-sum slice:
; evaluates sum(term,indexVar,lower,upper) nodes (exprAst.scm/exprParse.scm
; parse the "sum(n^2,n,1,10)" surface syntax into these; see exprAst.scm's
; own header for the node shape). Infinite series/sequence convergence is
; explicitly NOT this file's job -- calculus2.md frames that as a much
; bigger, separate piece of the same Foundation gap; this is just "add up
; finitely many terms of a literal-integer range."
;
; Depends on: exprAst.scm, exprParse.scm, diffExpr.scm (exprContainsVar?,
; exprFreeVariables), limitExpr.scm (evalExprAt, evalKnownFunc). Load
; after all four (this file only ever consumes them, never the reverse --
; see limitExpr.scm's own evalExprAt sum-arm comment for why that
; direction matters).
;
; ---- Scope ----
; - Bounds (lower/upper) may be any CONSTANT expression (exprFreeVariables
;   empty), not just a bare literal -- "sum(n,n,1,2+3)" is fine -- but must
;   evaluate to an exact integer. A symbolic bound ("sum(n,n,1,N)") is out
;   of scope, same as calculus2.md's own framing of power series/general
;   series as separate, bigger work.
; - term may depend ONLY on indexVar -- this engine's established
;   one-active-variable-at-a-time convention (same as dcalc/icalc/eval).
;   "sum(x*n,n,1,5)" errors clearly rather than guessing what x means or
;   silently substituting the wrong thing (evalExprAt's own var/point
;   substitution is blind to variable NAME -- see its own header -- so
;   this check is load-bearing, not just a nice error message).
; - lower > upper is the standard empty-sum convention (0), not an error.
;
; ---- Evaluation strategy ----
; A curated closed-form table (sumClosedForm below: constant, linear,
; quadratic, cubic, and geometric term shapes, extended through addition/
; subtraction/negation/constant-multiple by ordinary linearity of
; summation) is tried FIRST -- exact, O(1) regardless of range size, and
; what makes something like sum(n,n,1,10000000) return instantly instead
; of looping ten million times. Anything the table doesn't recognize
; (e.g. sum(sin(n),n,1,1000)) falls back to direct term-by-term summation
; (sumDirectEvaluate), which works for ANY term evalExprAt can evaluate
; but costs one evalExprAt call per integer in [lower,upper].
;
; ---- Long-running direct sums: progress + interrupt ----
; sumDirectEvaluate tracks real elapsed time (Chez's own real-time, ms
; since process start) and, once a sum has been computing for more than
; sumProgressIntervalMs (10s), starts printing a "computing..." progress
; line (throttled to once per additional interval, not every iteration)
; and polling stdin (char-ready?, non-blocking) for the literal line
; "sumc" as a break command. This only ever does anything useful in an
; actual interactive session (the chez-docker REPL bridge, not this
; engine's batch dispatcher protocol) -- in batch mode nothing is typing
; into the process's stdin, so char-ready? is simply always #f there and
; this degrades to a no-op; the progress lines still print to stdout,
; which the batch protocol never reads (dispatcher.scm's own "process"
; command writes its answer to an explicit output FILE via
; call-with-output-file, not stdout -- see its own header), so this can't
; corrupt the batch output either way.

(define sumBreakCommand "sumc")
(define sumProgressIntervalMs 10000)

; ---- Bound evaluation ----
; e must have no free variables at all (checked explicitly, rather than
; just trusting evalExprAt not to hit an evar node, so a mistake like
; "sum(n,n,1,x)" gets THIS file's own clear message instead of a
; confusing one from deep inside evalExprAt). The (var . point) pair
; handed to evalExprAt is never actually touched -- there is provably no
; evar node left in e once the free-variable check passes -- so 'n/0 is
; just an arbitrary placeholder, not a real substitution.
(define (evalSumBound e whichBound)
    (if (not (null? (exprFreeVariables e)))
        (error #f (string-append "sum: " whichBound " bound must be a constant expression, not one containing a free variable") (exprToString e))
        (let ((v (evalExprAt e 'n 0)))
            (cond
                ((eqv? v 'undefined) (error #f (string-append "sum: " whichBound " bound is undefined") (exprToString e)))
                ((not (integer? v)) (error #f (string-append "sum: " whichBound " bound must be an exact integer") v))
                ('t v)))))

; ---- Closed-form recognition ----
; triangular(k) = 1+2+...+k = k(k+1)/2 -- and sumSquares/sumCubes below --
; are all defined for ANY integer k, negative included (the ordinary
; algebraic continuation of each formula), specifically so a general
; [lower,upper] range (lower possibly negative or 0) can be handled via
; rangeSumViaAntidifference's F(upper)-F(lower-1) without a separate
; case for "does the range start below 1".
(define (triangular k) (/ (* k (+ k 1)) 2))
(define (sumSquares k) (/ (* k (+ k 1) (+ (* 2 k) 1)) 6))
(define (sumCubes k) (let ((t (triangular k))) (* t t)))

(define (rangeSumViaAntidifference F lower upper)
    (- (F upper) (F (- lower 1))))

; #f if e's shape (as a function of indexVar) isn't one this table
; recognizes; otherwise the exact value of sum_{indexVar=lower}^{upper} e.
; lower/upper are already-evaluated exact integers (evalSumBound's job,
; done once by the caller before this is ever invoked) with lower<=upper
; (the empty-sum case is also handled once by the caller).
(define (sumClosedForm e indexVar lower upper)
    (cond
        ; Constant w.r.t. indexVar (doesn't contain it at all) -- every
        ; term in the range is the same value.
        ((not (exprContainsVar? e indexVar)) (* (evalExprAt e indexVar lower) (+ 1 (- upper lower))))
        ; Bare index variable: sum n.
        ((and (exprEvar? e) (eqv? (exprEvarName e) indexVar)) (rangeSumViaAntidifference triangular lower upper))
        ; n^2 / n^3 (literal integer exponent on the bare index variable).
        ((and (exprPow? e) (exprEvar? (exprPowBase e)) (eqv? (exprEvarName (exprPowBase e)) indexVar)
              (exprNum? (exprPowExponent e)) (integer? (exprNumValue (exprPowExponent e))))
            (case (exprNumValue (exprPowExponent e))
                ((2) (rangeSumViaAntidifference sumSquares lower upper))
                ((3) (rangeSumViaAntidifference sumCubes lower upper))
                (else #f)))
        ; Geometric: r^n, r a nonzero constant (w.r.t. indexVar) base,
        ; bare indexVar exponent. Standard closed form, r != 1 case;
        ; r=0/r=1 handled as their own trivial sums.
        ((and (exprPow? e) (not (exprContainsVar? (exprPowBase e) indexVar))
              (exprEvar? (exprPowExponent e)) (eqv? (exprEvarName (exprPowExponent e)) indexVar))
            (let ((r (evalExprAt (exprPowBase e) indexVar lower)))
                (cond
                    ((eqv? r 'undefined) #f)
                    ((= r 0) 0)
                    ((= r 1) (+ 1 (- upper lower)))
                    ('t (* (expt r lower) (/ (- (expt r (+ 1 (- upper lower))) 1) (- r 1)))))))
        ; Linearity: constant multiple (c*f(n) or f(n)*c).
        ((and (exprMul? e) (not (exprContainsVar? (exprMulLeft e) indexVar)))
            (let ((inner (sumClosedForm (exprMulRight e) indexVar lower upper)))
                (and inner (* (evalExprAt (exprMulLeft e) indexVar lower) inner))))
        ((and (exprMul? e) (not (exprContainsVar? (exprMulRight e) indexVar)))
            (let ((inner (sumClosedForm (exprMulLeft e) indexVar lower upper)))
                (and inner (* inner (evalExprAt (exprMulRight e) indexVar lower)))))
        ; Linearity: sum/difference/negation, term by term.
        ((exprAdd? e)
            (let ((l (sumClosedForm (exprAddLeft e) indexVar lower upper))
                  (r (sumClosedForm (exprAddRight e) indexVar lower upper)))
                (and l r (+ l r))))
        ((exprSub? e)
            (let ((l (sumClosedForm (exprSubLeft e) indexVar lower upper))
                  (r (sumClosedForm (exprSubRight e) indexVar lower upper)))
                (and l r (- l r))))
        ((exprNeg? e)
            (let ((inner (sumClosedForm (exprNegOperand e) indexVar lower upper)))
                (and inner (- inner))))
        ('t #f)))

; ---- Direct term-by-term fallback, with progress/interrupt ----

; Strips a trailing \r (a line typed in a CRLF terminal) so "sumc"
; entered interactively still matches on Windows-flavored line endings;
; deliberately not a general trim (this codebase's own trim helpers live
; in dispatcher.scm/chain.scm, both loaded in a different position than
; this file -- see this file's own header on load order).
(define (stripTrailingCR s)
    (if (and (> (string-length s) 0) (eqv? (string-ref s (- (string-length s) 1)) #\return))
        (substring s 0 (- (string-length s) 1))
        s))

; Non-blocking: #t only if a full line is already waiting on stdin AND it
; reads back as exactly sumBreakCommand. See this file's header note on
; why this is a no-op (never #t) under the batch dispatcher protocol.
(define (sumBreakRequested?)
    (and (char-ready? (current-input-port))
         (let ((line (get-line (current-input-port))))
             (and (string? line) (string=? (stripTrailingCR line) sumBreakCommand)))))

(define (sumDirectEvaluate term indexVar lower upper)
    (let ((startTime (real-time)) (total (+ 1 (- upper lower))))
        (let loop ((k lower) (acc 0) (count 0) (lastReport startTime))
            (if (> k upper)
                acc
                (let ((v (evalExprAt term indexVar k)))
                    (if (eqv? v 'undefined)
                        (error #f "sum: term is undefined at n =" k)
                        (let* ((now (real-time)) (elapsed (- now startTime)))
                            (if (and (>= elapsed sumProgressIntervalMs) (>= (- now lastReport) sumProgressIntervalMs))
                                (begin
                                    (display (string-append "computing... (" (number->string count) "/" (number->string total)
                                                  " terms so far) -- type " sumBreakCommand " then Enter to break"))
                                    (newline)
                                    (flush-output-port (current-output-port))
                                    (if (sumBreakRequested?)
                                        (error #f "sum: interrupted by user")
                                        (loop (+ k 1) (+ acc v) (+ count 1) now)))
                                (loop (+ k 1) (+ acc v) (+ count 1) lastReport)))))))))

; ---- Public entry point for a single sum node ----
(define (evalSumNode e)
    (let* ((indexVar (exprSumIndexVar e))
           (term (exprSumTerm e))
           (lower (evalSumBound (exprSumLower e) "lower"))
           (upper (evalSumBound (exprSumUpper e) "upper")))
        (if (not (for-all (lambda (v) (eqv? v indexVar)) (exprFreeVariables term)))
            (error #f "sum: term must depend only on the index variable" (exprToString term))
            (if (> lower upper)
                0
                (or (sumClosedForm term indexVar lower upper)
                    (sumDirectEvaluate term indexVar lower upper))))))

; ---- Whole-expression constant evaluator (the "sumcalc" dispatcher
;      command's own engine) ----
;
; Mirrors evalExprAt's structural recursion, but (a) adds the sum case
; evalExprAt itself deliberately doesn't support (see that file's own
; comment), and (b) errors on ANY free evar rather than substituting one
; particular (var . point) pair -- a sumcalc line ("sum(n^2,n,1,10)+3",
; "2*sum(n,n,1,5)") has no ambient variable the way dcalc/icalc/eval's
; commands do; it's expected to already be a closed, fully numeric
; expression once every embedded sum(...) is evaluated.
(define (evalConstExpr e)
    (case (exprKind e)
        ((num) (exprNumValue e))
        ((evar) (error #f "sumcalc: expression has a free variable -- sumcalc only evaluates closed (fully numeric) expressions" (exprEvarName e)))
        ((add) (+ (evalConstExpr (exprAddLeft e)) (evalConstExpr (exprAddRight e))))
        ((sub) (- (evalConstExpr (exprSubLeft e)) (evalConstExpr (exprSubRight e))))
        ((neg) (- (evalConstExpr (exprNegOperand e))))
        ((mul) (* (evalConstExpr (exprMulLeft e)) (evalConstExpr (exprMulRight e))))
        ((div)
            (let ((d (evalConstExpr (exprDivDenom e))))
                (if (= d 0) (error #f "sumcalc: division by zero") (/ (evalConstExpr (exprDivNumer e)) d))))
        ((pow) (expt (evalConstExpr (exprPowBase e)) (evalConstExpr (exprPowExponent e))))
        ((apply) (evalKnownFunc (exprApplyFunc e) (evalConstExpr (exprApplyArg e))))
        ((sum) (evalSumNode e))
        ((factorial)
            (let ((v (evalConstExpr (exprFactorialOperand e))))
                (if (and (integer? v) (>= v 0)) (factorial v)
                    (error #f "sumcalc: factorial is only defined for a nonnegative integer" v))))))

; Formats evalConstExpr's raw number the same way the rest of the
; exprAst engine formats a numeric result (limitResultToString/
; numericResult, limitExpr.scm) -- exact rational -> exact, irrational/
; transcendental (e.g. a term that used sin/exp) -> 6-sig-fig decimal.
(define (evalConstExprToString e) (limitResultToString (numericResult (evalConstExpr e))))
