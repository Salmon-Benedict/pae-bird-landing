; theoremLibrary.scm -- a centralized, cited table of the boxed
; theorem/equation/rule/property sequence from Stewart's Calculus, 8th
; ed. (2016 Cengage), Section 4.2 "The Definite Integral", pp.308-313:
; Theorem 4 (a definite integral is the limit of its right-endpoint
; Riemann sums), Equations 5-11 (closed-form power-sum formulas plus
; sigma-notation linearity rules), the Midpoint Rule (p.312 --
; RiemannSum.scm's 'midpoint side, an APPROXIMATION rule, unlike
; Theorem 4/Equations 5-11 which back an EXACT n->infinity evaluation
; in riemannLimitIntegral.scm), and Properties 1-4 of the definite
; integral (p.313 -- linearity, the integral-level analogue of
; Equations 8-11's sum linearity; not yet consumed by any computation,
; same "verified data, ready for/traceable from a future consumer"
; status identityLibrary.scm's own header describes for itself).
; Requested directly by the user as a "T library" -- companion to
; identityLibrary.scm's trig/log table, same "verified DATA, cited by
; page" shape, but for theorems/formulas instead of pointwise algebraic
; identities.
;
; Equations 5-11 back riemannLimitIntegral.scm's definiteIntegralByRiemannLimit
; (the actual computation, evaluating a definite integral exactly via
; Theorem 4's own limit-of-Riemann-sums definition, replicating
; Stewart's own Example 2b hand-derivation of integral(x^3-6x, 0, 3) =
; -6.75) -- but that file bakes the closed-form ALGEBRA directly
; (binomial-expand f(a+i*dx), collect by power of i, apply the power-
; sum formulas, take the n->infinity limit termwise) rather than
; literally executing a lookup against this table at runtime. This
; table's own job is citation + independent verification that each
; numbered fact, AS THIS ENGINE STATES IT, is actually true -- the same
; "verified data, ready for/traceable from a consumer" role
; identityLibrary.scm's own header describes.
;
; Stewart's own labeling: only #4 is called a "Theorem" in the text;
; 5-11 are boxed but captioned "Equation"; the Midpoint Rule is boxed
; but captioned "Midpoint Rule" with no number at all; Properties 1-4
; are boxed under "Properties of the Integral", a FRESH 1-4 numbering
; distinct from (and unrelated to) Equations 5-11's own numbering,
; despite living in the same source section. Kept together here under
; one T library per the user's own framing ("Theorems 4-11"), each
; entry's own description says which is which.

; ---- Citation data: (list name statement page) ----
; statement is the plain-English/math rendering of the boxed box text;
; not independently verified here (Theorem 3/4 are definitional --
; "integrability" and "the definite integral equals this particular
; limit" aren't equations with two sides to numerically compare the
; way 5-11 are). See below for 5-11's own numeric verification.
;
; TODO (pre-ship, per the user, 2026-08-09): cross-reference every
; statement below against an open-source calculus text (e.g. MIT
; OpenCourseWare 18.01) before this ships. Deliberately deferred until
; this library is more complete -- not a sign the concern was dismissed.
; Each statement here is already this engine's own paraphrase into its
; function-call notation (integral(...)/sum(...)), not verbatim Stewart
; prose -- and the underlying math facts (a limit definition, closed-
; form sum formulas, linearity) aren't copyrightable in themselves --
; but the page citations point at Stewart specifically, and that
; attribution + Stewart-specific framing is exactly what still needs a
; second, independent source before shipping.
(define theoremLibraryCitations
    (list
        (list 'theorem-3
            "Integrability Theorem: if f is continuous on [a,b], or if f has only a finite number of jump discontinuities, then f is integrable on [a,b]; that is, the definite integral integral(f(x),x,a,b) exists."
            "Stewart Calculus 8th ed., p.308")
        (list 'theorem-4
            "If f is integrable on [a,b], then integral(f(x),x,a,b) = lim(n->infinity, sum(f(x_i)*Deltax, i, 1, n)), where Deltax=(b-a)/n and x_i=a+i*Deltax (right endpoints)."
            "Stewart Calculus 8th ed., p.308")
        (list 'equation-5 "sum(i, i, 1, n) = n(n+1)/2" "Stewart Calculus 8th ed., p.309")
        (list 'equation-6 "sum(i^2, i, 1, n) = n(n+1)(2n+1)/6" "Stewart Calculus 8th ed., p.309")
        (list 'equation-7 "sum(i^3, i, 1, n) = [n(n+1)/2]^2" "Stewart Calculus 8th ed., p.309")
        (list 'equation-8 "sum(c, i, 1, n) = n*c, c constant" "Stewart Calculus 8th ed., p.309")
        (list 'equation-9 "sum(c*a_i, i, 1, n) = c*sum(a_i, i, 1, n), c constant" "Stewart Calculus 8th ed., p.309")
        (list 'equation-10 "sum(a_i+b_i, i, 1, n) = sum(a_i, i, 1, n) + sum(b_i, i, 1, n)" "Stewart Calculus 8th ed., p.309")
        (list 'equation-11 "sum(a_i-b_i, i, 1, n) = sum(a_i, i, 1, n) - sum(b_i, i, 1, n)" "Stewart Calculus 8th ed., p.309")
        (list 'midpoint-rule
            "Midpoint Rule: integral(f(x),x,a,b) ~= sum(f(xbar_i)*Deltax, i, 1, n) = Deltax*[f(xbar_1)+...+f(xbar_n)], where Deltax=(b-a)/n and xbar_i=(x_(i-1)+x_i)/2, the midpoint of subinterval [x_(i-1),x_i]."
            "Stewart Calculus 8th ed., p.312")
        (list 'property-1 "integral(c,x,a,b) = c*(b-a), c constant" "Stewart Calculus 8th ed., p.313")
        (list 'property-2 "integral(f(x)+g(x),x,a,b) = integral(f(x),x,a,b) + integral(g(x),x,a,b)" "Stewart Calculus 8th ed., p.313")
        (list 'property-3 "integral(c*f(x),x,a,b) = c*integral(f(x),x,a,b), c constant" "Stewart Calculus 8th ed., p.313")
        (list 'property-4 "integral(f(x)-g(x),x,a,b) = integral(f(x),x,a,b) - integral(g(x),x,a,b)" "Stewart Calculus 8th ed., p.313")))

(define (theoremLibraryLookup name)
    (let ((hit (assv name theoremLibraryCitations)))
        (if hit (caddr hit) (error #f "theoremLibraryLookup: no citation with this name" name))))

; ---- Verification (Equations 5-11 only -- see Theorem 3/4's own note
;      above): direct term-by-term summation loop, unrelated to
;      riemannLimitIntegral.scm's own binomial-expansion machinery, so
;      this genuinely double-checks the formulas rather than checking
;      that file's algebra against itself. ----

(define (directSum f n)
    (let loop ((i 1) (acc 0))
        (if (> i n) acc (loop (+ i 1) (+ acc (f i))))))

; Equations 5-7: sum(i^k) for k=1,2,3, k the power (not a table index --
; deliberately not zero-based, matching the exponent each equation is
; actually about).
(define (powerSumFormula k n)
    (case k
        ((1) (/ (* n (+ n 1)) 2))
        ((2) (/ (* n (+ n 1) (+ (* 2 n) 1)) 6))
        ((3) (let ((s (/ (* n (+ n 1)) 2))) (* s s)))
        (else (error #f "powerSumFormula: only k=1,2,3 (Equations 5-7) are in this library" k))))

(define (powerSumHoldsFor? k n) (= (directSum (lambda (i) (expt i k)) n) (powerSumFormula k n)))

; Equations 8-11: verified against two concrete sequences (a_i=i,
; b_i=i^2) and a concrete constant (c=3) -- same "a genuinely wrong
; rule essentially never happens to agree by coincidence across several
; n" reasoning identityLibrary.scm's own sample-point verification
; relies on, adapted from "several x values" to "several n values".
(define (equation8HoldsFor? n) (= (directSum (lambda (i) 3) n) (* n 3)))
(define (equation9HoldsFor? n) (= (directSum (lambda (i) (* 3 i)) n) (* 3 (directSum (lambda (i) i) n))))
(define (equation10HoldsFor? n)
    (= (directSum (lambda (i) (+ i (* i i))) n) (+ (directSum (lambda (i) i) n) (directSum (lambda (i) (* i i)) n))))
(define (equation11HoldsFor? n)
    (= (directSum (lambda (i) (- (* i i) i)) n) (- (directSum (lambda (i) (* i i)) n) (directSum (lambda (i) i) n))))

; ---- Verification (Properties 1-4): checked against intExpr.scm's
;      definiteIntegral (FTC) on concrete example functions -- this
;      confirms each property is correctly TRANSCRIBED here, the same
;      "correctly captured, not just correctly believed" discipline as
;      5-11 above; it isn't a claim that Stewart's own math needs
;      independently reproving. f=x^2, g=x throughout (arbitrary but
;      fixed, same "one concrete pair, several a/b/c" choice equations
;      8-11 make above with a_i=i/b_i=i^2).
(define (property1HoldsFor? c a b)
    (= (definiteIntegral (exprParse (string->list (number->string c))) 'x a b) (* c (- b a))))
(define (property2HoldsFor? a b)
    (= (definiteIntegral (exprParse (string->list "x^2+x")) 'x a b)
       (+ (definiteIntegral (exprParse (string->list "x^2")) 'x a b) (definiteIntegral (exprParse (string->list "x")) 'x a b))))
(define (property3HoldsFor? c a b)
    (= (definiteIntegral (exprParse (string->list (string-append (number->string c) "*x^2"))) 'x a b)
       (* c (definiteIntegral (exprParse (string->list "x^2")) 'x a b))))
(define (property4HoldsFor? a b)
    (= (definiteIntegral (exprParse (string->list "x^2-x")) 'x a b)
       (- (definiteIntegral (exprParse (string->list "x^2")) 'x a b) (definiteIntegral (exprParse (string->list "x")) 'x a b))))
