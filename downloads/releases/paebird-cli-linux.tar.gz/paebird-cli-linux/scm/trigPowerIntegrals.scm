; trigPowerIntegrals.scm -- Stewart Calculus section 7.2's trigonometric
; integrals: the general reduction techniques for powers and products of
; trig functions that intExpr.scm's own basic antiderivative table and
; curated sec^2/sec*tan/csc^2/csc*cot pairs (intExprMul/intExprPow) don't
; cover -- sin(x)*cos(x), sin^3(x), sin^2(x)*cos^2(x), tan^3(x)*sec(x),
; sec^4(x), cot(x)*csc^3(x), and so on, for ANY nonnegative integer
; exponents (not just the specific hand-picked pairs those curated
; shapes catch). All results are for arg = ax+b LINEAR in var -- same
; scope boundary as the rest of intExpr.scm, no exception here.
;
; ---- Control shape: intExpr.scm owns every iteration ----
; A function here NEVER recurses into itself or into another function in
; this file to make progress on a SMALLER sub-problem. Instead: build the
; smaller sub-problem as a plain expr AST node (the algebraic rewrite one
; reduction step produces, not yet integrated), and hand it to
; (intExpr subExpr var) -- which re-examines it from scratch (constant?
; a sum? a bare table function? a trig-power shape again, routed back
; into this file via intExprMul's/intExprPow's own hooks?) and decides
; what happens next. This is the exact same shape intExpr.scm's own IBP
; control loop (intExprIBPRound) already uses for integrationByParts.scm.
; Established 2026-08-15 as the standing pattern for every multi-step
; integration technique in this engine.
;
; This version (same day, second pass) goes further than the first: even
; the "odd exponent" substitution cases now PEEL one factor at a time
; and hand the remainder to intExpr, rather than doing a full binomial
; expansion internally in one shot -- caught by walking through a
; concrete example (∫sin^m(x)cos^(2k+1)(x)dx: peel one cos^2 via
; cos^2=1-sin^2, THEN hand that rewrite to intExpr, not expand the whole
; (1-sin^2)^k binomial and integrate it internally). Peeling ONE factor
; at a time, repeated via intExpr round-trips, reaches the SAME final
; answer as a one-shot binomial expansion would -- it just does it via
; genuinely separate iterations instead of one large internal computation,
; which is what lets a combined problem (e.g. IBP producing a remainder
; that happens to be trig-power-shaped) interleave with this file
; correctly. The result: NO function here is a multi-term one-shot
; closed form anymore. Every "odd" case bottoms out at an exponent of
; exactly 1 -- genuinely trivial, a single substitution with nothing
; left to expand (∫sin(x)cos^n(x)dx = -cos^(n+1)(x)/(n+1), one term) --
; reached by peeling down to it, not by a binomial shortcut.
;
; Three families:
;
;   sin^m(x)*cos^n(x) -- integrateSinCosProduct
;     - m=1 or n=1: trivial, one substitution, one term.
;     - odd? m (m>=3): peel one sin^2 (sin^2=1-cos^2) --
;       sin^m*cos^n = sin^(m-2)*cos^n - sin^(m-2)*cos^(n+2) -- hand to
;       intExpr; terminates at m=1 (odd, preserved by peeling by 2).
;     - odd? n (n>=3, m even at this point): the symmetric peel on cos^2
;       (cos^2=1-sin^2) -- terminates at n=1.
;     - both even, one of them 0: power-reduction (sin^2=(1-cos2x)/2,
;       cos^2=(1+cos2x)/2) rewrites the bare power as a polynomial in
;       cos(2x) -- a DIFFERENT technique, unavoidably needed here
;       (peeling a bare even power alone cycles forever between sin^2
;       and cos^2, verified by hand while designing this -- it never
;       reaches a base case) -- hand to intExpr.
;     - both even, both >=2: peel m (same identity as the odd-m case,
;       valid for ANY m>=2) -- always makes progress toward m=0, where
;       the bare-power case above takes over.
;
;   tan^m(x)*sec^n(x) -- integrateTanSecProduct
;     - m=0 or n=0: a reduction formula (integrateTanPower/
;       integrateSecPower) -- this round's boundary term computed
;       directly, the exponent-2-smaller remainder built as a plain expr
;       and handed to intExpr.
;     - m=1: trivial (∫tan(x)sec^n(x)dx = sec^n(x)/n, one term).
;     - m>=2 (any parity -- unlike sin/cos, tan^2=sec^2-1 needs no
;       separate bare-power technique, since integrateTanPower/
;       integrateSecPower already resolve m=0/n=0 directly): peel one
;       tan^2 (tan^2=sec^2-1) -- tan^m*sec^n = tan^(m-2)*sec^(n+2) -
;       tan^(m-2)*sec^n -- hand to intExpr; terminates at m=1 (trivial)
;       or m=0 (integrateTanPower/integrateSecPower takes over).
;
;   cot^m(x)*csc^n(x) -- integrateCotCscProduct
;     Exact mirror of tan^m*sec^n (cot^2=csc^2-1 plays tan^2=sec^2-1's
;     role) -- see integrateCotPower's own comment for the one place a
;     sign difference from tan/sec shows up (d/dx[csc(x)]=-csc(x)cot(x),
;     a minus, unlike sec's plus).
;
; Depends on (forward references, resolved at call time -- same
; reasoning as intExpr.scm's own header note for its two-way dependency
; on integrationByParts.scm): intExpr.scm (intExpr itself -- every
; reduction step's "another iteration" -- plus scaleByLinearArgInverse,
; exprIsApplyOf?), limitExpr.scm (exprEqual?), factorial.scm (factorial),
; exprAst.scm's smart constructors. intExpr.scm itself calls INTO this
; file (trigPowerProductResult/trigPowerBaseResult, wired into
; intExprMul/intExprPow) -- another genuine two-way dependency, same
; shape as the intExpr.scm<->integrationByParts.scm one.

; n-choose-k, via factorial (factorial.scm) -- named nCr rather than
; reusing riemannLimitIntegral.scm's own binomialCoeff (same formula,
; different file, loaded much later than this one) to avoid yet another
; same-name-different-file landmine like the one exprSimplify.scm's own
; header already documents having hit once this session. Used by the
; binomial-expansion rewrites and the Fourier power-reduction below.
(define (nCr n k) (/ (factorial n) (* (factorial k) (factorial (- n k)))))

; Sums a list of expr nodes via makeExprAdd. Folds pairwise (NOT (apply
; makeExprAdd lst) -- makeExprAdd takes exactly 2 arguments, so that
; only ever worked by coincidence when a term-list happened to have
; exactly 2 elements; confirmed live as a real bug once, "incorrect
; number of arguments to makeExprAdd" on a 1- or 3-plus-term list). 0
; for an empty list (never actually arises here, but keeps this total).
(define (sumExprList lst)
    (cond
        ((null? lst) (makeExprNum 0))
        ((null? (cdr lst)) (car lst))
        ('t (makeExprAdd (car lst) (sumExprList (cdr lst))))))

; ---- Exponent limit (2026-09-18) ----
; The expansions below are O(m) TERMS with exact big-rational binomial
; coefficients, so cost and (especially) answer size grow fast: sin^1001 =
; 62k characters, cos^2000 = 1M characters and 5.7s, cos^20000 never
; finishes. The 3-second governor (intExpr.scm) can't interrupt a single
; long computation like that -- it is only checked between intExpr calls
; -- so an absurd exponent used to hang. Every entry point here checks
; the SUM of the absolute exponents against this cap first and fails with
; a short plain message instead.
;
; History: this was 500, then 100, then 500 again. It was lowered to 100
; because the dispatcher's final simplifyAcrossApplyBoundaries was
; superlinear on big flat sums (cos^200 3.1s, sec^500 34s end-to-end); the
; two causes (constant-denominator cross-multiplication in expandParse.scm's
; fracAddScalar, and exprEqual? rendering at every tree node in
; intExpr.scm's substituteApplyAtoms) were then fixed at the source, and
; the worst cases at 500 are now about 1.1s end-to-end (cos^500,
; tan^250*sec^250, cot^250*csc^250) -- still not free, and a 500-power
; answer is 50-70k characters, so this remains a sanity bound.
(define maxTrigPowerExponent 500)

(define (checkTrigExponentBudget total)
    (if (> total maxTrigPowerExponent)
        (error #f (string-append "intExpr: trig exponent too large (total power "
                                 (number->string (if (integer? total) total (exact->inexact total)))
                                 ", limit " (number->string maxTrigPowerExponent) ")"))))

; ---- sin^m(x)*cos^n(x) ----

; m=1 (any n): ∫sin(x)cos^n(x)dx = -cos^(n+1)(x)/(n+1) -- one
; substitution (u=cos(x), d(cos)=-sin(x)dx), one term, nothing to expand.
(define (sinCosTrivialSin n arg var)
    (makeExprNeg (scaleByLinearArgInverse arg var (makeExprDiv (makeExprPow (makeExprApplyChecked 'cos arg) (makeExprNum (+ n 1))) (makeExprNum (+ n 1))))))

; n=1 (any m): ∫sin^m(x)cos(x)dx = sin^(m+1)(x)/(m+1) -- symmetric,
; u=sin(x), d(sin)=+cos(x)dx, no extra sign.
(define (sinCosTrivialCos m arg var)
    (scaleByLinearArgInverse arg var (makeExprDiv (makeExprPow (makeExprApplyChecked 'sin arg) (makeExprNum (+ m 1))) (makeExprNum (+ m 1)))))

; ---- Shared builders for the binomial-expansion rewrites below ----
;
; History (2026-09-18): these rewrites replaced the earlier one-factor
; PEEL steps (sin^m*cos^n -> sin^(m-2)*cos^n - sin^(m-2)*cos^(n+2), and
; the tan/sec, cot/csc mirrors). A peel hands intExpr a `sub` whose BOTH
; halves are still non-trivial trig-power problems, so
; T(m,n) = T(m-2,n) + T(m-2,n+2) -- a binary tree of depth m/2,
; O(2^(m/2)) total (measured: sin^31 = 259ms, sin^41 > 3s governor cap,
; sin^51 never finished). Expanding (1-cos^2)^k (or (sec^2-1)^k) in ONE
; step, as a SUM of terms each already terminal or a linear reduction
; chain, is the same "one algebraic rewrite handed to intExpr" shape
; sinCosEvenFourierStep's expansion also uses -- so it still honors this file's
; control rule (nothing here recurses; intExpr re-dispatches every
; term) while costing O(m) terms instead of O(2^(m/2)).

; func(arg)^e as an expr, or #f for e=0 (factor omitted); e=1 is the
; bare apply, so downstream shape checks see sin(x), not sin(x)^1.
(define (trigPowerFactor func arg e)
    (cond
        ((= e 0) #f)
        ((= e 1) (makeExprApplyChecked func arg))
        ('t (makeExprPow (makeExprApplyChecked func arg) (makeExprNum e)))))

; Product of a list of factors, skipping #f entries; 1 if none remain.
(define (trigFactorProduct factors)
    (let loop ((fs (filter (lambda (f) f) factors)))
        (cond
            ((null? fs) (makeExprNum 1))
            ((null? (cdr fs)) (car fs))
            ('t (makeExprMul (car fs) (loop (cdr fs)))))))

; sum_{i=0}^{k} C(k,i) * (sgn i) * (termAt i), as one expr sum.
(define (binomialExpansionSum k sgn termAt)
    (sumExprList
        (map (lambda (i) (makeExprMul (makeExprNum (* (nCr k i) (sgn i))) (termAt i)))
             (range (+ k 1)))))

; sin^m(x)cos^n(x), odd m=2k+1>=3: sin^m = sin*(1-cos^2)^k, so
; sin^m*cos^n = sum_i C(k,i)(-1)^i * sin(x)*cos^(n+2i) -- every term is
; the m=1 trivial case.
(define (sinCosOddSinExpand m n arg var)
    (intExpr
        (binomialExpansionSum (quotient (- m 1) 2)
            (lambda (i) (expt -1 i))
            (lambda (i) (trigFactorProduct (list (trigPowerFactor 'sin arg 1) (trigPowerFactor 'cos arg (+ n (* 2 i)))))))
        var))

; Symmetric: odd n=2k+1>=3 (m even at this point): cos^n = cos*(1-sin^2)^k,
; so sin^m*cos^n = sum_i C(k,i)(-1)^i * sin^(m+2i)*cos(x) -- every term
; is the n=1 trivial case.
(define (sinCosOddCosExpand m n arg var)
    (intExpr
        (binomialExpansionSum (quotient (- n 1) 2)
            (lambda (i) (expt -1 i))
            (lambda (i) (trigFactorProduct (list (trigPowerFactor 'sin arg (+ m (* 2 i))) (trigPowerFactor 'cos arg 1)))))
        var))

; Both m and n even (either may be 0): sin^m(x)*cos^n(x) as a FLAT Fourier
; sum c_0 + sum_{k>=1} c_k*cos(2k*arg), the textbook power-reduction form
; (sin^2 = 1/2 - cos(2x)/2, cos^4 = 3/8 + cos(2x)/2 + cos(4x)/8, ...),
; with every c_k an exact rational computed here once. Handed to intExpr,
; where each cos(2k*arg) is a plain table entry.
;
; Why this and not nested power reduction (cos^2p -> cos(2x)^i, then
; cos(2x)^i reduced again into cos(4x)..., 2026-09-18): the nested route's
; integral is correct but its RESULT is a deeply nested unsimplified tree
; -- sin^24*cos^24 took 4.5s in exprSimplify alone, 40/40 never finished.
; The flat sum has (m+n)/2 + 1 terms at any size.
;
; Coefficients: cos^n = sum_j a_j cos(2jx), a_0 = C(n,n/2)/2^n,
; a_j = 2*C(n,n/2-j)/2^n; sin^m the same with b_l carrying (-1)^l.
; Multiplied via cos(A)cos(B) = [cos(A+B)+cos(A-B)]/2. m=0 or n=0 is the
; same computation with the other side the constant polynomial [1].

; Coefficient vector (list, index j = coefficient of cos(2jx)) of
; func^e for func in sin/cos, e even (e=0 -> '(1)).
(define (evenPowerFourierCoeffs func e)
    (let ((p (quotient e 2)))
        (map (lambda (j)
                 (* (if (= j 0) 1 2)
                    (if (and (eqv? func 'sin) (odd? j)) -1 1)
                    (/ (nCr e (- p j)) (expt 2 e))))
             (range (+ p 1)))))

; Product of two such coefficient vectors, as one vector indexed by the
; combined frequency (length = len(a) + len(b) - 1).
(define (fourierCoeffProduct a b)
    (let ((out (make-vector (+ (length a) (length b) -1) 0)))
        (let loopA ((as a) (j 0))
            (if (not (null? as))
                (begin
                    (let loopB ((bs b) (l 0))
                        (if (not (null? bs))
                            (let ((c (/ (* (car as) (car bs)) 2)))
                                (vector-set! out (+ j l) (+ (vector-ref out (+ j l)) c))
                                (vector-set! out (abs (- j l)) (+ (vector-ref out (abs (- j l))) c))
                                (loopB (cdr bs) (+ l 1)))))
                    (loopA (cdr as) (+ j 1)))))
        (vector->list out)))

; a*var+b as ONE linear expr (the b term omitted when 0, the coefficient
; omitted when 1) -- so sin(4*(2*x)) prints as sin(8*x), not sin(4*2*x),
; and a slope of exactly 1 prints as sin(x), not sin(1*x). Callers pass
; a POSITIVE slope (product-to-sum normalizes sign before calling).
(define (linearArgExpr a b var)
    (let ((lin (if (= a 1) (makeExprEvar var) (makeExprMul (makeExprNum a) (makeExprEvar var)))))
        (cond
            ((= b 0) lin)
            ((< b 0) (makeExprSub lin (makeExprNum (- b))))
            ('t (makeExprAdd lin (makeExprNum b))))))

; Returns the antiderivative DIRECTLY (not via intExpr): after the Fourier
; expansion every term is a plain table entry -- c_0 -> c_0*var, and
; c_k*cos(2k*arg) -> c_k/(2k*a)*sin(2k*arg), a = arg's linear coefficient
; -- so there is no further sub-problem to hand back, same as the
; sinCosTrivial* cases above. Folding c_k/(2k*a) into ONE exact rational
; per term is what yields the textbook form (3/8*x+1/4*sin(2*x)+
; 1/32*sin(4*x)) rather than stacked "1/2*1/2*sin(2*x)" coefficients.
(define (sinCosEvenFourierStep m n arg var)
    (let ((ab (linearCoeffs arg var)))
        (if (not ab)
            (error #f "intExpr: u-substitution beyond a linear argument is out of scope" arg)
            (let ((a (car ab)) (b (cdr ab))
                  (coeffs (fourierCoeffProduct (evenPowerFourierCoeffs 'sin m) (evenPowerFourierCoeffs 'cos n))))
                (sumExprList
                    (filter (lambda (t) t)
                        (map (lambda (c k)
                                 (cond
                                     ((= c 0) #f)
                                     ((= k 0) (makeExprMul (makeExprNum c) (makeExprEvar var)))
                                     ('t (makeExprMul (makeExprNum (/ c (* 2 k a))) (makeExprApplyChecked 'sin (linearArgExpr (* 2 k a) (* 2 k b) var))))))
                             coeffs (range (length coeffs)))))))))

; Top-level entry: sin^m(x)*cos^n(x), any nonnegative integers m, n
; (bare sin^m alone is n=0; bare cos^n alone is m=0). Order matters:
; m=1/n=1 (trivial) are checked before oddness in general, since they're
; the terminal case any odd-m/odd-n peel is heading toward; oddness is
; checked before the bare-alone/both-even cases, since a bare ODD power
; alone (e.g. sin^3(x), n=0) must still peel toward m=1, NOT get routed
; into sinCosEvenFourierStep (which assumes both exponents are even).
(define (integrateSinCosProduct m n arg var)
    (checkTrigExponentBudget (+ m n))
    (cond
        ((and (= m 0) (= n 0)) (makeExprEvar var))
        ((= m 1) (sinCosTrivialSin n arg var))
        ((= n 1) (sinCosTrivialCos m arg var))
        ((odd? m) (sinCosOddSinExpand m n arg var))
        ((odd? n) (sinCosOddCosExpand m n arg var))
        ('t (sinCosEvenFourierStep m n arg var))))

; ---- tan^m(x)*sec^n(x) ----


; ---- Flat closed forms for the reduction-formula families (2026-09-18) ----
; The reduction formulas
;   I_m(tan) = tan^(m-1)/(m-1) - I_(m-2)              (cot: -cot^(m-1)/(m-1) - I_(m-2))
;   I_n(sec) = sec^(n-2)tan/(n-1) + (n-2)/(n-1) I_(n-2)  (csc: -csc^(n-2)cot/(n-1) + ...)
; used to be applied ONE ROUND PER intExpr CALL, nesting each remainder
; inside the previous round's term: a(sec^18 tan + 18/19(sec^16 tan + ...)).
; Raw intExpr output was correct, but that depth-n/2 tree made the
; dispatcher's final simplify passes crawl (tan^100*sec^100 = 9.3s end to
; end, tan^250*sec^250 and cot^200*csc^100 over a minute, though intExpr
; itself took milliseconds). Unrolling the recurrence here, with exact
; rational coefficients, gives the same answer as a FLAT sum -- boundary
; terms, one log (or x) term -- that simplifies in linear time. Like
; sinCosEvenFourierStep and the product-to-sum hook these return the
; antiderivative directly: the rewrite is closed-form, nothing is left to
; hand back to intExpr.
;
; Coefficients: boundary/log terms carry 1/alpha (alpha = arg's slope, the
; reduction formula's own u-substitution factor); the bare-x term from
; I_0 does NOT (I_0 = integral of 1 dx).

; Terms are (list K expr style): K an exact nonzero rational, style 'div
; (unit numerator prints expr/d, like sec(x)^2*tan(x)/3) or 'mul (always
; n/d*expr, for log terms: 1/2*ln(...)). Sign handled by subtraction so raw
; output reads tan(x)-x, not tan(x)+-x.
(define (flatTermExpr K expr style)
    (cond
        ((= K 1) expr)
        ((= (denominator K) 1) (makeExprMul (makeExprNum K) expr))
        ((and (eqv? style 'div) (= (numerator K) 1)) (makeExprDiv expr (makeExprNum (denominator K))))
        ('t (makeExprMul (makeExprDiv (makeExprNum (numerator K)) (makeExprNum (denominator K))) expr))))

(define (sumFlatTerms terms)
    (let ((terms (filter (lambda (t) (not (= (car t) 0))) terms)))
        (if (null? terms)
            (makeExprNum 0)
            (let loop ((acc (let ((t (car terms))) (if (< (car t) 0) (makeExprNeg (flatTermExpr (- (car t)) (cadr t) (caddr t))) (flatTermExpr (car t) (cadr t) (caddr t)))))
                       (rest (cdr terms)))
                (if (null? rest)
                    acc
                    (let* ((t (car rest)) (K (car t)))
                        (loop (if (< K 0)
                                  (makeExprSub acc (flatTermExpr (- K) (cadr t) (caddr t)))
                                  (makeExprAdd acc (flatTermExpr K (cadr t) (caddr t))))
                              (cdr rest))))))))

(define (flatSlope arg var)
    (let ((ab (linearCoeffs arg var)))
        (if (and ab (not (= (car ab) 0)))
            (car ab)
            (error #f "intExpr: u-substitution beyond a linear argument is out of scope" arg))))

; INT func(arg)^m dx for func in tan/cot, m >= 2:
;   I_m = a*func^(m-1)/(m-1) - I_(m-2), a = +1 (tan) / -1 (cot); unrolled
;   c starts at 1 and flips sign each round; the chain ends at I_0 = x
;   (m even) or I_1 (m odd: tan -> -ln|cos|, cot -> +ln|sin|).
(define (pureTrigPowerFlat func m arg var)
    (let ((alpha (flatSlope arg var)) (a (if (eqv? func 'tan) 1 -1)))
        (sumFlatTerms
            (let loop ((cur m) (c 1) (acc '()))
                (cond
                    ((>= cur 2)
                        (loop (- cur 2) (- c)
                              (cons (list (/ (* c a) (* alpha (- cur 1))) (trigPowerFactor func arg (- cur 1)) 'div) acc)))
                    ((= cur 0) (reverse (cons (list c (makeExprEvar var) 'div) acc)))
                    ('t (reverse
                            (cons (if (eqv? func 'tan)
                                      (list (/ (- c) alpha) (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprApplyChecked 'cos arg))) 'mul)
                                      (list (/ c alpha) (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprApplyChecked 'sin arg))) 'mul))
                                  acc))))))))

; SUM_k w_k * INT secLike(arg)^N_k dx  (pairs = list of (N . w), each N >= 1),
; secLike sec (other = tan, a = +1) or csc (other = cot, a = -1):
;   I_N = a*secLike^(N-2)*other/(N-1) + (N-2)/(N-1) I_(N-2),
; ending at I_1 = ln|sec+tan| (sec) / -ln|csc+cot| (csc), or I_2's
; tan / -cot (its (N-2) factor zeroes the remainder). Terms from every
; pair are MERGED by exponent, so e.g. the tan^4*sec^3 expansion's repeated
; sec^k*tan pieces collapse into one coefficient each.
(define (secFamilyFlat secLike pairs arg var)
    (let* ((alpha (flatSlope arg var))
           (other (if (eqv? secLike 'sec) 'tan 'cot))
           (a (if (eqv? secLike 'sec) 1 -1))
           (table '())      ; alist: exponent e of secLike  ->  coefficient of secLike^e * other
           (logCoef 0))
        (for-each
            (lambda (pair)
                (let loop ((cur (car pair)) (c (cdr pair)))
                    (cond
                        ((>= cur 2)
                            (let* ((e (- cur 2)) (old (assv e table)) (add (/ (* c a) (- cur 1))))
                                (if old (set-cdr! old (+ (cdr old) add)) (set! table (cons (cons e add) table)))
                                (loop (- cur 2) (* c (/ (- cur 2) (- cur 1))))))
                        ((= cur 1) (set! logCoef (+ logCoef (* c a))))
                        (else #f))))
            pairs)
        (sumFlatTerms
            (append
                (map (lambda (entry)
                         (list (/ (cdr entry) alpha)
                               (trigFactorProduct (list (trigPowerFactor secLike arg (car entry)) (makeExprApplyChecked other arg)))
                               'div))
                     (sort (lambda (x y) (> (car x) (car y))) table))
                (list (list (/ logCoef alpha)
                            (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprAdd (makeExprApplyChecked secLike arg) (makeExprApplyChecked other arg))))
                            'mul))))))


; d/dx[tan(x)]=sec^2(x) gives tan^m(x)=d/dx[tan^(m-1)(x)]/(m-1) -
; tan^(m-2)(x) for any m>=2 (even or odd -- verified via
; tan^(m-2)(x)*sec^2(x) = tan^(m-2)(x)*(1+tan^2(x)) =
; tan^(m-2)(x)+tan^m(x)), so ∫tan^m(x)dx = tan^(m-1)(x)/(m-1) -
; ∫tan^(m-2)(x)dx. This round's boundary term is computed directly; the
; remaining ∫tan^(m-2)(x)dx is built as a plain expr and handed to
; intExpr for another iteration (routes back through intExprPow's own
; hook, NOT a self-call). Bare tan power alone -- routed here directly
; from integrateTanSecProduct whenever n=0, regardless of m's parity.
(define (integrateTanPower m arg var)
    (cond
        ((= m 0) (makeExprEvar var))
        ((= m 1) (scaleByLinearArgInverse arg var (makeExprNeg (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprApplyChecked 'cos arg))))))
        ('t (pureTrigPowerFlat 'tan m arg var))))

; Standard IBP-derived reduction formula: ∫sec^n(x)dx =
; sec^(n-2)(x)tan(x)/(n-1) + (n-2)/(n-1)*∫sec^(n-2)(x)dx, n>=2 -- same
; "this round's boundary term directly, the remainder via intExpr"
; shape as integrateTanPower above. Bare sec power alone -- routed here
; directly from integrateTanSecProduct whenever m=0.
(define (integrateSecPower n arg var)
    (cond
        ((= n 0) (makeExprEvar var))
        ((= n 1) (scaleByLinearArgInverse arg var (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprAdd (makeExprApplyChecked 'sec arg) (makeExprApplyChecked 'tan arg))))))
        ('t (secFamilyFlat 'sec (list (cons n 1)) arg var))))

; m=1 (any n>=1 -- n=0 already routed to integrateTanPower above):
; ∫tan(x)sec^n(x)dx = sec^n(x)/n -- one substitution (u=sec(x),
; d(sec)=sec*tan dx), one term.
(define (tanSecTrivial n arg var)
    (scaleByLinearArgInverse arg var (makeExprDiv (makeExprPow (makeExprApplyChecked 'sec arg) (makeExprNum n)) (makeExprNum n))))

; tan^m(x)sec^n(x), m>=2, n>=1 (n=0 and m=0 are the linear reduction
; formulas above, never routed here): with j=floor(m/2), tan^2=sec^2-1
; gives tan^m = [tan if m odd]*(sec^2-1)^j, so
; tan^m*sec^n = sum_i C(j,i)(-1)^(j-i) * [tan]*sec^(n+2i). m odd: every
; term is tan*sec^(>=1), the m=1 trivial case. m even: every term is a
; BARE sec power, resolved by integrateSecPower's linear chain. One
; algebraic REWRITE handed to intExpr, not a self-call (see the
; binomial-expansion history note above for why this replaced the peel).
; famFunc/famPow are tan/sec here, cot/csc for the mirror below --
; cot^2=csc^2-1 has the identical shape and signs.
(define (tanSecFamilyExpand tanLike secLike m n arg var)
    (let ((j (quotient m 2)) (tanExp (if (odd? m) 1 0)))
        (if (even? m)
            ; m even: every term is a BARE sec^(n+2i), whose reduction
            ; formula secFamilyFlat unrolls and MERGES across all i in one
            ; flat sum (2026-09-18) -- see the flat-forms note above.
            (secFamilyFlat secLike
                (map (lambda (i) (cons (+ n (* 2 i)) (* (nCr j i) (expt -1 (- j i))))) (range (+ j 1)))
                arg var)
            (intExpr
                (binomialExpansionSum j
                    (lambda (i) (expt -1 (- j i)))
                    (lambda (i) (trigFactorProduct (list (trigPowerFactor tanLike arg tanExp) (trigPowerFactor secLike arg (+ n (* 2 i)))))))
                var))))

(define (tanSecExpand m n arg var) (tanSecFamilyExpand 'tan 'sec m n arg var))

; Top-level entry: tan^m(x)*sec^n(x), any nonnegative integers m, n.
(define (integrateTanSecProduct m n arg var)
    (checkTrigExponentBudget (+ m n))
    (cond
        ((= n 0) (integrateTanPower m arg var))
        ((= m 0) (integrateSecPower n arg var))
        ((= m 1) (tanSecTrivial n arg var))
        ('t (tanSecExpand m n arg var))))

; ---- cot^m(x)*csc^n(x) -- exact mirror of tan^m*sec^n ----
; cot^2(x)=csc^2(x)-1 plays tan^2=sec^2-1's role throughout. One sign
; difference: d/dx[csc(x)]=-csc(x)cot(x) (a MINUS, unlike sec's plus),
; visible below in integrateCotPower's own boundary term and
; cotCscTrivial (tanSecPeelStep's own mirror, cotCscPeelStep, needs no
; such sign -- the csc^2=1+cot^2/cot^2=csc^2-1 algebraic identity itself
; carries no sign difference from tan/sec's, only the DERIVATIVE-based
; steps do).

; d/dx[cot(x)]=-csc^2(x) gives (by the same derivation as
; integrateTanPower, with the extra minus sign folded through):
; ∫cot^m(x)dx = -cot^(m-1)(x)/(m-1) - ∫cot^(m-2)(x)dx, m>=2 -- boundary
; term direct, remainder via intExpr.
(define (integrateCotPower m arg var)
    (cond
        ((= m 0) (makeExprEvar var))
        ((= m 1) (scaleByLinearArgInverse arg var (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprApplyChecked 'sin arg)))))
        ('t (pureTrigPowerFlat 'cot m arg var))))

; Mirror of integrateSecPower, sign-flipped on the boundary term:
; ∫csc^n(x)dx = -csc^(n-2)(x)cot(x)/(n-1) + (n-2)/(n-1)*∫csc^(n-2)(x)dx.
(define (integrateCscPower n arg var)
    (cond
        ((= n 0) (makeExprEvar var))
        ((= n 1) (scaleByLinearArgInverse arg var (makeExprNeg (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprAdd (makeExprApplyChecked 'csc arg) (makeExprApplyChecked 'cot arg)))))))
        ('t (secFamilyFlat 'csc (list (cons n 1)) arg var))))

; m=1 (any n>=1): ∫cot(x)csc^n(x)dx = -csc^n(x)/n -- one substitution
; (u=csc(x), d(csc)=-csc*cot dx -- the sign this family carries).
(define (cotCscTrivial n arg var)
    (makeExprNeg (scaleByLinearArgInverse arg var (makeExprDiv (makeExprPow (makeExprApplyChecked 'csc arg) (makeExprNum n)) (makeExprNum n)))))

; cot^m(x)csc^n(x), m>=2, n>=1: mirrors tanSecExpand exactly (cot^2=csc^2-1
; plays tan^2=sec^2-1's role, no sign difference in this identity).
(define (cotCscExpand m n arg var) (tanSecFamilyExpand 'cot 'csc m n arg var))

; Top-level entry: cot^m(x)*csc^n(x), any nonnegative integers m, n.
(define (integrateCotCscProduct m n arg var)
    (checkTrigExponentBudget (+ m n))
    (cond
        ((= n 0) (integrateCotPower m arg var))
        ((= m 0) (integrateCscPower n arg var))
        ((= m 1) (cotCscTrivial n arg var))
        ('t (cotCscExpand m n arg var))))

; ---- sin(Ax+..)*cos(Bx+..): product-to-sum (Stewart 7.2, sin mx cos nx) ----
;
; Two sin/cos factors, each to the first power, with DIFFERENT linear
; arguments A=a1*x+b1, B=a2*x+b2 (same-argument products are the
; sin^m*cos^n family above, tried first by intExprMul):
;   sin A cos B = 1/2 sin(A+B) + 1/2 sin(A-B)
;   sin A sin B = 1/2 cos(A-B) - 1/2 cos(A+B)
;   cos A cos B = 1/2 cos(A-B) + 1/2 cos(A+B)
; (cos A sin B is sin B cos A -- the factors are swapped first.) Each
; resulting term is a bare sin/cos table entry, so like
; sinCosEvenFourierStep this returns the antiderivative DIRECTLY with one
; folded rational per term instead of handing sub-problems back.
;
; A term is (list coef func slope offset), meaning coef*func(slope*x+offset).
; normalizeTrigTerm makes the slope positive (sin(-u) = -sin(u), cos(-u)
; = cos(u)); a slope of exactly 0 (A and B parallel, e.g. sin(x)*cos(x+1))
; leaves a constant term coef*func(offset), which integrates to
; coef*func(offset)*x -- func(0) is folded (cos 0 = 1, sin 0 = 0).
(define (normalizeTrigTerm coef func slope offset)
    (if (< slope 0)
        (list (if (eqv? func 'sin) (- coef) coef) func (- slope) (- offset))
        (list coef func slope offset)))

(define (trigTermIntegral term var)
    (let ((coef (car term)) (func (cadr term)) (a (caddr term)) (b (cadddr term)))
        (cond
            ((= a 0)
                (cond
                    ((and (= b 0) (eqv? func 'sin)) #f)
                    ((and (= b 0) (eqv? func 'cos)) (makeExprMul (makeExprNum coef) (makeExprEvar var)))
                    ; sin(-c) = -sin(c), cos(-c) = cos(c): keep the constant's
                    ; argument positive so it prints sin(1), not sin(-1).
                    ((< b 0) (trigTermIntegral (list (if (eqv? func 'sin) (- coef) coef) func 0 (- b)) var))
                    ('t (makeExprMul (makeExprNum coef) (makeExprMul (makeExprApplyChecked func (makeExprNum b)) (makeExprEvar var))))))
            ((eqv? func 'sin) (makeExprMul (makeExprNum (- (/ coef a))) (makeExprApplyChecked 'cos (linearArgExpr a b var))))
            ('t (makeExprMul (makeExprNum (/ coef a)) (makeExprApplyChecked 'sin (linearArgExpr a b var)))))))

; f1(A)*f2(B), A=(a1 . b1), B=(a2 . b2) from linearCoeffs -> list of terms.
(define (trigProductTerms f1 A f2 B)
    (let* ((swap? (and (eqv? f1 'cos) (eqv? f2 'sin)))
           (fa (if swap? f2 f1)) (fb (if swap? f1 f2))
           (a1 (car (if swap? B A))) (b1 (cdr (if swap? B A)))
           (a2 (car (if swap? A B))) (b2 (cdr (if swap? A B)))
           (sumS (+ a1 a2)) (sumO (+ b1 b2)) (difS (- a1 a2)) (difO (- b1 b2)))
        (cond
            ((and (eqv? fa 'sin) (eqv? fb 'cos))
                (list (normalizeTrigTerm 1/2 'sin sumS sumO) (normalizeTrigTerm 1/2 'sin difS difO)))
            ((and (eqv? fa 'sin) (eqv? fb 'sin))
                (list (normalizeTrigTerm 1/2 'cos difS difO) (normalizeTrigTerm -1/2 'cos sumS sumO)))
            ('t
                (list (normalizeTrigTerm 1/2 'cos difS difO) (normalizeTrigTerm 1/2 'cos sumS sumO))))))

; intExprMul hook (after trigPowerProductResult): l, r both known
; var-dependent. Returns the antiderivative, or #f if l/r aren't two
; first-power sin/cos factors with linear var-dependent arguments (an
; exponent > 1, a non-linear argument, a tan/sec/... factor all fall
; through to intExprMul's own IBP fallback, unchanged).
(define (trigProductToSumResult l r var)
    (let ((li (trigPowerInfo l)) (ri (trigPowerInfo r)))
        (and li ri
             (= (cadr li) 1) (= (cadr ri) 1)
             (memv (car li) '(sin cos)) (memv (car ri) '(sin cos))
             (let ((A (linearCoeffs (caddr li) var)) (B (linearCoeffs (caddr ri) var)))
                 (and A B (not (= (car A) 0)) (not (= (car B) 0))
                      (let ((pieces (filter (lambda (t) t)
                                              (map (lambda (t) (trigTermIntegral t var))
                                                   (trigProductTerms (car li) A (car ri) B)))))
                          (if (null? pieces) (makeExprNum 0) (sumExprList pieces))))))))

; ---- intExpr.scm hooks ----

; If e is exactly funcName(arg) (implicit power 1) or funcName(arg)^k
; for a literal nonnegative integer k, returns (list funcName k arg);
; else #f. Shared by both hooks below.
(define (trigPowerInfo e)
    (let try ((funcs '(sin cos tan sec cot csc)))
        (if (null? funcs)
            #f
            (let ((f (car funcs)))
                (cond
                    ((exprIsApplyOf? e f) (list f 1 (exprApplyArg e)))
                    ((and (exprPow? e) (exprIsApplyOf? (exprPowBase e) f) (exprNum? (exprPowExponent e))
                          (let ((k (exprNumValue (exprPowExponent e)))) (and (integer? k) (>= k 0))))
                        (list f (exprNumValue (exprPowExponent e)) (exprApplyArg (exprPowBase e))))
                    ('t (try (cdr funcs))))))))

; Whether e is a MUL node shaped like a trig-power product this file's
; own trigPowerProductResult would recognize -- same family (sin/cos,
; tan/sec, or cot/csc), matching argument (exprEqual?, limitExpr.scm).
; A lightweight SHAPE check, not a computation -- doesn't build or
; return an antiderivative. Used by integrationByParts.scm's own
; liateCategory: without this, a mul node like sin(x)*cos(x) falls
; through to the generic Algebraic default (the same category a bare
; variable gets), so an outer IBP problem like x*sin(x)*cos(x) could
; tie sin(x)*cos(x) against x and pick the WRONG u/dv -- confirmed live
; as a real bug: it produced an ever-growing, non-terminating remainder
; (u=sin(x)cos(x), whose derivative cos^2(x)-sin^2(x) never simplifies
; away) instead of routing sin(x)*cos(x) straight through this file as
; dv, the way LIATE's own Trigonometric-ranks-after-Algebraic ordering
; is supposed to make happen.
(define (trigPowerProductShape? e)
    (and (eqv? (exprKind e) 'mul)
         (let ((li (trigPowerInfo (exprMulLeft e))) (ri (trigPowerInfo (exprMulRight e))))
             (and li ri
                  ; Two first-power sin/cos factors with DIFFERENT arguments
                  ; are also a recognizable product now (product-to-sum, see
                  ; trigProductToSumResult below).
                  (or (and (= (cadr li) 1) (= (cadr ri) 1) (memv (car li) '(sin cos)) (memv (car ri) '(sin cos)))
                      (exprEqual? (caddr li) (caddr ri)))
                  (or (and (memv (car li) '(sin cos)) (memv (car ri) '(sin cos)))
                      (and (memv (car li) '(tan sec)) (memv (car ri) '(tan sec)))
                      (and (memv (car li) '(cot csc)) (memv (car ri) '(cot csc))))))))

; intExprMul hook: e = l*r, both already known to be var-dependent and
; not one of intExprMul's own more specific curated shapes (checked
; first there). Returns the antiderivative if l and r are both
; sin/cos powers or both tan/sec powers or both cot/csc powers of the
; EXACT SAME argument (exprEqual?, limitExpr.scm) -- same function on
; both sides (e.g. sin(x)*sin(x)) sums the exponents; different
; functions in the same family (sin(x)*cos(x)^3) route through the
; matching top-level entry point above -- or #f if l/r aren't this
; shape at all (mismatched arguments, unrelated functions, a
; non-trig factor), leaving intExprMul's own IBP fallback to handle it.
(define (trigPowerProductResult l r var)
    (let ((li (trigPowerInfo l)) (ri (trigPowerInfo r)))
        (if (not (and li ri (exprEqual? (caddr li) (caddr ri))))
            #f
            (let ((fl (car li)) (ml (cadr li)) (fr (car ri)) (mr (cadr ri)) (arg (caddr li)))
                (cond
                    ((and (eqv? fl fr) (memv fl '(sin cos)))
                        (if (eqv? fl 'sin) (integrateSinCosProduct (+ ml mr) 0 arg var) (integrateSinCosProduct 0 (+ ml mr) arg var)))
                    ((and (eqv? fl fr) (memv fl '(tan sec)))
                        (if (eqv? fl 'tan) (integrateTanSecProduct (+ ml mr) 0 arg var) (integrateTanSecProduct 0 (+ ml mr) arg var)))
                    ((and (eqv? fl fr) (memv fl '(cot csc)))
                        (if (eqv? fl 'cot) (integrateCotCscProduct (+ ml mr) 0 arg var) (integrateCotCscProduct 0 (+ ml mr) arg var)))
                    ((and (memv fl '(sin cos)) (memv fr '(sin cos)))
                        (if (eqv? fl 'sin) (integrateSinCosProduct ml mr arg var) (integrateSinCosProduct mr ml arg var)))
                    ((and (memv fl '(tan sec)) (memv fr '(tan sec)))
                        (if (eqv? fl 'tan) (integrateTanSecProduct ml mr arg var) (integrateTanSecProduct mr ml arg var)))
                    ((and (memv fl '(cot csc)) (memv fr '(cot csc)))
                        (if (eqv? fl 'cot) (integrateCotCscProduct ml mr arg var) (integrateCotCscProduct mr ml arg var)))
                    ('t #f))))))

; intExprPow hook: base = func(arg), exponent = literal nonnegative
; integer k -- e.g. sin(x)^3, sec(x)^4, cot(x)^5. func is already known
; to be one of sin/cos/tan/sec/cot/csc (checked at the call site,
; intExprPow, before this is called).
(define (trigPowerBaseResult func k arg var)
    (case func
        ((sin) (integrateSinCosProduct k 0 arg var))
        ((cos) (integrateSinCosProduct 0 k arg var))
        ((tan) (integrateTanSecProduct k 0 arg var))
        ((sec) (integrateTanSecProduct 0 k arg var))
        ((cot) (integrateCotCscProduct k 0 arg var))
        ((csc) (integrateCotCscProduct 0 k arg var))))
