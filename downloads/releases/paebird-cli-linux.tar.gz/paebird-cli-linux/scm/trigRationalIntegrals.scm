; trigRationalIntegrals.scm -- integrals of trig products/quotients whose
; exponents are NEGATIVE integers or FRACTIONAL: 1/cos(x)^2, sin(x)/cos(x),
; sin(x)^2/cos(x), 1/(sin(x)^2*cos(x)^2), sqrt(sin(x))*cos(x), sec(x)^(-2),
; ... -- the shapes trigPowerIntegrals.scm's nonnegative-integer families
; never see (intExprMul/intExprPow/intExprDiv used to reject every one of
; them). All arguments LINEAR in var (ax+b), same scope boundary as the
; rest of intExpr.scm.
;
; ---- Method ----
; trigMonomialParse folds any product/quotient/power tree of trig atoms
; sharing ONE linear argument (plus var-free constant factors) into
; coef * sin(arg)^p * cos(arg)^q with exact exponents, via
;   sec = cos^-1, csc = sin^-1, tan = sin*cos^-1, cot = cos*sin^-1.
; integrateSinCosGeneral then dispatches on (p, q):
;   - both nonnegative integers ........ delegate to integrateSinCosProduct
;   - other exponent 0, one negative ... integrateTanSecProduct/CotCsc
;                                        (sec^n / csc^n reduction formulas)
;   - other exponent exactly 1 ......... u-substitution, ANY real exponent:
;                                        sin^p cos = sin^(p+1)/(p+1), p=-1 ->
;                                        ln|sin|; cos^q sin likewise
;   - odd positive integer >= 3 ........ (1-cos^2)^k / (1-sin^2)^k expansion,
;                                        other exponent anything (incl.
;                                        fractional or negative)
;   - even nonneg integer, other a
;     negative integer ................. same expansion, yielding single
;                                        powers of the negative-exponent one
;   - both negative integers ........... a+b even: u = tan substitution,
;                                        closed form below; a+b odd: #f
;                                        (needs partial fractions -- out of
;                                        scope, reported as a clean error)
; Anything else returns #f and the caller falls through unchanged.
;
; Control shape (see trigPowerIntegrals.scm's header): expansions are ONE
; algebraic rewrite handed to intExpr, never a self-call; every terminal
; case here is a direct closed form of a single substitution.
;
; Output naming: a negative power prints with the reciprocal name --
; cos^-n -> sec(x)^n, sin^-n -> csc(x)^n, tan^-n -> cot(x)^n -- so
; \int sin/cos^2 = sec(x), not cos(x)^-1.
;
; Depends on (resolved at call time): intExpr.scm (intExpr, linearCoeffs,
; containsVar?, exprIsApplyOf?), trigPowerIntegrals.scm (integrateSinCosProduct,
; integrateTanSecProduct, integrateCotCscProduct, binomialExpansionSum,
; trigPowerFactor, trigFactorProduct, sumExprList, nCr), limitExpr.scm
; (exprEqual?), exprAst.scm's smart constructors.

; ---- parsing ----

; A monomial is (list coefExpr p q arg): coefExpr * sin(arg)^p * cos(arg)^q,
; arg #f when there is no trig atom yet (a pure constant).
(define (monoCoef m) (car m))
(define (monoP m) (cadr m))
(define (monoQ m) (caddr m))
(define (monoArg m) (cadddr m))

(define (monoMerge a b)
    (and a b
         (let ((argA (monoArg a)) (argB (monoArg b)))
             (and (or (not argA) (not argB) (exprEqual? argA argB))
                  (list (makeExprMul (monoCoef a) (monoCoef b))
                        (+ (monoP a) (monoP b))
                        (+ (monoQ a) (monoQ b))
                        (or argA argB))))))

; 1/m: coefficient inverted, exponents negated.
(define (monoInvert m)
    (list (makeExprDiv (makeExprNum 1) (monoCoef m)) (- (monoP m)) (- (monoQ m)) (monoArg m)))

(define (monoScale m r)
    (list (monoCoef m) (* r (monoP m)) (* r (monoQ m)) (monoArg m)))

; sin^dp*cos^dq contribution of one bare trig function call.
(define (trigAtomMonomial func arg)
    (case func
        ((sin) (list (makeExprNum 1) 1 0 arg))
        ((cos) (list (makeExprNum 1) 0 1 arg))
        ((tan) (list (makeExprNum 1) 1 -1 arg))
        ((cot) (list (makeExprNum 1) -1 1 arg))
        ((sec) (list (makeExprNum 1) 0 -1 arg))
        ((csc) (list (makeExprNum 1) -1 0 arg))
        (else #f)))

(define (trigAtom? e)
    (and (exprApply? e) (memv (exprApplyFunc e) '(sin cos tan sec cot csc)) #t))

; Exact literal exponent (integer or rational; a float exponent is refused
; so exponent arithmetic below stays exact).
(define (exactLiteralExponent e)
    (and (exprNum? e) (exact? (exprNumValue e)) (exprNumValue e)))

(define (trigMonomialParse e var)
    (cond
        ((not (containsVar? e var)) (list e 0 0 #f))
        ((trigAtom? e) (trigAtomMonomial (exprApplyFunc e) (exprApplyArg e)))
        (else
            (case (exprKind e)
                ((mul) (monoMerge (trigMonomialParse (exprMulLeft e) var) (trigMonomialParse (exprMulRight e) var)))
                ((div) (let ((d (trigMonomialParse (exprDivDenom e) var)))
                           (and d (monoMerge (trigMonomialParse (exprDivNumer e) var) (monoInvert d)))))
                ((neg) (let ((m (trigMonomialParse (exprNegOperand e) var)))
                           (and m (list (makeExprNeg (monoCoef m)) (monoP m) (monoQ m) (monoArg m)))))
                ((pow) (let ((r (exactLiteralExponent (exprPowExponent e))) (base (exprPowBase e)))
                           (and r (trigAtom? base)
                                (monoScale (trigAtomMonomial (exprApplyFunc base) (exprApplyArg base)) r))))
                ((apply) (and (eqv? (exprApplyFunc e) 'sqrt) (trigAtom? (exprApplyArg e))
                              (let ((a (exprApplyArg e)))
                                  (monoScale (trigAtomMonomial (exprApplyFunc a) (exprApplyArg a)) 1/2))))
                (else #f)))))

; ---- output helpers ----

; K*expr with K an exact rational: 1 -> expr, -1 -> -expr, 1/d -> expr/d.
(define (scaledTerm K expr)
    (cond
        ((< K 0) (makeExprNeg (scaledTerm (- K) expr)))
        ((= K 1) expr)
        ((= (denominator K) 1) (makeExprMul (makeExprNum K) expr))
        ((= (numerator K) 1) (makeExprDiv expr (makeExprNum (denominator K))))
        ('t (makeExprMul (makeExprDiv (makeExprNum (numerator K)) (makeExprNum (denominator K))) expr))))

; func(arg)^e for func in sin/cos/tan, with a NEGATIVE INTEGER e printed
; as the reciprocal function (sec/csc/cot) to the positive power.
(define (trigPowNamed func e arg)
    (cond
        ((and (integer? e) (< e 0))
            (trigPowerFactor (case func ((sin) 'csc) ((cos) 'sec) (else 'cot)) arg (- e)))
        ('t (trigPowerFactor func arg e))))

; ---- terminal substitutions ----

; INT sin(arg)^p * cos(arg) dx, any real p: sin^(p+1)/(p+1), p=-1 -> ln|sin|.
(define (sinPowerTimesCos p a arg)
    (let ((e (+ p 1)))
        (if (= e 0)
            (scaledTerm (/ 1 a) (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprApplyChecked 'sin arg))))
            (scaledTerm (/ 1 (* a e)) (trigPowNamed 'sin e arg)))))

; INT cos(arg)^q * sin(arg) dx, any real q: -cos^(q+1)/(q+1), q=-1 -> -ln|cos|.
(define (cosPowerTimesSin q a arg)
    (let ((e (+ q 1)))
        (if (= e 0)
            (scaledTerm (/ -1 a) (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprApplyChecked 'cos arg))))
            (scaledTerm (/ -1 (* a e)) (trigPowNamed 'cos e arg)))))

; 1/(sin^a cos^b), a,b >= 1 integers, a+b = 2m even. With u = tan(arg):
; sin^-a cos^-b = u^-a (1+u^2)^(m-1) * sec^2, so
; INT = sum_{i=0}^{m-1} C(m-1,i) * INT u^(2i-a) du
;     = sum C(m-1,i) * u^(j)/j  (j = 2i-a+1; j=0 -> ln|u|), scaled by 1/alpha.
; (1/(sin^2 cos^2) = tan - cot; 1/(sin cos) = ln|tan|.)
(define (integrateBothNegative aNeg bNeg alpha arg)
    (let ((m (/ (+ aNeg bNeg) 2)))
        (sumExprList
            (map (lambda (i)
                     (let ((j (+ (- (* 2 i) aNeg) 1)) (c (nCr (- m 1) i)))
                         (if (= j 0)
                             (scaledTerm (/ c alpha) (makeExprApplyChecked 'ln (makeExprApplyChecked 'abs (makeExprApplyChecked 'tan arg))))
                             (scaledTerm (/ c (* alpha j)) (trigPowNamed 'tan j arg)))))
                 (range m)))))

; ---- expansions (one algebraic rewrite, handed to intExpr) ----

; sin^p (p even >= 2) * cos^q (q negative integer): sin^p = (1-cos^2)^(p/2),
; so = sum_i C(p/2,i)(-1)^i cos^(q+2i) -- single cos powers (positive ones
; go to the ordinary families, negative ones back through this file's own
; pow hook, where sin's exponent is 0).
(define (sinEvenCosNegExpand p q arg var)
    (intExpr
        (binomialExpansionSum (quotient p 2)
            (lambda (i) (expt -1 i))
            (lambda (i) (trigFactorProduct (list (trigPowerFactor 'cos arg (+ q (* 2 i)))))))
        var))

; Mirror: cos^q (q even >= 2) * sin^p (p negative integer).
(define (cosEvenSinNegExpand p q arg var)
    (intExpr
        (binomialExpansionSum (quotient q 2)
            (lambda (i) (expt -1 i))
            (lambda (i) (trigFactorProduct (list (trigPowerFactor 'sin arg (+ p (* 2 i)))))))
        var))

; ---- dispatch ----

; Antiderivative of sin(arg)^p * cos(arg)^q (arg = alpha*var + beta), or #f.
(define (integrateSinCosGeneral p q arg var)
    (checkTrigExponentBudget (+ (abs p) (abs q)))
    (let* ((ab (linearCoeffs arg var))
           (alpha (and ab (car ab)))
           (pInt? (integer? p)) (qInt? (integer? q)))
        (and ab (not (= alpha 0))
            (cond
                ((and pInt? qInt? (>= p 0) (>= q 0)) (integrateSinCosProduct p q arg var))
                ((and (= p 0) qInt? (< q 0)) (integrateTanSecProduct 0 (- q) arg var))
                ((and (= q 0) pInt? (< p 0)) (integrateCotCscProduct 0 (- p) arg var))
                ((= q 1) (sinPowerTimesCos p alpha arg))
                ((= p 1) (cosPowerTimesSin q alpha arg))
                ((and pInt? (odd? p) (>= p 3)) (sinCosOddSinExpand p q arg var))
                ((and qInt? (odd? q) (>= q 3)) (sinCosOddCosExpand p q arg var))
                ((and pInt? (even? p) (>= p 2) qInt? (< q 0)) (sinEvenCosNegExpand p q arg var))
                ((and qInt? (even? q) (>= q 2) pInt? (< p 0)) (cosEvenSinNegExpand p q arg var))
                ((and pInt? qInt? (< p 0) (< q 0) (even? (+ p q)))
                    (integrateBothNegative (- p) (- q) alpha arg))
                ; Both negative, ODD total (1/(sin*cos^2), 1/(sin^3*cos^4)):
                ; no tan substitution applies -- needs partial fractions or a
                ; different technique. Fail specifically and immediately
                ; rather than falling through to an IBP attempt that burns
                ; the whole time budget and ends in a confusing message.
                ((and pInt? qInt? (< p 0) (< q 0))
                    (error #f "intExpr: 1/(sin^a*cos^b) with a+b odd needs partial fractions, out of scope"))
                (else #f)))))

; The hook body shared by intExprMul / intExprDiv / intExprPow: e parses as
; coef*sin^p*cos^q over one linear argument AND has at least one var-
; dependent trig factor -> the antiderivative, else #f.
(define (trigMonomialResult e var)
    (let ((m (trigMonomialParse e var)))
        (and m (monoArg m)
             (let ((result (integrateSinCosGeneral (monoP m) (monoQ m) (monoArg m) var)))
                 (and result
                      (if (exprIsLiteral? (monoCoef m) 1)
                          result
                          (makeExprMul (monoCoef m) result)))))))

; ---- quotients with a NON-trig numerator: n / (trig monomial) ----
;
; x/cos(x)^2, (1+sin(x))/cos(x)^2, exp(x)/sin(x)^2. trigMonomialResult
; can't take these (the numerator isn't a trig monomial), and intExprDiv
; used to reject them outright even though the equivalent PRODUCT
; (x*sec(x)^2) integrates fine via IBP. So: a sum/difference numerator
; splits into a sum/difference of quotients (each re-dispatched by
; intExpr); anything else is rewritten as the product
; numerator * (reciprocal of the trig monomial, in sec/csc/cot-free
; sin/cos-power form) and handed to intExpr, which sends it down
; intExprMul (IBP included). Returns the antiderivative, or #f when the
; denominator isn't a single-argument trig monomial.
(define (monomialToExpr m)
    (let ((factors (list (trigPowNamed 'sin (monoP m) (monoArg m)) (trigPowNamed 'cos (monoQ m) (monoArg m)))))
        (let ((body (trigFactorProduct factors)))
            (if (exprIsLiteral? (monoCoef m) 1) body (makeExprMul (monoCoef m) body)))))

(define (trigDivRewriteResult e var)
    (let* ((n (exprDivNumer e)) (d (exprDivDenom e)) (dm (trigMonomialParse d var)))
        (and dm (monoArg dm) (containsVar? n var)
             (case (exprKind n)
                 ((add) (intExpr (makeExprAdd (makeExprDiv (exprAddLeft n) d) (makeExprDiv (exprAddRight n) d)) var))
                 ((sub) (intExpr (makeExprSub (makeExprDiv (exprSubLeft n) d) (makeExprDiv (exprSubRight n) d)) var))
                 (else (intExpr (makeExprMul n (monomialToExpr (monoInvert dm))) var))))))
