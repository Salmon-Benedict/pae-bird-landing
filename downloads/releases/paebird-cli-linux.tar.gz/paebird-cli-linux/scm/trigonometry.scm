; trigonometry.scm -- trig evaluation and equation solving, ported in
; spirit (not line-by-line) from the C++ engine's evaluateTrig/
; solveTrigEquation/solveTrigonometric (the latter is a pure passthrough
; to solveTrigEquation in C++, so only one function is ported here).
; Requires helperS.scm, mathHelp.scm, basicmath.scm, chemistry.scm (for
; findSubstring, range), equationVariants.scm (for pi-const,
; roundToSigFigs, stripSpaces, findStringCharPos, parseNumeralToRational),
; linearSystems.scm (for splitSignedTerms, parseLinearTerm,
; parseFractionOrDecimal, findFirstAlphaPos -- reused here to parse a
; trig argument like "2x+30" the same way a linear-system term is
; parsed, since "coefficient*x plus/minus a constant" is exactly that
; grammar), mathSymbolClass.scm (for ms-symbol -- see "expression-list
; representation" below), and polyBridge.scm (for expr->engine-str,
; ms-poly-str) to be loaded first.
;
; ---- Expression-list representation ----
; A trig function call is represented as a 2-token expression list:
; (trigExpr 'sin argMs) = (list (ms-symbol 'function 'sin) argMs). This
; needs no changes to mathSymbolClass.scm -- ms-symbol's own header
; comment already lists sin/cos/tan as example function names, and
; polyBridge.scm's expr->engine-str already wraps every ms-fraction in
; parens for engine input, so (trigExpr 'sin (ms-fraction-str "x" "1"))
; round-trips to the string "sin(x)" for free. This is the same token
; kind item 6 (comprehensive/mixed expansion) will need to embed a trig
; call inside a larger polynomial expression, so building on it now
; keeps that door open rather than inventing a second representation.
;
; ---- Scope ----
; Exact special-angle values (degrees only -- radian-mode symbolic input
; like "pi/6" is out of scope) for sin/cos/tan at all 17 standard angles
; 0,30,...,360, covering the full circle. This exceeds C++'s own
; evaluateTrig, which only returns exact fractions for 0-180 degrees and
; silently falls back to a decimal for the recognized angle strings
; 210-360 despite explicitly listing them as inputs it handles (verified
; by reading MathSymbol.cpp directly: its exact-value return block only
; checks angleValue against 0..pi, never the 210-360 range, even though
; the input-parsing block above it accepts those degree strings).
;
; solveTrigEquation supports compound arguments (coefficient*x plus/minus
; an offset, e.g. "sin(2x+30)=1/2"), matching C++'s fuller scope, using
; exact rational arithmetic throughout the base-angle-table case (C++
; uses doubles even for the angles it has exact fractions for). The
; coefficient must be a positive integer -- a clear error is raised
; otherwise, rather than C++'s silent zero-solutions bug when
; (int)coefficient truncates to 0.
;
; Ported from ../trigonometry.scm (MIT Scheme) to Chez Scheme. Changes:
; all 5 (error "msg" ...) call sites get an explicit #f who-arg. Nothing
; else -- assv/assoc/case/memv/sin/cos/tan/asin/acos/atan/rational?/round
; all behave identically in Chez, and range/findSubstring come from the
; already-ported chemistry.scm per this file's own header.

; ---- Special-angle exact-value table ----
; (degree sin cos tan), covering the full circle 0-360 in the standard
; 30/45-degree steps. "undefined" for tan at 90/270.
(define trigSpecialAngles
    (list
        (list 0   "0"     "1"     "0")
        (list 30  "1/2"   "√3/2"  "√3/3")
        (list 45  "√2/2"  "√2/2"  "1")
        (list 60  "√3/2"  "1/2"   "√3")
        (list 90  "1"     "0"     "undefined")
        (list 120 "√3/2"  "-1/2"  "-√3")
        (list 135 "√2/2"  "-√2/2" "-1")
        (list 150 "1/2"   "-√3/2" "-√3/3")
        (list 180 "0"     "-1"    "0")
        (list 210 "-1/2"  "-√3/2" "√3/3")
        (list 225 "-√2/2" "-√2/2" "1")
        (list 240 "-√3/2" "-1/2"  "√3")
        (list 270 "-1"    "0"     "undefined")
        (list 300 "-√3/2" "1/2"   "-√3")
        (list 315 "-√2/2" "√2/2"  "-1")
        (list 330 "-1/2"  "√3/2"  "-√3/3")
        (list 360 "0"     "1"     "0")))

; Evaluates sin/cos/tan at a degree angle (char list, e.g. "30"),
; returning an exact special value string if the angle is one of the 17
; standard angles, else a decimal approximation rounded to 6 significant
; figures.
(define (evaluateTrig funcSym degreeChars)
    (let* ((degValue (parseNumeralToRational (stripSpaces (list->string degreeChars))))
           (row (assv degValue trigSpecialAngles)))
        (if row
            (case funcSym
                ((sin) (cadr row)) ((cos) (caddr row)) ((tan) (cadddr row))
                (else (error #f "evaluateTrig: unsupported function (expected sin, cos, or tan)" funcSym)))
            (let ((rad (/ (* (exact->inexact degValue) pi-const) 180)))
                (roundToSigFigs
                    (case funcSym
                        ((sin) (sin rad)) ((cos) (cos rad)) ((tan) (tan rad))
                        (else (error #f "evaluateTrig: unsupported function (expected sin, cos, or tan)" funcSym)))
                    6)))))

; ---- Base-angle tables for solveTrigEquation ----
; Given a special RHS value, the reference angle(s) within one period
; whose sin/cos/tan equals it -- ported directly from C++'s
; getSineBaseAngles/getCosineBaseAngles/getTangentBaseAngles.
(define sineBaseAngles
    (list (cons "0" (list 0 180)) (cons "1/2" (list 30 150)) (cons "√2/2" (list 45 135))
          (cons "√3/2" (list 60 120)) (cons "1" (list 90)) (cons "-1" (list 270))))
(define cosineBaseAngles
    (list (cons "0" (list 90 270)) (cons "1/2" (list 60 300)) (cons "√2/2" (list 45 315))
          (cons "√3/2" (list 30 330)) (cons "1" (list 0)) (cons "-1" (list 180))))
(define tangentBaseAngles
    (list (cons "0" (list 0)) (cons "1" (list 45)) (cons "√3" (list 60))
          (cons "√3/3" (list 30)) (cons "-1" (list 135))))

(define (periodFor func) (if (eqv? func 'tan) 180 360))
(define (baseAngleTable func)
    (case func ((sin) sineBaseAngles) ((cos) cosineBaseAngles) ((tan) tangentBaseAngles)
               (else (error #f "solveTrigEquation: unsupported function (expected sin, cos, or tan)" func))))

(define (normalizeAngle a period)
    (cond ((< a 0) (normalizeAngle (+ a period) period))
          ((>= a period) (normalizeAngle (- a period) period))
          ('t a)))

; Formats a degree value: bare integer if it's a whole number (always
; true for the base-angle-table case, since that path stays exact
; rational throughout), else rounds to 6 significant figures (the
; numeric-fallback case, which is inherently a decimal approximation).
(define (formatDegreeNumber a)
    (if (and (rational? a) (= a (round a)))
        (number->string (round a))
        (roundToSigFigs (exact->inexact a) 6)))

(define (formatAngleSolution angle period)
    (string-append "x = " (formatDegreeNumber angle) "° + " (formatDegreeNumber period) "°n"))

; Finds which of "sin(", "cos(", "tan(", "sec(", "csc(", "cot(" occurs
; (searching the whole string, matching C++'s find()-based approach)
; and returns (cons funcSymbol indexJustPastTheOpenParen), or #f if
; none found. sec/csc/cot are solved by reducing to their reciprocal
; partner (reciprocalPartner below) rather than getting their own
; base-angle table -- see solveTrigEquation's single-term dispatch and
; normalizeReciprocalTerm.
(define (findFuncCall s)
    (let ((sinIdx (findSubstring s "sin(" 0))
          (cosIdx (findSubstring s "cos(" 0))
          (tanIdx (findSubstring s "tan(" 0))
          (secIdx (findSubstring s "sec(" 0))
          (cscIdx (findSubstring s "csc(" 0))
          (cotIdx (findSubstring s "cot(" 0)))
        (cond
            (sinIdx (cons 'sin (+ sinIdx 4)))
            (cosIdx (cons 'cos (+ cosIdx 4)))
            (tanIdx (cons 'tan (+ tanIdx 4)))
            (secIdx (cons 'sec (+ secIdx 4)))
            (cscIdx (cons 'csc (+ cscIdx 4)))
            (cotIdx (cons 'cot (+ cotIdx 4)))
            ('t #f))))

; sec<->cos, csc<->sin, cot<->tan -- the reciprocal-pair mapping used
; throughout this file's sec/csc/cot support (single-term reduction,
; the two-term reciprocal-pair quadratic, and the trig=trig identity
; case). #f for anything else.
(define (reciprocalPartner func)
    (case func
        ((sec) 'cos) ((csc) 'sin) ((cot) 'tan)
        ((cos) 'sec) ((sin) 'csc) ((tan) 'cot)
        ('t #f)))

; Named distinctly from equationVariants.scm's own degToRad (the
; char-list-based @:degtorad command implementation) -- both used to be
; named degToRad; Chez's single global namespace let this file's later
; load silently shadow that one, breaking @:degtorad entirely (it fed a
; char list into this function's exact->inexact, crashing on every
; input -- confirmed live via a 50-case sweep, 100% reproducible).
(define (trigDegToRadNum d) (/ (* (exact->inexact d) pi-const) 180))
(define (cosDeg d) (cos (trigDegToRadNum d)))
(define (sinDeg d) (sin (trigDegToRadNum d)))

; Parses a trig argument ("x", "2x", "x+30", "2x-45", ...) into
; (cons coefficient offset), reusing linearSystems.scm's term parser --
; the grammar is identical to one side of a linear equation.
(define (parseTrigArgument argument)
    (let loop ((terms (splitSignedTerms argument)) (coefficient 1) (offset 0))
        (cond
            ((null? terms) (cons coefficient offset))
            ((findFirstAlphaPos (car terms) 0)
                (loop (cdr terms) (cdr (parseLinearTerm (car terms))) offset))
            ('t (loop (cdr terms) coefficient (parseFractionOrDecimal (car terms)))))))

; Removes every '(' and ')' from a string -- used to normalize the RHS,
; since ms-poly-str (polyBridge.scm) renders a bare constant fraction
; like 1/2 as "(1) / (2)" (parenthesized so it's safely re-parseable by
; the general engine grammar elsewhere), but a trig equation's RHS is
; always just a bare special-value string ("1/2", "√3/2", "undefined")
; or a bare number here, never an expression that genuinely needs
; grouping -- so stripping parens entirely is safe and normalizes both
; "(1) / (2)" and "1/2" to the same "1/2" before matching/parsing it.
(define (removeParens s) (list->string (remove-all #\) (remove-all #\( (string->list s)))))

; ---- Multi-term LHS support (leading coefficient, power, sum of two
; trig terms, and an RHS that's itself a trig call) ----
;
; A trig equation term is (list coeff func argCoeff argOffset power),
; e.g. "-2sin(2x+30)^3" -> (list -2 'sin 2 30 3). coeff/power default to
; 1 when absent; argCoeff/argOffset come from parseTrigArgument on the
; call's own argument, same as before.
(define (termCoeff t) (car t))
(define (termFunc t) (cadr t))
(define (termArgCoeff t) (caddr t))
(define (termArgOffset t) (cadddr t))
(define (termPower t) (car (cddddr t)))

; Same contract as linearSystems.scm's splitSignedTerms, but tracks
; paren depth so a '+'/'-' INSIDE a function call's own argument (e.g.
; the "+30" in "sin(x+30)") isn't mistaken for a top-level term
; boundary. splitSignedTerms itself is paren-unaware -- correct for ITS
; callers (parseTrigArgument below, applied only to a bare argument
; with no nested calls), but not safe to reuse here where the LHS may
; contain one or more full sin(...)/cos(...)/tan(...) calls.
(define (splitSignedTermsParenAware s)
    (let loop ((i 1) (start 0) (depth 0) (acc '()))
        (cond
            ((>= i (string-length s)) (reverse (cons (substring s start (string-length s)) acc)))
            ((eqv? (string-ref s i) #\() (loop (+ i 1) start (+ depth 1) acc))
            ((eqv? (string-ref s i) #\)) (loop (+ i 1) start (- depth 1) acc))
            ((and (= depth 0) (or (eqv? (string-ref s i) #\+) (eqv? (string-ref s i) #\-)))
                (loop (+ i 1) i depth (cons (substring s start i) acc)))
            ('t (loop (+ i 1) start depth acc)))))

; Reads an optional "^N" suffix immediately after a term's closing
; paren -- "" (nothing left) means power 1; anything else that isn't a
; positive-integer power is a clear error rather than being silently
; dropped (the bug this whole rewrite exists to fix: "sin(x)^2=1" used
; to silently parse as "sin(x)=1", losing the x=270° solution).
(define (parseTrigPowerSuffix trailing)
    (cond
        ((= (string-length trailing) 0) 1)
        ((and (eqv? (string-ref trailing 0) #\^) (> (string-length trailing) 1))
            (let ((n (parseNumeralToRational (substring trailing 1 (string-length trailing)))))
                (if (and (integer? n) (> n 0))
                    n
                    (error #f "solveTrigEquation: the exponent must be a positive integer" trailing))))
        ('t (error #f "solveTrigEquation: unexpected trailing content after a function call" trailing))))

; Whether s is a plain decimal numeral ("2", "-2", "0.5", ".5") --
; digits, at most one leading '-', at most one '.', at least one digit
; somewhere. Doesn't itself accept a '/' (validNumeralText? below
; splits that off first) or exponent notation (not this file's
; convention anywhere).
(define (validPlainNumeralText? s)
    (and (> (string-length s) 0)
         (let loop ((i (if (eqv? (string-ref s 0) #\-) 1 0)) (sawDigit #f) (sawDot #f))
             (cond
                 ((>= i (string-length s)) sawDigit)
                 ((char-numeric? (string-ref s i)) (loop (+ i 1) 't sawDot))
                 ((and (eqv? (string-ref s i) #\.) (not sawDot)) (loop (+ i 1) sawDigit 't))
                 ('t #f)))))

; Whether s is a valid numeral for parseFractionOrDecimal -- a plain
; decimal, or two plain decimals separated by '/'.
(define (validNumeralText? s)
    (let ((slashIdx (findStringCharPos #\/ s 0)))
        (if slashIdx
            (and (validPlainNumeralText? (substring s 0 slashIdx)) (validPlainNumeralText? (substring s (+ slashIdx 1) (string-length s))))
            (validPlainNumeralText? s))))

; Parses one signed term (already split by splitSignedTermsParenAware,
; e.g. "-2sin(2x+30)^3") into (list coeff func argCoeff argOffset
; power). A leading numeral before the function name (with an optional
; '*', "2*sin(x)") is the term's own coefficient -- previously silently
; discarded ("2sin(x)=1" used to solve as "sin(x)=1"), same underlying
; bug as the power suffix above. The text before the function name must
; actually BE a numeral, checked via validNumeralText? -- without this,
; anything else there (a stray variable, "y*sin(x)"; or, worse, the
; leftover "a"/"arc" of an inverse-trig name this file doesn't support,
; "asin("/"arcsin(" both containing "sin(" as a literal substring) fell
; through to parseFractionOrDecimal and raw-crashed with a confusing
; "/: #f is not a number" instead of a clear error naming the problem.
(define (parseTrigTerm rawTerm)
    (let* ((negative (and (> (string-length rawTerm) 0) (eqv? (string-ref rawTerm 0) #\-)))
           (body (if (and (> (string-length rawTerm) 0)
                          (or (eqv? (string-ref rawTerm 0) #\+) (eqv? (string-ref rawTerm 0) #\-)))
                     (substring rawTerm 1 (string-length rawTerm))
                     rawTerm))
           (call (findFuncCall body)))
        (if (not call)
            (error #f "solveTrigEquation: expected sin(...), cos(...), tan(...), sec(...), csc(...), or cot(...) on the left side" rawTerm))
        (let* ((func (car call)) (argStart (cdr call)) (nameStart (- argStart 4))
               (rawCoeffText (substring body 0 nameStart))
               (coeffText (if (and (> (string-length rawCoeffText) 0)
                                    (eqv? (string-ref rawCoeffText (- (string-length rawCoeffText) 1)) #\*))
                               (substring rawCoeffText 0 (- (string-length rawCoeffText) 1))
                               rawCoeffText))
               (magnitude (cond
                              ((= (string-length coeffText) 0) 1)
                              ((validNumeralText? coeffText) (parseFractionOrDecimal coeffText))
                              ('t (error #f "solveTrigEquation: expected a numeric coefficient before the function call (inverse/hyperbolic trig functions like arcsin, asin, sinh aren't supported)" coeffText))))
               (coeff (if negative (- magnitude) magnitude))
               (closeIdx (findStringCharPos #\) body argStart))
               (argument (substring body argStart closeIdx))
               (parsedArg (parseTrigArgument argument))
               (trailing (substring body (+ closeIdx 1) (string-length body)))
               (power (parseTrigPowerSuffix trailing)))
            (list coeff func (car parsedArg) (cdr parsedArg) power))))

; If s (already stripped of surrounding whitespace) is, in its
; entirety, "func(argument)" with nothing before the function name or
; after its closing paren, returns (list funcSymbol argumentString);
; otherwise #f. Used to detect an RHS that's itself a trig call (e.g.
; "sin(x)=cos(x)") -- as opposed to a plain value -- BEFORE removeParens
; would otherwise mangle it.
(define (parseWholeTrigCall s)
    (let ((call (findFuncCall s)))
        (if (and call (= (cdr call) 4))
            (let* ((argStart (cdr call)) (closeIdx (findStringCharPos #\) s argStart)))
                (if (and closeIdx (= closeIdx (- (string-length s) 1)))
                    (list (car call) (substring s argStart closeIdx))
                    #f))
            #f)))

(define (assertValidArgCoeff coefficient)
    (if (or (not (integer? coefficient)) (<= coefficient 0))
        (error #f "solveTrigEquation: the coefficient of x must be a positive integer" coefficient)))

; All solutions within one period for a known base angle, generalized
; across sin/cos/tan/compound-argument -- C++ special-cases sin, cos,
; and tan into three near-duplicate blocks; this is the one shared path.
(define (solveBaseAngleCase func baseAngles coefficient offset)
    (let ((period (periodFor func)))
        (if (and (= coefficient 1) (= offset 0))
            (map (lambda (ba) (formatAngleSolution ba period)) baseAngles)
            (let ((periodOut (/ period coefficient)))
                (apply append
                    (map (lambda (baseAngle)
                             (map (lambda (k)
                                      (formatAngleSolution
                                          (normalizeAngle (/ (+ (- baseAngle offset) (* period k)) coefficient) period)
                                          periodOut))
                                  (range coefficient)))
                         baseAngles))))))

; Parses a numeric-fallback RHS value that may contain a literal '√'
; (e.g. "√2/2", "√3", "√3/3") -- the base-angle tables' own RHS strings
; use this notation for irrational special values, and a value that
; isn't a key in the ACTIVE function's own table still needs to reach
; this fallback (e.g. tan(x)=√2/2: that value is a key in sineBaseAngles/
; cosineBaseAngles but not tangentBaseAngles, since tan never equals
; √2/2 at a standard angle). parseFractionOrDecimal/parseNumeralToRational
; have no notion of '√' at all, so this used to crash with a raw
; "/: #f is not a number" instead of producing the decimal approximation
; this fallback exists to give (found via this session's Excel test-
; workbook generation, which happened to include that exact case).
(define (parseTrigRhsValue rhs)
    (let ((rootIdx (findStringCharPos #\√ rhs 0)))
        (if (not rootIdx)
            (parseFractionOrDecimal rhs)
            (let* ((afterRoot (substring rhs (+ rootIdx 1) (string-length rhs)))
                   (slashIdx (findStringCharPos #\/ afterRoot 0))
                   (radicand (parseNumeralToRational (if slashIdx (substring afterRoot 0 slashIdx) afterRoot)))
                   (denom (if slashIdx (parseNumeralToRational (substring afterRoot (+ slashIdx 1) (string-length afterRoot))) 1)))
                (/ (sqrt (exact->inexact radicand)) denom)))))

; Numeric fallback via asin/acos/atan when the RHS isn't one of the
; standard special values.
(define (solveNumericCase func rhsValue coefficient offset)
    (if (and (memv func '(sin cos)) (or (< rhsValue -1) (> rhsValue 1)))
        (list "No real solutions (value out of range [-1, 1])")
        (let* ((angleRad (case func ((sin) (asin rhsValue)) ((cos) (acos rhsValue)) ((tan) (atan rhsValue))))
               (angleDeg0 (/ (* angleRad 180) pi-const))
               (angleDeg (if (and (eqv? func 'tan) (< angleDeg0 0)) (+ angleDeg0 180) angleDeg0))
               (period (periodFor func))
               (periodOut (/ period coefficient))
               (secondAngle (case func ((sin) (- 180 angleDeg)) ((cos) (- 360 angleDeg)) ((tan) #f))))
            (if secondAngle
                (list (formatAngleSolution (/ (- angleDeg offset) coefficient) periodOut)
                      (formatAngleSolution (/ (- secondAngle offset) coefficient) periodOut))
                (list (formatAngleSolution (/ (- angleDeg offset) coefficient) periodOut))))))

; Finds the baseAngleTable entry (a (valueString . angleList) pair)
; whose own value equals `value` (within a small float tolerance --
; needed since several entries, e.g. "√2/2", are irrational and can
; only ever be compared as floats), or #f if none matches. Generalizes
; the old plain string-equality lookup (assoc rhs (baseAngleTable
; func)) so a value arrived at via a leading coefficient or a power
; root -- not just the original RHS string verbatim -- can still hit
; the table's exact-angle case instead of always falling to the
; decimal numeric fallback.
(define (findBaseAngleEntryByValue func value)
    (let ((target (exact->inexact value)))
        (let try ((entries (baseAngleTable func)))
            (cond
                ((null? entries) #f)
                ((< (abs (- (exact->inexact (parseTrigRhsValue (caar entries))) target)) 1e-9) (car entries))
                ('t (try (cdr entries)))))))

; Solves func(argCoeff*x+argOffset) = value for a single already-
; resolved numeric value (value has already had any leading coefficient
; divided out and/or the appropriate root taken -- see
; solveTrigPowerCase below).
(define (solveTrigValueCase func value argCoeff argOffset)
    (let ((baseEntry (findBaseAngleEntryByValue func value)))
        (if baseEntry
            (solveBaseAngleCase func (cdr baseEntry) argCoeff argOffset)
            (solveNumericCase func (exact->inexact value) argCoeff argOffset))))

; Solves func(argCoeff*x+argOffset)^power = value. power=1 is the
; ordinary case (unchanged behavior); power>1 takes the real root(s) of
; value first -- both signs for an even power (matching e.g. sin(x)=1
; and sin(x)=-1 both being valid square roots of sin(x)^2=1, the
; "sin(x)^2=1 solves as sin(x)=1 only, silently missing x=270°" bug
; this exists to fix), the single sign-preserving root for an odd
; power -- then unions the solutions from each root that's actually in
; sin/cos's [-1,1] domain.
(define (solveTrigPowerCase func value argCoeff argOffset power)
    (if (= power 1)
        (solveTrigValueCase func value argCoeff argOffset)
        (let* ((evenPower (even? power))
               (magnitude (expt (exact->inexact (abs value)) (/ 1.0 power)))
               (roots (cond
                          ((and evenPower (< value 0)) '())
                          (evenPower (list magnitude (- magnitude)))
                          ((< value 0) (list (- magnitude)))
                          ('t (list magnitude)))))
            (let ((inRangeRoots (if (memv func '(sin cos)) (filter (lambda (r) (<= (abs r) 1)) roots) roots)))
                (if (null? inRangeRoots)
                    (list "No real solutions (value out of range [-1, 1])")
                    (apply append (map (lambda (r) (solveTrigValueCase func r argCoeff argOffset)) inRangeRoots)))))))

; Reduces func(theta)^power=value (func in sec/csc/cot) to the
; equivalent statement about its reciprocal partner, so the EXISTING
; solveTrigPowerCase (built for cos/sin's [-1,1] domain and tan's
; unrestricted one) handles sec/csc/cot's own domain restrictions for
; free: sec(theta)^n=value <=> (1/cos(theta))^n=value <=>
; cos(theta)^n=1/value for ANY power n (the reciprocal commutes with
; the power), and sec(theta)^n=value has a real solution exactly when
; |1/value|<=1, i.e. |value|>=1 -- sec's true range -- with no special-
; casing needed. Returns (list normalizedFunc normalizedValue), or
; (list #f _) if there is provably no real solution (sec/csc are never
; 0, so "func(theta)=0" for those is immediately empty).
; cot is the one exception: cot(theta)=0 is a real, common case
; (theta=90+180n) that the 1/value reduction can't express (division by
; zero), so it's routed directly to cos(theta)=0 instead -- correct
; regardless of power, since cot(theta)^n=0 <=> cot(theta)=0 for any n
; (0 has no other real n-th root).
(define (normalizeReciprocalTerm func value)
    (cond
        ((and (eqv? func 'cot) (= value 0)) (list 'cos 0))
        ((= value 0) (list #f 0))
        ('t (list (reciprocalPartner func) (/ 1 value)))))

; Solves func(argCoeff*x+argOffset)=value for func in sec/csc/cot,
; power already handled uniformly by normalizeReciprocalTerm above
; (the cot(theta)=0 special case forces power to 1, since that
; reduction is only valid for the bare, unpowered condition).
(define (solveTrigReciprocalPowerCase func value argCoeff argOffset power)
    (let ((normalized (normalizeReciprocalTerm func value)))
        (if (not (car normalized))
            (list "No real solutions (sec/csc are never 0)")
            (solveTrigPowerCase (car normalized) (cadr normalized) argCoeff argOffset
                (if (and (eqv? func 'cot) (= value 0)) 1 power)))))

; q*y^2 - v*y + p = 0 (y = the "direct" trig function's value), the
; equation p*reciprocalFunc(theta) + q*directFunc(theta) = v reduces to
; after multiplying through by directFunc(theta) -- e.g.
; sec(theta)+cos(theta)=v, p=q=1, becomes cos(theta)^2-v*cos(theta)+1=0.
; Vieta's gives product-of-roots = p/q, so whenever p!=0 (a real term
; was actually there) neither root is ever exactly 0 -- meaning
; directFunc(theta)=0 (which would make the reciprocal side undefined)
; can never come out of this quadratic, so no extra domain filtering is
; needed here the way the trig=trig identity case (above) needed one.
(define (solveReciprocalPairQuadratic p q v)
    (if (= q 0)
        (error #f "solveTrigEquation: degenerate coefficient (0) on the direct trig term" q))
    (let ((disc (- (* v v) (* 4 p q))))
        (cond
            ((< disc 0) '())
            ((= disc 0) (list (/ v (* 2.0 q))))
            ('t (let ((sq (sqrt (exact->inexact disc))))
                    (list (/ (+ v sq) (* 2.0 q)) (/ (- v sq) (* 2.0 q))))))))

; Formats the general solution of a linear congruence coeff*x = const +
; period*k (k any integer) the same way solveBaseAngleCase's own
; per-angle formula does. coeff=0 is the degenerate case where x drops
; out entirely: either every x satisfies it (const an exact multiple of
; period -- a genuine identity, e.g. sin(x+90)=cos(x)) or no x does
; (skipped, since the OTHER branch of a two-branch identity, e.g.
; sin(A)=cos(B)'s two ± branches, may still be the real answer).
;
; domainOk? is an (x) -> boolean predicate, checked once at the
; branch's own base x (n=0) -- sufficient because every branch here has
; period 360 or 180, always a multiple of 180, which is also the period
; of a sin/cos zero-crossing set, so whether that base x lands on an
; excluded (reciprocal-function-undefined) point is constant across the
; WHOLE branch, never just some of it. See reciprocalDomainOk? below,
; the only caller that passes anything other than "always true".
;
; Known limitation: the coeff=0 "any real number" branch does NOT run
; domainOk? at all (there's no single base x to test -- the branch IS
; "every x"), so a self-identity like "sec(x)=sec(x)" reports "any real
; number" even though sec is actually undefined at x=90+180n. Excluding
; a periodic set of points from an "any real number" answer would need
; new output vocabulary ("all x except ...") this file doesn't have;
; left unfixed since no realistic equation reduces to this branch --
; only a literal self-equality (funcX(x)=funcX(x)) ever does, and it
; typically arrives alongside a correct, real, non-degenerate second
; branch anyway.
(define (formatLinearCongruenceSolutions coeff const period domainOk?)
    (cond
        ((= coeff 0)
            (if (integer? (/ const period))
                (list "x = any real number (identity)")
                '()))
        ('t
            (let* ((periodOut (/ period (abs coeff)))
                   (base (normalizeAngle (/ const coeff) periodOut)))
                (if (domainOk? base)
                    (list (formatAngleSolution base periodOut))
                    '())))))

; sin(c1*x+o1) = cos(c2*x+o2), via the co-function identity
; sin(A)=cos(90-A): cos(90-A)=cos(B) <=> 90-A = +-B + 360k, giving two
; linear-congruence branches in x.
(define (solveSinEqualsCos c1 o1 c2 o2 domainOk?)
    (append
        (formatLinearCongruenceSolutions (+ c1 c2) (- 90 o1 o2) 360 domainOk?)
        (formatLinearCongruenceSolutions (- c1 c2) (+ (- 90 o1) o2) 360 domainOk?)))

; func1(c1*x+o1) = func2(c2*x+o2), where the RHS is itself a trig call
; (e.g. "sin(x)=cos(x)") rather than a plain value -- a different
; solving family from the rest of this file (a periodic-identity
; reduction to one or two linear congruences in x, not a base-angle
; lookup). sin/cos with each other or themselves reduce cleanly via the
; standard equal-value/co-function identities; tan mixed with sin/cos
; has no such simple periodic-shift identity (tan(A)=sin(B) is a
; genuinely different, non-elementary equation), so that combination is
; a clear "not supported" error rather than a wrong or missing answer.
; func1/func2 here are already reciprocal-normalized (sec->cos, csc->
; sin, cot->tan -- see solveTrigEquation's rhsCall dispatch); domainOk?
; is where the ORIGINAL (pre-normalization) function identity comes
; back in, to exclude points where a sec/csc/cot side was actually
; undefined (reciprocalDomainOk? below), or "always true" if neither
; side was sec/csc/cot.
(define (solveTrigIdentityEquation func1 c1 o1 func2 c2 o2 domainOk?)
    (cond
        ((and (eqv? func1 'sin) (eqv? func2 'sin))
            (append (formatLinearCongruenceSolutions (- c1 c2) (- o2 o1) 360 domainOk?)
                    (formatLinearCongruenceSolutions (+ c1 c2) (- 180 o1 o2) 360 domainOk?)))
        ((and (eqv? func1 'cos) (eqv? func2 'cos))
            (append (formatLinearCongruenceSolutions (- c1 c2) (- o2 o1) 360 domainOk?)
                    (formatLinearCongruenceSolutions (+ c1 c2) (- (- o1) o2) 360 domainOk?)))
        ((and (eqv? func1 'tan) (eqv? func2 'tan))
            (formatLinearCongruenceSolutions (- c1 c2) (- o2 o1) 180 domainOk?))
        ((and (eqv? func1 'sin) (eqv? func2 'cos)) (solveSinEqualsCos c1 o1 c2 o2 domainOk?))
        ((and (eqv? func1 'cos) (eqv? func2 'sin)) (solveSinEqualsCos c2 o2 c1 o1 domainOk?))
        ('t (error #f "solveTrigEquation: equating these two trig functions is not supported" (list func1 func2)))))

; Whether func1(argCoeff1*x+argOffset1) = func2(argCoeff2*x+argOffset2)
; is actually DEFINED at x, given the ORIGINAL (pre-normalization)
; functions -- sec/csc/cot are undefined wherever their reciprocal
; partner is 0; sin/cos/tan need no new check here (their own domain
; issues, e.g. tan's, are pre-existing and out of scope, unchanged by
; this).
(define (reciprocalSideOk? funcRaw argCoeff argOffset x)
    (let ((angle (+ (* argCoeff x) argOffset)))
        (case funcRaw
            ((sec) (> (abs (cosDeg angle)) 1e-9))
            ((csc) (> (abs (sinDeg angle)) 1e-9))
            ((cot) (> (abs (sinDeg angle)) 1e-9))
            ('t 't))))

(define (reciprocalDomainOk? func1Raw c1 o1 func2Raw c2 o2)
    (lambda (x) (and (reciprocalSideOk? func1Raw c1 o1 x) (reciprocalSideOk? func2Raw c2 o2 x))))

(define (bothInSinCosTan? f1 f2) (and (memv f1 '(sin cos tan)) (memv f2 '(sin cos tan))))

; func1(A)=func2(B) is equivalent to reciprocalPartner(func1)(A) =
; reciprocalPartner(func2)(B) -- reciprocating BOTH sides of any x=y is
; valid whenever x and y are both defined/nonzero, which they must be
; for the original functions to be defined at all. So there are two
; candidate rewritings of the SAME equation: the original pairing, and
; the fully-reciprocated pairing. This only reaches
; solveTrigIdentityEquation's periodic-identity territory if EITHER one
; lands with both sides in {sin, cos, tan} -- picking the wrong half
; (reciprocating only ONE side) gives an algebraically different, WRONG
; equation. sec(A)=sin(B) is a clear example: naively swapping just the
; sec side gives "cos(A)=sin(B)", which LOOKS like the supported
; co-function identity and would silently return a wrong answer (this
; was caught live: sec(x)=sin(x) returned "x=45+180n", but
; sec(45)~=1.414 != sin(45)~=0.707 -- not actually a solution). The
; correct reciprocal of sin is csc, not sin itself, so the fully-
; reciprocated pairing here is (cos, csc) -- csc still isn't in
; {sin, cos, tan}, and neither is the original (sec, sin), so this
; combination is correctly unsupported, not a coincidentally-similar
; supported one.
(define (normalizeIdentityPair func1 func2)
    (cond
        ((bothInSinCosTan? func1 func2) (list func1 func2))
        ((bothInSinCosTan? (reciprocalPartner func1) (reciprocalPartner func2))
            (list (reciprocalPartner func1) (reciprocalPartner func2)))
        ('t #f)))

; a*sin(theta) + b*cos(theta) = rhsValue, theta = argCoeff*x+argOffset,
; via the auxiliary-angle identity a*sin(theta)+b*cos(theta) =
; R*sin(theta+phi), R=sqrt(a^2+b^2), phi=atan2(b,a) -- so the equation
; reduces to sin(theta+phi) = rhsValue/R, solved the same asin/180-asin
; way solveNumericCase's sin case already does.
(define (solveTrigAuxiliaryAngle sinCoeff cosCoeff rhsValue argCoeff argOffset)
    (let* ((a (exact->inexact sinCoeff)) (b (exact->inexact cosCoeff))
           (r (sqrt (+ (* a a) (* b b)))))
        (if (= r 0)
            (error #f "solveTrigEquation: degenerate sin/cos combination (both coefficients zero)" (list sinCoeff cosCoeff)))
        (let ((effectiveValue (/ (exact->inexact rhsValue) r)))
            (if (> (abs effectiveValue) 1)
                (list "No real solutions (value out of range [-1, 1])")
                (let* ((phiDeg (/ (* (atan b a) 180) pi-const))
                       (angle1 (/ (* (asin effectiveValue) 180) pi-const))
                       (angle2 (- 180 angle1))
                       (periodOut (/ 360.0 argCoeff)))
                    (map (lambda (angle)
                             (formatAngleSolution (normalizeAngle (/ (- angle phiDeg argOffset) argCoeff) periodOut) periodOut))
                         (list angle1 angle2)))))))

; Two trig terms summed on the LHS (e.g. "sin(x)+cos(x)=1",
; "sec(x)+cos(x)=1"). Requires the exact same argument on both (a
; compound-argument mismatch, e.g. "sin(x)+cos(2x)", has no simple
; closed form) and no power on either. Three shapes:
;   - same function on both (e.g. "sin(x)+sin(x)") is really just a
;     scaled single term -- combine the coefficients and fall back to
;     the ordinary single-term path.
;   - exactly {sin, cos} -- the auxiliary-angle identity.
;   - a reciprocal pair (sec+cos, csc+sin, cot+tan, in either order) --
;     multiplying through by the "direct" function's own value turns it
;     into a quadratic in that value (solveReciprocalPairQuadratic).
; Any other combination (sec+sin, sec+tan, cot+sin, ...) has no simple
; closed form and is a clear "not supported" error, same reasoning as
; solveTrigIdentityEquation's tan-mixed case.
(define (solveTrigTwoTermCase t1 t2 rhsRightRaw)
    (if (not (and (= (termArgCoeff t1) (termArgCoeff t2)) (= (termArgOffset t1) (termArgOffset t2))))
        (error #f "solveTrigEquation: a sum of two trig terms is only supported when both have the exact same argument" (list t1 t2)))
    (if (not (and (= (termPower t1) 1) (= (termPower t2) 1)))
        (error #f "solveTrigEquation: a sum of two trig terms with a power is not supported" (list t1 t2)))
    (cond
        ((eqv? (termFunc t1) (termFunc t2))
            (let ((combinedCoeff (+ (termCoeff t1) (termCoeff t2))))
                (if (= combinedCoeff 0)
                    (error #f "solveTrigEquation: degenerate case (coefficients cancel entirely)" (list t1 t2)))
                (let ((value (/ (parseTrigRhsValue rhsRightRaw) combinedCoeff)))
                    (if (memv (termFunc t1) '(sec csc cot))
                        (solveTrigReciprocalPowerCase (termFunc t1) value (termArgCoeff t1) (termArgOffset t1) 1)
                        (solveTrigPowerCase (termFunc t1) value (termArgCoeff t1) (termArgOffset t1) 1)))))
        ((and (memv (termFunc t1) '(sin cos)) (memv (termFunc t2) '(sin cos)))
            (let* ((sinTerm (if (eqv? (termFunc t1) 'sin) t1 t2))
                   (cosTerm (if (eqv? (termFunc t1) 'cos) t1 t2)))
                (solveTrigAuxiliaryAngle (termCoeff sinTerm) (termCoeff cosTerm) (parseTrigRhsValue rhsRightRaw)
                    (termArgCoeff t1) (termArgOffset t1))))
        ((eqv? (reciprocalPartner (termFunc t1)) (termFunc t2))
            (let* ((reciprocalTerm (if (memv (termFunc t1) '(sec csc cot)) t1 t2))
                   (directTerm (if (memv (termFunc t1) '(sec csc cot)) t2 t1))
                   (roots (solveReciprocalPairQuadratic (termCoeff reciprocalTerm) (termCoeff directTerm) (parseTrigRhsValue rhsRightRaw))))
                (if (null? roots)
                    (list "No real solutions")
                    (let ((inRangeRoots (if (memv (termFunc directTerm) '(sin cos)) (filter (lambda (r) (<= (abs r) 1)) roots) roots)))
                        (if (null? inRangeRoots)
                            (list "No real solutions (value out of range [-1, 1])")
                            (apply append (map (lambda (r) (solveTrigValueCase (termFunc directTerm) r (termArgCoeff t1) (termArgOffset t1))) inRangeRoots)))))))
        ('t (error #f "solveTrigEquation: a sum of two trig terms is only supported for sin+cos, or a reciprocal pair (sec+cos, csc+sin, cot+tan), of the same argument" (list t1 t2)))))

; Solves a trig equation, e.g. (string->list "sin(x)=0") ->
; (list "x = 0° + 360°n" "x = 180° + 360°n"). See file header for scope.
; Dispatches on the LHS's term count and whether the RHS is a plain
; value or itself a trig call (parseWholeTrigCall) -- see
; solveTrigTwoTermCase/solveTrigIdentityEquation above for the two
; multi-term/identity families.
(define (solveTrigEquation eqChars)
    (let ((eq (stripSpaces (list->string eqChars))))
        (if (not (findStringCharPos #\= eq 0))
            (list "Error: No equals sign found")
            (let* ((eqIdx (findStringCharPos #\= eq 0))
                   (leftRaw (substring eq 0 eqIdx))
                   (rightRaw (substring eq (+ eqIdx 1) (string-length eq)))
                   (terms (map parseTrigTerm (splitSignedTermsParenAware leftRaw))))
                (for-each (lambda (term) (assertValidArgCoeff (termArgCoeff term))) terms)
                (let ((rhsCall (parseWholeTrigCall rightRaw)))
                    (cond
                        (rhsCall
                            (if (not (and (= (length terms) 1) (= (termCoeff (car terms)) 1) (= (termPower (car terms)) 1)))
                                (error #f "solveTrigEquation: equating with another trig function is only supported for a bare func(...) on each side (no leading coefficient or power)" eq)
                                (let* ((t1 (car terms))
                                       (func1Raw (termFunc t1))
                                       (func2Raw (car rhsCall))
                                       (arg2Parsed (parseTrigArgument (cadr rhsCall))))
                                    (assertValidArgCoeff (car arg2Parsed))
                                    (let ((normalized (normalizeIdentityPair func1Raw func2Raw)))
                                        (if (not normalized)
                                            (error #f "solveTrigEquation: equating these two trig functions is not supported" (list func1Raw func2Raw))
                                            (let* ((needsDomainCheck (or (memv func1Raw '(sec csc cot)) (memv func2Raw '(sec csc cot))))
                                                   (domainOk? (if needsDomainCheck
                                                                   (reciprocalDomainOk? func1Raw (termArgCoeff t1) (termArgOffset t1) func2Raw (car arg2Parsed) (cdr arg2Parsed))
                                                                   (lambda (x) 't)))
                                                   (solutions (solveTrigIdentityEquation
                                                                  (car normalized) (termArgCoeff t1) (termArgOffset t1)
                                                                  (cadr normalized) (car arg2Parsed) (cdr arg2Parsed) domainOk?)))
                                                (if (null? solutions) (list "No solutions") solutions)))))))
                        ((= (length terms) 1)
                            (let* ((t1 (car terms))
                                   (rhsValue (/ (parseTrigRhsValue (removeParens rightRaw)) (termCoeff t1))))
                                (if (memv (termFunc t1) '(sec csc cot))
                                    (solveTrigReciprocalPowerCase (termFunc t1) rhsValue (termArgCoeff t1) (termArgOffset t1) (termPower t1))
                                    (solveTrigPowerCase (termFunc t1) rhsValue (termArgCoeff t1) (termArgOffset t1) (termPower t1)))))
                        ((= (length terms) 2)
                            (solveTrigTwoTermCase (car terms) (cadr terms) (removeParens rightRaw)))
                        ('t (error #f "solveTrigEquation: only 1 or 2 trig terms on the left side are supported" eq))))))))

; solveTrigonometric is a pure passthrough to solveTrigEquation in C++.
(define (solveTrigonometric eqChars) (solveTrigEquation eqChars))

; ---- ms-symbol / expr-list integration ----

; Builds the two-token expression representing "FUNC(ARG)", e.g.
; (trigExpr 'sin (ms-fraction-str "x" "1")) represents sin(x).
(define (trigExpr funcName argMs) (list (ms-symbol 'function funcName) argMs))

; Solves a trig equation given as an expr-list LHS (built via trigExpr)
; and an ms-fraction RHS, e.g.
; (ms-solve-trig (trigExpr 'sin (ms-fraction-str "x" "1")) (ms-fraction-int 1 2))
; -> ("x = 30° + 360°n" "x = 150° + 360°n").
(define (ms-solve-trig lhsExpr rhsMs)
    (solveTrigEquation (string->list (string-append (expr->engine-str lhsExpr) "=" (ms-poly-str rhsMs)))))
