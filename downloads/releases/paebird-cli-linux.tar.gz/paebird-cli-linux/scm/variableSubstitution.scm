; variableSubstitution.scm -- implements the "@:setval"/"@:clearval"
; feature documented in README_COMMANDS.html as "Planned -- not yet
; implemented": substituting known numeric values for named variables
; in an expression, leaving any variable without an assigned value
; symbolic. Ported in spirit from the C++ engine's real (if apparently
; abandoned) MathSymbol::substituteVariables (Poly-Working/MathSymbol.cpp,
; ~line 11404): for each term, multiply the coefficient by value^degree
; for every variable with an assigned value, checking multivariable
; terms too. Generalized here to exact rationals (not just C++'s int)
; and to indexed-variable symbols (x_1, n_x, x_(x+1)), not just single
; characters.
;
; Requires recordPoly2.scm (record accessors, makep/makepx), mathHelp.scm
; (var?), expandParse.scm (parseExpansion, expandSum, combineLikeTerms),
; simplify.scm (unapplysigns), PolyStoSymbol.scm (recordToString),
; equationVariants.scm or radicalRationalSolve.scm (findStringCharPos),
; linearSystems.scm (parseFractionOrDecimal) to be loaded first.

; Attempts to substitute a numeric value for one (variable . exponent)
; occurrence. Returns (cons #t multiplier) if v has an assigned value in
; varValueAlist AND exponent is a plain integer; (cons #f 1) otherwise
; (either no value assigned, or a fractional exponent -- deliberately
; declined rather than producing an inexact/irrational result this
; engine otherwise keeps symbolic, e.g. via square-root notation).
(define (trySubstituteOne v exponent varValueAlist)
    (let ((assigned (assq v varValueAlist)))
        (if (and assigned (integer? exponent))
            (cons #t (expt (cdr assigned) exponent))
            (cons #f 1))))

; Substitutes known values into one <poly> term, checking both the
; primary `var` field and every entry in `xvars` (multivariable terms,
; e.g. the "y" in "3x^2y" -- xvars entries can themselves be
; indexed-variable symbols, not just plain letters, since var? already
; accepts both). Coefficient power (pn/pd) is unrelated to which
; variables appear and is always carried through unchanged.
;
; If the primary variable substitutes away but xvars still has
; unsubstituted entries, the first remaining xvars entry is promoted to
; primary (this engine's own invariant is that a constant term has an
; empty xvars -- see termVarAlist's '() result for constants). If
; everything substitutes, the term becomes a plain constant (var = 1,
; the existing non-variable sentinel). If the primary variable doesn't
; substitute, it stays primary and only xvars shrinks.
(define (substituteTermValues term varValueAlist)
    (let* ((primaryVar (var term))
           (isVar (var? primaryVar))
           (primaryExp (if isVar (/ (varPn term) (varPd term)) 0))
           (primaryResult (if isVar (trySubstituteOne primaryVar primaryExp varValueAlist) (cons #f 1)))
           (primarySubstituted? (car primaryResult))
           (primaryMultiplier (cdr primaryResult))
           (xvarsResults (map (lambda (p) (list p (trySubstituteOne (car p) (cdr p) varValueAlist))) (xvars term)))
           (xvarsMultiplier (apply * (map (lambda (r) (cdr (cadr r))) (filter (lambda (r) (car (cadr r))) xvarsResults))))
           (remainingXvars (map car (filter (lambda (r) (not (car (cadr r)))) xvarsResults)))
           (newCoeff (* (/ (cn term) (cd term)) primaryMultiplier xvarsMultiplier)))
        (cond
            ((and isVar primarySubstituted? (pair? remainingXvars))
                (let ((newPrimary (car remainingXvars)) (restXvars (cdr remainingXvars)))
                    (makepx (numerator newCoeff) (denominator newCoeff) (pn term) (pd term)
                            (car newPrimary) (numerator (cdr newPrimary)) (denominator (cdr newPrimary))
                            '+ restXvars)))
            ((or (not isVar) (and primarySubstituted? (null? remainingXvars)))
                (makep (numerator newCoeff) (denominator newCoeff) (pn term) (pd term) 1 1 1 '+))
            ('t
                (makepx (numerator newCoeff) (denominator newCoeff) (pn term) (pd term)
                        primaryVar (varPn term) (varPd term) '+ remainingXvars)))))

; Substitutes known values into a whole (true-signed) term list, then
; combines like terms -- confirmed safe: combineLikeTerms keys on
; termVarAlist, which is '() for every constant, so two separate
; constant terms produced by substitution merge into one via the same
; bucketing path multiplication/expandPower already rely on.
(define (substituteVariableValues termList varValueAlist)
    (combineLikeTerms (map (lambda (term) (substituteTermValues term varValueAlist)) termList)))

; Splits s on runs of one or more spaces, dropping empty pieces --
; tolerates multiple spaces and leading/trailing whitespace, unlike a
; naive single-space split.
(define (splitOnSpaces s)
    (let loop ((i 0) (start 0) (acc '()))
        (cond
            ((>= i (string-length s))
                (reverse (if (> i start) (cons (substring s start i) acc) acc)))
            ((eqv? (string-ref s i) #\space)
                (loop (+ i 1) (+ i 1) (if (> i start) (cons (substring s start i) acc) acc)))
            ('t (loop (+ i 1) start acc)))))

; Parses "x=3 y=1/2 x_1=5" (space-separated var=val pairs) into an
; alist of (symbol . exact-number). Deliberate departure from the
; documented C++ "@:setval <vars> <vals>" positional syntax (a
; concatenated string of single characters paired positionally with
; space-separated values) -- that format is physically incapable of
; naming a multi-character indexed variable like x_1. var=val pairs are
; unambiguous and trivially support both. A piece with no "=" is
; silently skipped rather than erroring the whole batch. Values may be
; integers, decimals, or fractions (parseFractionOrDecimal, linearSystems.
; scm, already handles a leading "-" itself).
(define (parseSetvalArg argString)
    (let loop ((pairs (splitOnSpaces argString)) (acc '()))
        (if (null? pairs)
            (reverse acc)
            (let* ((piece (car pairs))
                   (eqIdx (findStringCharPos #\= piece 0)))
                (if (not eqIdx)
                    (loop (cdr pairs) acc)
                    (loop (cdr pairs)
                          (cons (cons (string->symbol (substring piece 0 eqIdx))
                                      (parseFractionOrDecimal (substring piece (+ eqIdx 1) (string-length piece))))
                                acc)))))))

; True if tok is a plain "<letters>=<anything>" assignment token -- name
; portion purely alphabetic and non-empty. Used only by
; splitOneLineSetval to find where a one-line "@@:setval" directive's
; var=val prefix ends and its trailing expression begins; deliberately
; stricter than parseSetvalArg's own "any '=' means a pair" rule (which
; is safe there since @:setval's whole line is nothing BUT var=val
; pairs), because here an equation in the expression itself -- e.g.
; "x+1=y" -- contains a "=" too and must NOT be mistaken for a variable
; assignment.
(define (isPlainAssignmentToken? tok)
    (let ((eqIdx (findStringCharPos #\= tok 0)))
        (and eqIdx (> eqIdx 0)
             (let allAlpha ((i 0))
                 (or (>= i eqIdx)
                     (and (char-alphabetic? (string-ref tok i)) (allAlpha (+ i 1))))))))

; Splits a one-line "@@:setval <var=val ...> <expression>" directive's
; remainder into (values pairString expressionString) -- the persistent
; "@:setval" form never needs this because its var=val pairs occupy the
; whole line by themselves, with the expression on separate following
; lines; the one-line override crams both onto one line, so this scans
; space-separated tokens from the front, consuming while each looks like
; a plain assignment (isPlainAssignmentToken?), stopping at the first
; one that doesn't -- that token and everything after it is the
; expression.
(define (splitOneLineSetval s)
    (let loop ((tokens (splitOnSpaces s)) (pairTokens '()))
        (if (or (null? tokens) (not (isPlainAssignmentToken? (car tokens))))
            (values (join-strings (reverse pairTokens) " ") (join-strings tokens " "))
            (loop (cdr tokens) (cons (car tokens) pairTokens)))))

; Substitutes one plain expression piece (no "=") and renders it back
; to a string.
; Substitutes varValueAlist into piece. Uses classifyFrac (expandParse.scm
; -- the same path solvePoly.scm's parseEquationToZero and factor()'s own
; rational-expression support already use), not the old plain expandSum,
; since expandSum unconditionally rejects ANY variable denominator --
; including one that would fully resolve to a plain CONSTANT once
; substituted (e.g. "w/t" with t=5 known is just "w/5", perfectly fine),
; which used to make substitution silently no-op on the whole piece
; (substituteKnownValues's own outer guard catches expandSum's error and
; falls back to the unmodified original line -- a caller had no way to
; tell "nothing needed substituting" apart from "substitution quietly
; failed"). Found live via physics module Phase 3's power command
; (p=w/t) -- the exact same class of gap already fixed once in
; solvePoly.scm's parseEquationToZero for solve() itself.
;
; A 'whole classification substitutes and renders exactly as before. A
; 'fraction classification substitutes numerator and denominator
; separately; if the denominator substitutes down to a plain constant,
; folds it in (foldConstantDenom, expandParse.scm) and renders as an
; ordinary whole polynomial string, same as the 'whole case -- this is
; the common case for a physics equation like "p=w/t" once its
; variables are known. If the denominator still has a genuine variable
; left (not every variable in it was substituted), renders as a
; "(numer) / (denom)" fraction string, matching expand()'s own
; rational-expression rendering convention -- substitution can't
; silently drop a denominator that's still genuinely there.
(define (substituteOnePiece piece varValueAlist)
    (let ((classified (classifyFrac (parseExpansion (string->list piece)))))
        (cond
            ((eqv? (car classified) 'whole)
                (recordToString (unapplysigns (substituteVariableValues (cdr classified) varValueAlist))))
            ((eqv? (car classified) 'fraction)
                (let* ((numer (substituteVariableValues (car (cdr classified)) varValueAlist))
                       (denom (substituteVariableValues (cdr (cdr classified)) varValueAlist)))
                    (if (and (= (length denom) 1) (not (var? (var (car denom)))))
                        (recordToString (unapplysigns (foldConstantDenom numer (car denom))))
                        (string-append "(" (recordToString (unapplysigns numer)) ") / (" (recordToString (unapplysigns denom)) ")"))))
            ('t (error #f "substituteOnePiece: matrix input isn't supported here" piece)))))

; String-level entry point: substitutes every assigned variable's
; value into line. Splits on the first "=" if present (equations) and
; substitutes each side independently, else treats the whole line as
; one expression. Falls back to the ORIGINAL, unmodified line if
; parsing throws -- e.g. the line contains matrix brackets, "!", or
; chemistry notation, anything parseExpansion doesn't understand -- so
; substitution silently declines rather than corrupting or erroring an
; otherwise-valid line. A no-op (returns line unchanged) whenever
; varValueAlist is empty, to avoid parsing overhead for the common
; no-setval-active case.
(define (substituteKnownValues line varValueAlist)
    (if (null? varValueAlist)
        line
        (guard (c (#t line))
            (let ((eqIdx (findStringCharPos #\= line 0)))
                (if eqIdx
                    (string-append (substituteOnePiece (substring line 0 eqIdx) varValueAlist)
                                   "="
                                   (substituteOnePiece (substring line (+ eqIdx 1) (string-length line)) varValueAlist))
                    (substituteOnePiece line varValueAlist))))))
