; workEnergy.scm -- physics module Phase 3: Work, Energy, Power
; (project_physics_module.md's Mechanics curriculum order, item 3).
; Five small, independent formula-relations, each a thin wrapper over
; physicsSolve.scm's solvePhysicsCommand -- no new solving logic
; anywhere, matching dynamics.scm's own precedent for bundling a whole
; curriculum-order topic into one file.
;
; Depends on: physicsUnits.scm (dimEnergy/dimPower and the shared role
; table), physicsSolve.scm (solvePhysicsCommand). Load this file after
; physicsSolve.scm.
;
; Variable letters (all single lowercase, per mathHelp.scm's var?
; constraint -- see dynamics.scm's own header for why): w=work/energy,
; k=kinetic energy, e=gravitational PE, g=gravitational acceleration
; (its own symbol, not a reused 'a' -- see physicsUnits.scm's
; physicsRoleTable comment), h=height, p=power. f/m/t/u/v/d are already
; established (Newton's law, SUVAT).

; ---- Work: w = f*d ----
; Scope: force along the direction of motion only. The angled case
; (w=f*d*cos(theta)) is deliberately out of scope, same as circular
; motion's own "just the core relations" boundary (Phase 2) -- solve()'s
; pure-polynomial engine has no trig-equation-solving concept at all, so
; theta would need to be pre-evaluated to a plain number before ever
; reaching an equation string here, a different and more involved
; feature than anything else in this file.
(define workVars '(w f d))
(define workEquations (list "w=f*d"))

; ---- Kinetic energy: k = 1/2*m*v^2 ----
; Solving for v can branch (+/-), same as SUVAT/circular's own quadratic
; steps -- a given kinetic energy is equally consistent with either
; direction of motion.
(define kineticVars '(k m v))
(define kineticEquations (list "k=1/2*m*v^2"))

; ---- Gravitational potential energy: e = m*g*h ----
; A pure product of three linear terms -- solving for any one of e/m/g/h
; given the other three is always linear, never branches.
(define gravpeVars '(e m g h))
(define gravpeEquations (list "e=m*g*h"))

; ---- Power: p = w/t, p = f*v ----
; 5 variables, 2 equations. Unlike SUVAT/circular, NOT every "give any 3
; of 5" combination is solvable here -- p is the only variable common to
; both equations, so w and t are only ever related to EACH OTHER (never
; independently to f or v), and likewise f and v are only ever related
; to each other. Missing {w,t} or missing {f,v} is therefore genuinely
; underdetermined (one equation, two unknowns, with the other equation
; unable to help at all) regardless of which third variable is given --
; confirmed by hand-tracing all 10 combinations, not by assumption. Both
; of those two report a clear "could not solve" error rather than
; guessing; the other 8 combinations all solve correctly (p is what
; makes them solvable -- e.g. knowns {w,t,f}: p comes from the first
; equation alone, then v from the second). Missing {w,t} with knowns
; {p,f,v} specifically was also what surfaced physicsSolve.scm's
; tryPhysicsEquation hardening (see that file's own comment) -- the
; second equation becomes fully determined once p is known, which
; needed an explicit fix even though the combination itself turned out
; to be unsolvable anyway.
(define powerVars '(p w t f v))
(define powerEquations (list "p=w/t" "p=f*v"))

; ---- Work-energy theorem: w = 1/2*m*v^2 - 1/2*m*u^2 ----
; Reuses SUVAT's own u/v (initial/final velocity) convention directly --
; the physical meaning lines up exactly. Solving for u or v can branch
; (+/-), same reasoning as kineticCommand above.
(define workenergyVars '(w m u v))
(define workenergyEquations (list "w=1/2*m*v^2-1/2*m*u^2"))
