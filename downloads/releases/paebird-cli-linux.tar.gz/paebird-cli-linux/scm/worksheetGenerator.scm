; Worksheet generation, ported from the C++ engine's WorksheetGenerator
; (Poly-Working/WorksheetGenerator.cpp -- not vendored into this repo's
; vendor/cpp/, which only has MathSymbol; read directly from the
; sibling Poly-Working checkout instead). Requires expandParse.scm,
; factorPoly.scm, solvePoly.scm, calcPoly.scm, equationVariants.scm
; (for solveExponential/solveLogarithm), and conicSections.scm (for
; analyzeConic, used by the conic-section worksheet type) to be loaded
; first.
;
; Ported from ../worksheetGenerator.scm (MIT Scheme) to Chez Scheme.
; Changes:
;   - Both (error "msg" type) call sites get an explicit #f who-arg.
;   - get-universal-time/universal-time->string are MIT-only (confirmed
;     unbound in Chez); currentTimestamp uses Chez's own (date-and-time),
;     which already returns a formatted string directly (e.g. "Sat Jul 11
;     22:53:23 2026") -- not textually identical to MIT's format, but
;     nothing golden-tests this (it's a generated-file timestamp, not
;     reproducible across runs either way).
;   - All 5 open-output-file call sites get an explicit 'replace second
;     arg: Chez's open-output-file errors ("file exists") if the target
;     already exists, unlike MIT's, which silently overwrites (confirmed
;     empirically against both binaries) -- 'replace restores MIT's
;     overwrite behavior.
;   - random, list-ref, assoc, filter, open-output-file/close-port (given
;     'replace, above) all verified present in Chez with matching
;     MIT-compatible signatures -- no changes needed for those.
;
; Unlike expand/factor/solve/calc (each checked against the C++ engine
; as an oracle), this file's solution generation does NOT replicate the
; C++ WorksheetGenerator's own logic -- it reuses this codebase's
; already-verified expand/factor/solve/differentiate/integrate/
; analyzeConic functions directly. This was a deliberate choice:
; inspecting actual past output from the C++ generator (committed CSVs
; in the Poly-Working tree) showed its calculus solutions are seriously
; broken, e.g. differentiating "-3b-3b+5b^4+4b^4" gives "-3 - 3 + 20b^3
; + 16b^3" (the terms are never combined, neither in the restated
; problem nor the answer), and integrating "5z^4+4z+2z^2" gives "5z *
; z^5/5 + + 4z * z^2/2 + + 2z * z^3/3 + C" (a display bug -- "5z *
; z^5/5" should just be "z^5" -- with the same spurious double "+" bug
; documented in calcPoly.scm). Since this codebase's own calculus
; functions are independently verified against 1000 closed-form cases,
; building the worksheet generator on top of them sidesteps this
; entire class of bug rather than reproducing it.
;
; Problems are generated so a clean answer is *guaranteed* (e.g.
; factoring problems are built by expanding chosen integer roots,
; rather than picking random coefficients and hoping they factor).
;
; ---- Remaining gaps closed here ----
; Three of the four originally-missing pieces (cpp-vs-scheme-gaps.md):
; conic-section worksheets (below, reusing analyzeConic), a MIXED
; *difficulty* mode (distinct from the 'mixed *type* mode already
; above -- C++ has both: a WorksheetType::MIXED_PRACTICE that varies
; the problem TYPE per problem, matching this file's existing 'mixed,
; and a separate DifficultyLevel::MIXED that varies EASY/MEDIUM/HARD
; per problem, which this file didn't have until now), and HTML export
; (MathJax) -- all pure output-formatting/generation logic with a
; C++ reference to check against, so ported directly. PDF export is
; scoped down: C++'s exportToPDF shells out to an installed `pdflatex`
; binary (`system("pdflatex ...")`) to compile a temp .tex file --
; that's an external-tool dependency, not math-engine logic, so this
; file generates the LaTeX *source* (the portable, testable part,
; verified structurally) but doesn't attempt to invoke a PDF compiler.

; Note: helperS.scm defines its OWN `remove`, with signature (remove
; element list) -- it removes one occurrence of a literal value, NOT
; SRFI-1's (remove predicate list). Passing a predicate lambda to it
; silently removes nothing (no list element is ever eqv? to a lambda),
; which doesn't error -- it just silently fails. This bit the first
; draft of genCalculusPolynomial below (its degree-without-replacement
; picker looked correct but always failed to shrink its candidate
; pool, occasionally producing uncombined duplicate-degree terms like
; "3z^2+z^2"); fixed by calling (remove pick avail) directly.

(define variablePool '(a b c m n p q r s t u v w y z))
(define (randomVariable) (list-ref variablePool (random (length variablePool))))

; Random nonzero integer in [-mag, mag] (excludes 0).
(define (randomNonzero mag)
    (let ((n (- (random (+ (* 2 mag) 1)) mag)))
        (if (= n 0) 1 n)))

(define (randomInt mag) (- (random (+ (* 2 mag) 1)) mag))

(define (difficultyRange difficulty)
    (cond
        ((eqv? difficulty 'easy) 5)
        ((eqv? difficulty 'medium) 10)
        ((eqv? difficulty 'hard) 15)
        ('t 10)))

(define (range n) (let loop ((i 0) (acc '())) (if (>= i n) (reverse acc) (loop (+ i 1) (cons i acc)))))

; Formats a single "coeff*var^deg" term as a signed string piece
; suitable for direct concatenation (e.g. "+3x^2", "-x", "+5"),
; omitting a coefficient of 1 (but not -1, which prints as "-var").
(define (termPiece coeff v deg)
    (let* ((sign (if (< coeff 0) "-" "+"))
           (mag (abs coeff))
           (magStr (if (and (= mag 1) (> deg 0)) "" (number->string mag)))
           (varStr (cond ((= deg 0) "") ((= deg 1) (symbol->string v)) ('t (string-append (symbol->string v) "^" (number->string deg))))))
        (string-append sign magStr varStr)))

; Concatenates termPiece strings into one expression, dropping any
; zero terms and stripping the leading "+" (or returning "0" if
; everything cancelled).
(define (joinTermPieces pieces)
    (let* ((nonZero (filter (lambda (p) (not (string=? p "+0"))) pieces))
           (s (apply string-append nonZero)))
        (cond
            ((= (string-length s) 0) "0")
            ((eqv? (string-ref s 0) #\+) (substring s 1 (string-length s)))
            ('t s))))

; ---- Problem generators ----
;
; Each returns a bare problem string (no "factor "/"solve "/etc.
; prefix -- generateWorksheet adds the appropriate display wrapper).

; Expansion: "(ax+b)(cx+d)" or "(ax+b)^2".
(define (genExpansionProblem difficulty)
    (let* ((v (randomVariable))
           (mag (difficultyRange difficulty))
           (coeffMag (if (eqv? difficulty 'easy) 3 5))
           (a (randomNonzero coeffMag)) (b (randomInt mag))
           (c (randomNonzero coeffMag)) (d (randomInt mag))
           (factor1 (string-append "(" (joinTermPieces (list (termPiece a v 1) (termPiece b v 0))) ")"))
           (useSquare (and (not (eqv? difficulty 'hard)) (= (random 2) 0))))
        (if useSquare
            (string-append factor1 "^2")
            (string-append factor1 "(" (joinTermPieces (list (termPiece c v 1) (termPiece d v 0))) ")"))))

; Factoring: picks 2 (easy/medium) or 3 (hard) small integer roots and
; builds the EXPANDED polynomial from them, guaranteeing it factors.
(define (genFactoringProblem difficulty)
    (let* ((v (randomVariable))
           (numRoots (if (eqv? difficulty 'hard) 3 2))
           (mag (if (eqv? difficulty 'easy) 6 10))
           (roots (let loop ((n numRoots) (acc '())) (if (= n 0) acc (loop (- n 1) (cons (randomNonzero mag) acc)))))
           (factorStrs (map (lambda (r) (string-append "(" (joinTermPieces (list (termPiece 1 v 1) (termPiece (- r) v 0))) ")")) roots))
           (factoredForm (apply string-append factorStrs)))
        (expand (string->list factoredForm))))

; Algebraic solving: linear "ax+b=c" (easy/medium), or a quadratic
; "ax^2+bx+c=0" built from two integer roots (hard), so it's always
; rational-root solvable. Linear answers are deliberately left as
; exact rationals (e.g. m = 3/2) -- answers stay symbolic, not forced
; to whole numbers.
(define (genSolvingProblem difficulty)
    (let ((v (randomVariable)) (mag (difficultyRange difficulty)))
        (if (eqv? difficulty 'hard)
            (let* ((r1 (randomNonzero 8)) (r2 (randomNonzero 8)) (a (randomNonzero 3))
                   (factor1 (string-append "(" (joinTermPieces (list (termPiece a v 1) (termPiece (- r1) v 0))) ")"))
                   (factor2 (string-append "(" (joinTermPieces (list (termPiece 1 v 1) (termPiece (- r2) v 0))) ")"))
                   (expanded (expand (string->list (string-append factor1 factor2)))))
                (string-append expanded "=0"))
            (let ((a (randomNonzero 9)) (b (randomInt mag)) (c (randomInt mag)))
                (string-append (joinTermPieces (list (termPiece a v 1) (termPiece b v 0))) "=" (number->string c))))))

; Exponential solving: "base^(ax+b)=value", where value is
; pre-computed as base^k for a chosen integer k, guaranteeing an exact
; rational solution (x = (k-b)/a, left symbolic).
(define (genExponentialProblem difficulty)
    (let* ((v (randomVariable))
           (base (+ 2 (random 4)))
           (a (randomNonzero (if (eqv? difficulty 'easy) 2 3)))
           (b (randomInt (if (eqv? difficulty 'easy) 3 6)))
           (k (randomInt (if (eqv? difficulty 'hard) 5 4)))
           (value (expt base k))
           (expChars (joinTermPieces (list (termPiece a v 1) (termPiece b v 0)))))
        (string-append (number->string base) "^(" expChars ")=" (number->string value))))

; Logarithmic solving: "log_base(x+offset)=k", guaranteeing the
; argument evaluates to the exact integer base^k.
(define (genLogarithmProblem difficulty)
    (let* ((v (randomVariable))
           (base (+ 2 (random 4)))
           (k (+ 1 (random (if (eqv? difficulty 'hard) 4 3))))
           (offset (randomInt (if (eqv? difficulty 'easy) 3 6)))
           (argStr (joinTermPieces (list (termPiece 1 v 1) (termPiece offset v 0)))))
        (string-append "log_" (number->string base) "(" argStr ")=" (number->string k))))

; Calculus: a random already-simplified polynomial (2-3 distinct-
; degree terms) for differentiation or integration practice.
(define (genCalculusPolynomial difficulty)
    (let* ((v (randomVariable))
           (maxDeg (cond ((eqv? difficulty 'easy) 3) ((eqv? difficulty 'hard) 5) ('t 4)))
           (mag (difficultyRange difficulty))
           (numTerms (+ 2 (random 2)))
           (degsUsed (let loop ((n numTerms) (acc '()) (avail (range (+ maxDeg 1))))
                         (if (or (= n 0) (null? avail))
                             acc
                             (let ((pick (list-ref avail (random (length avail)))))
                                 (loop (- n 1) (cons pick acc) (remove pick avail))))))
           ; Standard form: highest degree first ("-12a^4+10a^3", not
           ; "-9y+8-12y^5" in whatever order the picker drew them).
           (pieces (map (lambda (d) (termPiece (randomNonzero mag) v d)) (sort > degsUsed))))
        (joinTermPieces pieces)))

; Signed constant piece for direct concatenation, e.g. 3 -> "+3",
; -2 -> "-2", 0 -> "".
(define (signedOffset n)
    (cond ((= n 0) "")
          ((> n 0) (string-append "+" (number->string n)))
          ('t (string-append "-" (number->string (- n))))))

; Conic section: circle, parabola, ellipse, or hyperbola in standard
; form, chosen at random -- matching C++'s generateConicSectionProblems'
; 4 patterns. Doesn't vary by difficulty (neither does C++'s version).
; Parabola is generated as "y=a(x-h)^2+k" (fully on the right side)
; rather than C++'s own "y-k=a(x-h)^2" -- mathematically identical, but
; matches analyzeConic's accepted standard-form shape directly rather
; than requiring it to also recognize a shifted-left-hand-side variant.
; "(x-h)^2", or just "x^2" when h=0 (no pointless "(x)^2").
(define (shiftedSquare v h)
    (if (= h 0)
        (string-append (symbol->string v) "^2")
        (string-append "(" (symbol->string v) (signedOffset (- h)) ")^2")))

(define (genConicProblem difficulty)
    (let ((type (random 4)))
        (cond
            ((= type 0)
                (let ((h (randomInt 5)) (k (randomInt 5)) (r (+ 2 (random 7))))
                    (string-append (shiftedSquare 'x h) "+" (shiftedSquare 'y k) "=" (number->string (* r r)))))
            ((= type 1)
                (let* ((h (randomInt 3)) (k (randomInt 3)) (a (+ 1 (random 4)))
                       ; A leading coefficient of 1 is omitted ("y=x^2+2", not "y=1x^2+2").
                       (aStr (if (= a 1) "" (number->string a)))
                       (sq (shiftedSquare 'x h)))
                    (string-append "y=" aStr sq (signedOffset k))))
            ((= type 2)
                (let* ((a (+ 3 (random 6))) (b0 (+ 2 (random 5))) (b (if (>= b0 a) (max 1 (- a 1)) b0)))
                    (string-append "x^2/" (number->string (* a a)) "+y^2/" (number->string (* b b)) "=1")))
            ('t
                (let ((a (+ 2 (random 5))) (b (+ 2 (random 5))))
                    (string-append "x^2/" (number->string (* a a)) "-y^2/" (number->string (* b b)) "=1"))))))

; ---- Answer-text cleanup (worksheet-scoped) ----
; The engine's own number/term formatting is locked by golden tests
; (C++-oracle parity: "1x^3/3", MIT-style "2." / ".5"), and app users
; see those strings from @:integrate/@:conic. A worksheet answer key is
; read by a teacher, so it gets a presentation pass HERE instead of
; changing the shared engine output.

; Drops a redundant coefficient 1 -- a "1" at the start or right after
; "+"/"-" and immediately followed by a letter: "1u^2/2" -> "u^2/2",
; "-1z^4/2" -> "-z^4/2". Leaves "11u", "21x", "x^-1", "1/2" alone.
(define (tidyUnitCoefficients s)
    (let ((n (string-length s)))
        (let loop ((i 0) (acc '()))
            (if (>= i n)
                (list->string (reverse acc))
                (let ((c (string-ref s i)))
                    (if (and (char=? c #\1)
                             (or (= i 0) (memv (string-ref s (- i 1)) '(#\+ #\-)))
                             (< (+ i 1) n)
                             (char-alphabetic? (string-ref s (+ i 1))))
                        (loop (+ i 1) acc)
                        (loop (+ i 1) (cons c acc))))))))

; MIT-style flonum text -> ordinary decimals: "2." -> "2", ".5" -> "0.5".
; A "." between two digits is untouched.
(define (tidyDecimals s)
    (let ((n (string-length s)))
        (let loop ((i 0) (acc '()))
            (if (>= i n)
                (list->string (reverse acc))
                (let* ((c (string-ref s i))
                       (prevDigit (and (> i 0) (char-numeric? (string-ref s (- i 1)))))
                       (nextDigit (and (< (+ i 1) n) (char-numeric? (string-ref s (+ i 1))))))
                    (cond
                        ((not (char=? c #\.)) (loop (+ i 1) (cons c acc)))
                        ((and prevDigit (not nextDigit)) (loop (+ i 1) acc))
                        ((and (not prevDigit) nextDigit) (loop (+ i 1) (cons #\. (cons #\0 acc))))
                        ('t (loop (+ i 1) (cons c acc)))))))))

(define (trimLeadingSpaces s)
    (let loop ((i 0))
        (if (and (< i (string-length s)) (char=? (string-ref s i) #\space))
            (loop (+ i 1))
            (substring s i (string-length s)))))

; analyzeConic returns a list of lines; a hyperbola's "Asymptotes:"
; header is its own item followed by two indented equation lines.
; Joining that list naively gave "Asymptotes:,   y - 0 = 2.(x - 0),   ...".
; Merges the header with its two lines, then joins the items with "; ".
(define (conicAnswerString lines)
    (let loop ((l lines) (items '()))
        (cond
            ((null? l) (tidyDecimals (joinWithSeparator "; " (reverse items))))
            ((and (string=? (car l) "Asymptotes:") (>= (length l) 3))
                (loop (cdddr l)
                      (cons (string-append "Asymptotes: " (trimLeadingSpaces (cadr l))
                                           " and " (trimLeadingSpaces (caddr l)))
                            items)))
            ('t (loop (cdr l) (cons (car l) items))))))

(define (joinWithSeparator sep lst)
    (let loop ((l lst) (acc ""))
        (cond
            ((null? l) acc)
            ((string=? acc "") (loop (cdr l) (car l)))
            ('t (loop (cdr l) (string-append acc sep (car l)))))))

; ---- Fraction arithmetic problems ----
; Simplest worksheet types here -- earlier in a student's progression
; than the algebra types above (see the calling task: worksheet types
; requested "working backward" from algebra toward more basic
; material). Denominators deliberately stay small even at 'hard, since
; the point is arithmetic fluency, not the large-coefficient difficulty
; scaling the algebra generators use.

; Formats a reduced (numerator denominator) pair (as returned by
; reducefrac/addfrac/etc., basicmath.scm) as a plain fraction string,
; e.g. (3 4) -> "3/4". A denominator of 1 (full cancellation, e.g.
; 6/3 -> 2/1) prints as a bare integer rather than "2/1".
(define (fracString n d)
    (if (= d 1) (number->string n) (string-append (number->string n) "/" (number->string d))))

(define (fracDenomMag difficulty)
    (cond ((eqv? difficulty 'easy) 6) ((eqv? difficulty 'hard) 12) ('t 9)))

; A random positive fraction, denominator in [2, mag], numerator in
; [1, 2*d] (so improper fractions like 7/4 are possible), reduced to
; lowest terms via reducefrac -- the fraction as GIVEN in a problem
; should already be simplified, same as how genFactoringProblem builds
; its polynomial from known roots rather than leaving cleanup work
; that isn't the point of the exercise.
(define (randomFraction mag)
    (let* ((d (+ 2 (random mag))) (n (+ 1 (random (* 2 d)))))
        (reducefrac n d)))

(define (genFracAddProblem difficulty)
    (let* ((mag (fracDenomMag difficulty)) (f1 (randomFraction mag)) (f2 (randomFraction mag)))
        (string-append (fracString (car f1) (cadr f1)) "+" (fracString (car f2) (cadr f2)))))

; Orders the two operands (larger minus smaller, compared by cross-
; multiplication) so the result is never negative -- standard practice
; for a fraction unit that predates signed-number fluency.
(define (genFracSubProblem difficulty)
    (let* ((mag (fracDenomMag difficulty)) (f1 (randomFraction mag)) (f2 (randomFraction mag))
           (cmp (- (* (car f1) (cadr f2)) (* (car f2) (cadr f1))))
           (big (if (>= cmp 0) f1 f2)) (small (if (>= cmp 0) f2 f1)))
        (string-append (fracString (car big) (cadr big)) "-" (fracString (car small) (cadr small)))))

; No parens needed around the second operand: a*/-chain of two
; fractions gives the same result regardless of left-to-right grouping
; (e.g. 3/4*5/6, grouped either way, reduces to 5/8).
(define (genFracMulProblem difficulty)
    (let* ((mag (fracDenomMag difficulty)) (f1 (randomFraction mag)) (f2 (randomFraction mag)))
        (string-append (fracString (car f1) (cadr f1)) "*" (fracString (car f2) (cadr f2)))))

; Unlike multiplication, division is NOT associative under left-to-
; right chaining (3/4/5/6 would parse as ((3/4)/5)/6, not (3/4)/(5/6)),
; so the second operand is always parenthesized.
(define (genFracDivProblem difficulty)
    (let* ((mag (fracDenomMag difficulty)) (f1 (randomFraction mag)) (f2 (randomFraction mag)))
        (string-append (fracString (car f1) (cadr f1)) "/(" (fracString (car f2) (cadr f2)) ")")))

; ---- Worksheet types and per-type problem/solution generation ----

(define worksheetTypes '(expand factor solve solveexp solvelog diff integ conic))
(define fractionWorksheetTypes '(fracadd fracsub fracmul fracdiv))

; The pool 'mixed/'fracmixed each draw a random concrete type from --
; kept as separate pools (rather than one combined list) since mixing
; fraction-arithmetic problems into the same worksheet as algebra
; problems would defeat the point of having a level-appropriate type
; at all.
(define (mixedPoolFor type)
    (if (eqv? type 'fracmixed) fractionWorksheetTypes worksheetTypes))

(define (genProblemOfType type difficulty)
    (cond
        ((eqv? type 'expand) (genExpansionProblem difficulty))
        ((eqv? type 'factor) (genFactoringProblem difficulty))
        ((eqv? type 'solve) (genSolvingProblem difficulty))
        ((eqv? type 'solveexp) (genExponentialProblem difficulty))
        ((eqv? type 'conic) (genConicProblem difficulty))
        ((eqv? type 'solvelog) (genLogarithmProblem difficulty))
        ((eqv? type 'diff) (genCalculusPolynomial difficulty))
        ((eqv? type 'integ) (genCalculusPolynomial difficulty))
        ((eqv? type 'fracadd) (genFracAddProblem difficulty))
        ((eqv? type 'fracsub) (genFracSubProblem difficulty))
        ((eqv? type 'fracmul) (genFracMulProblem difficulty))
        ((eqv? type 'fracdiv) (genFracDivProblem difficulty))
        ('t (error #f "genProblemOfType: unknown type" type))))

(define (joinSolutionList lst)
    (let loop ((l lst) (acc ""))
        (cond
            ((null? l) acc)
            ((string=? acc "") (loop (cdr l) (car l)))
            ('t (loop (cdr l) (string-append acc ", " (car l)))))))

; Display form of a fraction-division problem: the solver receives the
; "a/b/(c/d)" chain (so parsing stays unambiguous), but a student should
; see "a/b ÷ c/d", not a nested complex fraction.
(define (fracDivDisplay p)
    (let ((i (findStringCharPos #\( p 0)))
        (if (and i (> i 0) (char=? (string-ref p (- i 1)) #\/))
            (string-append (substring p 0 (- i 1)) " ÷ " (substring p (+ i 1) (- (string-length p) 1)))
            p)))

; Returns (list prompt exprRaw solutionRaw) for one problem of the given
; type, using this codebase's own verified solvers -- e.g. ("Solve"
; "2m-1=2" "m = 3/2"). All three are PLAIN ASCII math (plus the engine's
; own √/π symbols): no Unicode super/subscripts yet, so the structure
; survives for worksheetMath.scm's TeX and MathML emitters.
(define (genWorksheetItemRaw type difficulty)
    (let* ((p (genProblemOfType type difficulty)))
        (cond
            ((eqv? type 'expand) (list "Expand" p (expand (string->list p))))
            ((eqv? type 'factor) (list "Factor" p (factor (string->list p))))
            ((eqv? type 'solve) (list "Solve" p (joinSolutionList (solve (string->list p)))))
            ((eqv? type 'solveexp) (list "Solve" p (joinSolutionList (solveExponential (string->list p)))))
            ((eqv? type 'solvelog) (list "Solve" p (joinSolutionList (solveLogarithm (string->list p)))))
            ((eqv? type 'diff) (list "Differentiate" p (differentiateExpr (string->list p))))
            ((eqv? type 'integ) (list "Integrate" p (tidyUnitCoefficients (integrateExpr (string->list p)))))
            ((eqv? type 'conic) (list "Analyze" p (conicAnswerString (analyzeConic (string->list p)))))
            ; Fraction arithmetic reuses expand() directly (same
            ; rational-coefficient arithmetic expandParse.scm already
            ; uses for polynomial coefficients) rather than a
            ; separate fraction evaluator -- p is already a pure
            ; numeric expression (no variable), so expand() just
            ; reduces it to a single fraction.
            ((eqv? type 'fracadd) (list "Simplify" p (expand (string->list p))))
            ((eqv? type 'fracsub) (list "Simplify" p (expand (string->list p))))
            ((eqv? type 'fracmul) (list "Simplify" p (expand (string->list p))))
            ((eqv? type 'fracdiv) (list "Simplify" (fracDivDisplay p) (expand (string->list p))))
            ('t (error #f "genWorksheetItemRaw: unknown type" type)))))

; Unicode-notation pair (problem . solution) for one raw item: CSV, JSON
; and the app's text views. Both strings go through toSubscriptNotation
; (subscriptFormat.scm) and THEN toSuperscriptNotation
; (superscriptFormat.scm) before returning, same order as
; dispatcher.scm's safeApplyCommand and for the same reason (see its own
; comment) -- the other choke point every worksheet's problem/answer text
; passes through.
(define (itemToUnicodePair item)
    (cons (toSuperscriptNotation (toSubscriptNotation (string-append (car item) ": " (cadr item))))
          (toSuperscriptNotation (toSubscriptNotation (caddr item)))))

; Returns (cons displayProblemString solutionString) for one problem
; of the given type, in Unicode notation.
(define (genProblemAndSolution type difficulty)
    (itemToUnicodePair (genWorksheetItemRaw type difficulty)))

; "mixed"/"fracmixed" pick a random type from their respective pool
; (mixedPoolFor) per problem instead of a fixed one.
(define (genMixedProblemAndSolution type difficulty)
    (let ((pool (mixedPoolFor type)))
        (genProblemAndSolution (list-ref pool (random (length pool))) difficulty)))

; ---- Top-level worksheet data generation ----

(define typeDisplayNames '(
    (expand . "Polynomial Expansion")
    (factor . "Polynomial Factoring")
    (solve . "Algebraic Solving")
    (solveexp . "Exponential Equation Solving")
    (solvelog . "Logarithmic Equation Solving")
    (diff . "Calculus - Differentiation")
    (integ . "Calculus - Integration")
    (conic . "Conic Sections")
    (mixed . "Mixed Practice")
    (fracadd . "Fraction Addition")
    (fracsub . "Fraction Subtraction")
    (fracmul . "Fraction Multiplication")
    (fracdiv . "Fraction Division")
    (fracmixed . "Fraction Operations (Mixed)")))

(define (typeDisplayName type) (cdr (assoc type typeDisplayNames)))

; 'mixed here is a DIFFERENT axis than the 'mixed worksheet TYPE above
; -- C++ has both a WorksheetType::MIXED_PRACTICE (varies the problem
; type per problem, matching this file's existing genMixedProblemAndSolution)
; and a separate DifficultyLevel::MIXED (varies easy/medium/hard per
; problem, independent of which type is being generated) -- resolved
; per-problem in generateProblemSet below via resolveDifficulty.
(define difficultyDisplayNames '((easy . "Easy") (medium . "Medium") (hard . "Hard") (mixed . "Mixed")))
(define (difficultyDisplayName difficulty) (cdr (assoc difficulty difficultyDisplayNames)))

(define (resolveDifficulty difficulty)
    (if (eqv? difficulty 'mixed)
        (list-ref '(easy medium hard) (random 3))
        difficulty))

; Draws count items from makeOne (a thunk), skipping any whose key
; (the problem text) already appeared: retries up to 25 times per slot,
; then accepts the duplicate anyway -- small pools (easy conics,
; fractions) can't always supply count distinct problems, and a full
; worksheet beats an error.
(define (generateUniqueProblems count makeOne key)
    (let loop ((n count) (acc '()) (seen '()))
        (if (= n 0)
            (reverse acc)
            (let try ((attempt 0))
                (let* ((item (makeOne)) (k (key item)))
                    (if (and (member k seen) (< attempt 25))
                        (try (+ attempt 1))
                        (loop (- n 1) (cons item acc) (cons k seen))))))))

; Generates count (problem . solution) pairs for the given worksheet
; type and difficulty (type 'mixed randomly varies the type per
; problem; difficulty 'mixed randomly varies easy/medium/hard per
; problem -- the two are independent and can be combined). Problems
; within one worksheet are unique where the type's pool allows.
(define (generateProblemSet type difficulty count)
    (generateUniqueProblems count
        (lambda ()
            (let ((d (resolveDifficulty difficulty)))
                (if (or (eqv? type 'mixed) (eqv? type 'fracmixed))
                    (genMixedProblemAndSolution type d)
                    (genProblemAndSolution type d))))
        car))

; Like generateProblemSet, but returns raw items (prompt exprRaw
; solutionRaw actualType) -- the file writers need the ASCII structure
; and the concrete type (even under 'mixed) for TeX/MathML and layout.
(define (generateWorksheetItems type difficulty count)
    (generateUniqueProblems count
        (lambda ()
            (let* ((d (resolveDifficulty difficulty))
                   (actualType (resolveProblemType type)))
                (append (genWorksheetItemRaw actualType d) (list actualType))))
        (lambda (item) (string-append (car item) (cadr item)))))

; Makes a worksheet reproducible: the same seed (with the same type,
; difficulty and count) regenerates the identical problem set. Chez's
; random-seed needs an integer in [1, 4294967295].
(define *current-worksheet-seed* #f)
(define (seedWorksheetRandom n)
    (let ((code (modulo n 4294967295)))
        ; The recorded/printed "worksheet code" is n reduced into range,
        ; so passing the printed code back regenerates the same sheet.
        (set! *current-worksheet-seed* code)
        (random-seed (+ 1 code))))

; ---- JSON output (for PAE-API's HTTP worksheet endpoint) ----

; Escapes a string for embedding in a JSON string literal. Problem/answer
; text never contains raw control characters in practice, but this is
; defensive rather than assuming that always holds.
(define (jsonEscapeChar c)
    (cond
        ((eqv? c #\") "\\\"")
        ((eqv? c #\\) "\\\\")
        ((eqv? c #\newline) "\\n")
        ((eqv? c #\tab) "\\t")
        ('t (string c))))

(define (jsonEscapeString s)
    (apply string-append (map jsonEscapeChar (string->list s))))

; Resolves 'mixed/'fracmixed to one randomly-chosen concrete type from
; the matching pool (the same pick genMixedProblemAndSolution makes
; internally), otherwise returns type unchanged -- needed because
; genMixedProblemAndSolution itself never exposes which type it
; picked, but the JSON API needs to label each problem with its actual
; type.
(define (resolveProblemType type)
    (if (or (eqv? type 'mixed) (eqv? type 'fracmixed))
        (let ((pool (mixedPoolFor type)))
            (list-ref pool (random (length pool))))
        type))

; Like generateProblemSet, but returns a list of (problem solution
; typeLabel) triples instead of (problem . solution) pairs, so the
; caller knows the real per-problem type even when the requested type
; is 'mixed.
(define (generateProblemSetWithTypes type difficulty count)
    (generateUniqueProblems count
        (lambda ()
            (let* ((d (resolveDifficulty difficulty))
                   (actualType (resolveProblemType type))
                   (pair (genProblemAndSolution actualType d)))
                (list (car pair) (cdr pair) (typeDisplayName actualType))))
        car))

(define (problemTripleToJSON triple)
    (string-append "{\"problem\":\"" (jsonEscapeString (car triple))
                   "\",\"answer\":\"" (jsonEscapeString (cadr triple))
                   "\",\"type\":\"" (jsonEscapeString (caddr triple)) "\"}"))

; Local joiner rather than dispatcher.scm's join-strings -- this file is
; loaded by load-engine.scm (no dispatcher.scm dependency), so it must
; stay self-contained; joinSolutionList above isn't reused here since
; its separator (", ") is baked in and not a parameter.
(define (joinWithComma lst)
    (let loop ((l lst) (acc ""))
        (cond
            ((null? l) acc)
            ((string=? acc "") (loop (cdr l) (car l)))
            ('t (loop (cdr l) (string-append acc "," (car l)))))))

(define (problemSetToJSON triples)
    (string-append "[" (joinWithComma (map problemTripleToJSON triples)) "]"))

; ---- STEPS-FEATURE-PLAN.md's wire format ----
; {"result": "...", "steps": [{"rule": "...", "narration": "...", "expr": "...."}, ...]}
; -- the JSON shape dispatcher.scm's "differentiatesteps"/"solvesteps"/
; "expandsteps" compute commands return, for a <step> list (steps.scm)
; produced by diffExprWithSteps/solveWithSteps/expandWithSteps.

(define (stepToJSON step)
    (string-append "{\"rule\":\"" (jsonEscapeString (symbol->string (stepRule step)))
                   "\",\"narration\":\"" (jsonEscapeString (stepNarration step))
                   "\",\"expr\":\"" (jsonEscapeString (stepExpr step)) "\"}"))

(define (stepsToJSON steps)
    (string-append "[" (joinWithComma (map stepToJSON steps)) "]"))

(define (resultStepsToJSON resultStr steps)
    (string-append "{\"result\":\"" (jsonEscapeString resultStr) "\",\"steps\":" (stepsToJSON steps) "}"))

; Top-level JSON entry point for PAE-API's /worksheet route (see
; dispatcher.scm's "jsonworksheet" mode) -- generates the problems and
; returns them as a single JSON array string, with no file output
; (unlike generateWorksheet, which is for the app's CSV/HTML/LaTeX
; file-based worksheet feature).
(define (generateWorksheetJSON type difficulty count)
    (problemSetToJSON (generateProblemSetWithTypes type difficulty count)))

; ---- Output helpers ----

(define (twoDigits n) (if (< n 10) (string-append "0" (number->string n)) (number->string n)))

; YYYY-MM-DD (the old (date-and-time) string was long and locale-ish).
(define (currentTimestamp)
    (let ((d (current-date)))
        (string-append (number->string (date-year d)) "-" (twoDigits (date-month d)) "-" (twoDigits (date-day d)))))

(define (writeStringToFile filename s)
    (let ((port (open-output-file filename 'replace)))
        (display s port)
        (close-port port)))

(define (splitOn sep s)
    (let ((k (string-length sep)) (n (string-length s)))
        (let loop ((start 0) (i 0) (acc '()))
            (cond
                ((> (+ i k) n) (reverse (cons (substring s start n) acc)))
                ((string=? (substring s i (+ i k)) sep) (loop (+ i k) (+ i k) (cons (substring s start i) acc)))
                ('t (loop start (+ i 1) acc))))))

; A structured answer ("Type: Circle; Center: (0, 0); ...") is a list of
; "Label: value" facts; anything else is one math expression.
(define (answerFacts solution)
    (let ((parts (splitOn "; " solution)))
        (if (null? (cdr parts))
            #f
            (map (lambda (part)
                     (let ((i (let loop ((j 0))
                                  (cond ((>= (+ j 1) (string-length part)) #f)
                                        ((string=? (substring part j (+ j 2)) ": ") j)
                                        ('t (loop (+ j 1)))))))
                         (if i
                             (cons (substring part 0 i) (substring part (+ i 2) (string-length part)))
                             (cons #f part))))
                 parts))))

; ---- CSV output ----
; RFC-4180 quoting (embedded " doubled), a UTF-8 byte-order mark so Excel
; reads ², √, π correctly instead of mojibake, and NO "# comment" lines
; (they became junk rows on import). Just a header row and the data.

(define csvBOM (string (integer->char #xFEFF)))

(define (csvField s)
    (string-append "\""
        (apply string-append (map (lambda (c) (if (char=? c #\") "\"\"" (string c))) (string->list s)))
        "\""))

(define (worksheetCsvString pairs teacher?)
    (string-append csvBOM
        (if teacher? "Problem Number,Problem,Solution\n" "Problem Number,Problem\n")
        (let loop ((l pairs) (n 1) (acc ""))
            (if (null? l)
                acc
                (loop (cdr l) (+ n 1)
                      (string-append acc (number->string n) "," (csvField (car (car l)))
                                     (if teacher? (string-append "," (csvField (cdr (car l)))) "")
                                     "\n"))))))

; ---- HTML output ----
; One self-contained file: inline CSS, MathML for math (native in
; Safari/Chrome/Firefox, pastes into Word as real equations), no script
; tags and no external URLs -- so it renders offline and can't be broken
; or tampered with by a CDN. (The old pages loaded polyfill.io and a
; MathJax CDN.) Print rules keep each problem on one page.

(define worksheetCss
  (string-append
    "@page { margin: 2cm; }\n"
    "body { font-family: -apple-system, 'Segoe UI', Helvetica, Arial, sans-serif; font-size: 12pt; color: #111; max-width: 18cm; margin: 1.5cm auto; line-height: 1.4; }\n"
    "h1 { font-size: 20pt; margin: 0 0 0.2em; }\n"
    "h2 { font-size: 14pt; margin: 1.2em 0 0.4em; }\n"
    ".sub { color: #555; margin: 0 0 0.8em; }\n"
    ".name-line { display: flex; gap: 1.2em; margin: 0.8em 0; }\n"
    ".name-line span { flex: 1; border-bottom: 1px solid #333; padding-bottom: 0.9em; font-size: 10pt; color: #555; }\n"
    ".name-line span:first-child { flex: 2; }\n"
    ".instr { font-style: italic; margin: 0.4em 0 1em; }\n"
    "ol.problems { padding-left: 1.6em; }\n"
    "li.problem { margin: 0 0 1.1em; break-inside: avoid; page-break-inside: avoid; }\n"
    ".prompt { font-weight: 600; margin-right: 0.3em; }\n"
    "math { font-size: 1.15em; }\n"
    ".work { border: 1px dashed #bbb; border-radius: 4px; margin-top: 0.5em; }\n"
    ".answer { color: #0b4fb3; margin-top: 0.4em; }\n"
    ".answer .lab, .facts .lab { font-weight: 600; }\n"
    "ul.facts { margin: 0.2em 0 0; padding-left: 1.2em; }\n"
    "section.key { break-before: page; page-break-before: always; }\n"
    "ol.keylist { columns: 2; column-gap: 2em; padding-left: 1.6em; }\n"
    "ol.keylist li { break-inside: avoid; margin-bottom: 0.5em; }\n"
    "ol.keylist ul.facts { list-style: none; padding: 0; margin: 0; }\n"
    "ol.keylist ul.facts li { display: inline; margin: 0; }\n"
    "ol.keylist ul.facts li + li::before { content: '  \\00b7  '; color: #888; }\n"
    "footer { margin-top: 1.5em; font-size: 9pt; color: #777; border-top: 1px solid #ddd; padding-top: 0.4em; }\n"
    "@media print { body { margin: 0; max-width: none; } }\n"))

; Answer-space height (cm) by problem type.
(define (workHeightCm type)
    (cond ((memv type '(conic)) "6")
          ((memv type '(solve solveexp solvelog)) "3.5")
          ((memv type '(fracadd fracsub fracmul fracdiv)) "2.5")
          ('t "3")))

(define (answerHtml solution)
    (let ((facts (answerFacts solution)))
        (if (not facts)
            (mathToMathML solution)
            (string-append "<ul class=\"facts\">"
                (apply string-append
                    (map (lambda (f)
                             (string-append "<li>"
                                 (if (car f) (string-append "<span class=\"lab\">" (htmlEscape (car f)) ":</span> ") "")
                                 (mathToMathML (cdr f)) "</li>"))
                         facts))
                "</ul>"))))

(define (worksheetFooterHtml)
    (string-append "<footer>Generated " (currentTimestamp) " by PAE Bird"
        (if *current-worksheet-seed*
            (string-append " &middot; Worksheet code: " (number->string *current-worksheet-seed*))
            "")
        "</footer>\n"))

(define (worksheetHtmlPage title bodyHtml)
    (string-append
        "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
        "<title>" (htmlEscape title) "</title>\n"
        "<style>\n" worksheetCss "</style>\n"
        "</head>\n<body>\n" bodyHtml "</body>\n</html>\n"))

(define (worksheetHeaderHtml title difficulty student?)
    (string-append
        "<h1>" (htmlEscape title) "</h1>\n"
        "<p class=\"sub\">Difficulty: " (htmlEscape (difficultyDisplayName difficulty)) "</p>\n"
        (if student?
            (string-append
                "<div class=\"name-line\"><span>Name</span><span>Date</span><span>Class</span></div>\n"
                "<p class=\"instr\">Solve each problem. Show your work.</p>\n")
            "")))

(define (worksheetProblemsHtml items showAnswers?)
    (string-append "<ol class=\"problems\">\n"
        (apply string-append
            (map (lambda (item)
                     (string-append
                         "<li class=\"problem\"><span class=\"prompt\">" (htmlEscape (car item)) ":</span> "
                         (mathToMathML (cadr item)) "\n"
                         (if showAnswers?
                             (string-append "<div class=\"answer\"><span class=\"lab\">Answer:</span> " (answerHtml (caddr item)) "</div>\n")
                             (string-append "<div class=\"work\" style=\"height:" (workHeightCm (cadddr item)) "cm\"></div>\n"))
                         "</li>\n"))
                 items))
        "</ol>\n"))

(define (worksheetStudentHtml type difficulty items)
    (let ((title (typeDisplayName type)))
        (worksheetHtmlPage (string-append "Worksheet - " title)
            (string-append (worksheetHeaderHtml title difficulty #t)
                           (worksheetProblemsHtml items #f)
                           (worksheetFooterHtml)))))

; Teacher version: every problem with its answer inline, then a compact
; Answer Key on its own page (the part a teacher actually marks from).
(define (worksheetTeacherHtml type difficulty items)
    (let ((title (typeDisplayName type)))
        (worksheetHtmlPage (string-append "Teacher Copy - " title)
            (string-append
                (worksheetHeaderHtml (string-append title " (Teacher Copy)") difficulty #f)
                (worksheetProblemsHtml items #t)
                "<section class=\"key\">\n<h2>Answer Key</h2>\n<ol class=\"keylist\">\n"
                (apply string-append
                    (map (lambda (item) (string-append "<li>" (answerHtml (caddr item)) "</li>\n")) items))
                "</ol>\n</section>\n"
                (worksheetFooterHtml)))))

; ---- LaTeX output ----
; Matches C++'s generateLaTeXDocument: produces the .tex SOURCE only
; (C++'s exportToPDF shells out to an installed `pdflatex` binary, an
; external-tool dependency outside this engine's scope -- see the file
; header). Math is real TeX now (\frac, ^{}, \log_{}, \sqrt{}), ASCII-only,
; with the prompt word in text mode, not inside the math.

(define (answerTex solution)
    (let ((facts (answerFacts solution)))
        (if (not facts)
            (string-append "$" (mathToTeX (mathParse solution)) "$")
            (string-append "\n\\begin{itemize}\n"
                (apply string-append
                    (map (lambda (f)
                             (string-append "\\item "
                                 (if (car f) (string-append "\\textbf{" (texEscape (car f)) ":} ") "")
                                 "$" (mathToTeX (mathParse (cdr f))) "$\n"))
                         facts))
                "\\end{itemize}"))))

(define (worksheetTexString type difficulty items)
    (string-append
        "\\documentclass[11pt]{article}\n"
        "\\usepackage[margin=1in]{geometry}\n"
        "\\usepackage{amsmath,amssymb}\n"
        "\\title{" (texEscape (typeDisplayName type)) "}\n"
        "\\date{" (currentTimestamp) "}\n"
        "\\begin{document}\n\\maketitle\n"
        "\\noindent\\textbf{Difficulty:} " (texEscape (difficultyDisplayName difficulty))
        (if *current-worksheet-seed*
            (string-append " \\hfill \\textbf{Worksheet code:} " (number->string *current-worksheet-seed*))
            "")
        "\n\n\\begin{enumerate}\n"
        (apply string-append
            (map (lambda (item)
                     (string-append
                         "\\item \\textbf{" (texEscape (car item)) ":} $" (mathToTeX (mathParse (cadr item))) "$\n\n"
                         "\\textit{Solution:} " (answerTex (caddr item)) "\n\n"
                         "\\vspace{0.4cm}\n\n"))
                 items))
        "\\end{enumerate}\n\\end{document}\n"))

; Top-level entry point: generates a worksheet of the given type
; ('expand/'factor/'solve/'solveexp/'solvelog/'diff/'integ/'conic/'mixed/
; 'fracadd/'fracsub/'fracmul/'fracdiv/'fracmixed),
; difficulty ('easy/'medium/'hard/'mixed), and problem count, writing a
; STUDENT (problems only) and TEACHER (problems + solutions) file in
; CSV and HTML, plus one LaTeX .tex source, using baseFilename as a
; shared prefix. The five file names are a contract with the Mac app
; (PolyProcessor.mm reads _STUDENT/_TEACHER .csv/.html and deletes all
; five) -- change contents freely, never the names. Returns the problem
; set as (problem . solution) Unicode pairs.
(define (generateWorksheet type difficulty count baseFilename)
    (let* ((items (generateWorksheetItems type difficulty count))
           (pairs (map itemToUnicodePair items)))
        (writeStringToFile (string-append baseFilename "_STUDENT.csv") (worksheetCsvString pairs #f))
        (writeStringToFile (string-append baseFilename "_TEACHER.csv") (worksheetCsvString pairs #t))
        (writeStringToFile (string-append baseFilename "_STUDENT.html") (worksheetStudentHtml type difficulty items))
        (writeStringToFile (string-append baseFilename "_TEACHER.html") (worksheetTeacherHtml type difficulty items))
        (writeStringToFile (string-append baseFilename ".tex") (worksheetTexString type difficulty items))
        pairs))
