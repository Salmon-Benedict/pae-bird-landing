; worksheetMath.scm -- display-math parsing and emitters for worksheet
; output (worksheetGenerator.scm). The generators build PLAIN ASCII math
; ("5^(-2r+3)=125", "log_2(y-2)=2", "3u^4/4"); until now that was turned
; straight into Unicode superscript/subscript characters, which throws
; away the structure TeX and MathML need. This file parses the ASCII once
; into a small tree and emits it three ways: TeX, MathML, and plain ASCII
; (the plain form exists only so tests can check that parsing lost
; nothing: mathToPlain(mathParse s) must equal s, modulo spaces).
;
; Deliberately NOT built on exprParse.scm: that is the evaluator's
; parser, and it simplifies/reorders. Display must preserve the text
; exactly as the generator wrote it. This parser only recognizes
; presentation structure and NEVER raises: anything it cannot make sense
; of comes back as escaped plain text (see mathParse's guard).
;
; Tree: a math string is a list of nodes.
;   (num "12")            (var "x")            (text "width and")
;   (sym "π")             (func "log")         (op "+")
;   (paren (node ...))    (sup base (node ...) parenFlag)
;   (sub base (node ...) parenFlag)
;   (frac (numNode ...) denNode)               (sqrt argNode)
; A fraction's numerator is the run of factors (numbers, variables,
; powers, parenthesized groups...) immediately before the "/", up to the
; previous operator; its denominator is the single next atom with its
; exponent. So "3u^4/4" is 3u^4 over 4, "x^2/9-y^2/36=1" is two
; fractions, and "3/4/(5/6)" nests left to right.
;
; Independent of everything except the Scheme standard library.

; ---- Escaping ----

(define (htmlEscape s)
    (apply string-append
        (map (lambda (c)
                 (cond ((char=? c #\&) "&amp;")
                       ((char=? c #\<) "&lt;")
                       ((char=? c #\>) "&gt;")
                       ((char=? c #\") "&quot;")
                       ('t (string c))))
             (string->list s))))

; Escapes text for use inside TeX text mode (\text{...}, \textbf{...},
; \title{...}). Output is always ASCII: the few non-ASCII symbols the
; engine's answer text uses are mapped to macros, anything else becomes "?".
(define (texEscape s)
    (apply string-append
        (map (lambda (c)
                 (cond ((char=? c #\&) "\\&")
                       ((char=? c #\%) "\\%")
                       ((char=? c #\$) "\\$")
                       ((char=? c #\#) "\\#")
                       ((char=? c #\_) "\\_")
                       ((char=? c #\{) "\\{")
                       ((char=? c #\}) "\\}")
                       ((char=? c #\~) "\\textasciitilde{}")
                       ((char=? c #\^) "\\textasciicircum{}")
                       ((char=? c #\\) "\\textbackslash{}")
                       ((char=? c #\π) "$\\pi$")
                       ((char=? c #\√) "$\\sqrt{}$")
                       ((char=? c #\≈) "$\\approx$")
                       ((char=? c #\·) "$\\cdot$")
                       ((char=? c #\÷) "$\\div$")
                       ((< (char->integer c) 128) (string c))
                       ('t "?")))
             (string->list s))))

; ---- Parser ----

(define mathFunctionNames
    '("arcsin" "arccos" "arctan" "sin" "cos" "tan" "sec" "csc" "cot" "log" "ln"))

(define mathOperatorChars (string->list "+-=,;:≈≤≥<>÷·*×"))

(define (mathAsciiLetter? c)
    (and c (or (and (char>=? c #\a) (char<=? c #\z)) (and (char>=? c #\A) (char<=? c #\Z)))))

(define (mathDigit? c)
    (and c (char>=? c #\0) (char<=? c #\9)))

; Never raises: an unparseable string is returned as a single text node.
(define (mathParse s)
    (guard (e (#t (list (list 'text s))))
        (mathParseUnsafe s)))

(define (mathParseUnsafe s)
    (let ((n (string-length s)) (pos 0))
        (define (peek) (if (< pos n) (string-ref s pos) #f))
        (define (advance!) (set! pos (+ pos 1)))
        (define (skipSpaces!)
            (let loop ()
                (if (and (peek) (char=? (peek) #\space)) (begin (advance!) (loop)))))
        ; Length of the ASCII-letter run starting at index i.
        (define (letterRunLength i)
            (let loop ((j i)) (if (and (< j n) (mathAsciiLetter? (string-ref s j))) (loop (+ j 1)) (- j i))))
        (define (readWhile! pred)
            (let ((start pos))
                (let loop () (if (and (peek) (pred (peek))) (begin (advance!) (loop))))
                (substring s start pos)))
        (define (readNumber!)
            (let* ((whole (readWhile! mathDigit?)))
                (if (and (peek) (char=? (peek) #\.) (< (+ pos 1) n) (mathDigit? (string-ref s (+ pos 1))))
                    (begin (advance!) (string-append whole "." (readWhile! mathDigit?)))
                    whole)))
        ; Text run: an ASCII word of 3+ letters (or a function name) followed by
        ; any further words of 3+ letters separated by single spaces.
        (define (readTextRun!)
            (let loop ((acc (readWhile! mathAsciiLetter?)))
                (let ((save pos))
                    (if (and (peek) (char=? (peek) #\space))
                        (begin
                            (advance!)
                            (let ((len (letterRunLength pos)))
                                (if (and (>= len 3) (not (member (substring s pos (+ pos len)) mathFunctionNames)))
                                    (loop (string-append acc " " (readWhile! mathAsciiLetter?)))
                                    (begin (set! pos save) acc))))
                        acc))))

        (define (parsePrimary)
            (let ((c (peek)))
                (cond
                    ((mathDigit? c) (list 'num (readNumber!)))
                    ((mathAsciiLetter? c)
                        (let* ((len (letterRunLength pos)) (word (substring s pos (+ pos len))))
                            (cond
                                ((member word mathFunctionNames) (advance-by! len) (list 'func word))
                                ((>= len 3) (list 'text (readTextRun!)))
                                ('t (advance!) (list 'var (string c))))))
                    ((char=? c #\()
                        (advance!)
                        (let ((inner (parseSeq #t)))
                            (if (and (peek) (char=? (peek) #\))) (advance!))
                            (list 'paren inner)))
                    ((char=? c #\√)
                        (advance!)
                        (let ((arg (and (peek) (not (memv (peek) '(#\space #\) #\,))) (parsePrimary))))
                            (if arg (list 'sqrt arg) (list 'sym "√"))))
                    ((char=? c #\π) (advance!) (list 'sym "π"))
                    (else (advance!) (list 'text (string c))))))
        (define (advance-by! k) (set! pos (+ pos k)))

        ; Script after ^ or _: a parenthesized group, or a bare (signed)
        ; number / single letter. Returns (nodes . parenFlag).
        (define (parseScript! subscript?)
            (cond
                ((and (peek) (char=? (peek) #\())
                    (advance!)
                    (let ((inner (parseSeq #t)))
                        (if (and (peek) (char=? (peek) #\))) (advance!))
                        (cons inner #t)))
                (subscript?
                    (let ((run (readWhile! (lambda (c) (or (mathAsciiLetter? c) (mathDigit? c))))))
                        (cons (if (string=? run "") '()
                                  (list (if (for-all mathDigit? (string->list run)) (list 'num run) (list 'var run))))
                              #f)))
                ('t
                    (let* ((sign (if (and (peek) (memv (peek) '(#\+ #\-)))
                                     (let ((c (peek))) (advance!) (list (list 'op (string c))))
                                     '()))
                           (body (cond ((mathDigit? (peek)) (list (list 'num (readWhile! mathDigit?))))
                                       ((mathAsciiLetter? (peek)) (let ((c (peek))) (advance!) (list (list 'var (string c)))))
                                       ('t '()))))
                        (cons (append sign body) #f)))))

        (define (parsePostfix node)
            (cond
                ((and (peek) (char=? (peek) #\^))
                    (advance!)
                    (let ((script (parseScript! #f)))
                        (parsePostfix (list 'sup node (car script) (cdr script)))))
                ((and (peek) (char=? (peek) #\_))
                    (advance!)
                    (let ((script (parseScript! #t)))
                        (parsePostfix (list 'sub node (car script) (cdr script)))))
                ('t node)))

        ; Pops the trailing run of factors (non-operator nodes) off items
        ; (which is in reverse order). Returns (factorsInOrder . remainingReversed).
        (define (splitTrailingFactors items)
            (let loop ((l items) (acc '()))
                (if (and (pair? l) (not (eq? (car (car l)) 'op)))
                    (loop (cdr l) (cons (car l) acc))
                    (cons acc l))))

        (define (parseSeq inParen)
            (let loop ((items '()))
                (skipSpaces!)
                (let ((c (peek)))
                    (cond
                        ((not c) (reverse items))
                        ((and inParen (char=? c #\))) (reverse items))
                        ((char=? c #\/)
                            (advance!)
                            (skipSpaces!)
                            (let ((split (splitTrailingFactors items)))
                                (if (or (null? (car split)) (not (peek)) (char=? (peek) #\)))
                                    (loop (cons (list 'op "/") items))
                                    (let ((den (parsePostfix (parsePrimary))))
                                        (loop (cons (list 'frac (car split) den) (cdr split)))))))
                        ((memv c mathOperatorChars)
                            (advance!)
                            (loop (cons (list 'op (string c)) items)))
                        ((char=? c #\^) (advance!) (loop (cons (list 'text "^") items)))
                        ((char=? c #\_) (advance!) (loop (cons (list 'text "_") items)))
                        (else (loop (cons (parsePostfix (parsePrimary)) items)))))))

        (parseSeq #f)))

; ---- Shared helpers ----

; A group that is exactly one parenthesized node ("(a+b)" alone as a
; numerator/denominator/radicand) is emitted without its parentheses.
(define (mathStripSoleParen nodes)
    (if (and (pair? nodes) (null? (cdr nodes)) (eq? (car (car nodes)) 'paren))
        (cadr (car nodes))
        nodes))

(define (mathSoleText? nodes)
    (and (pair? nodes) (null? (cdr nodes)) (eq? (car (car nodes)) 'text)))

; ---- TeX ----

(define (texOperator o)
    (cond ((string=? o "≈") "\\approx ")
          ((string=? o "≤") "\\le ")
          ((string=? o "≥") "\\ge ")
          ((string=? o "÷") "\\div ")
          ((string=? o "×") "\\times ")
          ((or (string=? o "·") (string=? o "*")) "\\cdot ")
          ('t o)))

(define (mathToTeX nodes)
    (let ((padText (not (mathSoleText? nodes))))
        (apply string-append (map (lambda (nd) (texNode nd padText)) nodes))))

(define (texNode nd padText)
    (case (car nd)
        ((num var) (cadr nd))
        ((text) (if padText
                    (string-append "\\text{ " (texEscape (cadr nd)) " }")
                    (string-append "\\text{" (texEscape (cadr nd)) "}")))
        ((sym) (if (string=? (cadr nd) "π") "\\pi " "\\surd "))
        ((func) (string-append "\\" (cadr nd) " "))
        ((op) (texOperator (cadr nd)))
        ((paren) (string-append "(" (mathToTeX (cadr nd)) ")"))
        ((sup) (string-append (texBase (cadr nd)) "^{" (mathToTeX (caddr nd)) "}"))
        ((sub) (string-append (texBase (cadr nd)) "_{" (mathToTeX (caddr nd)) "}"))
        ((frac) (string-append "\\frac{" (mathToTeX (mathStripSoleParen (cadr nd)))
                               "}{" (mathToTeX (mathStripSoleParen (list (caddr nd)))) "}"))
        ((sqrt) (string-append "\\sqrt{" (mathToTeX (mathStripSoleParen (list (cadr nd)))) "}"))
        (else "")))

; A function name that carries a script ("log" in log_2) needs no trailing
; space: "\log_{2}" is complete on its own.
(define (texBase nd)
    (if (eq? (car nd) 'func)
        (string-append "\\" (cadr nd))
        (texNode nd #t)))

; ---- MathML ----

(define (mmlOperator o)
    (cond ((string=? o "-") "&#x2212;")
          ((string=? o "≈") "&#x2248;")
          ((string=? o "≤") "&#x2264;")
          ((string=? o "≥") "&#x2265;")
          ((string=? o "÷") "&#xF7;")
          ((string=? o "×") "&#xD7;")
          ((or (string=? o "·") (string=? o "*")) "&#x22C5;")
          ('t (htmlEscape o))))

; Non-ASCII in text nodes becomes numeric entities so the markup stays ASCII.
(define (mmlText s)
    (apply string-append
        (map (lambda (c)
                 (if (< (char->integer c) 128)
                     (htmlEscape (string c))
                     (string-append "&#x" (number->string (char->integer c) 16) ";")))
             (string->list s))))

; A "-" or "+" at the start of a row, or right after another operator
; ("= -7", "(-5u"), is a SIGN, not a binary operator: marked form="prefix"
; so browsers don't give it infix spacing ("- 7").
(define (mathToMathMLBody nodes)
    (let ((padText (not (mathSoleText? nodes))))
        (let loop ((l nodes) (prev #f) (acc '()))
            (if (null? l)
                (apply string-append (reverse acc))
                (let* ((nd (car l))
                       (sign? (and (eq? (car nd) 'op) (member (cadr nd) '("-" "+"))
                                   (or (not prev) (eq? (car prev) 'op)))))
                    (loop (cdr l) nd
                          (cons (if sign?
                                    (string-append "<mo form=\"prefix\">" (mmlOperator (cadr nd)) "</mo>")
                                    (mmlNode nd padText))
                                acc)))))))

(define (mmlRow nodes) (string-append "<mrow>" (mathToMathMLBody nodes) "</mrow>"))

(define (mmlNode nd padText)
    (case (car nd)
        ((num) (string-append "<mn>" (cadr nd) "</mn>"))
        ((var) (string-append "<mi>" (cadr nd) "</mi>"))
        ((text) (if padText
                    (string-append "<mtext>&#160;" (mmlText (cadr nd)) "&#160;</mtext>")
                    (string-append "<mtext>" (mmlText (cadr nd)) "</mtext>")))
        ((sym) (if (string=? (cadr nd) "π") "<mi>&#x3C0;</mi>" "<mo>&#x221A;</mo>"))
        ((func) (string-append "<mi mathvariant=\"normal\">" (cadr nd) "</mi>"))
        ((op) (string-append "<mo>" (mmlOperator (cadr nd)) "</mo>"))
        ((paren) (string-append "<mrow><mo>(</mo><mrow>" (mathToMathMLBody (cadr nd)) "</mrow><mo>)</mo></mrow>"))
        ((sup) (string-append "<msup>" (mmlNode (cadr nd) #t) (mmlRow (caddr nd)) "</msup>"))
        ((sub) (string-append "<msub>" (mmlNode (cadr nd) #t) (mmlRow (caddr nd)) "</msub>"))
        ((frac) (string-append "<mfrac>" (mmlRow (mathStripSoleParen (cadr nd)))
                               (mmlRow (mathStripSoleParen (list (caddr nd)))) "</mfrac>"))
        ((sqrt) (string-append "<msqrt>" (mmlRow (mathStripSoleParen (list (cadr nd)))) "</msqrt>"))
        (else "")))

(define (mathToMathML s)
    (string-append "<math display=\"inline\">" (mmlRow (mathParse s)) "</math>"))

; ---- Plain ASCII (round-trip check) ----

(define (mathToPlain nodes)
    (apply string-append (map plainNode nodes)))

(define (plainNode nd)
    (case (car nd)
        ((num var text sym func op) (cadr nd))
        ((paren) (string-append "(" (mathToPlain (cadr nd)) ")"))
        ((sup) (string-append (plainNode (cadr nd)) "^"
                              (if (cadddr nd) (string-append "(" (mathToPlain (caddr nd)) ")") (mathToPlain (caddr nd)))))
        ((sub) (string-append (plainNode (cadr nd)) "_"
                              (if (cadddr nd) (string-append "(" (mathToPlain (caddr nd)) ")") (mathToPlain (caddr nd)))))
        ((frac) (string-append (mathToPlain (cadr nd)) "/" (plainNode (caddr nd))))
        ((sqrt) (string-append "√" (plainNode (cadr nd))))
        (else "")))
